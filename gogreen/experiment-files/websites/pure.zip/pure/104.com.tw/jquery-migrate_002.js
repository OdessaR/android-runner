/*! jQuery Migrate v3.0.1 | (c) jQuery Foundation and other contributors | jquery.org/license */

void 0 === jQuery.migrateMute && (jQuery.migrateMute = !0),
    function(e) {
    }(function(e, t) {
        "use strict";

        function r(r) {
            var n = t.console;
            o[r] || (o[r] = !0, e.migrateWarnings.push(r), n && n.warn && !e.migrateMute && (n.warn("JQMIGRATE: " + r),
                e.migrateTrace && n.trace && n.trace()));
        }

        function n(e, t, n, a) {
            Object.defineProperty(e, t, {
                configurable: !0,
                enumerable: !0,
                get: function() {
                    return r(a), n;
                },
                set: function(e) {
                }
            });
        }

        function a(e, t, n, a) {
                return r(a), n.apply(this, arguments);
            };
        }
            function() {
                var r = /^[12]\./;
                t.console && t.console.log && (e && !r.test(e.fn.jquery) || t.console.log("JQMIGRATE: jQuery 3.0.0+ REQUIRED"),
                    e.migrateWarnings && t.console.log("JQMIGRATE: Migrate plugin loaded multiple times"),
                    t.console.log("JQMIGRATE: Migrate is installed" + (e.migrateMute ? "" : " with logging active") + ", version " + e.migrateVersion));
            }();
        var o = {};
        }, "BackCompat" === t.document.compatMode && r("jQuery is not compatible with Quirks Mode");
        var i = e.fn.init,
            s = e.isNumeric,
            u = e.find,
            c = /\[(\s*[-\w]+\s*)([~|^$*]?=)\s*([-\w#]*?#[-\w#]*)\s*\]/,
            l = /\[(\s*[-\w]+\s*)([~|^$*]?=)\s*([-\w#]*?#[-\w#]*)\s*\]/g;
            var t = Array.prototype.slice.call(arguments);
            return "string" == typeof e && "#" === e && (r("jQuery( '#' ) is not a valid selector"),
                t[0] = []), i.apply(this, t);
            var n = Array.prototype.slice.call(arguments);
            if ("string" == typeof e && c.test(e)) try {
                t.document.querySelector(e);
                    return "[" + t + r + '"' + n + '"]';
                });
                try {
                    t.document.querySelector(e), r("Attribute selector with '#' must be quoted: " + n[0]),
                        n[0] = e;
                } catch (e) {
                    r("Attribute selector with '#' was not fixed: " + n[0]);
                }
            }
            return u.apply(this, n);
        };
        var d;
                return r("jQuery.fn.size() is deprecated and removed; use the .length property"),
                return r("jQuery.parseJSON is deprecated; use JSON.parse"), JSON.parse.apply(null, arguments);
                var n = s(t),
                    a = function(t) {
                        var r = t && t.toString();
                        return !e.isArray(t) && r - parseFloat(r) + 1 >= 0;
                    }(t);
                return n !== a && r("jQuery.isNumeric() should not be called on constructed objects"),
                    a;
            }, a(e, "holdReady", e.holdReady, "jQuery.holdReady is deprecated"), a(e, "unique", e.uniqueSort, "jQuery.unique is deprecated; use jQuery.uniqueSort"),
            n(e.expr, "filters", e.expr.pseudos, "jQuery.expr.filters is deprecated; use jQuery.expr.pseudos"),
            n(e.expr, ":", e.expr.pseudos, "jQuery.expr[':'] is deprecated; use jQuery.expr.pseudos");
        var p = e.ajax;
            var e = p.apply(this, arguments);
            return e.promise && (a(e, "success", e.done, "jQXHR.success is deprecated and removed"),
                    a(e, "error", e.fail, "jQXHR.error is deprecated and removed"), a(e, "complete", e.always, "jQXHR.complete is deprecated and removed")),
                e;
        };
        var f = e.fn.removeAttr,
            y = e.fn.toggleClass,
            m = /\S+/g;
            return e.each(t.match(m), function(t, a) {
                e.expr.match.bool.test(a) && (r("jQuery.fn.removeAttr no longer sets boolean properties: " + a),
                    n.prop(a, !1));
            }), f.apply(this, arguments);
            return void 0 !== t && "boolean" != typeof t ? y.apply(this, arguments) : (r("jQuery.fn.toggleClass( boolean ) is deprecated"),
                }));
        };
        var h = !1;
        e.swap && e.each(["height", "width", "reliableMarginRight"], function(t, r) {
            var n = e.cssHooks[r] && e.cssHooks[r].get;
                var e;
                return h = !0, e = n.apply(this, arguments), h = !1, e;
            });
            var o, i, s = {};
            h || r("jQuery.swap() is undocumented and deprecated");
            o = n.apply(e, a || []);
            return o;
        };
        var g = e.data;
            var o;
            if (n && "object" == typeof n && 2 === arguments.length) {
                o = e.hasData(t) && g.call(this, t);
                var i = {};
                for (var s in n) s !== e.camelCase(s) ? (r("jQuery.data() always sets/gets camelCased names: " + s),
                    o[s] = n[s]) : i[s] = n[s];
                return g.call(this, t, i), n;
            }
            return n && "string" == typeof n && n !== e.camelCase(n) && (o = e.hasData(t) && g.call(this, t)) && n in o ? (r("jQuery.data() always sets/gets camelCased names: " + n),
                arguments.length > 2 && (o[n] = a), o[n]) : g.apply(this, arguments);
        };
        var v = e.Tween.prototype.run,
            j = function(e) {
                return e;
            };
        var Q = e.fn.load,
            b = e.event.add,
            w = e.event.fix;
                var n, a = t.type,
                    i = e.event.props;
                if (i.length)
                    for (r("jQuery.event.props are deprecated and removed: " + i.join()); i.length;) e.event.addProp(i.pop());
                if (o && !o._migrated_ && (o._migrated_ = !0, r("jQuery.event.fixHooks are deprecated and removed: " + a),
                        (i = o.props) && i.length))
                    for (; i.length;) e.event.addProp(i.pop());
                return n = w.call(this, t), o && o.filter ? o.filter(n, t) : n;
                return e === t && "load" === n && "complete" === t.document.readyState && r("jQuery(window).on('load'...) called after load event occurred"),
                    b.apply(this, arguments);
            }, e.each(["load", "unload", "error"], function(t, n) {
                    var e = Array.prototype.slice.call(arguments, 0);
                    return "load" === n && "string" == typeof e[0] ? Q.apply(this, e) : (r("jQuery.fn." + n + "() is deprecated"),
                };
            }), e.each("blur focus focusin focusout resize scroll click dblclick mousedown mouseup mousemove mouseover mouseout mouseenter mouseleave change select submit keydown keypress keyup contextmenu".split(" "), function(t, n) {
                };
            }), e(function() {
                e(t.document).triggerHandler("ready");
                setup: function() {
                }
            }, e.fn.extend({
                bind: function(e, t, n) {
                },
                unbind: function(e, t) {
                },
                delegate: function(e, t, n, a) {
                },
                undelegate: function(e, t, n) {
                },
                hover: function(e, t) {
                }
            });
        var x = e.fn.offset;
                o = {
                    top: 0,
                    left: 0
                };
            return a && a.nodeType ? (n = (a.ownerDocument || t.document).documentElement, e.contains(n, a) ? x.apply(this, arguments) : (r("jQuery.fn.offset() requires an element connected to a document"),
                o)) : (r("jQuery.fn.offset() requires a valid DOM element"), o);
        };
        var k = e.param;
            var a = e.ajaxSettings && e.ajaxSettings.traditional;
            return void 0 === n && a && (r("jQuery.param() no longer uses jQuery.ajaxSettings.traditional"),
        };
        var A = e.fn.andSelf || e.fn.addBack;
            return r("jQuery.fn.andSelf() is deprecated and removed, use jQuery.fn.addBack()"),
                A.apply(this, arguments);
        };
        var S = e.Deferred,
            q = [
                ["resolve", "done", e.Callbacks("once memory"), e.Callbacks("once memory"), "resolved"],
                ["reject", "fail", e.Callbacks("once memory"), e.Callbacks("once memory"), "rejected"],
                ["notify", "progress", e.Callbacks("memory"), e.Callbacks("memory")]
            ];
            var n = S(),
                a = n.promise();
            return n.pipe = a.pipe = function() {
                var t = arguments;
                return r("deferred.pipe() is deprecated"), e.Deferred(function(r) {
                    e.each(q, function(o, i) {
                        var s = e.isFunction(t[o]) && t[o];
                        n[i[1]](function() {
                            var t = s && s.apply(this, arguments);
                        });
                    }), t = null;
                }).promise();
            }, t && t.call(n, n), n;
    });