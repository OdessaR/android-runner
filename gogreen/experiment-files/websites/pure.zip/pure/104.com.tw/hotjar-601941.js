window.hjSiteSettings = window.hjSiteSettings || {
    "site_id": 601941,
    "r": 0.05998643270502645,
    "rec_value": 1.0,
    "state_change_listen_mode": "automatic_with_fragments",
    "record": false,
    "continuous_capture_enabled": false,
    "recording_capture_keystrokes": true,
    "anonymize_digits": false,
    "anonymize_emails": false,
    "suppress_all": false,
    "suppress_text": null,
    "suppress_location": false,
    "user_attributes_enabled": false,
    "legal_name": null,
    "privacy_policy_url": null,
    "deferred_page_contents": [{
        "id": 18182662,
        "targeting": [{
            "component": "url",
            "match_operation": "simple",
            "pattern": "https://www.104.com.tw/area/freshman/book/resume",
            "negate": false
        }, {
            "component": "device",
            "match_operation": "exact",
            "pattern": "desktop",
            "negate": false
        }]
    }, {
        "id": 18182661,
        "targeting": [{
            "component": "url",
            "match_operation": "simple",
            "pattern": "https://www.104.com.tw/area/freshman/book/resume",
            "negate": false
        }, {
            "component": "device",
            "match_operation": "exact",
            "pattern": "tablet",
            "negate": false
        }]
    }, {
        "id": 18182660,
        "targeting": [{
            "component": "url",
            "match_operation": "simple",
            "pattern": "https://www.104.com.tw/area/freshman/book/resume",
            "negate": false
        }, {
            "component": "device",
            "match_operation": "exact",
            "pattern": "phone",
            "negate": false
        }]
    }],
    "record_targeting_rules": [],
    "feedback_widgets": [],
    "forms": [],
    "heatmaps": [{
        "id": 5760798,
        "created_epoch_time": 1586500308,
        "targeting": [{
            "component": "url",
            "match_operation": "simple",
            "pattern": "https://www.104.com.tw/area/freshman/book/resume",
            "negate": false
        }],
        "selector_version": 2,
        "capture_type": "SNAPSHOT_1000"
    }],
    "polls": [],
    "integrations": {
        "optimizely": {
            "tag_recordings": false
        }
    },
    "features": ["settings.billing_v2", "recordings.page_content_ws"]
};

! function(e) {
    var t = {};

    function n(o) {
        if (t[o]) return t[o].exports;
        var r = t[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return e[o].call(r.exports, r, r.exports, n), r.l = !0, r.exports
    }
            enumerable: !0,
            get: o
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var o = Object.create(null);
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
                return e[t]
            }.bind(null, r));
        return o
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return Object.prototype.hasOwnProperty.call(e, t)
}({
    251: function(e, t) {
            var o = ["bot", "headless", "google", "baidu", "bing", "msn", "duckduckbot", "teoma", "slurp", "yandex", "phantomjs", "pingdom", "ahrefsbot"].join("|"),
                r = new RegExp(o, "i"),
                    userAgent: "unknown"
                },
                i = a.userAgent ? a.userAgent : "unknown";
            else {
                var d = function(e, t, n) {
                };
                d(0, 0, n);
                    f = p.head || p.getElementsByTagName("head")[0];
            }

            function h() {
                setTimeout((function() {
                }), 50)
            }
    }
});
//# sourceMappingURL=hotjar.js.map