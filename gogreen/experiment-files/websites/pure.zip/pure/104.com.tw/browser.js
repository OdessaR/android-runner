! function(e, r, t) {
        var e = !1,
            t = !1,
            o = !1,
            n = !1,
            i = "",
            a = function(e) {
                e = e.toLowerCase();
                var r = /(opr)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(opera)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(edge)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(chrome)[ \/]([\w.]+)/.exec(e) || /(webkit)(?:.*version|)[ \/]([\w.]+)/.exec(e) || /(msie) ([\w.]+)/.exec(e) || e.indexOf("trident") > 0 && /(rv)(?:.*version|)[ \:]([\w.]+)/.exec(e) || e.indexOf("compatible") < 0 && e.indexOf("trident") < 0 && /(mozilla)(?:.*? rv:([\w.]+)|)/.exec(e) || [];
                return {
                    browser: r[1] || "",
                    version: r[2] || "0"
                }
            },
            p = function() {
                return a(r).version
            },
            d = function(e) {
                return a(r).browser === e
            },
            l = {
                opera: d("opr") || d("opera"),
                ie: d("msie") || d("rv"),
                edge: d("edge"),
                firefox: d("mozilla"),
                safari: d("webkit"),
                chrome: d("chrome"),
            },
            s = function(e) {
            },
            c = function(e, r) {
                for (var t in r) e.style[t] = r[t]
            },
            m = function(e, r) {
                for (var t in r) e.setAttribute(t, r[t])
            },
            f = function(e, r) {
                var t;
                t = 736 === r ? "40px 20px 10px" : "40px 17px 10px", 1024 === r ? c(e, {
                    maxWidth: "960px",
                    margin: "0 auto",
                    padding: "5px 20px 10px",
                    textAlign: "center",
                    overflow: "hidden",
                    display: "block"
                }) : c(e, {
                    maxWidth: "960px",
                    margin: "0 auto",
                    padding: t,
                    textAlign: "center",
                    display: "block"
                })
            },
            u = function(e, r, t) {
                var o;
                c(e, {
                    position: o = 1024 === o ? "fixed" : "absolute",
                    zIndex: "10000",
                    left: "0",
                    top: parseInt(t.fixedHeight.replace(/px/gi, "")) + "px"
                })
            },
            g = function(e, r) {
                var t;
                t = r >= 414 ? 480 === r ? "45%" : "44%" : "42%", r >= 736 ? c(e, {
                    margin: "10px",
                    textDecoration: "none",
                    styleFloat: "left",
                    "float": "left",
                    color: "#000",
                    fontSize: "14px"
                }) : c(e, {
                    margin: "10px",
                    textDecoration: "none",
                    styleFloat: "left",
                    "float": "left",
                    color: "#000",
                    fontSize: "13px",
                    display: "block",
                    width: t
                })
            },
            h = function(e) {
            },
            w = function(e, r, t, o, n) {
                i <= 360 ? (r && f(r, 360), t && u(t, 360, e), o && g(o, 360)) : i <= 414 ? (r && f(r, 414), t && u(t, 414, e), o && g(o, 414)) : i <= 480 ? (r && f(r, 480), t && u(t, 480, e), o && g(o, 480)) : i <= 736 ? (r && f(r, 736), t && u(t, 736, e), o && g(o, 736)) : (r && f(r, 1024), t && u(t, 1024, e), o && g(o, 1024))
            },
            x = function(r) {
                    i = s("div");
                w("", i);
                var a = s("div");
                c(a, {
                    margin: "20px auto 0",
                    maxWidth: "520px",
                    overflow: "hidden"
                });
                var p = s("br"),
                    d = s("br"),
                    l = s("br"),
                    f = s("br"),
                    u = s("a");
                m(u, {
                    href: "https://support.microsoft.com/zh-tw/help/17621/internet-explorer-downloads",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    title: "Internet Explorer"
                }), w("", "", "", u);
                var g = s("img");
                m(g, {
                    title: "Internet Explorer",
                    alt: "Internet Explorer",
                    src: "https://static.104.com.tw/104main/common/ie11.png",
                    width: 100,
                    height: 100
                }), c(g, {
                    border: 0
                });
                var x = o.createTextNode("Internet Explorer");
                u.appendChild(g), u.appendChild(p), u.appendChild(x);
                var b = s("a");
                m(b, {
                    href: "https://www.google.com.tw/chrome/browser/desktop/index.html",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    title: "Chrome"
                }), w("", "", "", b);
                var v = s("img");
                m(v, {
                    title: "Chrome",
                    alt: "Chrome",
                    src: "https://static.104.com.tw/104main/common/chrome.png",
                    width: 101,
                    height: 100
                }), c(v, {
                    border: 0
                });
                var C = o.createTextNode("Chrome");
                b.appendChild(v), b.appendChild(d), b.appendChild(C);
                var y = s("a");
                m(y, {
                    href: "https://www.apple.com/tw/safari/",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    title: "Safari"
                }), w("", "", "", y);
                var I = s("img");
                m(I, {
                    title: "Safari",
                    alt: "Safari",
                    src: "https://static.104.com.tw/104main/common/safari.png",
                    width: 100,
                    height: 100
                }), c(I, {
                    border: 0
                });
                var A = o.createTextNode("Safari");
                y.appendChild(I), y.appendChild(l), y.appendChild(A);
                var B = s("a");
                m(B, {
                    href: "https://www.mozilla.org/zh-TW/firefox/new/",
                    target: "_blank",
                    rel: "noopener noreferrer",
                    title: "Firefox"
                }), w("", "", "", B);
                var k = s("img");
                m(k, {
                    title: "Firefox",
                    alt: "Firefox",
                    src: "https://static.104.com.tw/104main/common/firefox.png",
                    width: 107,
                    height: 100
                }), c(k, {
                    border: 0
                });
                var S = o.createTextNode("Firefox");
                B.appendChild(k), B.appendChild(f), B.appendChild(S), t || a.appendChild(u), a.appendChild(b), (!t || t && n) && a.appendChild(y), a.appendChild(B);
                var E = s("p"),
                        return "\u89aa\u611b\u7684\u4f7f\u7528\u8005\uff0c\u70ba\u4e86\u60a8\u7684\u8cc7\u6599\u5b89\u5168\u53ca\u66f4\u597d\u7684\u4f7f\u7528\u9ad4\u9a57\uff0c\u5f9e " + e.date + " \u8d77\uff0c\u6211\u5011\u5c07\u4e0d\u518d\u652f\u63f4 " + e.browserVersion + " (\u542b)\u4ee5\u4e0b\u7684\u700f\u89bd\u5668\uff0c\u5efa\u8b70\u60a8\u9ede\u9078\u4e0b\u9762\u9023\u7d50\u76e1\u5feb\u5347\u7d1a\u5b89\u88dd\u4ee5\u4e0b\u700f\u89bd\u5668"
                    }(r));
                ! function(e) {
                    c(e, {
                        fontSize: "19px",
                        color: "#c74708",
                        fontWeight: "bold",
                        marginTop: "5px",
                        lineHeight: "1.5",
                        marginBottom: "5px"
                    })
                }(E), E.appendChild(F), i.appendChild(E), i.appendChild(a);
                var j = s("div");
                m(j, {
                    id: "bsOverlay"
                }), c(j, {
                    background: "#eee",
                    borderTop: "1px solid #ccc",
                    borderBottom: "1px solid #ccc",
                    fontFamily: "Arial, sans-serif",
                    width: "100%",
                    letterSpacing: "1px",
                    lineHeight: "1.5",
                    textAlign: "center",
                    display: "block"
                });
                var z = s("span");
                m(z, {
                    title: "\u95dc\u9589"
                }), c(z, {
                    styleFloat: "right",
                    "float": "right",
                    marginRight: "20px",
                    marginTop: "10px",
                    cursor: "pointer"
                }), z.onclick = function() {
                    r.closeFun && h(r.closeFun), r.appendId && o.getElementById(r.appendId) ? o.getElementById(r.appendId).removeChild(j) : o.body.removeChild(j)
                };
                var T = s("img");
                if (m(T, {
                        src: "https://static.104.com.tw/104main/common/browser-close.png",
                        title: "\u95dc\u9589"
                    }), c(T, {
                        verticalAlign: "middle",
                        width: "30px"
                    }), z.appendChild(T), r.fixedHeight && w(r, "", j), j.appendChild(z), j.appendChild(i), o.body && !e)
                    if (e = !0, r.appendId && o.getElementById(r.appendId)) o.getElementById(r.appendId).appendChild(j);
                    else {
                        var O = o.body.firstChild;
                        o.body.insertBefore(j, O)
                    }
            },
            b = function() {
                return t
            },
            v = function(e) {
                var r = p();
                e.fixedHeight && e.fixedHeight;
                if (! function(e) {
                        if (!(e && e.support && e.lowest && e.date && e.browserVersion)) return !1;
                        return !0
                for (var i = 0; i < e.support.length; i++)
                    if (e.support[i] && e.lowest[i] && (l.mobileDevice && (t = !0), l.android && (o = !0), l.ios && (n = !0), l[e.support[i]] && parseInt(r) <= parseInt(e.lowest[i]))) return x(e), "\u6210\u529f\u57f7\u884chtmlRender"
            };
        return {
            init: function(e) {
                    return function(e) {
                            t = r ? b() : "";
                    }(e), "\u6210\u529f\u57f7\u884cinit"
                }
            },
            userAgentMatch: a,
            getVersion: p,
            getBrowser: d,
            getSrcVars: b,
            run: v,
            closeFun: h,
            browserSupportStatusLog: function() {
                var d = {
                    appendChildBody: e,
                    isMobileDevice: t,
                    isAndroid: o,
                    isIOS: n,
                    userAgent: r,
                    browserData: i,
                    browserVersion: p(),
                    userAgentBrowser: a(r)
                };
            }
        }
    }
}(window, "commonBrowser104");