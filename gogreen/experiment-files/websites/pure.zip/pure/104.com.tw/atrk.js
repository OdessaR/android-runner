! function() {
    var t = {
        iu: "https://certify.alexametrics.com/atrk.gif?",
        ver: "20130128",
        opts: {
            atrk_acct: "",
            domain: "",
            dynamic: !1
        },
        opt_out_class: "__aoc",
        opted_out: function() {
            return "true" === t.gbc(t.opt_out_class)
        },
        opt_out_setup: function() {
                "function" == typeof n.preventDefault && n.preventDefault(), t.sbc(t.opt_out_class, "true", 31536e4)
                "function" == typeof n.preventDefault && n.preventDefault(), t.sbc(t.opt_out_class, "true", 1)
            })
        },
        register_opt_out_listener: function(t, n) {
                var o = e[r];
                "function" == typeof o.addEventListener ? o.addEventListener("click", n) : "function" == typeof o.attachEvent && o.attachEvent("onclick", n)
            }
        },
        fired: function() {
        },
        params: {
            frame_height: function() {
                return t.frame("innerHeight", "clientHeight")
            },
            frame_width: function() {
                return t.frame("innerWidth", "clientWidth")
            },
            iframe: function() {
                try {
                } catch (t) {
                    return 0
                }
            },
            title: function() {
            },
            time: function() {
                var t = new Date;
                return t.getTime() + "&time_zone_offset=" + t.getTimezoneOffset()
            },
            screen_params: function() {
                try {
                } catch (t) {}
                return ""
            },
            java_enabled: function() {
            },
            cookie_enabled: function() {
            },
            ref_url: function() {
            },
            host_url: function() {
            },
            random_number: function() {
                return Math.round(21474836747 * Math.random())
            },
            sess_cookie: function() {
                return t.gc("__asc", t.user_cookie_v, "sess_cookie", 1800)
            },
            user_cookie: function() {
                return t.gc("__auc", t.user_cookie_v, "user_cookie", 31622400)
            },
            dynamic: function() {
            },
            domain: function() {
            },
            account: function() {
            },
            jsv: function() {
            },
            user_lang: function() {
            }
        },
        frame: function(t, n) {
            try {
            } catch (t) {
                return "-"
            }
        },
        r: function() {
            return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
        },
        muc: function() {
        },
        gc: function(t, n, e, r) {
            var o = "",
                i = 0;
            try {
            } catch (t) {}
        },
        ue: function(t) {
            try {
                return encodeURIComponent(t)
                return escape(t)
            }
        },
        gbc: function(t) {
                r = t + "=",
                o = e.indexOf("; " + r);
            if (-1 == o) {
                if (0 != (o = e.indexOf(r))) return null
            } else o += 2;
        },
        sbc: function(t, n, e) {
            var r = new Date,
        },
        dom: function() {
            return "www." == t.substr(0, 4) ? t.substr(4) : t
        },
        gen_url: function() {
            try {
                    return n + "=" + e.call(t)
                }).join("&")
            } catch (t) {
            }
        },
        map: function(t, n) {
            var e = [];
            for (var r in t) t.hasOwnProperty(r) && e.push(n.call(this, r, t[r]));
            return e
        },
        cloudfront: {
            url: "http://cloudfront-labs.amazonaws.com/x.png",
            fire: function() {
            }
        },
        user_cookie_v: "",
        fire: function(t) {
            }
        }
    };
        t.fire(_atrk_opts)
}();