(window.webpackJsonp = window.webpackJsonp || []).push([
    [15], {
        476: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(1),
                a = n.n(i),
                s = n(5),
                c = n.n(s),
                r = n(4),
                d = n(781);
            c()(r.m).subscribe((function(e, t) {
                var n = a()(".recipe-button.print");
            })), c()(r.m).subscribe((function(e, t) {
                var n = a()(".recipe-content-toggle-section").find(".checkbox-list-input");
                Object(d.a)(t, n) && (! function(e) {
                    var t = a()(".recipe-content"),
                        n = e.val(),
                        i = "";
                    "Images" === n && (i = "print_hide_images"), "Tips" === n && (i = "print_hide_tips"), "Nutrition" === n && (i = "print_hide_nutrition"), "Sale Items" === n && (i = "print_hide_sales"), e.attr("checked") ? t.addClass(i) : t.removeClass(i)
                }(t), t.attr("checked") ? (t.attr("checked", !1), t.parent().find(".checkbox-list-checkmark").removeClass("checked").addClass("unchecked"), t.parent().parent().find(".section-body").removeClass("checked")) : (t.attr("checked", "checked"), t.parent().find(".checkbox-list-checkmark").addClass("checked").removeClass("unchecked"), t.parent().parent().find(".section-body").addClass("checked")))
            }))
        },
        481: function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, "default", (function() {
            }));
            var i = n(1),
                a = n.n(i),
                s = n(5),
                c = n.n(s),
                r = n(2),
                d = n.n(r),
                o = n(4),
                l = n(781);

            function p(e) {
                if (a.a.isArray(e)) {
                    var t = a()(".ingredients-section li");
                    a.a.each(t, (function(t, n) {
                        var i = a()(n),
                            s = i.data("id");
                        e.includes(s) && (i.find("input").prop("checked", !0), i.find(".checkbox-list-checkmark").addClass("checked").removeClass("unchecked"))
                    })), e.length >= 1 && (a()(".recipe-shopping-list__add-all-button").addClass("hidden"), a()(".recipe-shopping-list__add-all-success, .recipe-shopping-list__view-items").removeClass("hidden"), a()(".recipe-shopping-list__add-all-success-text").text("".concat(e.length, " ingredient").concat(e.length > 1 ? "s" : "", " added")))
                } else e.prop("checked", !0), e.parent().find(".checkbox-list-checkmark").addClass("checked").removeClass("unchecked")
            }

            function u(e, t) {
                if (a()("body").hasClass("authenticated")) {
                    var n = e.type,
                        i = a()(".recipe-shopping-list__add-all-button");
                    a.a.post("/element-api/content-proxy/shopping-list", e, (function(a, s) {
                        "success" === s && ("post" === n ? !t || Object(l.a)(t, i) ? p(e.ingredientIds || [e.ingredientId]) : p(t) : function(e) {
                            e.prop("checked", !1), e.parent().find(".checkbox-list-checkmark").removeClass("checked").addClass("unchecked")
                        }(t))
                    }))
                } else {
                    var s = a()(".component.recipe-ingredients-new").data("login-url"),
                        c = "?id=".concat(e.id, "&servings=").concat(e.servings, "&type=").concat(e.type);
                }
            }

            function g() {
                var e = a()(".ingredients-section").find(".checkbox-list-input"),
                    t = a()(".recipe-adjust-servings__size-minus"),
                    n = a()(".recipe-adjust-servings__size-plus"),
                    i = a()(".recipe-adjust-servings__adjust-button"),
                    s = a()(".recipe-shopping-list__add-all-button"),
                    r = a()(".recipe-shopping-list__add-all-button-text");
                e.change((function() {
                    var t = e.filter(":checked").length;
                    a()(".component.recipe-ingredients-new").attr("data-ingredients-selected", t), t >= 1 ? r.text("Add ".concat(t, " ingredient").concat(t > 1 ? "s" : "", " to shopping list")) : r.text("Add all ingredients to shopping list")
                })), c()(o.m).subscribe((function(e, c) {
                    if (Object(l.a)(c, t)) {
                        var r = parseInt(a()(".recipe-adjust-servings__size-quantity").text(), 10);
                        r > 1 && (r -= 1, a()(".recipe-adjust-servings__size-quantity").text(r))
                    } else if (Object(l.a)(c, n)) {
                        var o = parseInt(a()(".recipe-adjust-servings__size-quantity").text(), 10);
                        o < 300 && (o += 1, a()(".recipe-adjust-servings__size-quantity").text(o))
                    } else if (Object(l.a)(c, i)) {
                        var p, g = parseInt(a()(".recipe-adjust-servings__size-quantity").text(), 10),
                            h = a()(".keyvals").data("meredith_brand"),
                            f = a()(".keyvals").data("content_cms_id");
                        p = (p = -1 !== h.indexOf("allrecipes.com") ? "cms/allrecipes_recipe_alrcom_".concat(f) : a()("body").data("content-graph-id")).split("/");
                        var v = d.a.get(p, "[0]", null),
                            k = d.a.get(p, "[1]", null),
                            b = "/element-api/recipe-scaling/".concat(v, "/").concat(k),
                            m = {
                                servings: g
                            };
                        a.a.get(b, m, (function(e) {
                            var t = e.ingredient_groups;
                            return !!t && (a.a.each(t, (function(e, t) {
                                a.a.each(t.ingredients, (function(e, t) {
                                    a()(".ingredients-section li[data-id=".concat(t.cms_ingredient_id, "] .ingredients-item-name")).text(t.full_ingredient_line)
                                }))
                            })), a()(".recipe-adjust-servings__validation-message").show(), !0)
                        }))
                    } else if (Object(l.a)(c, s)) {
                        var _ = c.closest(".recipe-ingredients-new"),
                            C = _.data("recipe-id"),
                            w = _.data("servings"),
                            x = _.find("li input:checked");
                        x.length || (x = _.find("li"), a()(".component.recipe-ingredients-new").attr("data-ingredients-selected", x.length));
                        var y = [];
                        x.length && a.a.each(x, (function(e, t) {
                            var n = a()(t).closest("li").data("id");
                            y.push(n)
                        })), u({
                            id: C,
                            ingredientIds: y,
                            servings: w,
                            type: "post"
                        }, c)
                    }
                }))
            }

            function h() {
                var e = a()(".component.recipe-ingredients-new"),
                    t = e.parent(),
                    n = a()("li.ingredients-item");
                    e.forEach((function(e) {
                        "id" === d.a.get(e, "attributeName") && "ar-calvera-app" === d.a.get(e, "target.id") && g()
                    }))
                })).observe(t.get(0), {
                    attributes: !0
                }), c()(o.fb).subscribe(function() {
                    if (a()("body").hasClass("authenticated")) {
                            t = e.get("id"),
                            n = e.get("servings"),
                            i = e.get("ingredientIds"),
                            s = e.get("ingredientId"),
                            c = e.get("type");
                        if (!t || !n || !s && !i || !c) return !1;
                        var r = {
                            id: t,
                            servings: n,
                            type: "post"
                        };
                        if (i) {
                            i = i.split(",");
                            var d = [];
                            a.a.each(i, (function(e, t) {
                                d.push(parseInt(t, 10))
                            })), r.ingredientIds = d
                        } else r.ingredientId = parseInt(s, 10);
                        return u(r), !0
                    }
                    return !0
                }())
            }
        },
        482: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(1),
                a = n.n(i),
                s = n(5),
                c = n.n(s),
                r = n(4),
                d = n(781);
                c()(r.m).subscribe((function(e, t) {
                    var n = a()(".instructions-section").find(".checkbox-list-input");
                    Object(d.a)(t, n) && (t.attr("checked") ? (t.attr("checked", !1), t.parent().find(".checkbox-list-checkmark").removeClass("checked").addClass("unchecked"), t.parent().parent().find(".checkbox-list").removeClass("checked"), t.parent().parent().find(".section-body").removeClass("checked")) : (t.attr("checked", "checked"), t.parent().find(".checkbox-list-checkmark").addClass("checked").removeClass("unchecked"), t.parent().parent().find(".checkbox-list").addClass("checked"), t.parent().parent().find(".section-body").addClass("checked")))
                }))
            }
        },
        484: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n(1),
                a = n.n(i),
                s = n(5),
                c = n.n(s),
                r = n(4),
                d = n(781);
                c()(r.zb).subscribe((function(e, t) {
                    e.find(".rating-star-input").each((function(e, n) {
                    }))
                })), c()(r.m).subscribe((function(e, t) {
                    var n = a()(".component.recipe-ratings > .ratings-dropdown-button"),
                        i = a()(".component.recipe-ratings > .ratings-dropdown-menu"),
                        s = a()(".component.recipe-ratings .add-rating-reviews-link"),
                        o = a()(".component.feedback"),
                        l = function() {
                            n.removeClass("open"), n.attr("aria-expanded", !1), i.removeClass("open")
                        };
                    if (Object(d.a)(t, s) && !o.length)
                        if (e.preventDefault(), a()("body").hasClass("authenticated")) setTimeout((function() {
                            return c()(r.Ub).broadcast(e, t)
                        }), 0);
                        else if (!t.closest(".embedded-auth-modal-trigger").length) {
                        var p = s.data("login-url");
                    }
                    if (t.closest(".recipe-ratings").hasClass("interactive") && t.closest(".rating-star").length) {
                        var u = t.closest(".recipe-ratings").find("input[name=ugc-rating]"),
                            g = t.closest(".rating-star").data("rating");
                        g && u.val([g])
                    }
                    return t.closest(".ratings-dropdown-button").length && !t.closest(".recipe-ratings").hasClass("interactive") && i.length ? (e.preventDefault(), i.hasClass("open") ? l() : (n.addClass("open"), n.attr("aria-expanded", !0), i.addClass("open"))) : l(), null
                }))
            }
        },
        781: function(e, t, n) {
            "use strict";
                return e.is(t) || t.has(e).length > 0
            }
        }
    }
]);
//# sourceMappingURL=15-15.js.map