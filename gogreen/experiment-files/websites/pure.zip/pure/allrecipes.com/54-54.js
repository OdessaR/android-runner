(window.webpackJsonp = window.webpackJsonp || []).push([
    [54], {
        466: function(e, a, n) {
            "use strict";
            n.r(a), n.d(a, "default", (function() {
            }));
            var s = n(1),
                t = n.n(s),
                i = n(5),
                r = n.n(i),
                o = n(782),
                l = n(4),
                d = n(781),
                c = n(885),
                u = n(57);

            function m() {
                return t()(".navigation-test.component").each((function() {
                    var e, a, n, s, i, m, p, b = t()("body"),
                        h = t()("header.navigation-test"),
                        f = t()("header.navigation-test").find("nav.main-new"),
                        v = f.find(".icon.search.js-activate"),
                        g = f.find(".icon.search-nav.js-activate"),
                        C = f.find(".nav-search-mobile .icon"),
                        y = f.find(".icon.close-search"),
                        w = f.find(".search-field"),
                        k = f.find(".menu"),
                        j = f.find(".primary-text-links"),
                        O = f.find(".menu-search"),
                        x = b.find(".menu-link.expand-trigger"),
                        T = b.find("header.navigation-test .menu-overlay"),
                        L = f.find(".icon.menu-close"),
                        A = b.find(".expand-trigger"),
                        D = b.find(".submenu-link.main-link"),
                        I = t()("header.navigation-test .modal.hamburger"),
                        M = new o.a(I, "hamburger"),
                        P = I.find(".close"),
                        z = I.find(".close svg"),
                        E = I.find(".top-menu .submenu-children-wrapper"),
                        J = I.find("li.has-submenu"),
                        K = I.find(".expand-trigger"),
                        N = I.find(".modal-navigation"),
                        R = t()(".modal-shortcut-link"),
                        S = I.find(".dialog-wrap"),
                        V = t()(".ad-wrapper.karma-leaderboard-docking-element"),
                        W = null,
                        q = 0,
                        B = function() {
                            a = t()(".content-breadcrumbs").length ? t()(".content-breadcrumbs").height() : 0, n = f.hasClass("homepage") ? f.find(".menu-homepage-row").height() : f.height(), s = t()(".component.share-new").length ? t()(".component.share-new").height() : 0, i = t()(".main-header").length ? t()(".main-header").height() : 0, m = V.height(), p = t()(".logo-row").height() || 0, e = c.a.isMobileTabletLayout()
                        };
                    var F = function(a) {
                            if (J.removeClass("selected"), E.removeClass("children-wrapper-expanded"), K.removeAttr("aria-disabled"), e && K.removeAttr("style"), e || (K.attr("aria-expanded", !1), x.removeAttr("aria-disabled")), a) {
                                var n = a.find(".submenu-children-wrapper"),
                                    s = a.find(".expand-trigger");
                                if (a.addClass("selected"), e || s.attr({
                                        "aria-expanded": !0,
                                        "aria-disabled": !0
                                    }), n.addClass("children-wrapper-expanded"), e) {
                                    W = s, s.css("display", "none");
                                    var t = n.find(".back-button.mobile-only");
                                    t.length && t.focus()
                                }
                            }
                        },
                        G = function() {
                            b.removeClass("menu-active"), x.parent().removeClass("active"), x.attr("aria-expanded", !1), k.removeClass("open"), J.removeClass("selected"), I.removeClass("secondary-menu-open"), I.removeClass("submenu-open"), F(), e && (W = null)
                        },
                        H = function() {
                            if (f.hasClass("full-size-nav-enabled") && h.hasClass("sticky-nav")) {
                                var e = O.outerWidth();
                                j.css({
                                    paddingRight: e
                                })
                            }
                        },
                        Q = function() {
                            f.hasClass("full-size-nav-enabled") && j.removeAttr("style")
                        },
                        U = Array.prototype.slice.call(D);
                    D.on("keydown", (function(e) {
                        var a = e.target,
                            n = e.which.toString(),
                            s = e.ctrlKey && n.match(/33|34/);
                        if (a.classList.contains("main-link") && (n.match(/38|40/) || s)) {
                            var t = U.indexOf(a),
                                i = n.match(/34|40/) ? 1 : -1,
                                r = U.length;
                            U[(t + r + i) % r].focus(), e.preventDefault()
                        }
                    })), r()(l.tb).subscribe((function() {
                        if (b.hasClass("modal-active") && b.hasClass("hamburger")) {
                            var e = Object(u.a)();
                            ("mobile" === e || "tablet" === e) && h.find(".children-wrapper-expanded").length ? I.addClass("submenu-open") : (I.removeClass("submenu-open"), h.find(".expand-trigger").css("display", ""))
                        }
                    })), r()(l.m).subscribe((function(a, n) {
                        var s = b.hasClass("modal-active") && b.hasClass("hamburger") ? I.find(".secondary-links .menu-list-item.has-submenu") : f.find(".secondary-links .menu-list-item.has-submenu");
                        if (!n.closest(".component.navigation-test").length || s.hasClass("active")) return s.removeClass("active"), x.attr("aria-expanded", !1), I.removeClass("secondary-menu-open"),
                            function(e) {
                                if (Object(d.a)(e, R)) {
                                    M.open(), b.addClass("menu-active"), k.addClass("open");
                                    var a = I.find("".concat(R.data("menuTarget")));
                                    F(a);
                                    var n = I.find("".concat(R.data("focusTarget")));
                                    if (R.data("focusTarget")) return n.focus()
                                }
                            }(n), null;
                        if (n.closest(".search-by-ingredient-mobile-show").length || n.closest(".search-by-ingredient-mobile-hide").length || n.closest(".component.search-by-ingredient").length) return null;
                        var i = I.find("li.has-submenu.selected .back-button"),
                            o = i.find("svg"),
                            c = o.find("path");
                        if (Object(d.a)(n, v) && !f.hasClass("search-open")) return f.addClass("search-open"), H(), w.prop("disabled", !1).focus();
                        if (Object(d.a)(n, v) || Object(d.a)(n, y)) return f.removeClass("search-open"), H(), w.blur().prop("disabled", !0);
                        if (Object(d.a)(n, g)) return g.addClass("search-nav-open"), w.focus(), b.toggleClass("menu-active");
                        if (Object(d.a)(n, P) || Object(d.a)(n, z) || Object(d.a)(n, T)) G();
                        else {
                            if (Object(d.a)(n, C)) return M.open(), b.addClass("menu-active"), k.addClass("open"), I.find(".search-field").focus();
                            if (Object(d.a)(n, k) || Object(d.a)(n, L)) {
                                if (0 === f.find(".menu.open").length) {
                                    if (M.open(), b.addClass("menu-active"), k.addClass("open"), !e) {
                                        var u = I.find(".pos-0");
                                        F(u)
                                    }
                                } else G();
                                r()(l.pb).broadcast(), f.find(".search-nav-open").length > 0 ? g.removeClass("search-nav-open") : g.addClass("search-nav-open")
                            } else if (n.parents("li.has-submenu").length > 0 && n.parents(".menu-item-main").length > 0 && !Object(d.a)(n, i) && !Object(d.a)(n, o) && !Object(d.a)(n, c) && !n.parents("li.open-channel-page").length > 0) {
                                a.preventDefault(), a.stopImmediatePropagation();
                                var m = n.parents("li.has-submenu");
                                F(m), e ? (I.addClass("submenu-open"), S.animate({
                                    scrollTop: 0
                                }, 100)) : N.animate({
                                    scrollTop: 0
                                }, 100), r()(l.pb).broadcast()
                            } else if (Object(d.a)(n, i) || Object(d.a)(n, o) || Object(d.a)(n, c)) F(), I.removeClass("submenu-open"), e && W && W.length && (W.focus(), W = null);
                            else if (n.parents("li.header-primary-links.has-submenu").length > 0 && !n.parents("li.open-channel-page").length > 0) {
                                a.preventDefault(), a.stopImmediatePropagation(), M.open(), b.addClass("menu-active"), k.addClass("open");
                                var p = n.parent().data("navPos"),
                                    h = I.find(".".concat(p));
                                "pos-0" === p && r()(l.pb).broadcast(), F(h), e && I.addClass("submenu-open")
                            } else if (n.parents("header.navigation-test .secondary-links .menu-list-item.has-submenu").length > 0 && 0 === n.parents("header.navigation-test .secondary-links .menu-list-item.has-submenu .submenu-children-wrapper").length) {
                                a.preventDefault(), a.stopImmediatePropagation();
                                var j = n.closest(".menu-list-item.has-submenu"),
                                    O = j.find(".submenu-children-wrapper"),
                                    A = j.find(x);
                                j.hasClass("mobile-open") || j.hasClass("active") ? (j.removeClass("mobile-open"), j.removeClass("active")) : (e && (I.addClass("secondary-menu-open"), j.toggleClass("mobile-open"), t()("header").get(0).scrollIntoView()), j.toggleClass("active"), A.attr("aria-expanded", !0), O.find("a[href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), button:not([disabled]), *[tabindex][tabindex!=-1]").first().focus())
                            } else s.removeClass("active").removeClass("mobile-open"), I.removeClass("secondary-menu-open")
                        }
                        return null
                    })), r()(l.ab).subscribe((function() {
                        e && A.removeAttr("aria-expanded aria-disabled")
                    })), r()(l.ub).subscribe((function() {
                        var r = t()(window).scrollTop(),
                            o = p + (V.hasClass("docked") ? 0 : m);
                        return (r > o || c.a.isMobileLayout()) && (h.addClass("sticky-nav"), t()(".primary-nav-search").animate({
                            bottom: "0px"
                        }, 1e3)), 0 === r || r < o ? (b.removeClass("scroll-up"), h.removeClass("sticky-nav"), Q()) : q > r ? (b.addClass("scroll-up"), H()) : (b.removeClass("scroll-up"), Q()), q = r, r > s + i + a + n + m && e ? b.addClass("under-docked-sharebar") : b.removeClass("under-docked-sharebar")
                    }))
                })), r()(l.N).broadcast()
            }
        },
        885: function(e, a, n) {
            "use strict";
            var s = n(4),
                t = n(57),
                i = Object(t.a)();
                i = Object(t.a)()
                isMobileLayout: function() {
                    return "mobile" === i
                },
                isTabletLayout: function() {
                    return "tablet" === i
                },
                isMobileTabletLayout: function() {
                    return ["mobile", "tablet"].indexOf(i) >= 0
                }
            }
        }
    }
]);
//# sourceMappingURL=54-54.js.map