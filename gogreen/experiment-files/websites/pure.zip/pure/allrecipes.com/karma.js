/*! karma.js v.3.10.1 2020-9-28 */ ! function() {
    let n = e.karmads || {};
    n.vars = n.vars || {}, e.karma = e.karma || {}, e.karma.vars = e.karma.vars || {}, e.karma.config = e.karma.config || {};
    let i = {
            vars: {
                version: "3.10.1",
                targetingStorage: {},
                els: {
                    head: t.getElementsByTagName("head")[0]
                },
                videoTargeting: {},
                adaptiveTimeout: !1
            },
            slots: {
                catalog: [],
                deferred: [],
                lazy: [],
                scrollLoad: [],
                refresh: []
            },
            config: {
                networkCode: "3865",
                version: "3.16",
                scriptPath: "",
                environment: "",
                site: "",
                targeting: {},
                static: !1
            }
        },
        o, r, a, s, l, c, d, u, g, f, p, h, m, b, y, v, S, k, w, T, C, x, E, I, O, P, R, L, A, z, _, q, M;
    const D = i.vars,
        V = i.config;
        (e.ga.q = e.ga.q || []).push(arguments)
        "use strict";
        let e, t, r, s, c, d, u, g, f, p;
        const y = ["refreshSlotTypes", "header_tag_managerEnabled", "a9Enabled", "docking", "usPrivacy", "euPrivacy"];

        function v(n) {
            return u = "www" === t ? "" : t + ".", g = d ? ":9999" : "", V.scriptPath = "https://" + u + "karma.mdpcdn.com" + g + "/configs/" + s + "/" + (n || e) + ".json", V.scriptPath
        }

        function S(i) {
            p = n.config.storage.check(e, t, s), c || "object" != typeof p ? (a({
                label: "ConfigFetchStart"
            }), b(r, (function(e, t) {
                n.targeting.ivt(t), i(e), a("Loaded static config! v." + e.versionInfo.version + " from " + r)
            }), (function() {
                "email.mdp.com" === e ? a("Email address detected in the URL. Halting the ad request.", {
                    force: !0,
                    level: "error"
                }) : 0 === e.indexOf("deactivated.") ? a("Site is deactivated. Halting the ad request.", {
                    force: !0,
                    level: "error"
                }) : (a("Failed to load static config! " + r + ", trying for " + f, {
                    force: !0,
                    level: "error"
                }), r = V.scriptPath = v(f), b(r, (function(e) {
                    i(e), a("Loaded static config! v." + e.versionInfo.version + " from " + r, {
                        force: !0
                    })
                }), (function() {
                    a("Failed to load default static config! " + r, {
                        force: !0,
                        level: "error"
                    })
                })))
            }))) : (a("Loading Config from LocalStorage."), V.scriptPath = "localStorage.mdpKarmaConfig", V.environment = p.env, n.targeting.ivt("", !0), i(p))
        }
        return {
            load: S,
            process: function(e) {
                if (e) {
                    const o = n.targeting.get("type"),
                        r = V.onPageSettings;
                    let a, s, c, d, u = l(e.settings);
                    if (n.config.storage.set(V.site, e, t), u.hasOwnProperty("pageSpecificSettings") && u.pageSpecificSettings.hasOwnProperty(o) && (u = m(u, u.pageSpecificSettings[o])), V.static = u || !1, !1 !== V.static) {
                        const e = l(V.static);
                        h(e, (function(t) {
                            V[t] = e[t]
                        })), h(y, (function(t) {
                            r.config.hasOwnProperty(t) && (P(r.config[t]) ? V[t] = m(e[t], r.config[t]) : V[t] = r.config[t])
                        }))
                    }
                    if (n.urlVars.setTestValues(), i.slots.siteSpecific = l(e.siteSpecificSlots), V.targeting.abTest && "object" == typeof V.abTestMap && (a = V.targeting.abTest, s = V.abTestMap, s[a])) {
                        c = s[a].prop.split("."), d = V;
                        const e = c.length;
                        h(c, (function(t, n) {
                            n === e - 1 ? d[t] = s[a].val : d.hasOwnProperty(t) && (d = d[t])
                        }))
                    }
                } else a("No response received from the service")
            },
            init: function(i) {
                f = "default.mdp." + (o ? "mob" : "com"), c = c || n.urlVars.get("karmaConfig"), d = !("local" !== c), t = c && R(c) ? c : c && "" !== c || "local" !== D.environment ? D.environment || "www" : "dev", V.environment = t, t = t, s = "local" === t || "dev" === t ? "latest" : V.version, e = V.site.replace(/^test\./, ""), r = v(), S(i || L)
            }
        }
    }(), n.docking = function() {
        "use strict";
        let e = "";

        function t() {
            n.docking.leaderboard.init(), n.docking.rail.init()
        }

        function i(e) {
            if (!e || !Array.isArray(e)) return !1;
            let t = !0;
            return h(e, (function(e) {
                eval(e) || (t = !1)
            })), t
        }

        function o(t) {
            e += t;
            const i = n.dom.lookup("#dockingStyles", !1, !0);
            e.length > 0 && (null === i ? n.dom.create("style", D.els.head, {
                id: "dockingStyles",
                innerHTML: e
            }) : i.innerHTML = e)
        }

        function r() {
            if (V.docking) {
                let e;
                h(["leaderboard", "rail"], (function(t) {
                    V.docking[t] && (e = "leaderboard" === t ? "docked" === n.docking.leaderboard.getPosition() : n.docking[t].isEnabled(), n.targeting.set("docked" + t, e))
                }))
            }
        }

        function s(e) {
            switch (a(("both" === (e = e || "leaderboard") ? "leaderboard and rail docking have" : e + " docking has") + " been disabled by karma.releaseDocking()"), e) {
                case "both":
                    n.docking.rail.disableAllRails(), n.docking.leaderboard.forceReleaseBanner("method");
                    break;
                case "rail":
                    n.docking.rail.disableAllRails();
                    break;
                case "leaderboard":
                default:
                    n.docking.leaderboard.forceReleaseBanner("method")
            }
        }
        return {
            processAdditionalLogic: i,
            appendStyleSheetCss: o,
            disableDocking: s,
            targeting: r,
            init: t
        }
    }(), n.lazyLoad = function() {
        "use strict";
        let e = [];

        function o() {
            e.length > 0 ? (n.requestQueue.process(e), e = []) : a("Attempted to fill newly created slots, but no unfilled slots exist.", {
                force: !0
            })
        }
        return {
            create: function(r, s, c, d, u) {
                const g = ". Aborting karma.createSlot.";
                if ("string" != typeof r || "" === r) return a("The lazy load slot type you passed to karma.createSlot is not set or is not a string" + g, {
                    force: !0,
                    level: "error",
                    doc: "karmacreateslot"
                }), !1;
                if ("string" == typeof s && !n.dom.lookup("#" + s)) return a('You passed "' + s + '" as the lazy slot container id to karma.createSlot, but that element does not exist in the DOM' + g, {
                    force: !0,
                    level: "error",
                    doc: "karmacreateslot"
                }), !1;
                if ("boolean" != typeof c && (a("the autofill argument for karma.createSlot is not set or is not a boolean, so it defaults to false. You need to call karma.fillSlots() in order to fill the ad.", {
                        force: !0,
                        level: "warn",
                        doc: "karmafillslots"
                    }), c = !1), "object" == typeof d && Object.keys(d).length && (u = d, d = void 0), s = "string" == typeof s ? n.dom.lookup("#" + s) : s, !t.body.contains(s) && t.body !== s) return a("The container you passed to karma.createSlot for " + r + " is not attached to the document body." + g, {
                    force: !0,
                    level: "error",
                    doc: "karmacreateslot"
                }), !1;
                let f = (u = u || {}).tier;
                const p = n.tiers.getFromType(r);
                p && (r = r.replace("-tier" + p, ""), f = p);
                let h = i.slots.lazy.filter((function(e) {
                    return e.type === r || e.lazyType === r
                }))[0];
                if (!h) return a('Lazy slot "' + r + '" is not configured for this site' + g, {
                    force: !0,
                    level: "error",
                    doc: "karmacreateslot"
                }), !1;
                n.tiers.isValidTier(f) || (a('You did not pass a valid tier (1-4) to karma.createSlot. The slot will be loaded as tier0. You should use "' + r + '-tierx" instead, where "x" is the desired tier', {
                    force: !0,
                    level: "warn",
                    doc: "karmacreateslot"
                }), f = 0), h.lazyCount = h.lazyCount ? h.lazyCount : 0, h.lazyCount += 1;
                const b = h.lazyType + "-" + h.lazyCount,
                    y = n.dom.create("div", s, {
                        id: b,
                        "data-tier": f
                    });
                return h = l(h), h.tier = f, h.slotContainer = b, h.deferred = !1, h.tierString = "tier" + f, h.slotTargetingValues = h.slotTargetingValues || {}, u.hasOwnProperty("targeting") && "object" == typeof u.targeting && m(h.slotTargetingValues, u.targeting), V.tiers && V.tiers[h.type] && V.tiers[h.type][h.tierString] && m(h, V.tiers[h.type][h.tierString]), h.refreshType = u.refreshType || "lazy", u.bypassVisibilityCheck && (h.bypassVisibilityCheck = !0), n.gpt.define(h, n.targeting.adunit.build(h), b), i.slots.catalog.push(h), n.targeting.slotSetup(h), n.gpt.display(b), n.reporting.lazyLoadSlot(r), e.push(h), a("Finished adding GPT slot " + b), u.refreshable && (u.purgeRefreshList && n.refresh.purgeSlots(), n.refresh.addSlot(b)), c && o(), "function" == typeof d ? n.gpt.addCallback((function(e) {
                    e.slot.getSlotId().getDomId() === b && d(e)
                })) : void 0 !== d && a("Callback passed to karma.createSlot for " + b + " is " + typeof d + ", not a function. ignoring callback", {
                    force: !0,
                    level: "warn",
                    doc: "karmacreateslot"
                }), n.translate.slots(), y
            },
            fill: o,
            removeUnfilledSlot: function(t) {
                return e = e.filter((function(e) {
                    return e.slotContainer !== t
                })), e
            }
        }
    }(), n.partner = function() {
        "use strict";
        const e = ["a9", "header_tag_manager"],
            t = [];
        let o = !1;

        function r(e) {
            return V[e + "Enabled"] && !!n.partner[e]
        }

        function s(e, t) {
            const o = t || i.slots.catalog;
            return !!r(e) && (D[e] = D[e] || {}, D[e].slots = D[e].slots || {}, h(o, (function(t) {
                t.hasOwnProperty(e) && !0 === t[e] && n.slots.isValidSlotForDevice(t) && (D[e].slots[t.slotContainer] = t)
            })), D[e].slots)
        }

        function l(t) {
            return e.filter((function(e) {
                return c(t, e)
            })).length > 0
        }

        function c(e, t) {
            return e[t] && r(t)
        }
        return {
            buildSlots: s,
            getTimeoutLengths: function(e) {
                const t = V.bidTimeouts || {},
                    n = "hard" === e,
                    i = {
                        partnerEnforced: t[e] || 750,
                        failsafe: t.failsafe || 2e3,
                        message: n ? "failsafe" : "refresh"
                    };
                return i.karmaEnforced = n ? i.failsafe : i.partnerEnforced, i
            },
            init: function() {
                const i = V.bidTimeouts = V.bidTimeouts || {};
                i.failsafe = i.failsafe || 2e3, i.hard = i.hard || 750, i.soft = i.soft || 500, i.timed = i.timed || i.hard, !0 !== o && (o = !0, h(e, (function(e) {
                    r(e) && (s(e), t.push(e))
                })), h(t, (function(e) {
                    "function" == typeof n.partner[e].load && n.partner[e].load()
                })))
            },
            removeSlotFromAll: function(e) {
                let n;
                h(t, (function(t) {
                    r(t) && D[t].hasOwnProperty("slots") && (n = D[t].slots, n.hasOwnProperty(e) && delete n[e])
                }))
            },
            isAnyPartnerEnabledOnSlot: l,
            initDemandFetch: function(t) {
                function i(e) {
                    const i = s.indexOf(e);
                    i >= 0 && s.splice(i, 1), 0 === s.length && (a("Finishing request"), n.requestQueue.finishRequest(t))
                }

                function o(e, t) {
                    return e.filter((function(e) {
                        return t.indexOf(e) > -1
                    })).length > 0
                }
                const s = ["control"],
                    d = function(e) {
                        const t = e.map((function(e) {
                                return e.refreshType
                            })),
                            n = o(t, ["timed", "swap"]),
                            i = o(t, ["soft", "lazy", "scroll"]);
                        return n ? "timed" : i ? "soft" : "hard"
                    }(t);
                if (h(e, (function(e) {
                        (function(e, t) {
                            return e.filter((function(e) {
                                return c(e, t)
                            })).length > 0 && r(t)
                        })(t, e) && (n.partner.buildSlots(e, t), s.push(e), n.partner[e].fetchBids(t, d, (function() {
                            i(e)
                        })))
                    })), "timed" === d && function(e) {
                        return e.filter((function(e) {
                            return l(e)
                        })).length > 0
                    }(t)) {
                    const e = 1e3 * Math.ceil(V.bidTimeouts.timed / 1e3);
                    a("Starting partner control timeout for timed refresh: " + e), setTimeout((function() {
                        i("control")
                    }), e)
                } else i("control")
            }
        }
    }(), n.polyfills = function() {
        "use strict";
        return function() {
            if ("function" == typeof e.CustomEvent) return !1;

            function n(e, n) {
                n = n || {
                    bubbles: !1,
                    cancelable: !1,
                    detail: void 0
                };
                const i = t.createEvent("CustomEvent");
                return i.initCustomEvent(e, n.bubbles, n.cancelable, n.detail), i
            }
            n.prototype = e.Event.prototype, e.CustomEvent = n
            createCustomEvent: function(e) {
            }
        }
    }(), n.refresh = function() {
        "use strict";

        function e(e) {
            return (e = e || i.slots.refresh).map((function(e) {
                return e.slotContainer
            }))
        }
        return D.refreshingAds = !1, V.refresh = V.refresh || {}, {
            startRefresh: function(t) {
                if (!V.refresh.userInitiated.enabled) return a("User initiated refresh is disabled for this page."), !1;
                const o = [],
                    r = t || e();
                let s;
                return h(r, (function(e) {
                    s = n.slots.getById(e), s ? (s.shouldIncrementRefresh = !0, s.refreshType = "soft", n.refresh.timed.resetSlotTimer(s), o.push(s)) : i.log("Cannot refresh " + e + " because it does not exist", {
                        force: !0,
                        level: "warn"
                    })
                })), o.length > 0 && (a("refreshing these ads: " + e(o).toString()), n.refresh.timed.check(), n.requestQueue.process(o), E()), !1
            },
            buildDefaultSlots: function() {
                return i.slots.refresh = i.slots.catalog.filter((function(e) {
                    return -1 === e.slotContainer.indexOf("-lazy-") && n.slots.matchHandleArray(e, V.refresh.userInitiated.slotTypes || [], !0)
                }))
            },
            purgeSlots: function() {
                return i.slots.refresh = []
            },
            addSlot: function(e) {
                const t = n.slots.getById(e);
                return !!t && (i.slots.refresh.push(t), !0)
            },
            removeSlot: function(t, n) {
                const o = i.slots.refresh,
                    r = e(o).indexOf(t);
                return r > -1 ? o.splice(r, 1) : (n || a("Attempted to remove an invalid slot id from karma.slots.refresh: " + t, {
                    doc: "refresh"
                }), !1)
            },
            targeting: function(e) {
                h(e, (function(e) {
                    e.refreshType ? (n.targeting.clear(void 0, e), n.targeting.slotSetup(e)) : e.refreshType = "hard", n.targeting.set("refreshType", e.refreshType, e)
                }))
            },
            incrementRefreshCounter: function(e) {
                h(e, (function(e) {
                    e.shouldIncrementRefresh && (e.refreshCount = "number" == typeof e.refreshCount ? e.refreshCount : 0, e.refreshCount += 1, n.targeting.set("refresh", e.refreshCount, e), e.shouldIncrementRefresh = !1)
                }))
            }
        }
    }(), n.targeting = function() {
        "use strict";
        const t = {},
            i = ["app", "article", "audio", "audio_hub", "category", "channel", "collection", "freestuff", "homepage", "landing_page", "longform", "none", "page", "photos", "poll", "post", "print", "product", "profile", "project", "recipe", "recipe_hub", "reviews", "search", "slideshow", "slideshow_hub", "sponsored_collection", "sponsored_recipe_hub", "sponsored_print", "sponsored_profile", "sponsored_recipe", "tag", "video", "video_article", "video_hub", "video_playlist", "video_recipe"];
        let o, r, l = !1;

        function c() {
            l || (l = !0, setTimeout((function() {
                e.dispatchEvent(r), l = !1
            }), 100))
        }

        function d(e) {
            return e.toLowerCase().replace(/[^a-z0-9]/g, "")
        }

        function u(e, r, a) {
            const l = V.videoTargetingKeys || [];
            if (r = s(r), "" !== (r = "type" === e ? function(e) {
                    D.unmappedPageType = e, e = e ? d(e) : "";
                    const t = {
                        story: "article",
                        multimediaarticle: "video_article",
                        videostory: "video_article",
                        travelreview: "article",
                        productreview: "article",
                        backtalk: "article",
                        landing: "landing_page",
                        directory: "category",
                        channel: "category",
                        topic: "category",
                        subchannel: "category",
                        list: "slideshow",
                        gallery: "slideshow",
                        photogallery: "slideshow",
                        popularrecipes: "slideshow",
                        recipedetail: "recipe",
                        recipes: "recipe",
                        gallerydetails: "app",
                        productdetailpage: "app",
                        faq: "page",
                        contributor: "page",
                        blogpost: "post",
                        exclusiveoffers: "freestuff",
                        advertorialpage: "page",
                        author: "profile",
                        blog: "post",
                        blogtout: "post",
                        bracket: "bracket",
                        businesslisting: "page",
                        businesslistinglandingpage: "landing_page",
                        calculator: "app",
                        calendar: "slideshow",
                        channellandingpageresponsive: "category",
                        channellayout: "category",
                        checklist: "app",
                        conditioncenter: "app",
                        content: "page",
                        contentpackage: "category",
                        covevideo: "video",
                        dailyfinds: "app",
                        ecommercehub: "landing_page",
                        featurepackage: "category",
                        franchise: "page",
                        generic: "page",
                        genericpage: "page",
                        hgallery: "slideshow",
                        home: "homepage",
                        howto: "article",
                        imagelist: "photos",
                        index: "category",
                        listicle: "article",
                        magazine: "page",
                        main: "category",
                        makeover: "app",
                        multitag: "tag",
                        multitagpage: "tag",
                        newusesgallery: "slideshow",
                        odds: "odds",
                        optimizer: "optimizer",
                        package: "category",
                        packageflex: "category",
                        planner: "app",
                        plant: "app",
                        poy: "article",
                        rankings: "rankings",
                        recap: "article",
                        schedules: "schedules",
                        scrollinggallery: "slideshow",
                        section: "category",
                        sectionfront: "category",
                        shoppinghub: "product",
                        specialsectionpage: "category",
                        standings: "standings",
                        stats: "stats",
                        storied: "app",
                        syndicatedslideshow: "slideshow",
                        tags: "tag",
                        textlist: "page",
                        tiledlandingpage: "landing_page",
                        timeline: "app",
                        topicpage: "category",
                        topicpagechild: "category",
                        tout: "page",
                        tvrecapsubchannel: "category",
                        verticalgallery: "slideshow",
                        videoarticle: "video_article",
                        videolandingpage: "video_hub",
                        videoarchive: "video_hub",
                        videoseries: "video_playlist",
                        videos: "video_hub"
                    };
                    return h(i, (function(e) {
                        t[d(e)] = e
                    })), void 0 === e || "" === e ? "none" : t.hasOwnProperty(e) ? t[e] : e
                }(r) : r))
                if (a) n.gpt.setSlotTargeting(a, e, r);
                else {
                    if (t.hasOwnProperty(e) && t[e] === JSON.stringify(r)) return;
                    if (o[e] = r, t[e] = JSON.stringify(r), n.gpt.setPageTargeting(e, r), l.indexOf(e) > -1) {
                        const t = {};
                        t[e] = r, n.video.setTargeting(t)
                    }
                    c()
                }
        }

        function g(e, t) {
            if (t) {
                if (t = P(t) ? t : n.slots.getById(t), !P(t)) return void a("invalid slot id passed into karma.updateTargeting: " + t, {
                    force: !0,
                    level: "error",
                    doc: "karmaupdatetargeting"
                });
                h(e, (function(n) {
                    t.slotTargetingValues[n] = e[n]
                })), n.gpt.setSlotTargetingMap(t, e)
            } else h(e, (function(n) {
                u(n, e[n], t)
            }));
            c()
        }
        return {
            init: function() {
                V.targeting = V.targeting || {}, r = f("karmaSetTargeting"), o = V.targeting,
                    function() {
                        const t = e.location.pathname.split("/"),
                            n = t.length,
                            i = D.url.ref_hub;
                        i && "" !== i && (o.ref_hub = i), z(), h(D.targetingStorage, (function(e) {
                            D.targetingStorage[e] && (o[e] = D.targetingStorage[e])
                        })), O() && "search" !== o.type && (o.type = "homepage"), h(D.url.testValues, (function(e) {
                            o[e] = D.url.testValues[e]
                        })), (void 0 === o.type || "" === o.type) && (o.type = "none"), o.path = t.slice(1, t[n - 1] ? n : n - 1), q(.1) && (o.pft = 1), g(o)
                    }()
            },
            clear: function(e, i) {
                return o.hasOwnProperty(e) && delete o[e], t.hasOwnProperty(e) && delete t[e], i ? n.gpt.clearSlotTargeting(i, e) : n.gpt.clearPageTargeting(e)
            },
            get: function(e) {
                return V.targeting[e]
            },
            ivt: function(e, t) {
                const n = ["tag-ivt-detected", "cf-bot-score"],
                    i = n[0],
                    o = n[1],
                    r = e.split("\n"),
                    a = {},
                let c, d;
                h(r, (function(e) {
                    e = e.split(": "), n.indexOf(e[0]) > -1 && (a[e[0]] = e[1])
            },
            legacyUpdateSlot: function(e, t) {
                g(t, e)
            },
            prerequest: function() {
                ! function() {
                    if (t.hasOwnProperty("muid")) return t.muid;
                    const e = n.muid.getMuid();
                    a("Setting muid: " + e), u("muid", e), n.gpt.setPublisherProvidedId(e)
                }(),
                function() {
                    if (t.hasOwnProperty("mrid")) return t.mrid;
                    const e = n.muid.getRequestId();
                    a("Setting Meredith request id: " + e), u("mrid", e)
                }(), t.hasOwnProperty("gaid") || e.ga((function() {
                        const t = e.ga.getAll()[0].get("clientId");
                        "" !== t ? (u("gaid", t), a("Setting GA client id (gaid): " + t)) : a("GA client id not available.", {
                            force: !0,
                            level: "warn"
                        })
                    })),
                    function() {
                        if (D.targetingReady) return;
                        const e = n.dom.lookup("#page-segment-values"),
                            t = !!e && n.dom.lookup(".keyvals", !1, !1, e),
                            i = !!t && t.dataset;
                        "object" == typeof i && (u("concepts", (i.content_nlp_entities || "").split(/\/|\|/)), u("sentiment", i.content_nlp_sentiment_label), u("taxons", (i.content_nlp_categories || "").split(/\/|\|/)), u("mtax", (i.content_taxonomy || "").split(",")))
                    }()
            },
            ready: function() {
                e.dispatchEvent && (a("Dispatching event: karmaTargetingReady"), e.dispatchEvent(f("karmaTargetingReady"))), D.targetingReady = !0, o.id && "" !== o.id || a("karma.config.targeting.id is missing or empty.", {
                    force: !0,
                    level: "error",
                    doc: "karmaconfigtargetingid---required"
                }), o.type && "" !== o.type && "none" !== o.type || a("karma.config.targeting.type is missing or empty.", {
                    force: !0,
                    level: "error",
                    doc: "karmaconfigtargetingtype---required"
                }), o.channel && "" !== o.channel || a("karma.config.targeting.channel is missing or empty.", {
                    force: !0,
                    level: "error",
                    doc: "karmaconfigtargetingchannel---required"
                }), "app" !== o.type || o.app_name && "" !== o.app_name || a("This page has a type of 'app', but there is no value set for karma.config.targeting.app_name.", {
                    force: !0,
                    level: "warn",
                    doc: "karmaconfigtargetingapp_name"
                }), "search" !== o.type || o.search && "" !== o.search || a("This page has a type of 'search', but there is no value set for the search term in karma.config.targeting.search.", {
                    force: !0,
                    level: "warn",
                    doc: "karmaconfigtargetingsearch"
                }), -1 === i.indexOf(o.type) && a("karma.config.targeting.type (" + o.type + ") is an invalid value.", {
                    force: !0,
                    level: "warn",
                    doc: "karmaconfigtargetingtype---required"
                })
            },
            set: u,
            setTargetingMap: g,
            slotSetup: function(e) {
                e.slotTargetingValues = e.slotTargetingValues || {}, e.slotTargetingValues.slot = e.slotContainer.replace("div-gpt-", ""), g(e.slotTargetingValues, e)
            },
            vars: {
                standardTypes: i
            }
        }
    }(), n.utilities = function() {
        "use strict";
        const i = e.location.hostname,
            o = i.split("."),
            r = o.length,
            s = e.location.pathname;

        function l(e, t) {
            t = t || "abbr";
            let n, a, s = e = e || c();
            const l = {
                allpeoplequilt: "apq",
                agriculture: "ag",
                bestlifeonline: "bestlife",
                dailypaws: "dp",
                eatingwell: "ew",
                fitnessmagazine: "fitness",
                midwestliving: "mwl",
                marthastewart: "mslo",
                marthastewartweddings: "msw",
                rachaelray: "rachaelraycom",
                rachaelraymag: "rrmag",
                siempremujer: "sm",
                serpadres: "sp",
                woodmagazine: "wood",
                cookinglight: "ckl",
                coastalliving: "col",
                departures: "dep",
                ew: "enw",
                foodandwine: "fw",
                health: "hlt",
                instyle: "ins",
                myrecipes: "mre",
                people: "peo",
                peopleenespanol: "pesp",
                realsimple: "rsm",
                southernliving: "sol",
                travelandleisure: "tl"
            };
            return "abbr" === t ? (l.hasOwnProperty(e) && (s = l[e]), -1 !== i.indexOf("allrecipes") ? (n = r > 2 ? o[0] : null, a = o.slice(-1)[0], {
                qc: "arqc",
                ew: "eatingwell"
            } [n] || {
                ca: "arqc",
                uk: "aruk",
                au: "arau"
            } [a] || "ar") : s) : (m(l, (function(t) {
                e === l[t] && (s = t)
            })), s)
        }

        function c() {
            const e = n.urlVars.get("adTestSite"),
                t = o.slice(-2, -1)[0];
            if (e) return l(e.split(".")[0]);
            switch (t) {
                case "com":
                case "co":
                    return o.slice(-3, -1)[0];
                case "themarthablog":
                    return "marthastewart";
                case "soundst":
                    return o[0]
            }
            return t || "default"
        }

        function d(e, t) {
            return t = t || ["local", "dev", "test", "www"], "string" != typeof e || -1 !== t.indexOf(e)
        }

        function u(e) {
            return "string" == typeof e && ("true" === e || "false" === e || "" === e) || null == e ? "true" === e || !1 : e
        }

        function g(e) {
            return parseInt(e, 10)
        }

        function f(e, t) {
            return t && m(t, (function(n) {
                try {
                    t[n].constructor === Object ? e[n] = f(e[n], t[n]) : e[n] = t[n]
                } catch (i) {
                    e[n] = t[n]
                }
            })), e
        }

        function p(e) {
        }
        const h = e.localStorage;
        try {
            h.setItem("mdpTest", "1"), h.removeItem("mdpTest"), D.isLocalStorageAvailable = !0
        } catch (e) {
            D.isLocalStorageAvailable = !1
        }

        function m(e, t) {
            (e = p(e) ? Object.keys(e) : e).forEach(t)
        }

        function b() {}
        return {
            cleanCharacters: function e(t) {
                let n = "",
                    i = !1;
                return null == t ? n = "" : Array.isArray(t) ? (n = [], m(t, (function(t, i) {
                    n[i] = e(t)
                }))) : "string" == typeof t ? (n = t.replace(/[?'"=!#+*~;^()<>[\],&\s]/gi, ""), i = !0) : "number" != typeof t && "boolean" != typeof t || (n = String(t)), i && t !== n && a('Targeting value "' + t + '" was incorrectly formatted, so KARMA changed it to "' + n + '"', {
                    level: "warn",
                    force: !0
                }), n
            },
            clone: function e(t) {
                let n = t;
                return p(t) && (n = Object.create(t.constructor.prototype), m(t, (function(i) {
                    n[i] = e(t[i])
                }))), n
            },
            coerceType: function(e) {
                return "string" == typeof e ? e.match(/^[0-9]+$/) ? g(e) : u(e) : e
            },
            convertQueryStringToObject: function(e, t) {
                e = decodeURIComponent(e), t = void 0 === t || t;
                const n = {};
                return e.replace(/[?&]?([^=&]+)=([^&]*)/gi, (function(e, i, o) {
                    t ? n[i.toLowerCase()] = o : n[i] = o
                })), n
            },
            convertStringToBoolean: u,
            convertStringToNumber: g,
            createEvent: function(e) {
                let t;
                try {
                } catch (i) {
                    t = n.polyfills.createCustomEvent(e)
                }
                return t
            },
            debounce: function(e, t, n) {
                let i;
                return function() {
                        r = arguments,
                        a = n && !i;

                    function s() {
                        i = null, n || e.apply(o, r)
                    }
                    clearTimeout(i), i = setTimeout(s, t), a && e.apply(o, r)
                }
            },
            doLoop: m,
            extend: f,
            fetchJson: function(e, t, n) {
                let i = !1;

                function o() {
                    i = !0, a("XMLHttpRequest initialization error", {
                        level: "error",
                        force: !0
                    }), "function" == typeof n && n()
                }
                "withCredentials" in r ? (r.open("GET", e, !0), r.onloadend = function() {
                    if (404 !== r.status) {
                        e && 0 === Object.keys(e).length && e.constructor === Object ? o() : t(e, r.getAllResponseHeaders())
                    } else o()
                }, i || (r.onerror = o, r.send())) : o()
            },
            fetchResource: function(e, t, i, o, r) {
                t = t || b, i = i || b, o = o || "script", r = r || !1;
                const a = function() {
                    return null !== e && e.length >= 2 && e[1]
                }();
                let s = {
                    src: e
                };
                "9.0" !== a && "10.0" !== a && (s.onload = s.onreadystatechange = function() {
                    e && "complete" !== e && "loaded" !== e && i();
                    try {
                        t()
                    } catch (e) {
                        i(e)
                    }
                }, s.onerror = i), r && (s = f(s, r)), n.dom.create(o, D.els.head, s)
            },
            getBreakpoint: function(t) {
                const n = V.breakpoints;
                let i, o = "base",
                    r = 0;
                return n.hasOwnProperty("base") || (n.base = 0), i = t ? t.filter((function(e) {
                    return n.hasOwnProperty(e)
                })) : Object.keys(n), m(i.filter((function(t) {
                    return n[t] <= e.innerWidth
                })), (function(e) {
                    n[e] >= r && (r = n[e], o = e)
                })), o
            },
            getCookie: function(e) {
                    force: !0,
                    level: "warn"
                }), !1;
                const n = e + "=";
                let i;
                return m(decodeURIComponent(t.cookie).split(";"), (function(e) {
                    for (;
                        " " === e.charAt(0);) e = e.substring(1);
                    0 === e.indexOf(n) && (i = e.substring(n.length, e.length))
                })), i
            },
            getEnv: function() {
                const e = n.urlVars.get("adTestEnv"),
                    t = !!d(e) && e;
                if (t) return t;
                if (r < 3) return "www";
                const i = r > 2 ? o[0] : "www";
                return -1 !== ["dev", "localhost", "local"].indexOf(i) || r >= 2 && "betasites" === o[2] ? "dev" : "test" === i ? "test" : "www"
            },
            getKarmaScript: function(e, t) {
                e = e || "footer", t = t || !1;
                const i = n.dom.lookup('script[src*="karma.mdpcdn.com"]', !0, !0),
                    o = /^http(?:s)?:\/\/([^.]*)\.?karma\.mdpcdn\.com[:9]*\/service\/(js|js-min)\/(karma(.*))$/;
                let r, a, s = i.length;
                if (D.scriptPath && D.scriptPath.length > 0) return D.scriptPath.match(o);
                for (; s--;)
                    if (a = i[s], r = a.src.match(o), null !== r && t === (a.dataset && "true" === a.dataset.reloaded)) return r;
                return null
            },
            getSiteName: c,
            getSite: l,
            incrementPageCount: function() {
                const e = D.targetingStorage.pv++;
            },
            incrementizeBid: function(e, t, n) {
                let i;
                const o = t[0].low,
                    r = t[t.length - 1].high;
                return m(t, (function(t) {
                    e >= t.low && e <= t.high && (i = function(e, t, n) {
                        let i;
                        return i = n ? Math.floor(e / t) + 1 : Math.round(e / t), i * t
                    }(e, t.increment, n))
                })), i || (0 === e ? i = 0 : e < o ? i = o : e > r && (i = r)), Math.floor(i)
            },
            isHomepage: function() {
                return "/" === s && null !== /^www|dev|test|allrecipes|local|bestlifeonline|eatthis|eatingwell$/.test(o[0])
            },
            isIE: function() {
            },
            isObject: p,
            isValidEnv: d,
            randomPercentage: function(e) {
                return Math.random() < e / 100
            },
            referrerIsAmp: function() {
                const e = t.referrer.match(/^https?:\/\/(?:cdn\.ampproject\.org\/.\/)?(?:test\.|dev\.)?amp\.([a-z]+)\.com/);
                return null !== e && e[1] === c()
            },
            setAndCheckLocalStorageVars: function() {
                const e = Date.now(),
                    t = D.targetingStorage;
                let n = !1;
            },
            tryCatch: function(t, n) {
                try {
                    t()
                } catch (t) {
                    n ? n(t) : e.console.error(t)
                }
            },
            noop: b
        }
    }(), s = n.utilities.cleanCharacters, l = n.utilities.clone, c = n.utilities.coerceType, d = n.utilities.convertQueryStringToObject, u = n.utilities.convertStringToBoolean, g = n.utilities.convertStringToNumber, f = n.utilities.createEvent, p = n.utilities.debounce, h = n.utilities.doLoop, m = n.utilities.extend, b = n.utilities.fetchJson, y = n.utilities.fetchResource, v = n.utilities.getBreakpoint, S = n.utilities.getCookie, k = n.utilities.getEnv, w = n.utilities.getKarmaScript, T = n.utilities.getSiteName, C = n.utilities.getSite, E = n.utilities.incrementPageCount, I = n.utilities.incrementizeBid, O = n.utilities.isHomepage, M = n.utilities.isIE, P = n.utilities.isObject, R = n.utilities.isValidEnv, A = n.utilities.referrerIsAmp, L = n.utilities.noop, z = n.utilities.setAndCheckLocalStorageVars, _ = n.utilities.tryCatch, q = n.utilities.randomPercentage, n.targeting = n.targeting || {}, n.targeting.adunit = function() {
        "use strict";
        const e = ["money", "si", "fansided"];
        let t, i, r, a, c;

        function d() {
            var t;
            return i && (V.site = i), n.urlVars.urlContainsEmail() && (V.site = "email.mdp.com"), V.site = V.site && V.site.length > 0 ? V.site : [c].concat(function(e) {
                return e && e.length > 0 ? ["mdp", o ? "mob" : "com"] : []
            }(c)).join("."), t = V.site, e.filter((function(e) {
                return 0 === t.indexOf(e + ".mdp.")
            })).length && (V.site = "deactivated." + V.site), V.site
        }

        function u(e) {
            let t = [],
                i = l(a);
            return e && n.slots.isLazy(e) && (i = m(i, e.slotTargetingValues)), t.push(e && e.tierString ? e.tierString : "tier0"), t.push("" !== i.type ? i.type : "none"), i.channel && t.push(i.channel), t = t.map(s), (t.length > 0 ? "/" : "") + t.join("/")
        }
        return {
            build: function(e) {
                return r + u(e)
            },
            buildTop: function() {
                return r
            },
            buildSub: u,
            getTopLevelAdUnit: d,
            getVideoAdUnit: function() {
                return "/" + [V.networkCode, c + ".mdp.video" + (o ? ".mob" : "")].join("/") + u()
            },
            init: function() {
                t = n.urlVars.isTrue("adTest") ? "test." : "", i = null !== n.urlVars.get("adTestSite") && n.urlVars.get("adTestSite"), c = C(), r = V.networkCode + "/" + t + d(), a = V.targeting || {}, V.site = s(V.site)
            }
        }
    }(), n.bidz = function() {
        "use strict";
        let e, t;
        const i = [{
            low: 5,
            high: 999,
            increment: 5
        }, {
            low: 1e3,
            high: 1999,
            increment: 10
        }, {
            low: 2e3,
            high: 999999,
            increment: 25
        }];

        function o(t) {
            let o = function(e) {
                const t = function(e) {
                    if (void 0 === e) return !1;
                    const t = n.gpt.getSlotTargeting(e),
                        i = [];
                    let o, r;
                    return h(t, (function(e) {
                        o = t[e][0], r = !!o && function(e, t) {
                            const n = {
                                rpfl_12738: function(e) {
                                    return e.replace(/\d+_tier(\d+)/, "$1")
                                },
                                IOM: function(e) {
                                    return e.replace(/\d+x\d+_(\d+)/, "$1")
                                }
                            };
                            return n.ix_apnx_om = n.IOM, n.ix_pubm_om = n.IOM, n.ix_ox_om = n.IOM, n.ix_trstx_cpm = n.IOM, !(!n.hasOwnProperty(e) || (t = g(n[e](t)), isNaN(t))) && {
                                key: e,
                                value: t
                            }
                        }(e, o), !1 !== r && i.push(r)
                    })), i
                }(e);
                if (t.length > 0) {
                    const n = t.map((function(e) {
                        return e.value
                    })).sort((function(e, t) {
                        return t - e
                    }));
                    return e.bids = t, n.shift()
                }
            }(t) || 0;
            return o > 0 && (o *= e / 100 + 1), o = Math.floor(100 * o) / 100, I(o, i, !0)
        }
        return {
            setFloors: function(i) {
                e && t && h(i, (function(e) {
                    n.partner.isAnyPartnerEnabledOnSlot(e) && function(e) {
                        const t = o(e),
                            i = function(e) {
                                const t = n.gpt.getSlotTargeting(e);
                                return t.amznbid && t.amznbid[0] && t.amznbid[0].length > 1 ? 1 : 0
                            }(e) || (0 === t ? 0 : 1);
                        n.targeting.set("bz", function(e) {
                            const t = String(e),
                                n = t.length;
                            return 1 === n ? "00" + t : 2 === n ? "0" + t : t
                        }(t), e), n.targeting.set("bzr", i, e)
                    }(e)
                }))
            },
            init: function() {
                const n = function() {
                    const e = new Date,
                        t = new Date,
                        n = e.getTimezoneOffset() / 60,
                        i = V.bidzDayPartOverride || [];
                    let o = -1;
                    t.setMonth(0);
                    const r = 5 - (t.getTimezoneOffset() / 60 - n);
                    e.setHours(e.getHours() + (n - r));
                    const a = e.getHours();
                    return h(i, (function(e) {
                        a >= e.start && a < e.end && (o = e.percentage)
                    })), o
                }();
                return V.bidzEnabled = V.bidzEnabled && (!!V.header_tag_managerEnabled || !!V.a9Enabled), t = V.bidzEnabled, e = n >= 0 ? n : parseInt(V.bidzPercentage, 10) || 0, a("bidz enabled: " + t + "; percentage: " + e + "%"), e
            }
        }
    }(), n.callbacks = function() {
        "use strict";
        const e = [];
        let t;

        function i() {
            V.callback = {
                push: r
            }
        }

        function o(t) {
            "function" == typeof t ? (n.gpt.addCallback(t), e.push(t)) : a("karma.config.callback.push(fn): Not a valid function.", {
                force: !0,
                level: "error"
            })
        }

        function r(e) {
            t = t || [], "function" == typeof t && (a("karma.config.callback has been overwritten as a function. It should be an array. Please stop it", {
                force: !0,
                level: "error"
            }), i(), r(t)), Array.isArray(t) && o(e)
        }
        return {
            init: function() {
                t = V.callback, t && (t = "function" != typeof t ? t : [t], Array.isArray(t) ? h(t, o) : a("karma.config.callback is defined but is not an array of functions. Ignoring callback.", {
                    force: !0,
                    level: "error"
                })), i()
            },
            getCallbackArray: function() {
                return e
            },
            add: r
        }
    }(), n.calvera = function() {
        function e() {
            return "mdextest" !== V.targeting.abTest && (V.calveraEnabled = !1), V.calveraEnabled
        }
        return {
            load: function() {
                if (e()) {
                    const e = "//" + ("www" !== n.utilities.getEnv() ? "qa-" : "") + "cdn.polaris.me/cva/local-offers/c/" + V.site.split(".")[0] + "-calvera.js";
                    y(e, (function() {
                        a("Calvera script loaded. (" + e + ") ")
                    }), (function() {
                        a("Failed to fetch Calvera's script.", {
                            level: "error",
                            force: !0
                        }), V.calveraEnabled = !1
                    }))
                }
            },
            isEnabled: e
        }
    }(), n.config = n.config || {}, n.config.slots = function() {
        "use strict";
        const e = {},
            t = [],
            i = [{
                slotContainer: "div-gpt-leaderboard-flex",
                slotType: "leaderboard",
                slotSizes: ["728x90", "970x90", "970x250"],
                a9: !0,
                a9Sizes: [
                    [728, 90]
                ],
                header_tag_manager: !0,
                ixSizes: ["728x90", "970x250"]
            }, {
                slotContainer: "div-gpt-leaderboard-fixed",
                slotType: "leaderboard",
                slotSizes: ["728x90"],
                a9: !0,
                a9Sizes: [
                    [728, 90]
                ],
                header_tag_manager: !0,
                ixSizes: ["728x90"]
            }, {
                slotContainer: "div-gpt-square-flex",
                slotType: "square",
                slotSizes: ["300x250", "299x251", "300x600", "300x1050"],
                a9: !0,
                a9Sizes: [
                    [300, 250],
                    [300, 600]
                ],
                header_tag_manager: !0,
                ixSizes: ["300x250", "300x600", "300x1050"]
            }, {
                slotContainer: "div-gpt-square-fixed",
                slotType: "square",
                slotSizes: ["300x250", "299x251"],
                a9: !0,
                a9Sizes: [
                    [300, 250]
                ],
                header_tag_manager: !0,
                ixSizes: ["300x250"]
            }, {
                slotContainer: "div-gpt-halfPage-fixed",
                slotType: "halfPage",
                slotSizes: ["300x600"]
            }, {
                slotContainer: "div-gpt-halfPage-flex",
                slotType: "halfPage",
                slotSizes: ["300x250", "299x251", "300x600"],
                a9: !0,
                a9Sizes: [
                    [300, 250],
                    [300, 600]
                ]
            }, {
                slotContainer: "div-gpt-interstitial",
                slotType: "interstitial",
                outOfPage: !0
            }, {
                slotContainer: "div-gpt-wallpaper",
                slotType: "wallpaper",
                outOfPage: !0
            }, {
                slotContainer: "div-gpt-skyscraper",
                slotType: "skyscraper",
                slotSizes: ["160x600"],
                header_tag_manager: !0,
                ixSizes: ["160x600"]
            }, {
                slotContainer: "div-gpt-related",
                slotType: "related",
                slotSizes: ["1x6"]
            }, {
                slotContainer: "div-gpt-sponsorLogo",
                slotType: "sponsorLogo",
                slotSizes: ["122x34", "120x75"]
            }, {
                slotContainer: "div-gpt-fluid",
                slotType: "fluid",
                slotSizes: ["fluid"]
            }, {
                slotContainer: "div-gpt-mob-square-fixed",
                slotType: "mob-square",
                slotSizes: ["300x250", "299x251", "fluid"],
                a9: !0,
                a9Sizes: [
                    [300, 250]
                ],
                header_tag_manager: !0,
                ixSizes: ["300x250"],
                isMobile: !0
            }, {
                slotContainer: "div-gpt-mob-square-flex",
                slotType: "mob-square",
                slotSizes: ["300x250", "299x251", "320x100", "320x200", "fluid"],
                a9: !0,
                a9Sizes: [
                    [300, 250]
                ],
                isMobile: !0,
                header_tag_manager: !0,
                ixSizes: ["300x250"]
            }, {
                slotContainer: "div-gpt-mob-banner-fixed",
                slotType: "mob-banner",
                slotSizes: ["320x50", "319x51"],
                a9: !0,
                a9Sizes: [
                    [300, 250]
                ],
                header_tag_manager: !0,
                ixSizes: ["320x50"],
                isMobile: !0
            }, {
                slotContainer: "div-gpt-mob-banner-flex",
                slotType: "mob-banner",
                slotSizes: ["320x50", "319x51"],
                a9: !0,
                a9Sizes: [
                    [320, 50]
                ],
                header_tag_manager: !0,
                ixSizes: ["320x50"],
                isMobile: !0
            }, {
                slotContainer: "div-gpt-mob-adhesive-banner-fixed",
                slotType: "mob-adhesive-banner",
                slotSizes: ["320x50", "319x51"],
                a9: !0,
                a9Sizes: [
                    [320, 50]
                ],
                header_tag_manager: !0,
                ixSizes: ["320x50"],
                isMobile: !0
            }, {
                slotContainer: "div-gpt-mob-related",
                slotType: "related",
                isMobile: !0,
                slotSizes: ["320x175"]
            }, {
                slotContainer: "div-gpt-mob-sponsorLogo",
                slotType: "sponsorLogo",
                isMobile: !0,
                slotSizes: ["122x34", "120x75"]
            }, {
                slotContainer: "div-gpt-mob-fluid",
                slotType: "fluid",
                isMobile: !0,
                slotSizes: ["fluid"]
            }, {
                slotContainer: "div-gpt-leaderboard-responsive",
                slotType: "leaderboard-responsive",
                a9: !0,
                a9Sizes: [
                    [300, 250]
                ],
                responsiveA9Sizes: {
                    desktop: [
                        [728, 90]
                    ]
                },
                responsive: !0,
                slotSizes: ["300x250"],
                responsiveSlotSizes: {
                    desktop: ["728x90"]
                }
            }];
        return {
            build: function(o, r) {
                const s = {};
                let l, c, d;
                return "object" == typeof o && h(o, (function(o) {
                    d = n.tiers.getFromType(o) || null, c = o.split(":tier")[0], l = function(e) {
                        const t = i.filter((function(t) {
                            return e === t.slotContainer || -1 !== e.indexOf(t.slotContainer + "-")
                        }));
                        return 0 === t.length ? (a('Slot placeholder id "' + e + '" is not a valid KARMA ad slot.', {
                            force: !0,
                            level: "error",
                            doc: "slot-catalog"
                        }), !1) : m({}, t[0])
                    }(c), !1 !== l && (l.slotContainer = c, null !== d && n.tiers.setTierSettings(d, l, r), e.hasOwnProperty(l.slotContainer) || (t.push(l), e[l.slotContainer] = !0))
                })), s.adSlots = t, s.lazySlots = function(e, t) {
                    const n = [];
                    return h(e, (function(e) {
                        e.hasOwnProperty("site") && e.site !== t && -1 === e.site.indexOf(t) || ((e = m({}, e)).type = e.slotContainer, e.lazyType = e.type.replace("div-gpt", "div-gpt-lazy"), delete e.slotContainer, n.push(e))
                    })), n
                }(i, r), s
            }
        }
    }(), n.config = n.config || {}, n.config.storage = function() {
        "use strict";

        function e() {
        }
        return {
            check: function(t, n, i) {
                let o, r;
                if (D.isLocalStorageAvailable && s) {
                    try {
                        o = JSON.parse(s)
                    } catch (e) {
                        o = !1, a("Unable to parse stored config: localStorage.mdpKarmaConfig", {
                            force: !0
                        })
                    }
                    return P(o) && (o.adDomain === t && o.env === n ? o.version !== i ? (a("localStorage Config Found, but the version number is out of date. Removing cached version."), e()) : o.expires >= Date.now() ? r = o : (a(void 0 + "localStorage Config Found, but it's expired. Removing cached version."), e()) : (a("localStorage Config Found, but it's for another site or environment. Removing it."), e())), !(!r || !P(r)) && r
                }
            },
            set: function(e, t, n) {
            }
        }
    }(), n.debug = function() {
        "use strict";
        D.debug = !1;
        const t = e.console;

        function i(t) {
            "true" !== t && "log" !== t || (D.debug || (D.debug = !D.debug), e.karmads = n, D.queueExecuted && o())
        }

        function o() {
            const e = D.logObject;
            return h(e, (function(t) {
                r(e[t].consoleMessage, e[t].level)
            })), e
        }

        function r(e, n) {
            switch (e = "%c--KARMA " + (n = n || "log").toUpperCase() + ("warn" === n ? "ING" : "") + ": " + e, n) {
                case "error":
                    t.error(e, "font-size:14px;color:red");
                    break;
                case "warn":
                    t.warn(e, "font-size:14px;color:darkgoldenrod");
                    break;
                default:
                    t.log(e, "font-size:12px;color:green")
            }
        }
        return {
            init: i,
            showLog: o,
            consoleLog: function(e, n, i) {
                i && (e += " http://" + ("www" !== D.environment ? "dev." : "") + "karma.mdpcdn.com/docs/dev/#" + i), t && r(e, n)
            },
            publicDebug: function() {
                i("true")
            }
        }
    }(), n.deferred = function() {
        "use strict";
        return {
            init: function(t, o) {
                const r = [];
                let a = [];
                return "complete" !== o && V.useDeferred ? (h(t, (function(e) {
                    e.deferred ? r.push(e) : a.push(e)
                })), i.slots.deferred = r, r.length > 0 && e.addEventListener("load", (function() {
                    setTimeout((function() {
                        n.requestQueue.process(i.slots.deferred, !1, !1), i.slots.deferred = []
                    }), 500)
                }))) : a = t, a
            }
        }
    }(), n.docking = n.docking || {}, n.docking.leaderboard = function() {
        let i, o, r, s, l, c, d, p, m, b, y, v, S, k, w, T, C, x, E, I, O, P, R, L, A, z, _, q, M, N, j, H, B, F, U, K, Y, G;

        function Q() {
            return V.docking = V.docking || {}, O = V.docking.leaderboard || {}, "boolean" != typeof S && (S = u(O.enabled)), V.isMobile && (S = !1), S && O.hasOwnProperty("disableSmallScreen") && O.disableSmallScreen && e.innerWidth <= 1024 && (S = !1), S
        }

        function J() {
            Q() && (Y = !L && "docked" !== w && k - A - m < e.pageYOffset, G = "docked" === w && k - A - m >= e.pageYOffset, Y ? (n.docking.rail.leaderboardEventHandler("leaderboardDocked"), h(v, (function(e) {
                e.classList.add(p)
            })), H.dispatchEvent(M), w = "docked", C && !R && (R = !0, P = new function(t, n) {
                let i, o = n;
                    e.clearTimeout(E), o -= new Date - i, a("Rollup timer paused! " + o + " remaining")
                    i = new Date, e.clearTimeout(E), E = e.setTimeout(t, o), a("Rollup timer resumed!")
            }((function() {
                L = !0, "docked" === w ? X(!0) : ee()
            }), d), B.addEventListener("mouseover", P.pause), B.addEventListener("mouseout", P.resume))) : G && X())
        }

        function W() {
            return 0 !== T && T <= 90
        }

        function Z() {
            function e() {
                h(["touchstart", "touchmove", "touchend", "scroll"], (function(e) {
                    t.addEventListener(e, J)
                }))
            }
            if (V.docking = V.docking || {}, O = O || V.docking.leaderboard || {}, D.leaderboardInitialState = O.enabled || !1, E = null, d = 0, k = 0, v = [], I = [], R = !1, L = !1, w = "undocked", S = Q(), !S) return;
            let P, Y;
            i = O.additionalLogic || [], o = O.backgroundOpacity || ".7", r = O.backgroundRGB || "255,255,255", s = O.dockingElementSelector || "", l = O.zIndex || 595, c = O.customStyles || "", p = O.dockedClass || "docked", m = g(O.offset) || 0, C = u(O.rollUp) || !1, x = g(O.rollUpMs) || 1e4, A = g(O.topMargin) || 0, z = g(O.transitionMs) || 1e3, _ = u(O.useCSS) || !0, q = u(O.useDefaultHeight) || !1, H = t.body, B = O.dockingElementSelector ? n.dom.lookup(O.dockingElementSelector) : null, F = O.belowBannerSelector ? n.dom.lookup(O.belowBannerSelector) : null, U = O.siteContainerSelector ? n.dom.lookup(O.siteContainerSelector) : null, K = null, M = f("leaderboard_docked"), N = f("leaderboard_undocking"), j = f("leaderboard_undocked"), C && !isNaN(g(x, 10)) && (d = x), B && F && U ? S = S && n.docking.processAdditionalLogic(i) : (a("Missing element for leaderboard docking. Disabling.", {
                force: !0,
                level: "warn",
                doc: "karma-docking"
            }), S = !1), V.docking.leaderboard && (V.docking.leaderboard.enabled = S), Q() && (a("initializing docking banner..."), Y = B.offsetHeight, K = n.dom.create("div", F.parentElement, {
                id: "docking-banner-placeholder"
            }, F), v = function() {
                const e = [B, K];
                return null !== U && e.push(U), h(I, (function(t) {
                    e.push(n.dom.lookup(t, !0, !0))
                })), e
            }(), _ && (P = s + "{position:relative;top:0;z-index:" + l + ";}#" + K.id + "{height:0;width:100%;background-color:rgb(" + r + ")}#" + K.id + "." + p + "{height:" + Y + "px}" + (q ? "." + p + " #div-gpt-leaderboard-flex-1{min-height:100px;padding:5px 0;box-sizing:border-box}" : "") + "#div-gpt-leaderboard-flex-1{text-align:center;overflow:hidden;box-sizing:border-box;position:relative;left:0;width:100%;top:0;}" + s + "." + p + "{position:fixed;background:rgba(" + r + "," + o + ");top:" + A + "px;left:0;right:0;width:100%;" + (q ? "height: 100px" : "") + "}" + s + ".undocking{top:-" + (Y + 20) + "px;transition:top 1s;z-index:" + l + ";}" + c, n.docking.appendStyleSheetCss(P)), null !== B && (k = B.offsetTop, y = n.dom.lookup('div[id^="div-gpt-leaderboard"]', !1, !1, B) || {}, b = y.id, n.gpt.addCallback((function(t) {
                const i = t.slot.getSlotId().getDomId();
                i === b && (function(e, t) {
                    const i = n.slots.getById(t);
                    let o;
                    return Array.isArray(e.size) ? T = e.size[1] : (o = n.dom.lookup('div[id^="google_ads_iframe"]', !1, !1, n.dom.get(i)), T = null !== o ? o.offsetHeight : 0), !(e.isEmpty || !W())
                }(t, i) ? !Q() && D.leaderboardInitialState ? (te(), e()) : Q() && (e(), J()) : $("sizeCheck"))
            }))))
        }

        function X(t) {
            function i() {
                B.classList.remove(p), h(v, (function(e) {
                    e !== B && e.classList.remove(p)
                })), C && L && ee(), w = "undocked", H.dispatchEvent(j), B.classList.remove("undocking")
            }
            H.dispatchEvent(N), t ? (w = "undocking", B.classList.add(w), n.docking.rail.leaderboardEventHandler("leaderboardUndocked", !0), e.setTimeout(i, z)) : (n.docking.rail.leaderboardEventHandler("leaderboardUndocked"), i())
        }

        function $(e) {
            if (Q()) {
                if (S = !1, V.docking.leaderboard.enabled = !1, D.leaderboardReleasedBy = e, "docked" !== w) return void ee();
                X()
            }
        }

        function ee() {
            h(["touchstart", "touchmove", "touchend", "scroll"], (function(e) {
                t.removeEventListener(e, J)
            })), e.clearTimeout(E), R && (B.removeEventListener("mouseover", P.pause), B.removeEventListener("mouseout", P.resume)), P = null
        }

        function te() {
            D.leaderboardInitialState && !Q() && W() ? (S = !0, V.docking.leaderboard.enabled = !0, Z(), J()) : a("Attempted to start leaderboard docking, but could not due to initial enabled state, or current leaderboard size.")
        }
        return {
            getPosition: function() {
                return w
            },
            getBannerSelectorHeight: function() {
                if (S) {
                    let e;
                    const n = B.clientHeight;
                    return e = t.all ? parseInt(B.currentStyle.marginTop, 10) + parseInt(B.currentStyle.marginBottom, 10) : parseInt(t.defaultView.getComputedStyle(B, "").getPropertyValue("margin-top"), 10) + parseInt(t.defaultView.getComputedStyle(B, "").getPropertyValue("margin-bottom"), 10), n + e
                }
                return 0
            }
        }
    }(), n.docking = n.docking || {}, n.docking.rail = function() {
        "use strict";
        const i = /karma-sticky-(top|stuck|bottom)/,
            o = "Disabling rail docking: ",
            r = {};
        let s, l, c = [],
            d = e.innerHeight;

        function g() {
            return n.dom.lookup(".karma-sticky-grid", !0).length > 0
        }

        function f(r, l) {
            try {
                const u = [];
                        let t = 0,
                            n = 100;
                        level: "warn",
                        doc: "karma-docking"
                        doc: "karma-docking"
                        level: "warn",
                        doc: "karma-docking"
                        level: "warn",
                        doc: "karma-docking"
                }
                        force: !0,
                        level: "warn",
                        doc: "karma-docking"
                    className: "karma-docking-rail-placeholder",
                    styles: "margin:0;height:0;"
            } catch (e) {
                a("Rail Docking: " + e.toString(), {
                    level: "error",
                    force: !0
                })
            }
        }

        function p() {
            h(c, (function(e) {
                e.enabled && e.check()
            }))
        }

        function m() {
            return V.docking = V.docking || {}, l = V.docking.rail || {}, "boolean" != typeof s && (s = u(l.enabled)), s
        }

        function b() {
            if (!m()) return;
            l = V.docking.rail || {}, e.addEventListener("orientationchange", (function() {
                d = e.innerHeight
            })), h(["touchstart", "touchmove", "touchend", "scroll"], (function(e) {
                t.addEventListener(e, n.docking.rail.checkAll)
            }));
            let i, r = g() ? n.dom.lookup(l.railSelector, !0, !0) || [] : n.dom.lookup(l.contentContainerSelector, !0, !0) || [],
                u = 0;
            g() || l.multi || (r = r[0] ? r[0] : []), 0 === r.length ? a(o + "Missing DOM Element contentContainer, selector: " + l.contentContainerSelector, {
                level: "error",
                doc: "karma-docking"
            }) : h(r, (function() {
                i = new f(l, u), i.enabled && c.push(i), u++
            })), 0 === c.length && (s = !1), V.docking.rail.enabled = s
        }

        function y(e, t) {
            r.event = e, r.useTransition = t, m() && h(c, (function(t) {
                switch (e) {
                    case "leaderboardDocked":
                        t.offset += t.leaderboardHeight, t.dockingElement.classList.add("dockedLeaderboard");
                        break;
                    case "leaderboardUndocked":
                        t.offset -= t.leaderboardHeight, t.useTransition ? (t.dockingElement.classList.add("undockingLeaderboard"), setTimeout((function() {
                            t.dockingElement.classList.remove("undockingLeaderboard"), t.dockingElement.classList.remove("dockedLeaderboard")
                        }), 1e3)) : t.dockingElement.classList.remove("dockedLeaderboard")
                }
            })), p()
        }
        return {
            init: b,
            checkAll: p,
            disableAllRails: function() {
                h(c, (function(e) {
                    e.enabled && (e.releaseAtTop(), e.disable()), s = !1, V.docking.rail.enabled = !1
                }))
            },
            isGrid: g,
            getRails: function() {
                return c
            },
            isEnabled: m,
            leaderboardEventHandler: y,
            rebuildRails: function() {
                if (s) {
                    c = [];
                    const e = n.dom.lookup(".karma-docking-rail-placeholder", !0, !0);
                    h(e, (function(e) {
                        e.parentNode.removeChild(e)
                    })), b(), c.length > 0 && "top" !== c[0].pos && y(r.event, r.useTransition), p()
                }
            }
        }
    }(), n.dom = function() {
        "use strict";

        function e(e) {
            return (e = "string" == typeof e ? n.slots.getById(e) : e) ? (e.dom || (e.dom = t.getElementById(e.slotContainer)), e.dom) : null
        }

        function o(t) {
            const n = e(t),
                i = !!n && !!(n.offsetWidth || n.offsetHeight || n.getClientRects().length);
            return t.isDisplayed = i, i
        }

        function s(e, n, i, o) {
            return n = n || !1, o = o || t, !(i = i || !1) && D.els.hasOwnProperty(e) || (D.els[e] = "#" === e.charAt(0) ? o.getElementById(e.substring(1)) : n ? o.querySelectorAll(e) : o.querySelector(e)), D.els[e]
        }
        return {
            isDisplayed: o,
            scrapeSlots: function(e) {
                const t = s('div[id^="div-gpt"]', !0),
                    i = [];
                let o, r, l;
                return h(t, (function(t) {
                    e && t.childNodes.length && (t.textContent = ""), l = t.dataset, r = l && n.tiers.isValidTier(l.tier) ? l.tier : 0, o = t.id + ":tier" + r, 0 === r && a("Slot " + o + ' does not have a valid data-tier attribute. <div id="' + o + '"' + (l.tier ? ' data-tier="' + l.tier + '"' : "") + ">. It will be requested as tier0.", {
                        force: !0,
                        level: "warn"
                    }), -1 === i.indexOf(o) && i.push(o)
                })), 0 === i.length && i.push("none"), i
            },
            get: e,
            create: function(e, n, i, o) {
                n = n || !1, o = o || !1;
                const r = t.createElement(e);
                return "object" == typeof i && h(i, (function(e) {
                    -1 !== e.indexOf("data-") ? r.setAttribute(e, i[e]) : r[e] = i[e]
                })), n && (o ? n.insertBefore(r, o) : n.appendChild(r)), r
            },
            lookup: s,
            ready: function(e) {
                let n = !1;

                function o(e, t) {
                    n || (n = !0, t && a(t + ", slot setup continuing"), e())
                }
                2 !== r ? V.bypassDOMReady || "loading" === t.readyState ? Array.isArray(i.cmd) && i.cmd.filter((function(e) {
                    return "go" === e
                })).length > 0 ? o(e, "Site already called go") : (V.go = function() {
                    o(e, "Site is calling go")
                }, V.bypassDOMReady || t.addEventListener("DOMContentLoaded", (function() {
                    o(e, "DOMContentLoaded firing")
                }))) : o(e, "DOMContentLoaded already triggered") : o(e)
            },
            remove: function(e) {
                return e.parentNode.removeChild(e)
            },
            getVisibleSlots: function(t) {
                const n = [];
                return h(t = t || [], (function(t) {
                    o(t) || t.outOfPage || function(t) {
                        const n = e(t).dataset,
                            i = n.karmaBypassVisibilityCheck,
                            o = u(i);
                        return void 0 !== i && "processed" !== i && (t.bypassVisibilityCheck = o, n.karmaBypassVisibilityCheck = "processed"), t.bypassVisibilityCheck || !1
                    }(t) ? n.push(t) : a("Did not request " + t.slotContainer + " because the container is not displayed.", {
                        force: !0,
                        level: "warn"
                    })
                })), n
            }
        }
    }(), n.gpt = function() {
        "use strict";
            t = !1;

        function o(e) {
        }

        function r(e) {
            l((function() {
            }))
        }

        function l(e) {
        }
        return {
            addCallback: function(e, t) {
                t = t || "slotRenderEnded", "function" == typeof e && l((function() {
                }))
            },
            clearPageTargeting: function(e) {
                l((function() {
                }))
            },
            clearSlotTargeting: function(e, t) {
                e && l(void 0 !== t ? function() {
                    e.gptSlot().clearTargeting(s(t))
                } : function() {
                    e.gptSlot().clearTargeting()
                })
            },
            define: function(e, t, i) {
                let o;
                            return t.getSlotElementId() === e
                        }));
                    return !!t.length && t[0]
                }, o
            },
            destroy: function(e) {
                e = Array.isArray(e) ? e : [e], l((function() {
                }))
            },
            display: r,
            displayAllSlots: function() {
                h(i.slots.catalog, (function(e) {
                    e.slotType && r(e.slotContainer)
                }))
            },
            enable: function() {
            },
            getSlotTargeting: function(e) {
                return e.gptSlot().getTargetingMap()
            },
            init: function() {
            },
            queuePush: l,
            refresh: function(e) {
                l((function() {
                }))
            },
            restrictDataProcessing: function(e) {
                (e = e || !1) && a("Restricting data processing in GPT", {
                    force: !0
                    restrictDataProcessing: e
                })
            },
            setNonPersonalizedAds: function(e) {
                (e = e || !1) && a("Enabling non-personalized ads in GPT", {
                    force: !0
            },
            setPageTargeting: function(e, t) {
                l((function() {
                }))
            },
            setPublisherProvidedId: o,
            setSlotTargeting: function(e, t, n) {
                void 0 !== e && !1 !== e && l((function() {
                    e.gptSlot().setTargeting(s(t), s(n))
                }))
            },
            setSlotTargetingMap: function(e, t) {
                void 0 !== e && !1 !== e && P(t) && l((function() {
                    e.gptSlot().updateTargetingFromMap(t)
                }))
            }
        }
    }(), n.kismet = function() {
        "use strict";
        return D.kismet = {
            checked: !1,
            reported: !1
        }, {
            report: function(e) {
                e = "string" == typeof e ? e : "spacer2", null !== n.dom.lookup('img[src$="kismet/' + e + '.png"]') || (y("/kismet/" + e + ".png", !1, !1, "img"), D.kismet.reported = !0)
            }
        }
    }(), n.log = function() {
        "use strict";
        let t = 0;
        const i = {},
            o = {},
            r = !!e.performance && "function" == typeof e.performance.now,

        function s(e, o) {
            "object" == typeof e ? e = (o = e).label || "" : o = o || {};
            const s = o.referencePoint || !1,
                l = o.report || !1,
                c = o.level ? o.level : "red" === o.color ? "error" : "log",
                u = !(!s || !i[s]) && d - i[s].timestamp,
                g = u ? " : " + s + " +" + u : "",
                f = !("range" !== l || !u) && function(e) {
                    const t = Math.floor(e / 100),
                        n = t === e / 100 ? 100 * t - 99 : 100 * t + 1;
                    return n + "-" + (n + 99)
                }(u),
                p = !(!o.label || e === o.label),
                h = o.force || !1,
                m = o.doc || !1,
                b = o.reportLabel || !1;
            t++;
            const y = o.label || "entry" + t;
            i[y] = {
                timestamp: d,
                referencePoint: s,
                eventDelta: u,
                eventDeltaMessage: g,
                consoleMessage: d + (p ? " : " + y : "") + " : " + e + g + (f ? " (" + f + ")" : ""),
                report: l,
                reportLabel: b,
                reported: !1,
                level: c
            }, (D.debug || h) && n.debug.consoleLog(e, c, m)
        }
        return D.logObject = i, {
            log: s,
            logPartnerEventOnce: function(e, t) {
                o[e] || (o[e] = !0, s(e, {
                    report: !0,
                    label: e,
                    referencePoint: t
                }))
            }
        }
    }(), a = n.log.log, n.methods = {
        init: function() {
            const e = {
                debug: n.debug.publicDebug,
                showLog: n.debug.showLog,
                log: n.log.log,
                init: n.timeline.init,
                createSlot: n.lazyLoad.create,
                fillSlots: n.lazyLoad.fill,
                destroySlot: n.slots.destroy,
                updateTargeting: n.targeting.setTargetingMap,
                getSlotById: n.slots.getById,
                getSlotCount: n.slots.getSlotCount,
                disableTimedRefreshOnSlot: n.refresh.timed.disableTimedRefreshOnSlot,
                reEnableTimedRefreshOnSlot: n.refresh.timed.reEnableTimedRefreshOnSlot,
                releaseDocking: n.docking.disableDocking,
                initDocking: n.docking.leaderboard.restart,
                report: n.reporting.segmentReport,
                isInView: n.viewability.isInView,
                refresh: n.refresh.startRefresh,
                setBypassViewabilityRequirement: n.viewability.setBypassViewabilityRequirement,
                purgeRefreshSlots: n.refresh.purgeSlots,
                rebuildRails: n.docking.rail.rebuildRails,
                resetVideoTargeting: n.video.resetTargeting,
                updateVideoTargeting: n.video.updateTargeting
            };
            h(e, (function(t) {
                i[t] = e[t]
            }))
        }
    }, n.muid = function() {
        function i() {
            let t = (new Date).getTime();
            return void 0 === e.performance && (t += e.performance.now()), "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                const n = (t + 16 * Math.random()) % 16 | 0;
                return t = Math.floor(t / 16), ("x" === e ? n : 3 & n | 8).toString(16)
            }))
        }
        const o = function() {
            let t = {
                setItem: L
            };
            try {
            } catch (e) {
                a(e, {
                    force: !0
                })
            }
            return t
        }();

        function r() {
            const e = {},
            for (let n = 0; n < t.length; n++) {
                const i = t[n].trim().split("=");
                i.length > 1 && "" !== i[1] && '""' !== i[1] && (e[i[0].trim()] = i[1].trim())
            }
            return e
        }

        function s() {
            "string" != typeof o.msg || D.msg || (D.msg = JSON.parse(o.msg))
        }

        function l() {
            if (n.urlVars.get("testMuid")) return n.urlVars.get("testMuid");
            if (e.globalTI && e.globalTI.session) return e.globalTI.session;
            return r["globalTI_SID"] || o.globalTI_SID || (a("Generating MUID from scratch", {
                force: !0
            }), i())
        }
        return {
            init: function() {
                const c = !!D.url.pixelDebug && u(D.url.pixelDebug),
                    d = "https://d9jj3mjthpub.cloudfront.net/x.gif",
                    g = e.location.hostname.toLowerCase(),
                    f = e.location.href,
                    p = t.referrer === f ? "" : t.referrer,
                    h = r();
                e.globalTI = e.globalTI || {};
                const m = h.globalTI_SID,
                    b = l();
                let v;
                m || function(e, t) {
                    o.setItem("globalTI_SID", t);
                    const n = new Date;
                    n.setTime(Date.now() + 63072e6);
                    const i = "; expires=" + n.toUTCString();
                }(0, b), e.globalTI.session = b, e.globalTI.request_id || (e.globalTI.request_id = i()), v || _((function() {
                    v = h.mdpaccount.match(/hashId":"([a-z0-9-]{20,})/i)[1]
                }), L), v || _((function() {
                    v = decodeURIComponent(h.monetate_profile).match(/hashId":"([a-z0-9-]{20,})/i)[1]
                }), L), v || '""' === h.hid || (v = h.hid);
                S = S && S[1] ? S[1] : null;
                const k = {
                    pulse: -1,
                    v: "l1.0",
                    type: "karma",
                    globalTI_SID: b,
                    hid: v,
                    request_id: e.globalTI.request_id,
                    url: f,
                    ref: p,
                    recipes_user_id: S,
                    host: g
                };
                e.globalTI.lite_capture = k;
                const w = [];
                let T;
                for (T in k) k.hasOwnProperty(T) && k[T] && '""' !== k[T] && w.push(T + "=" + encodeURIComponent(k[T]));
                var C;
                C = d + "?" + w.join("&"), a("Appending MUID pixel to the document"), n.dom.create("img", t.body, {
                    src: C,
                    height: "1",
                    width: "1"
                });
                const x = o.msg_date;
                (!x || (new Date).getTime() - x > 864e5) && delete o.msg, !o.msg && function(e) {
                    return "string" == typeof e && 36 === e.length && 5 === e.split("-").length
                }(b) ? y("https://qpsftq5jqg.execute-api.us-east-1.amazonaws.com/production/segments?muid=" + b, s) : s(), c && e.console && e.console.assert && (a("Pixel URL:" + d + "?" + w.join("&"), {
                    force: !0
                }), a("Pixel output Object", k, {
                    force: !0
                }), e.globalTI.request_id)
            },
            generateMuid: i,
            getMuid: l,
            getRequestId: function() {
                return e.globalTI && e.globalTI.request_id ? e.globalTI.request_id : (a("Generating Meredith Request Id from scratch", {
                    force: !0
                }), i())
            }
        }
    }(), n.partner = n.partner || {}, n.partner.a9 = function() {
        "use strict";
        D.a9 = {
            slots: {}
        };
        let i = [],
            o = !1;

        function r() {
                pubID: V.a9PubId,
                adServer: "googletag",
                videoAdServer: "DFP",
                deals: !0,
                params: {
                    aps_privacy: n.privacy.getCcpaConsentString(),
                    si_pagegroup: V.targeting.channel
                }
            })
        }

        function s(e) {
            const t = [],
                i = 1 === e.length && e[0].isPreroll;
            let r;
            var a;
            return i ? (e = e.splice(0, 1), r = []) : (h(e || D.a9.slots, (function(e) {
                e.a9Sizes = n.slots.getSizes(e, "A9") || [], t.push(e)
            })), r = t.map((function(e) {
                return {
                    slotID: e.slotContainer,
                    sizes: e.a9Sizes,
                    slotName: e.handle.hbSlotName
                }
            }))), a = i, V.a9PrerollEnabled & n.video.getVideoId() && (a || !o) && (o = !0, r.push({
                slotID: "preroll",
                mediaType: "video"
            })), r
        }

        function l(e) {
            return D.a9.slots[e] || !1
        }
        return {
            load: function() {
                ! function(e, t, n, i, o, r, a) {
                    function s(n, i) {
                        t[e]._Q.push([n, i])
                    }
                    t[e] || (t[e] = {
                        init: function() {
                            s("i", arguments)
                        },
                        fetchBids: function() {
                            s("f", arguments)
                        },
                        _Q: []
                    }, (r = n.createElement(i)).async = !0, r.src = "https://c.amazon-adsystem.com/aax2/apstag.js", (a = n.getElementsByTagName(i)[0]).parentNode.insertBefore(r, a))
                }("apstag", e, t, "script"), r()
            },
            init: r,
            fetchBids: function(e, t, o) {
                const r = n.partner.getTimeoutLengths(t);
                let c = !1,
                    d = !1;

                function u(e) {
                    let t;
                    h(e, (function(e) {
                        t = l(e.slotID), t && (t.a9Targeting = e.targeting, t.a9Targeting.size = e.size, t.a9Targeting.slotID = e.slotID)
                    }))
                }

                function g(e, t) {
                    switch (typeof t) {
                        case "undefined":
                            t = l(e.slotID);
                            break;
                        case "string":
                            t = l(t)
                    }
                    _((function() {
                    })), t && h(e.helpers.targetingKeys, (function(i) {
                        n.targeting.set(i, e.targeting[i], t)
                    }))
                }

                function f(e) {
                    return Array.isArray(e) ? e : (a("Unexpected data structure from a9. Ignoring response.", {
                        force: !0,
                        level: "warn"
                    }), [])
                }
                e = e.filter((function(e) {
                    return !0 === e.a9 || e.isPreroll
                })), a({
                    label: "a9FetchStart"
                }), h(e, (function(e) {
                    e.isPreroll || (delete e.a9Targeting, h(i, (function(t) {
                        n.targeting.clear(t, e)
                    })))
                })), a("starting a9 timeout: " + r.karmaEnforced), a("passing timeout to a9: " + r.partnerEnforced), _((function() {
                        slots: s(e),
                        timeout: r.partnerEnforced
                    }, (function(e) {
                        _((function() {
                            ! function(e, t, i, o, r) {
                                n.log.logPartnerEventOnce("a9Loaded", "a9FetchStart"), e = r(e), c || (h(e, (function(e) {
                                    e.hasOwnProperty("slotID") && ("preroll" === e.slotID ? n.video.setTargeting(e.targeting) : o(e, l(e.slotID)))
                                })), d = !0, clearTimeout(p), i(e), "function" == typeof t && t())
                            }(e, o, u, g, f)
                        }))
                    }))
                }));
                const p = setTimeout((function() {
                    c = !0, d || (a("a9 did not load before karma-enforced timeout period ended. " + r.karmaEnforced + "ms", {
                        force: !0,
                        level: "warn"
                    }), o())
                }), r.karmaEnforced)
            }
        }
    }(), n.partner = n.partner || {}, n.partner.aam = function() {
        function e() {
            return !!V.aamEnabled
        }
        return {
            load: function() {
                e() && y("//aamapi.com/api/init-182h1kagypftheeqt3p.js", (function() {
                    a("AAM loaded.")
                }), (function() {
                    a("Failed to fetch AAM.", {
                        level: "error",
                        force: !0
                    }), V.aamEnabled = !1
                }), !1, {
                    "data-cfasync": "false",
                    async: "true"
                })
            },
            isEnabled: e
        }
    }(), n.partner = n.partner || {}, n.partner.adLightning = function() {
        function e() {
            return !!V.adLightningEnabled
        }
        return {
            load: function() {
                e() && y("https://tagan.adlightning.com/meredith/op.js", (function() {
                    a("adlightning loaded.")
                }), (function() {
                    a("Failed to fetch adlightning.", {
                        level: "error",
                        force: !0
                    }), V.adLightningEnabled = !1
                }))
            },
            isEnabled: e
        }
    }(), n.partner = n.partner || {}, n.partner.header_tag_manager = function() {
        "use strict";
        D.header_tag_manager = {
            slots: {}
        }, e.headertag = e.headertag || {}, e.headertag.cmd = e.headertag.cmd || [];
        const t = [{
            low: 10,
            high: 2e3,
            increment: 10
        }, {
            low: 2001,
            high: 5e3,
            increment: 20
        }, {
            low: 5001,
            high: 1e4,
            increment: 50
        }];

        function o() {
            return V.header_tag_managerEnabled
        }

        function r(t) {
            _((function() {
                e.headertag.cmd.push(t)
            }))
        }

        function s() {
            V.indexPrerollEnabled && n.video.getVideoId() && r((function() {
                    htSlotName: "preroll"
                }], (function(e) {
                    ! function(e) {
                        _((function() {
                            let i, o, r;
                            P(e) && Array.isArray(e.preroll) && P(e.preroll[0]) && e.preroll[0].hasOwnProperty("targeting") && (e.preroll.sort((function(e, t) {
                                return e.price < t.price ? 1 : -1
                            })), o = e.preroll[0], r = I(o.price, t), i = o.targeting, i.price.ix_v_bid = r, n.video.setTargeting(i.price), n.video.setTargeting(i.deal))
                        }), (function(e) {
                            a("Error processing Index video bid request: " + e, {
                                level: "error"
                            })
                        }))
                    }(e)
                }), {
                    timeout: n.partner.getTimeoutLengths("video").partnerEnforced
                })
            }))
        }
        return {
            fetchBids: function(t, o, s) {
                const l = function(e) {
                        const t = [],
                            n = [];
                        return e = e.filter((function(e) {
                            return e.header_tag_manager
                        })), h(e, (function(e) {
                            const i = e.handle.hbSlotName; - 1 === n.indexOf(i) && (e.ixSlotName = i, n.push(i), t.push({
                                htSlotName: i
                            }))
                        })), t
                    }(t),
                    c = n.partner.getTimeoutLengths(o);
                let d = !1,
                    u = !1,
                    g = [];
                if (h(t, (function(e) {
                        g.push(e.slotContainer)
                    })), g = g.join(", "), 0 === l.length) return void s();
                a({
                    label: "header_tag_managerFetchStart"
                }), a("Requesting ix demand for the following slots: " + g), r((function() {
                    const t = n.partner.getTimeoutLengths(o),
                        r = {};
                    "hard" === o && !V.useAdaptiveTimeout || "hard" !== o ? (r.timeout = t.partnerEnforced, a("Passing timeout to ix: " + t.partnerEnforced)) : (D.adaptiveTimeout = e.headertag.getTimeout(), r.timeout = D.adaptiveTimeout, a("Using ix adaptive timeout: " + D.adaptiveTimeout), function(e) {
                        const t = {
                            category: "indexAdaptiveTimeout",
                            label: "tracking",
                            value: I(e, [{
                                low: 0,
                                high: 999999,
                                increment: 250
                            }], !0),
                            site: V.site
                        };
                        n.reporting.report(!1, t, "karmaRequest")
                    }(D.adaptiveTimeout)), e.headertag.retrieveDemand(l, (function(e) {
                        ! function(e) {
                            if ("object" == typeof e.slot && Object.keys(e.slot).length) {
                                const t = e.slot;
                                h(t, (function(e) {
                                    const o = i.slots.catalog.filter((function(t) {
                                            return t.ixSlotName === e
                                        }))[0],
                                        r = t[e] || [];
                                    o.ixSlotName = null, r.sort((function(e, t) {
                                        return e.price > t.price ? 1 : -1
                                    })), h(r, (function(e) {
                                        const t = e.targeting;
                                        h(t, (function(e) {
                                            n.targeting.set(e, t[e], o)
                                        }))
                                    }))
                                }))
                            } else a("No valid ix bids returned");
                            u = !0, clearTimeout(f), d || (s(), n.log.logPartnerEventOnce("header_tag_managerLoaded", "header_tag_managerFetchStart")), h(i.slots.catalog, (function(e) {
                                e.ixSlotName = null
                            }))
                        }(e)
                    }), r)
                })), a("Starting ix timeout: " + c.karmaEnforced);
                const f = setTimeout((function() {
                    d = !0, u || ("hard" === o && n.log.logPartnerEventOnce("header_tag_managerFailsafe", "header_tag_managerFetchStart"), a("ix did not load before the " + c.message + " timeout period ended. " + c.karmaEnforced + "ms", {
                        force: !0,
                        level: "warn"
                    }), s())
                }), c.karmaEnforced)
            },
            fetchVideoBids: s,
            load: function() {
                if (o()) {
                    const e = function() {
                        const e = V.ixSiteId;
                        return e ? "https://js-sec.indexww.com/ht/p/184003-" + e + ".js" : (V.header_tag_managerEnabled = !1, !1)
                    }();
                    e && y(e, (function() {
                        a("ix site-specific wrapper loaded: " + e)
                    }), (function() {
                        a("Failed to fetch site-specific ix wrapper (" + e + "). Disabling ix.", {
                            level: "error",
                            force: !0
                        }), V.header_tag_managerEnabled = !1
                    }))
                }
                r((function() {
                    if (e.headertag.subscribeEvent("error", !1, (function(e, t) {
                            a("headertag " + e + ": " + t, {
                                force: !0,
                                level: "error"
                            })
                        })), e.headertag.subscribeEvent("warning", !1, (function(e, t) {
                            a("headertag " + e + ": " + t, {
                                force: !0,
                                level: "warn"
                            })
                        })), Array.isArray(i.vars.msg)) {
                        const t = i.vars.msg.map((function(e) {
                            return "(" + e + ")"
                        }));
                        e.headertag.setUserKeyValueData({
                            user: {
                                keywords: t
                            }
                        })
                    }
                })), s()
            },
            isEnabled: o
        }
    }(), n.partner = n.partner || {}, n.partner.krux = function() {
        "use strict";
        return {
            targeting: function() {
                function t(t) {
                    const n = "kxmeredith_" + t;
                    return D.isLocalStorageAvailable ? e.localStorage[n] || "" : S(n)
                }
                e.Krux || ((e.Krux = function() {
                    e.Krux.q.push(arguments)
                }).q = []);
                const i = t("user"),
                    o = t("segs") ? t("segs").split(",") : [];
                e.Krux.user = i, e.Krux.segments = o, n.targeting.set("kuid", i), n.targeting.set("ksg", o)
            }
        }
    }(), n.privacy = function() {
        "use strict";

        function i(e) {
            return e ? -1 !== D.euCountryCodes.indexOf(e) : null
        }

        function o() {
            let e = S("OptanonConsent");
            return e ? (e = d(S("OptanonConsent"), !1), a("OneTrust cookie is present, with this data: " + JSON.stringify(e)), e) : null
        }

        function r(e) {
            return !(e = e || o()) || !(e.hasOwnProperty("groups") && -1 !== e.groups.indexOf("4:0"))
        }

        function s() {
            return n.utilities.getCookie("mdp.privacy.loc")
        }

        function l() {
        }

        function c(e) {
            if (e = e || s()) D.isUserInUsa = "2" === e;
            else {
                const e = l();
                e && e.hasOwnProperty("country") && (D.isUserInUsa = "US" === e.country)
            }
            return D.isUserInUsa
        }

        function u(e) {
            e = e || o();
            let t = null;
            return _((function() {
                t = e.groups.split(",").filter((function(e) {
                    return "4" === e.charAt(0) && ":" === e.charAt(1)
                }))
            }), (function() {
                a("Something went wrong when trying to check the groups param of the Onetrust consent cookie", {
                    force: !0
                })
            })), t
        }
        return V.usPrivacy = V.usPrivacy || {
            enabled: !1
        }, V.euPrivacy = V.euPrivacy || {
            enabled: !1
        }, D.isUserInEurope = null, D.isUserInUsa = null, D.euCountryCodes = ["AT", "BE", "BG", "CY", "CZ", "DE", "DK", "EE", "ES", "FI", "FR", "GB", "GR", "HR", "HU", "IE", "IS", "IT", "LI", "LT", "LU", "LV", "MT", "NL", "NO", "PL", "PT", "RO", "SE", "SI", "SK"], {
            check: function() {
                const e = o(),
                    a = s();
                if (e) {
                    const t = !r(e),
                        n = function(e) {
                            if ((e = e || o()) && e.hasOwnProperty("interactionCount")) {
                                const t = parseInt(e.interactionCount, 10);
                                return isNaN(t) ? null : t
                            }
                            return null
                        }(e);
                    V.usPrivacy.enabled = !!(c(a) && t && null !== n && n > 0), V.euPrivacy.enabled = !(! function(e) {
                        if (e = e || s()) D.isUserInEurope = "1" === e;
                        else {
                            const e = l();
                            e && e.hasOwnProperty("country") && (D.isUserInEurope = i(e.country))
                        }
                        return D.isUserInEurope
                    }(a) || !t)
                }
                n.gpt.setNonPersonalizedAds(V.euPrivacy.enabled), n.gpt.restrictDataProcessing(V.usPrivacy.enabled),
                    function(e, r) {
                        e = e || o(), r = r || s();
                        const a = l();
                        V.euPrivacy.enabled ? n.targeting.set("npa", 1) : n.targeting.clear("npa"), V.usPrivacy.enabled ? n.targeting.set("rdp", 1) : n.targeting.clear("rdp"), -1 === t.cookie.indexOf("mdp.privacy.loc=") ? n.targeting.set("geo", "missing") : r && n.targeting.set("geo", r), e && (e.hasOwnProperty("groups") ? n.targeting.set("otgrp", u(e)) : n.targeting.set("otgrp", null), e.hasOwnProperty("interactionCount") ? n.targeting.set("otic", e.interactionCount) : n.targeting.set("otic", null)), a && a.hasOwnProperty("country") && ("US" === a.country ? n.targeting.set("otgeo", 2) : i(a.country) ? n.targeting.set("otgeo", 1) : n.targeting.set("otgeo", 0))
                    }(e, a), D.url.hasOwnProperty("adprivacypartneroverride") && "true" === D.url.adprivacypartneroverride || !V.usPrivacy.enabled && !V.euPrivacy.enabled || ((V.onPageSettings.config.usPrivacy && V.onPageSettings.config.usPrivacy.enabled || V.euPrivacy.enabled) && (V.a9Enabled = !1), V.header_tag_managerEnabled = !1), V.a9Enabled && n.partner.a9.init()
            },
            getCcpaConsentString: function() {
                const e = ["1"];
                return c() ? (e.push("Y"), r() ? e.push("N") : e.push("Y")) : e.push("-", "-"), D.ccpaConsentString = e.join(""), D.ccpaConsentString
            },
            getOneTrustGroups: u,
            hasUserConsented: r
        }
    }(), n.refresh = n.refresh || {}, n.refresh.timed = function() {
        "use strict";
        const t = {},
            o = ["scroll", "focus", "blur", "click"];
        let r, s, c, d, u, g, f, b = [],
            y = !1;

        function v() {
            return !!(V.refresh && V.refresh.timed && V.refresh.timed.enabled && V.refresh.timed.map && "object" == typeof V.refresh.timed.map && Object.keys(V.refresh.timed.map).length > 0) || (a("Timed refresh disabled for this page by config."), !1)
        }

        function S() {
            if (!v()) return;
            const d = function() {
                let a, d, u;
                return r = i.slots.catalog, h(r, (function(e) {
                    if ("object" != typeof e.timedRefresh && (e.timedRefresh = {}), !e.handle || !e.handle.full) return !1;
                    if (!e.requested) return !1;
                    if (!t.hasOwnProperty(e.slotContainer) && !1 !== e.timedRefresh.enabled) {
                        for (a in b)
                            if (d = b[a], n.slots.matchHandle(e, a) && d.mode) {
                                u = l(d), t[e.slotContainer] = u, s++, e.timedRefresh = u;
                                break
                            } e.timedRefresh.enabled = !1
                    }
                })), s > 0 && !y ? (y = !0, h(o, (function(t) {
                    e.addEventListener(t, c, !0)
                }))) : s <= 0 && y && (y = !1, h(o, (function(t) {
                    e.removeEventListener(t, c)
                }))), !0
            }();
            let u, f, p;
            if (s > 0) {
                if (!d) return void a("An ad slot is missing a handle. Aborting slot swap.", {
                    force: !0,
                    level: "warn"
                });
                h(t, (function(e) {
                    f = n.slots.getById(e), u = function(e) {
                        if (!e.requested || e.inFlight) return !1;
                        let t = !1;
                        return T(e) && ! function(e) {
                            return e.timedRefreshOverride || !1
                        }(e) && (t = !0, e.timedRefreshOverride = !1), t
                    }(f), p = function(e) {
                        const t = e.refreshIntervalOverrides,
                            i = e.timedRefresh.mode || "refresh";
                        let o = 2e4,
                            r = 0;
                        return t && t[i] ? o = t[i] : g[i] && g[i][e.tierString] && (o = g[i][e.tierString]), n.partner.isAnyPartnerEnabledOnSlot(e) && (r = 1e3 * Math.ceil(V.bidTimeouts.timed / 1e3), o -= r), [o, r]
                    }(f), f.requested && !f.timedRefresh.timerRunning && u ? k(f, p[0], p[1]) : !u && f.timedRefresh.timerRunning && w(f)
                }))
            }
        }

        function k(e, t, i) {
            const o = e.timedRefresh || {};
            o.timerRunning = !0, o.duration = t /= 1e3, o.bidTimeout = i / 1e3, "number" != typeof o.timer && (o.timer = t), a("Starting timer for " + e.slotContainer + ": " + o.timer), o.interval = setInterval(function(e) {
                return function() {
                    e.timedRefresh.timer--, e.timedRefresh.timer > 0 || !n.slots.getById(e.slotContainer) || (w(e), T(e) && (e.timedRefresh.timer = null, "swap" === e.timedRefresh.mode ? function(e) {
                        const t = n.dom.get(e),
                            i = e.timedRefresh,
                            o = e.slotContainer,
                            r = o.match(/(.*)-\d/),
                            s = (r ? r[1] : o) + "-tier" + i.swapToTier;
                        let l = !1;
                        if (!i.filled && e.requested && null !== t) {
                            t.id = s.replace("div-gpt", "karma-reload-container"), t.style.height = t.clientHeight + "px", t.style.width = t.clientWidth + "px", n.slots.destroy(o);
                            const i = n.lazyLoad.create(s, t, !1, (function() {
                                    t.style.height = "", t.style.width = ""
                                }), {
                                    refreshType: "swap"
                                }).id,
                                r = n.slots.getById(i);
                            a("Swapping " + e.handle.full + " to " + r.handle.full), r.refreshCount = e.refreshCount || 0, r.shouldIncrementRefresh = !0, n.lazyLoad.fill(), l = !0
                        } else a("Tried to swap " + t.id + ", but failed. Disabling swap on this slot."), C(e)
                    }(e) : "refresh" === e.timedRefresh.mode && (e.shouldIncrementRefresh = !0, e.refreshType = "timed", n.requestQueue.process([e]))))
                }
            }(e), 1e3)
        }

        function w(e) {
            const t = e.timedRefresh || {};
            a("Pausing timer for " + e.slotContainer + ": " + t.timer), t.timerRunning = !1, clearInterval(t.interval), t.interval = !1
        }

        function T(e) {
            return n.viewability.isInView(e)
        }

        function C(e) {
            t.hasOwnProperty(e.slotContainer) && (delete t[e.slotContainer], e.timedRefresh = e.timedRefresh || {}, e.timedRefresh.enabled = !1, s--)
        }
        return {
            check: S,
            disableTimedRefreshOnSlot: function(e, i) {
                const o = n.slots.getById(e);
                i = i || !1,
                    function(e) {
                        return e && t.hasOwnProperty(e.slotContainer) && !e.timedRefreshOverride
                    }(o) && (o.timedRefreshOverride = !0, i ? (w(o), C(o)) : S(), a("disableTimedRefreshOnSlot(): " + (i ? "Permanently" : "Temporarily") + " disabling timed refresh on " + e))
            },
            getActiveMap: function() {
                return t
            },
            init: function() {
                v() && (r = i.slots.catalog, d = V.refresh || {}, u = d.timed || {}, f = u.refHubOverrides || {}, g = function() {
                    let e = {};
                    const t = i.config.refresh.timed.dayPartedIntervals || [],
                        n = new Date,
                        o = n.getTimezoneOffset() / 60,
                        r = new Date;
                    r.setMonth(0);
                    const a = 5 - (r.getTimezoneOffset() / 60 - o);
                    n.setHours(n.getHours() + (o - a));
                    const s = n.getHours();
                    return t.forEach((function(t) {
                        s >= t.start && s < t.end && (e = t.intervals)
                    })), 0 !== Object.keys(e).length && e
                }() || !!(f && D.url.ref_hub && D.url.ref_hub.indexOf("arbit") > -1) && m(u.intervals, f) || u.intervals || {}, b = u.map || [], s = 0, c = p(S, 250), e.addEventListener("message", (function(e) {
                    if ("string" == typeof e.data && -1 !== e.data.indexOf("karmaStopRefresh")) try {
                        const t = JSON.parse(e.data);
                        n.refresh.timed.disableTimedRefreshOnSlot("div-gpt-" + t.slot, !0)
                    } catch (e) {
                        a(e.toString(), {
                            level: "error",
                            force: !0
                        })
                    }
                }), !1), S())
            },
            isEnabled: v,
            pauseSlotTimer: w,
            reEnableTimedRefreshOnSlot: function(e) {
                const i = n.slots.getById(e);
                i && t.hasOwnProperty(e) && i.timedRefreshOverride && (i.timedRefreshOverride = !1, S(), a("Re-enabling timed refresh on " + e))
            },
            removeSlot: C,
            resetSlotTimer: function(e) {
                const t = e.timedRefresh || {};
                t.timer = t.duration, a("Resetting timer for " + e.slotContainer + ": " + t.timer)
            },
            startSlotTimer: k
        }
    }(), n.reload = function() {
        "use strict";
        return {
            checkParams: function(e) {
                e = e || "footer";
                const t = !!n.dom.lookup('script[src*="karma.mdpcdn.com"][data-reloaded="true"]'),
                    i = w(e, t) || [],
                    o = "" === i[1] || void 0 === i[1] ? "www" : i[1],
                    s = !i[2] || "js-min" === i[2],
                    l = n.urlVars.get("adTestEnv"),
                    c = n.urlVars.get("adTestMin"),
                    d = i[3] ? i[3] : 3 === r ? "karma.js" : "karma." + e + ".js",
                    u = D.environment = l || o,
                    g = D.minified = JSON.parse(c || "local" === u && u !== o ? "false" : s),
                    f = "www" === u ? "" : u + ".";
                let p;
                return D.scriptPath = i[0] || !1, o === u && s === g || t ? (D.reloaded = t, !1) : (p = "https://" + f + "karma.mdpcdn.com" + ("local" === u ? ":9999" : "") + "/service/js" + (!0 === g ? "-min" : "") + "/" + d, D.scriptPath = p, D.reloaded = !0, D.ready = !1, n.dom.create("script", D.els.head, {
                    src: p,
                    "data-reloaded": "true"
                }), a("Reloading KARMA " + e + " due to testing URL param. Env: " + u + ", Min: " + g, {
                    force: !0
                }), !0)
            }
        }
    }(), n.reporting = function() {
        let t, o = !1;

        function r() {
            const e = V.reportingEnabled;
            return null === n.urlVars.get("runKarmaTests") ? "ga" !== e && "segment" !== e ? (o || (a("Reporting is misconfigured or not enabled for this site. No reports sent."), V.reportingEnabled = !1), o = !0, !1) : "segment" === e || t ? e : (o || (a("GA reporting is enabled for this site, but this pageview didn't fall inside the sample rate of " + V.reportingSampleRate + "%. No reports sent."), V.reportingEnabled = !1), o = !0, !1) : (o || (a("GA reporting is enabled for this site, but we're on an automated testing page. No reports sent."), V.reportingEnabled = !1), o = !0, !1)
        }

        function s(t, n, i, o) {
            const s = r();
            "ga" === s && "object" == typeof e.dataLayer && "function" == typeof e.dataLayer.push && "object" == typeof t ? (e.dataLayer.push(t), a("Reported to GA: " + o)) : "segment" === s && "object" == typeof e.analytics && "function" == typeof e.analytics.track && ("karmaRequest" === i || "karmaPerformance" === i ? (e.analytics.track(i, n), a("Reported to Segment: " + i + ": " + JSON.stringify(n))) : a('Could not report to Segment, because event type was not "karmaRequest" || "karmaPerformance", eventType: ' + i))
        }

        function l() {
            const e = n.slots.getSlotIdTierCombos(i.slots.catalog),
                t = {
                    event: "adRequest",
                    karmaAdSlots: e,
                    karmaPageType: D.unmappedPageType + ":" + n.targeting.get("type"),
                    karmaChannel: n.targeting.get("channel"),
                    karmaId: n.targeting.get("id")
                };
            s(t, t, "karmaRequest", e.join())
        }

        function c() {
            let e, t, i, o, r = 0;
            return !!n.reporting.reportType() && (h(D.logObject, (function(n) {
                if (e = D.logObject[n], e.report && !e.reported) {
                    if (o = e.eventDelta || e.timestamp, t = {
                            event: "Timing",
                            CategoryT: "KarmaPerformance",
                            Var: n,
                            Value: o,
                            Label: e.reportLabel || "null"
                        }, i = {
                            category: n,
                            label: "timing",
                            value: o,
                            contentType: D.unmappedPageType + ":" + V.targeting.type,
                            site: V.site
                        }, e.reported = !0, 0 === t.Value) return a("Attempted to send performance timings to GA, but measured value is 0"), !1;
                    if (t.Value >= 6e5) return a("Attempted to send performance timing to GA, but measured value exceeds 599,999ms"), !1;
                    s(t, i, "karmaPerformance", n + ": " + o), r++
                }
            })), r || void a("karmads.reporting.reportTiming() was called, but there was nothing to report"))
        }
        return D.reporting = {}, {
            segmentReport: function(e, t) {
                s(!1, {
                    category: e,
                    label: "tracking",
                    value: t,
                    contentType: D.unmappedPageType + ":" + V.targeting.type,
                    site: V.site
                }, "karmaRequest")
            },
            init: function() {
                V.reportingSampleRate = V.reportingSampleRate || 0, t = q(V.reportingSampleRate), l()
            },
            report: s,
            reportTiming: c,
            reportType: r,
            initialSlots: l,
            lazyLoadSlot: function(e) {
                const t = {
                    event: "adSlotLazyLoad",
                    karmaAdSlots: [e],
                    karmaPageType: D.unmappedPageType + ":" + n.targeting.get("type"),
                    karmaChannel: n.targeting.get("channel"),
                    karmaId: n.targeting.get("id")
                };
                s(t, t, "karmaRequest", e)
            },
            addEventListener: function() {
                n.gpt.addCallback((function(e) {
                    D.slotOnloadLogged || (a("Slot onload event for " + e.slot.getSlotElementId(), {
                        label: "slotOnload",
                        report: !0
                    }), c(), D.slotOnloadLogged = !0)
                }), "slotOnload")
            }
        }
    }(), n.requestQueue = function() {
        "use strict";
        const o = [];
        let r, s, l = [],
            c = 0;

        function d(e) {
            return e.map((function(e) {
                return e.gptSlot()
            }))
        }

        function u(e) {
            if (e = g(e = e || []), e = n.scrollLoad.removeOffScreenSlots(e), e = function(e) {
                    const t = V.maxActiveSlots || 999,
                        n = [],
                        i = [];
                    return h(e, (function(e) {
                        o.indexOf(e.slotContainer) > -1 ? n.push(e) : o.length < t ? (e.overMax = !1, o.push(e.slotContainer), n.push(e)) : (e.overMax = !0, i.push(e.slotContainer), "processing" === e.scrollLoad && (e.scrollLoad = "true"))
                    })), n.length < e.length && a("Max active slot threshold(" + t + ") hit. Not requesting: " + i, {
                        level: "warn",
                        force: !0
                    }), n
                }(e = n.dom.getVisibleSlots(e)), D.queueExecuted || (e = n.deferred.init(e, t.readyState)), Array.isArray(e) && e.length > 0 && (l = l.concat(e)), 0 !== l.length)
                if (D.requestInFlight) a("Refresh called, but Karma is still processing the previous ad request. Adding " + e.length + " slots to the refresh queue.");
                else {
                    D.requestInFlight = !0, e = l.splice(0, s), h(e, (function(e) {
                        e.inFlight = !0, e.bypassViewabilityRequirement = !1
                    }));
                    const t = d(e);
                    a("Refresh running on " + e.length + " slots."), n.refresh.targeting(e), n.partner.initDemandFetch(e, t)
                }
        }

        function g(e) {
            const t = [];
            return h(e, (function(e) {
                const i = n.dom.get(e);
                null === i || null === i.parentElement ? n.slots.destroy(e.slotContainer) : t.push(e)
            })), t
        }
        return {
            init: function() {
                r = f("karmaRequest"), s = i.config.maxRequestSize || 30, n.gpt.addCallback((function(e) {
                    ! function(e) {
                        const t = e.slot.getSlotId().getDomId(),
                            i = n.slots.getById(t);
                        i && (i.requested = !0, i.inFlight = !1, n.slots.setResponseData(i, e), n.viewability.handleSpecialViewabilityRules(i)), c--, 0 === c && (D.requestInFlight = !1, l.length > 0 ? u(!1) : D.queueExecuted && n.refresh.timed.check())
                    }(e)
                }))
            },
            process: u,
            finishRequest: function(t) {
                let o = g(t);
                const a = i.slots.catalog.map((function(e) {
                    return e.slotContainer
                }));
                o = o.filter((function(e) {
                    return a.indexOf(e.slotContainer) > -1
                }));
                const s = o.map((function(e) {
                    return {
                        slotContainer: e.slotContainer,
                        refreshType: e.refreshType
                    }
                }));
                M() || (r.detail = JSON.stringify(s)), e.dispatchEvent(r), c = o.length, n.privacy.check(), n.bidz.setFloors(o), n.targeting.prerequest(), n.docking.targeting(), n.targeting.ready(), n.translate.targetingReady(), n.refresh.incrementRefreshCounter(o), n.gpt.refresh(d(o))
            },
            removeFromActiveSlots: function(e) {
                return e && o.splice(o.indexOf(e), 1), o
            }
        }
    }(), n.scrollLoad = function() {
        "use strict";
        let o, r, s = !1;

        function l(e) {
            let r, s = i.slots.scrollLoad;
            if (0 === s.length) return;
            try {
                r = e.slot.getSlotElementId()
            } catch (e) {
                a(e.message, {
                    force: !0,
                    level: "error"
                })
            }
            const l = n.slots.getById(r);
            l.scrollLoad && (l.scrollLoad = "loaded", s = s.filter((function(e) {
                return e.slotContainer !== r
            })), i.slots.scrollLoad = s, 0 === s.length && (t.removeEventListener("scroll", o), t.removeEventListener("click", d)))
        }

        function c(e, t) {
            const n = V.scrollLoadBatchSize || 1,
                i = [];
            let o = 0;
            return D.queueExecuted ? (h(e, (function(e) {
                u(e, t, o) && (0 === o && (o = n), o--, i.push(e), e.scrollLoad = "processing", e.refreshType = "scroll")
            })), i) : i
        }

        function d() {
            const e = c(i.slots.scrollLoad, r);
            e.length > 0 && n.requestQueue.process(e)
        }

        function u(e, t, i) {
            const o = Math.abs(n.viewability.getSlotOffsetFromViewport(e)),
                r = n.dom.isDisplayed(e);
            return "true" === e.scrollLoad && r && (o < t || i > 0)
        }
        return {
            check: c,
            checkAndRequest: d,
            removeOffScreenSlots: function(a) {
                const c = [];
                return s || (a = function(a) {
                    const c = [];
                    return s = !0, r = g(V.scrollLoadThreshold) || 100, h(a, (function(e) {
                        const t = n.dom.get(e),
                            i = e.scrollLoad || t.dataset.scrollLoad || t.dataset.lazyScroll;
                        "true" === i && (c.push(e), e.scrollLoad = i)
                    })), i.slots.scrollLoad = c, i.slots.scrollLoad.length > 0 && (o = p(d, 25), t.addEventListener("scroll", o), t.addEventListener("click", d), e.addEventListener("load", d), n.callbacks.add(l)), a
                }(a)), h(a, (function(e) {
                    "true" === e.scrollLoad ? u(e, r) && (e.scrollLoad = "processing", c.push(e)) : c.push(e)
                })), c
            }
        }
    }(), n.selectable = function() {
        "use strict";
        D.selectable = {
            id: !1
        };
        const e = {
            ag: {
                www: "LNhxaZJk",
                dev: "JWilnmZa"
            },
            aly: "AQpgugKT",
            apq: "DxnXoOoU",
            ar: {
                www: "ioRpChND",
                test: "QwsqdaRG"
            },
            arau: "nsPuedjs",
            arqc: "pNUDrUff",
            aruk: "TexCxYkZ",
            bestlife: "cUSLhXni",
            bhg: {
                www: "vnVjmqxi",
                dev: "FVffvCLg"
            },
            cdms: {
                www: "XnGwnkBX",
                test: "gYiKDmGY"
            },
            ckl: "DkGbnbKY",
            col: "tlXUypEe",
            dep: "ZQYBEdmc",
            dp: "BuUbxgAl",
            eatthis: "fnrULVjH",
            enw: "bPxqAvRO",
            ew: "lZFhoFLn",
            fitness: {
                www: "BLqmlLoN",
                dev: "eTGwXPRM"
            },
            fw: "qmjlIKrW",
            hellogiggles: "XcrQIMhE",
            hlt: "qBEZIJUa",
            ins: "meecEJMw",
            ironsearch: "zWDmYetc",
            more: "WrflNRqT",
            mre: "LdNlwIfb",
            mslo: "nNKBTXZy",
            msw: "StszHoSl",
            mwl: {
                www: "xshWdqAj",
                dev: "waceCxtV"
            },
            mywedding: {
                www: "aAoKYyNy",
                dev: "aebYbbqj"
            },
            parenting: {
                www: "PuuCSkBY",
                dev: "esZwwWOU"
            },
            parents: {
                www: "rjvsxjLh",
                dev: "KuuyegZm"
            },
            peo: "exskEZha",
            pesp: "lPluBfVP",
            rsm: "yHAKmYHF",
            shape: {
                www: "fRhMKNqJ",
                dev: "IdDjQTmo"
            },
            sm: "gDWwdEKH",
            sol: "WwSRxjYJ",
            sp: "obnddfke",
            tl: "PnvHlINd",
            wood: "erJgFIuB"
        };
        let t;

        function i() {
            n.dom.create("script", D.els.head, {
                src: "https://cdn.selectablemedia.com/tg/" + s(n.urlVars.get("tgt_path") || "p/" + t) + "/js/sm_uber.js",
                async: !0
            })
        }
        return {
            init: function() {
                t = function() {
                    const t = C(),
                        i = k();
                    let o = !1;
                    return n.translate.resetAdDomain(), e.hasOwnProperty(t) && ("string" == typeof e[t] ? o = e[t] : e[t].hasOwnProperty(i) ? o = e[t][i] : "local" === i && e[t].hasOwnProperty("dev") && (o = e[t].dev), o || (o = e[t][Object.keys(e[t]).pop()])), o
                }(), !1 !== t && (D.selectable.id = t, i())
            },
            load: i
        }
    }(), n.slots = function() {
        "use strict";
        const e = [],
            r = {};

        function s(e) {
            return e.isMobile && o || !e.isMobile && !o
        }

        function l(e, t) {
            const n = (t = t || "Slot").toLowerCase();
            if (e.responsive) {
                const i = e["responsive" + t + "Sizes"] || {};
                return i.base = e[n + "Sizes"], i[v(Object.keys(i))]
            }
            return e[n + "Sizes"]
        }

        function c(e) {
            return i.slots.catalog.filter((function(t) {
                return e === t.slotContainer
            }))[0] || !1
        }

        function d(e) {
            return !!("object" == typeof e && e.hasOwnProperty("slotContainer") && e.slotContainer.indexOf("-lazy-") > 0)
        }

        function u(e, t) {
            if (void 0 === typeof e) return a("Tried to match handle, but slot is undefined", {
                force: !0
            }), !1;
            if (!e.handle) return a("No handle is available for slot: " + e.slotContainer, {
                force: !0
            }), !1;
            if (e.handle.full === t) return !0;
            const n = e.handle,
                i = t.match(/^([a-zA-Z-]*)(?::tier)?(\d)?:?(\d+)?$/) || [],
                o = i[1],
                r = i[2],
                s = i[3];
            let l = !0;
            return (o !== n.type || r !== String(n.tier) && void 0 !== r || s !== String(n.instance) && void 0 !== s) && (l = !1), l
        }
        return {
            init: function() {
                const e = n.config.slots.build(n.dom.scrapeSlots(!0), V.site),
                    t = i.slots.catalog = i.slots.catalog.concat(e.adSlots),
                    o = [];
                i.slots.lazy = e.lazySlots, h(t, (function(e) {
                    (s(e) || "interstitial" === e.slotType) && o.push(e)
                })), i.slots.catalog = o
            },
            define: function() {
                const t = i.slots.catalog;
                let o, r;
                return h(t, (function(t) {
                    o = n.targeting.adunit.build(t), t.hasOwnProperty("slotType") && (r = n.gpt.define(t, o, t.slotContainer), e.push(r), n.targeting.slotSetup(t))
                })), e
            },
            convertAdSizes: function(e) {
                const t = l(e),
                    n = [];
                return h(t, (function(e) {
                    "fluid" === e || Array.isArray(e) ? n.push(e) : (e = e.split("x"), n.push([g(e[0]), g(e[1])]))
                })), n
            },
            makeHandle: function(e) {
                const t = e.tier,
                    n = e.slotType,
                    i = n + ":tier" + t,
                    o = e.slotContainer.match(/(fixed|flex)/),
                    a = o ? o[0] + "-" : "",
                    s = d(e) ? "lazy-" : "";
                let l = r[i] || 0;
                l++, e.handle = {
                    full: i + ":" + l,
                    type: n,
                    tier: parseInt(t, 10),
                    instance: l,
                    hbSlotName: s + n + "-" + a + "tier" + t
                }
            },
            matchHandle: u,
            matchHandleArray: function(e, t, i) {
                let o = !1;
                return t = Array.isArray(t) ? t : [], (!(i = i || !1) || !n.viewability.isElementHidden(n.dom.get(e))) && (h(t, (function(t) {
                    u(e, t) && (o = !0)
                })), o)
            },
            injectOutOfPageSlots: function() {
                V.suppressInterstitial || (a("Creating KARMA interstitial slot."), n.dom.create("div", t.body, {
                    id: "div-gpt-interstitial",
                    "data-tier": 1
                })), a("Creating KARMA wallpaper slot."), n.dom.create("div", t.body, {
                    id: "div-gpt-wallpaper",
                    "data-tier": 1
                })
            },
            isValidSlotForDevice: s,
            getSlotIdTierCombos: function(e) {
                return (e = Array.isArray(e) ? e : []).map((function(e) {
                    return e.slotContainer + (e.tierString ? ":" + e.tierString : "")
                }))
            },
            getSlotCount: function() {
                return i.slots.catalog.length
            },
            getById: c,
            getSizes: l,
            setResponseData: function(e, t) {
                e.creativeId = t.sourceAgnosticCreativeId, e.lineItemId = t.sourceAgnosticLineItemId, e.advertiserId = t.advertiserId, e.isEmpty = t.isEmpty, e.size = t.size
            },
            isLazy: d,
            destroy: function(e) {
                const t = c(e);
                return t && (n.lazyLoad.removeUnfilledSlot(e), n.gpt.destroy(t.gptSlot()), n.partner.removeSlotFromAll(e), n.refresh.removeSlot(e, !0), n.refresh.timed.removeSlot(t), i.slots.catalog = i.slots.catalog.filter((function(t) {
                    return t.slotContainer !== e
                })), n.requestQueue.removeFromActiveSlots(e), n.translate.slots()), !1
            }
        }
    }(), n.tiers = function() {
        "use strict";

        function e(e) {
            return void 0 !== e && !isNaN(parseInt(e, 10)) && e >= 0 && e <= 4
        }
        return {
            getFromType: function(e) {
                const t = e.indexOf("tier");
                return -1 !== t && e.charAt(t + 4)
            },
            isValidTier: e,
            setTierSettings: function(t, n) {
                if (e(t)) {
                    const e = n.slotContainer.replace(/-\d+$/i, ""),
                        i = "tier" + t;
                    n.tier = parseInt(t, 10), n.tierString = "tier" + t, V.tiers && V.tiers[e] && V.tiers[e][i] && h(V.tiers[e][i], (function(t) {
                        n[t] = V.tiers[e][i][t]
                    }))
                }
            }
        }
    }(), n.translate = function() {
        "use strict";

        function t() {
            return 2 === r
        }

        function o(e, t, n, i) {
            a("You called " + e + ", which has been deprecated. " + (t && "" !== t ? "You should call karma." + t + " instead. " : ""), {
                force: !0,
                level: "warn",
                doc: "api-method-changes-in-karma-3"
            }), "function" == typeof n && n.apply(this, i)
        }

        function s() {
            t() && (e.adService.adSlotsById = {}, i.slots.catalog.forEach((function(t) {
                e.adService.adSlotsById[t.slotContainer] = t
            })))
        }
        return {
            convertConfig: function() {
                if (t()) {
                    e.adService = e.adService || {};
                    const t = e.adService.unitValues || {},
                        n = e.adService.pageTargetingValues || {};
                    i.config.onPageSettings.config = e.adService !== {} ? e.adService : {}, i.config.isMobile = e.adService.mobileAds || !1, h(t, (function(e) {
                        "adDomain" === e ? i.config.site = t[e] : i.config.targeting[e] = t[e]
                    })), h(n, (function(e) {
                        i.config.targeting[e] = n[e]
                    })), i.config.suppressInterstitial = e.adService.suppressInterstitial || !1, i.config.header_tag_managerEnabled = e.adService.header_tag_managerEnabled || !1, i.config.a9Enabled = e.adService.a9Enabled || !1, i.config.refreshSlotTypes = e.adService.refreshSlotTypes || [], e.adService.hasOwnProperty("callback") && ("function" == typeof e.adService.callback && (a("adService.callback is a function. It should be an array of functions. You should use window.karma.config.callback anyway.", {
                        force: !0,
                        level: "warn",
                        doc: "karmaconfigcallback"
                    }), e.adService.callback = [e.adService.callback]), i.config.hasOwnProperty("callback") ? ("function" == typeof i.config.callback && (a("karma.config.callback is a function. It should be an array of functions.", {
                        force: !0,
                        level: "warn",
                        doc: "karmaconfigcallback"
                    }), i.config.callback = [i.config.callback]), "object" == typeof i.config.callback && i.config.callback.push(e.adService.callback)) : i.config.callback = e.adService.callback)
                }
            },
            init: function() {
                t() && (e.adService = e.adService || {}, e.adService.mobileAds = i.config.isMobile, e.adService.unitValues = {}, e.adService.unitValues.adDomain = i.config.site, e.adService.unitValues.channel = i.config.targeting.channel, e.adService.unitValues.parent = i.config.targeting.parent, e.adService.unitValues.child = i.config.targeting.child, e.adService.pageTargetingValues = i.config.targeting, e.adService.siteSettings = i.config.static, e.adService.docking = i.config.docking, e.adService.refresh = i.config.refresh, e.adService.callback = i.config.callback, e.adService.apiVersion = r, "3" !== r && a("You are using an out-of-date version of KARMA. You should upgrade to K3:", {
                    force: !0,
                    level: "warn",
                    doc: "karma-3-migration-guide"
                }), e.adService.adUnit = {
                    top: n.targeting.adunit.buildTop(),
                    sub: n.targeting.adunit.buildSub()
                }, e.adService.mdpPageCount = D.pageCount, function() {
                    const t = [{
                        func: "createLazyLoadSlot",
                        newName: "createSlot",
                        fn: n.lazyLoad.create
                    }, {
                        func: "fillLazyLoadSlots",
                        newName: "fillSlots",
                        fn: n.lazyLoad.fill
                    }, {
                        func: "updatePageTargeting",
                        newName: "updateTargeting",
                        fn: n.targeting.setTargetingMap
                    }, {
                        func: "updateSlotTargeting",
                        newName: "updateTargeting",
                        fn: n.targeting.legacyUpdateSlot
                    }, {
                        func: "buildDefaultRefreshSlots",
                        newName: "",
                        fn: n.refresh.buildDefaultSlots
                    }, {
                        func: "addToRefreshSlots",
                        newName: "createSlot(slotName, container, autofill, callback, {refreshable: true})",
                        fn: n.refresh.addSlot
                    }, {
                        func: "purgeRefreshSlots",
                        newName: "createSlot(slotName, container, autofill, callback, {purgeRefreshSlots: true})",
                        fn: n.refresh.addSlot
                    }, {
                        func: "removeFromRefreshSlots",
                        newName: "",
                        fn: n.refresh.removeSlot
                    }, {
                        func: "destroySlot",
                        newName: "destroySlot",
                        fn: n.slots.destroy
                    }, {
                        func: "addToCallbackList",
                        newName: "config.callback.push",
                        fn: n.callbacks.add
                    }, {
                        func: "getSlotCount",
                        newName: "getSlotCount",
                        fn: n.slots.getSlotCount
                    }, {
                        func: "isInView",
                        newName: "isInView",
                        fn: n.viewability.isInView
                    }, {
                        func: "disableTimedRefreshOnSlot",
                        newName: "disableTimedRefreshOnSlot",
                        fn: n.refresh.timed.disableTimedRefreshOnSlot
                    }, {
                        func: "forceReleaseBanner",
                        newName: "releaseDocking",
                        fn: n.docking.leaderboard.forceReleaseBanner
                    }, {
                        func: "createInfiniteScrollSlot",
                        newName: "createSlot",
                        fn: n.lazyLoad.create
                    }, {
                        func: "fillInfiniteScrollSlots",
                        newName: "fillSlots",
                        fn: n.lazyLoad.fill
                    }];
                    e.adService.renderAds = {}, h(t, (function(t) {
                        e.adService.renderAds[t.func] = function() {
                            o("adService.renderAds." + t.oldName, t.newName, t.fn, arguments)
                        }
                    })), e.adService.debug = function() {
                        o("adService.debug", "debug", n.debug.publicDebug, arguments)
                    }, e.adService.showLog = function() {
                        o("adService.showLog", "showLog", n.debug.showLog, arguments)
                    }
                }(), e.refreshAdFrame = function() {
                    o("refreshAdFrame", "refresh", n.refresh.startRefresh, arguments)
                }, s())
            },
            isEnabled: t,
            queue: function() {
                e.adServiceQ = e.adServiceQ || [], e.karma.cmd = void 0 !== e.karma.cmd && "object" == typeof e.karma.cmd ? e.adServiceQ.concat(e.karma.cmd) : e.adServiceQ.slice()
            },
            ready: function() {
                t() && (e.adService.queueExecuted = D.queueExecuted), e.adServiceQ = e.karma.cmd
            },
            resetAdDomain: function() {
                t() && (i.config.site = "")
            },
            slots: s,
            targetingReady: function() {
                t() && (e.adService.pageTargetingReady = D.targetingReady)
            }
        }
    }(), n.urlVars = function() {
        "use strict";
        const t = decodeURIComponent(e.location.search);

        function n() {
            return D.url = d(t), D.url.testValues = r(), D.url.serviceValues = r("service"), D.url
        }

        function o(e) {
            return D.url[e.toLowerCase()] || null
        }

        function r(e) {
            var n;
            e = ((n = e) ? n.replace(/\b\w+/g, (function(e) {
                return e.charAt(0).toUpperCase() + e.substr(1).toLowerCase()
            })) : "") || "";
            const i = {};
            return t.replace(new RegExp("[?&]adtest" + e + "keyvalues=([^&]*)", "i"), (function(e, t) {
                h(t.split("-"), (function(e) {
                    const t = e.split(",");
                    i[t[0]] = t[1]
                }))
            })), i
        }
        return n(), {
            setTestValues: function() {
                const e = D.url.serviceValues;
                let t, n, o;
                h(e, (function(r) {
                    t = r.split("."), n = i.config, o = t.length, h(t, (function(t, i) {
                        i === o - 1 ? n[t] = c(e[r]) : (n[t] = n.hasOwnProperty(t) ? n[t] : {}, n = n[t])
                    }))
                }))
            },
            get: o,
            init: n,
            isTrue: function(e) {
                return "true" === o(e.toLowerCase())
            },
            urlContainsEmail: function() {
                return decodeURIComponent(e.location.href).match(/[-a-z0-9~!$%^&*_=+}{'?]+(\.[-a-z0-9~!$%^&*_=+}{'?]+)*@([a-z0-9_][-a-z0-9_]*(\.[-a-z0-9_]+)*\.(aero|arpa|biz|com|coop|edu|gov|info|int|mil|museum|name|net|org|pro|travel|mobi|[a-z][a-z])|([0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}))(:[0-9]{1,5})?/gi)
            }
        }
    }(), n.video = function() {
        "use strict";
        let e, t = 20;

        function i() {
            let e = D.videoId;
            if (!e) {
                const t = n.dom.lookup(".video-js");
                t && t.dataset && t.dataset.videoId && (D.videoId = e = t.dataset.videoId)
            }
            return e
        }

        function o() {
            const e = V.videoTargetingKeys || [];
            D.videoTargeting = D.preRollHbKeys = {}, h(e, (function(e) {
                n.targeting.get(e) && (D.videoTargeting[e] = V.targeting[e])
            }))
        }
        return {
            initTargeting: function() {
                (V.a9PrerollEnabled || V.indexPrerollEnabled) && i() && (e = setInterval((function() {
                            o()
                        })), clearInterval(e)
                    }), (function(e) {
                        a("Error adding videojs listener: " + e), o()
                    })): (clearInterval(e), o())
                }), 1e3)), o()
            },
            getVideoId: i,
            setTargeting: function(e) {
                P(e) && m(D.videoTargeting, e)
            },
            resetTargeting: o,
            updateTargeting: function() {
                o(), n.partner.a9.fetchBids([{
                    isPreroll: !0
                }], "video", L), n.partner.header_tag_manager.fetchVideoBids()
            }
        }
    }(), n.viewability = function() {
        "use strict";
        let o = !0;
        return {
            isInView: function(e, i) {
                let r = !0;
                "string" == typeof e && (e = n.slots.getById(e));
                const s = e.viewabilityDom = function(e) {
                    let t = !1;
                    return e ? (e.firstChild && (e.firstChild.firstChild && (e.firstChild.children.length > 1 ? t = e.firstChild : "IFRAME" === e.firstChild.firstChild.tagName && (t = e.firstChild.firstChild)), !1 === t && (t = e.firstChild)), t) : t
                }(n.dom.get(e));
                if (!s) return a("Could not get viewability element: " + e.slotContainer, {
                    level: "error",
                    force: !0
                }), !1;
                if (!(i || o && "visible" === t.visibilityState)) return r = !1, r;
                if ("mob-adhesive-banner" === e.slotType) return r = !0, r;
                if (function(e) {
                        return !(!V.hasOwnProperty("alwaysRefreshDockedSlots") || !V.alwaysRefreshDockedSlots || !1 === V.docking.rail.enabled) && function(e, t, n) {
                            let i = 10;
                                if (e.matches(".karma-sticky-stuck") || e.matches(".karma-element-sticky-stuck")) return !0;
                                i--
                            }
                            return !1
                        }(t.getElementById(e.slotContainer))
                    }(e)) return r = !0, r;
                if (e.bypassViewabilityRequirement) return r = !0, r;
                const l = s.getBoundingClientRect(),
                    c = [
                        [Math.round(l.left + 1), Math.round(l.top + 1)],
                        [Math.round(l.right - 1), Math.round(l.top + 1)],
                        [Math.round(l.right - 1), Math.round(l.bottom - 1)],
                        [Math.round(l.left + 1), Math.round(l.bottom - 1)]
                    ];
                let d, u, g, f, p;
                for (d = 0; d < 4; d++)
                    if (u = c[d], g = u[0], f = u[1], p = t.elementFromPoint(g, f), p !== s && !s.contains(p)) {
                        r = !1;
                        break
                    } return r
            },
            isElementHidden: function(e) {
                return null !== e && null === e.offsetParent
            },
            addFocusListeners: function() {
                i ? (e.addEventListener("blur", (function() {
                    o = !1
                })), e.addEventListener("focus", (function() {
                    o = !0
                }))) : o = !1
            },
            getSlotOffsetFromViewport: function(t) {
                const i = e.innerHeight,
                    o = n.dom.get(t),
                    r = o.getBoundingClientRect().top,
                    a = o.clientHeight;
                return r + a < 0 ? r + a : r > i ? r - i : 0
            },
            setBypassViewabilityRequirement: function(e, t) {
                n.slots.getById(e).bypassViewabilityRequirement = t
            },
            handleSpecialViewabilityRules: function(e) {
                n.slots.matchHandle(e, "leaderboard:tier1:1") && 17396370 === e.advertiserId && (e.bypassViewabilityRequirement = !0)
            }
        }
    }(), n.timeline = function() {
        "use strict";
        if (D.initialized = D.initialized || !1, D.ready = !0, !n.reload.checkParams()) {
            if (D.headerInitialized) return void a("KARMA has already initialized; aborting init process. Please make sure you don't have multiple calls to karma.js on the page.", {
                force: !0,
                level: "error"
            });
            a("KARMA is loaded", {
                report: !0,
                label: "KarmaHeaderRunning"
            }), D.headerInitialized = D.headerInitialized = !0, n.gpt.init(), n.selectable.init(), n.muid.init(), (3 === r || e.karmaService && e.karmaService.vars.footerReady && !D.initialized) && s()
        }

        function s() {
            e.karma = e.karma || {}, i = m(i, e.karma), i.config.onPageSettings = Object.keys(e.karma).length > 0 ? e.karma : {}, n.translate.convertConfig(), n.urlVars.setTestValues("service"), i.config.hasOwnProperty("isMobile") && "boolean" == typeof i.config.isMobile || a("karma.config.isMobile is missing or is not a boolean.", {
                force: !0,
                level: "error",
                doc: "karmaconfigismobile---required"
            }), o = i.config.isMobile = u(i.config.isMobile), D.initialized = !0, e.karma = i, n.debug.init(n.urlVars.get("karmaDebug")), a("KARMA is running!", {
                report: !0,
                label: "KarmaServiceRunning",
                force: !0
            }), n.viewability.addFocusListeners(), n.targeting.adunit.init(), n.targeting.init(), n.callbacks.init(), n.reporting.addEventListener(), n.config.init(l)
        }

        function l(e) {
            a({
                report: !0,
                label: "AdSetupStart",
                referencePoint: "ConfigFetchStart",
                reportLabel: n.targeting.get("type")
            }), n.config.process(e), n.partner.krux.targeting(), n.requestQueue.init(), n.dom.ready(c)
        }

        function c() {
            n.slots.injectOutOfPageSlots(), n.slots.init(), n.bidz.init(), n.calvera.load(), n.gpt.queuePush(d)
        }

        function d() {
            var e;
            n.slots.define(), n.partner.init(), n.partner.adLightning.load(), a({
                label: "KarmaInit",
                referencePoint: "PartnerTimerStart"
            }), n.methods.init(), n.translate.init(), e = i.slots.catalog, n.gpt.enable(), n.gpt.displayAllSlots(), n.reporting.init(), n.partner.krux.targeting(), n.video.initTargeting(), a("Finished GPT Setup... calling DFP"), n.requestQueue.process(e), n.refresh.buildDefaultSlots(), n.gpt.addCallback(g, "slotOnload"), 0 === e.length ? (D.requestInFlight = !1, f()) : n.callbacks.add(f), -1 === V.site.indexOf(".mob") || o || a("karma.config.site (" + V.site + ") ends in .mob, but karma.config.isMobile is set to false. isMobile should be set to true when the site is mobile.", {
                force: !0,
                level: "error",
                doc: "karmaconfigismobile---required"
            }), -1 === V.site.indexOf(".mob") && o && a("karma.config.site (" + V.site + ") does not contain .mob, but karma.config.isMobile is set to true. isMobile should be set to false when the site is desktop.", {
                force: !0,
                level: "error",
                doc: "karmaconfigismobile---required"
            }), o && 0 === n.dom.scrapeSlots().filter((function(e) {
                return -1 !== e.indexOf("gpt-mob")
            })).length && a("karma.config.isMobile is set to true, but there are no mobile instant placeholders on the page. If you do not create any lazy-loaded slots, there will be no ads on the page.", {
                force: !0,
                level: "warn"
            }), o || 0 !== n.dom.scrapeSlots().filter((function(e) {
                return e.match(/gpt-(?!mob|wallpaper|interstitial)/)
            })).length || a("karma.config.isMobile is set to false, but there are no desktop instant placeholders on the page.  If you do not create any lazy-loaded slots, there will be no ads on the page.", {
                force: !0,
                level: "warn"
            }), t.querySelector('script[src^="http://karma.mdpcdn.com"]') && a("You're calling an insecure version of the KARMA script. You should use the https version.", {
                force: !0,
                level: "warn"
            }), t.querySelector('script[src*="web/js/mdp/app/gpt/gpt.core.js"]') && a("You're using a deprecated KARMA file: gpt.core.js. You should update to K3.", {
                force: !0,
                level: "warn",
                doc: "karma-3-migration-guide"
                force: !0,
                level: "warn",
                doc: "karma-3-migration-guide"
            })
        }

        function g() {
            if (!D.testsRun) {
                a({
                    label: "onload"
                });
                const e = D.environment,
                    t = "local" === e,
                    i = "www" !== e;
                n.urlVars.get("runKarmaTests") && n.gpt.queuePush((function() {
                    n.dom.create("script", D.els.head, {
                        src: "https://" + (i ? e + "." : "") + "karma.mdpcdn.com" + (t ? ":9999" : "") + "/tests/js/karma.tests.bookmarklet.js"
                    })
                })), D.testsRun = !0
            }!D.bookmarkletInjected && n.urlVars.isTrue("karmaDebug") && (n.gpt.queuePush((function() {
                n.dom.create("script", D.els.head, {
                    src: "https://karma.mdpcdn.com/files/tools/bookmarklets/karmaBookmarklet.js"
                })
            })), D.bookmarkletInjected = !0)
        }

        function f(t) {
            function o(e) {
                if ("function" == typeof e) try {
                    e()
                } catch (e) {
                    a("karma.cmd error running function: " + e, {
                        force: !0,
                        level: "error"
                    })
                }
            }
            if (!D.queueExecuted) {
                if (D.queueExecuted = !0, n.docking.init(), t && a("Slot: " + t.slot.getSlotElementId(), {
                        report: !0,
                        label: "slotRenderEnded"
                    }), n.refresh.timed.init(), i.cmd = e.karma.cmd || [], n.translate.queue(), "object" == typeof i.cmd)
                    for (; i.cmd.length > 0;) o(i.cmd[0]), i.cmd.splice(0, 1);
                i.cmd = {
                    push: o
                }, n.partner.aam.load(), n.translate.ready(), n.scrollLoad.checkAndRequest()
            }
        }
        return e.karmaService && e.karmaService.vars && (D.footerReady = e.karmaService.vars.footerReady), e.karmaService = {
            vars: D,
            init: s
        }, e.karma = e.karma || {}, e.karma.init = s, {
            init: s,
            afterConfigReady: l
        }
    }()
}();
//# sourceMappingURL=karma.js.map