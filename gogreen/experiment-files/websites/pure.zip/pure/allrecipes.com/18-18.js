(window.webpackJsonp = window.webpackJsonp || []).push([
    [18], {
        439: function(e, n, t) {
            "use strict";
            t.r(n);
            var a, s, o = t(5),
                r = t.n(o),
                i = t(4),
                l = t(914),
                c = t(1),
                d = t.n(c);

            function u() {
                var e = d()(".ecommerce-hub .hub-refine-wrap"),
                    n = d()(".ecommerce-hub .product-types");
                if (e.length && n.length) {
                    var t = Math.max(d()(window).scrollTop(), 0),
                        a = n.offset().top - 48;
                }
            }

            function h() {
                var e = d()(".ecommerce-hub .share");
                e.length && (Object(l.scrolledBelowElement)(e)() ? d()("body").addClass("under-social") : d()("body").removeClass("under-social"))
            }
            r()(i.m).subscribe((function(e, n) {
                var t = n.closest(".ecommerce-hub").find(".hub-dropdown"),
                    a = n.closest(".ecommerce-hub").find(".hub-refine-wrap"),
                    s = n.closest(".hub-dropdown"),
                    o = n.closest(".heading");
                return s.length && o.length && a.length ? s.hasClass("dropdown-open") ? (s.hasClass("hub-refine") && a.removeClass("refine-open"), s.removeClass("dropdown-open")) : (s.hasClass("hub-refine") && a.addClass("refine-open"), s.addClass("dropdown-open")) : (a.removeClass("refine-open"), t.removeClass("dropdown-open"))
            })), r()(i.ub).subscribe((function() {
                u(), h()
            })), r()(i.tb).subscribe((function() {
                u(), h()
            })), r()(i.fb).subscribe((a = d()(".ecommerce-hub").data("tracking-enabled"), s = d()(".ecommerce-hub").data("tracking-brand"), !(!a || !s || ([{
                class_selector: ".hub-nav-tile",
                section: "Category Navigation"
            }, {
                class_selector: ".hub-tile",
                section: "Featured Stories"
            }, {
                class_selector: ".hub-filter .heading",
                section: "Refine By"
            }, {
                class_selector: ".product-tile",
                section: "Products"
            }, {
                class_selector: ".ecommerce-hub .hub-button",
                section: "More Link"
            }].forEach((function(e) {
                d()(e.class_selector).find("a").toArray().forEach((function(n) {
                    var t = d()(e.class_selector).find(".headline").first(),
                        a = "";
                    a = t.length > 0 ? t.text().trim() : d()(n).text().trim();
                    var o = "".concat(e.section, " > ").concat(a);
                    d()(n).attr({
                        "data-tracking-category": "Ecommerce-hub",
                        "data-tracking-content-type": "ecommerce-hub",
                        "data-tracking-content-shown-on-plaform": "own",
                        "data-tracking-time-inc-application": "front end",
                        "data-tracking-time-inc-brand": s,
                        "data-tracking-event-name": "clicked to content",
                        "data-tracking-label": o
                    })
                }))
            })), 0))))
        },
        447: function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, "default", (function() {
            }));
            var a = t(1),
                s = t.n(a),
                o = t(5),
                r = t.n(o),
                i = t(859),
                l = t.n(i),
                c = t(4);

            function d() {
                r()(c.m).subscribe((function(e, n) {
                    return n.closest(".component.expander .open-button").closest(".component.expander").toggleClass("expander-open").find(".expander-inner").css("max-height", "none")
                }));
                return s()(".component.expander").each((function() {
                    return s()(this).data("article") ? function(e) {
                        var n = s()(".expander-inner", e);
                        if (n.show(), !l()().isMobile()) return !1;
                        var t = s()(".ad-container:visible", n).first(),
                            a = s()(".expander-button", e);
                        if (!n.length || !t.length || !a.length) return !1;
                        var o = t.position().top + t.outerHeight(!0) + 90;
                        return n.css("max-height", "".concat(o, "px")), a.show(), !0
                    }(s()(this)) : function(e) {
                        var n = s()(".expander-inner", e);
                        n.show();
                        var t = s()(".expander-button", e);
                        return !(!n.length || !t.length) && (n[0].scrollHeight - 2 <= n.height() ? (e.addClass("expander-open"), !1) : (t.show(), !0))
                    }(s()(this))
                }))
            }
        },
        467: function(e, n, t) {
            "use strict";
            t.r(n), t.d(n, "default", (function() {
            }));
            var a = t(1),
                s = t.n(a),
                o = t(2),
                r = t.n(o),
                i = t(5),
                l = t.n(i),
                c = t(859),
                d = t.n(c),
                u = t(914),
                h = t(4),
                f = t(781);

            function m() {
                var e = s()("body"),
                    n = s()("header.navigation").find("nav.main"),
                    t = s()("header.navigation").find("nav.menu"),
                    a = n.find(".icon.search.js-activate"),
                    o = n.find(".icon.search-nav.js-activate"),
                    i = n.find(".icon.close-search"),
                    c = n.find(".search-field"),
                    m = n.find(".menu"),
                    v = e.find("header.navigation .menu-overlay"),
                    b = n.find(".icon.menu-close"),
                    p = s()("header.navigation .sidebar-overlay-menu"),
                    g = t.find("li.has-submenu"),
                    w = s()("header.navigation .title-display"),
                    C = Math.ceil(w.width()),
                    x = s()(".longform-social") ? Object(u.scrolledBelowElement)(s()(".longform-social")) : Object(u.scrolledBelowElement)(s()(".article .share")),
                    k = !1,
                    y = function() {
                        k || (k = !0, setTimeout((function() {
                            l()(h.O).broadcast(), k = !1
                        }), 200))
                    };
                r.a.defer((function() {
                    return s()("header.navigation nav.main, header.navigation nav.menu").addClass("can-animate")
                })), w.width(C + C % 2), l()(h.m).subscribe((function(t, s) {
                    return Object(f.a)(s, a) && !n.hasClass("search-open") ? (n.addClass("search-open"), c.prop("disabled", !1).focus()) : Object(f.a)(s, a) || Object(f.a)(s, i) ? (n.removeClass("search-open"), c.blur().prop("disabled", !0)) : Object(f.a)(s, o) ? (o.addClass("search-nav-open"), c.focus(), e.toggleClass("menu-active")) : Object(f.a)(s, m) || Object(f.a)(s, b) ? (n.find(".search-nav-open").length > 0 ? o.removeClass("search-nav-open") : o.addClass("search-nav-open"), e.toggleClass("menu-active")) : Object(f.a)(s, v) ? e.removeClass("menu-active") : s.hasClass("has-submenu") ? s.toggleClass("submenu-active") : s.parents(".has-submenu").length > 0 ? s.parents(".menu-item").toggleClass("submenu-active") : null
                })), l()(h.ub).subscribe((function() {
                    return s()(".ads-sticky-header-wrapper").length > 0 && !n.hasClass("full-size-nav-enabled") ? (y(), !1) : (Object(u.scrolledDownPast)(150) ? n.hasClass("hide-nav-elements") || (n.addClass("hide-nav-elements"), t.addClass("hide-nav-elements"), y()) : (Object(u.scrolledUpWithVelocity)(30) || s()(window).scrollTop() < 150) && n.hasClass("hide-nav-elements") && (n.removeClass("hide-nav-elements"), t.removeClass("hide-nav-elements"), y()), x() ? e.addClass("under-social") : e.removeClass("under-social"))
                })), l()(h.L).subscribe((function(e, n) {
                    if (!d()().isMobile()) {
                        if (0 === n.parents(".sidebar-overlay-menu").length && 0 === n.parents("li.has-submenu").length && !n.hasClass("sidebar-overlay-menu") && !n.hasClass("has-submenu") && !n.is(t)) return p.addClass("hidden"), void g.removeClass("hover");
                        if (n.parents("nav.menu").length > 0) {
                            var a;
                            n.parents("li.has-submenu").length > 0 ? (p.removeClass("hidden"), a = n.parents("li.has-submenu")) : n.hasClass("has-submenu") && (p.removeClass("hidden"), a = n), g.removeClass("hover"), a.addClass("hover"), p.html(a.find(".submenu").clone());
                            o > s()(window).height() - p.height() + 9 && (o = s()(window).height() - p.height() + 9), p.css("top", o)
                        }
                    }
                })), l()(h.Hb).subscribe((function(a) {
                    if (t.length) {
                        var s = t.get(0),
                            o = s.scrollTop,
                            r = s.scrollHeight,
                            i = o + s.offsetHeight;
                        if (0 === o ? s.scrollTop = 2 : i === r && (s.scrollTop = o - 2), a.originalEvent.pageX > t.width() && a.originalEvent.pageY > n.height() && e.hasClass("menu-active")) return e.removeClass("menu-active"), a.preventDefault()
                    }
                    return a
                })), l()(h.Gb).subscribe((function(n, t) {
                    return e.hasClass("menu-active") && 0 === t.parents("nav.menu").length ? n.preventDefault() : n
                }))
            }
        },
        781: function(e, n, t) {
            "use strict";
                return e.is(n) || n.has(e).length > 0
            }
        },
        859: function(e, n, t) {
            var a;
                var n, t;
                return n = (null != e ? e.narrowDesktop : void 0) || 922, t = (null != e ? e.wideDesktop : void 0) || 1162, (null != e ? e.wideMobile : void 0) || 360, {
                    isMobileOrTablet: function() {
                        return a(window).width() < t
                    },
                    isMobile: function() {
                        return a(window).width() < n
                    },
                    isDesktop: function() {
                        return a(window).width() >= n
                    }
                }
            }
        },
        914: function(e, n, t) {
            var a, s, o;
                scrolledDownPast: (s = a(document), o = a(window).scrollTop() + 20, function(e, n) {
                    var t, r, i;
                }),
                scrolledUpWithVelocity: function() {
                    var e;
                    return a(document), e = a(window).scrollTop() + 20,
                        function(n) {
                            var t, s;
                            return s = (t = a(window).scrollTop()) + n < e, e = t, s
                        }
                }(),
                scrolledBelowElement: function(e) {
                    var n, t;
                    return n = (null != (t = e.offset()) ? t.top : void 0) + e.height() || 200,
                        function() {
                            return a(window).scrollTop() > n
                        }
                },
                elementBelowElement: function(e) {
                    var n, t;
                    return n = (null != (t = e.offset()) ? t.top : void 0) - e.height() || 200,
                        function(e) {
                            var t;
                            return (null != (t = e.offset()) ? t.top : void 0) < n
                        }
                }
            }
        }
    }
]);
//# sourceMappingURL=18-18.js.map