! function(n) {
    var e = {};

    function c(o) {
        if (e[o]) return e[o].exports;
        var t = e[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return n[o].call(t.exports, t, t.exports, c), t.l = !0, t.exports
    }
            enumerable: !0,
            get: n
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(o, "__esModule", {
            value: !0
        })
        if (4 & o && "object" == typeof t && t && t.__esModule) return t;
        var n = Object.create(null);
                enumerable: !0,
                value: t
            }), 2 & o && "string" != typeof t)
                return t[o]
            }.bind(null, e));
        return n
        var t = o && o.__esModule ? function() {
            return o.default
        } : function() {
            return o
        };
        return Object.prototype.hasOwnProperty.call(o, t)
}({
    14: function(o, t) {
            imgTrack: function(o, t) {
                var n = new Date,
                    e = n.getFullYear() + "_" + (n.getMonth() + 1) + "_" + n.getDate(),
                    c = n.getHours() + "_" + n.getMinutes() + "_" + n.getSeconds(),
                    i = encodeURI("key=" + o + "&datetime=" + (e + "-" + c) + "&message=" + t),
                return a.src = "/comun/img/dtm-track.jpg?" + i, a
            },
            exportRootVars: function() {
            },
            exportComscoreVars: function() {
            },
            setTrackBuscadorPlaySummum: function(o) {
                if (0 < t.length) {
                    var n = t[0].getAttribute("data-keywords");
                    if (null !== n && "" !== n) {
                        var e = t[0].getAttribute("data-num-entries"),
                            c = t[0].getAttribute("data-buscador");
                        o.set({
                            tipoBuscador: "buscador-" + c,
                            errorBusqueda: 0 == e ? "la-busqueda-no-obtuvo-ningun-resultado" : "",
                            nResultados: e
                        })
                    }
                }
            },
            kebabCase: function(o) {
                var t = o;
                return t = (t = (t = (t = t.replace(/([a-z][A-Z])/g, function(o) {
                    return o.substr(0, 1) + "-" + o.substr(1, 1).toLowerCase()
                })).toLowerCase()).replace(/[^-a-z0-9áéíóúàèìòùüñç]+/g, "-")).replace(/^-+/, "").replace(/-$/, "")
            },
            setTrackLandingAdblocker: function(e) {
                    var t = void 0 !== o && "anonimo" !== o.getUserType(),
                        titular: n
                    }).track()
                }), !0)
            },
            setTrackDetallesArchivo: function(o) {
                if (0 < t.length && "detail" === t[0].getAttribute("data-layout")) {
                    if (0 < n.length) {
                        var e = n[0].getAttribute("data-id"),
                            c = n[0].getAttribute("data-type"),
                            accionEcommerce: "vista-de-producto",
                            SKU: e,
                            nombreProducto: "producto-" + i,
                            categoriaProducto: c,
                            unidadesProducto: "1"
                        })
                    }
                }
            }
        }
    },
    170: function(o, t, n) {
        "use strict";
        n.r(t);
        n(26), n(27);
        var e = n(14),
            i = n.n(e);
        try {
                o.when("vtm:ready").then(function() {
                    try {
                            t = o.comscore;
                                seccion: t.voc_se,
                                subseccion1: t.voc_s1,
                                subseccion2: t.voc_s2,
                                subseccion3: t.voc_s3,
                                subseccion4: t.voc_s4,
                                titular: t.voc_tn,
                                tipoDominio: t.voc_pr,
                                edicion: t.voc_ed,
                                tipoContenido: t.voc_tc,
                                tipoContenidoA: t.voc_tcnew,
                                plataformaContenido: t.voc_pl,
                                sistemaPublicacion: t.voc_pu,
                                fechaPrimeraPublicacion: t.voc_fep,
                                fechaModificacion: t.voc_fem,
                                idioma: t.voc_idi,
                                IDEvolok: t.voc_pw_pid,
                                firmaAutor: t.voc_au,
                                origenContenido: t.voc_or,
                                topics: t.voc_top
                            scrollInfinitoHome: "1"
                            scrollInfinito: "true"
                        }));
                        else {
                                slot: "",
                                modulosRotacion: t.modulosRotacion,
                                idNoticia: t.idNoticia
                            });
                            var n = t.voc_tn.indexOf(".");
                                titular: t.voc_tn.substring(0, n)
                                titular: t.voc_tn
                            })
                        }
                        i.a.setTrackBuscadorPlaySummum(TagManager), i.a.setTrackDetallesArchivo(TagManager);
                        var e = i.a.setTrackLandingAdblocker(TagManager);
                            errorPagina: "404"
                        });
                    } catch (o) {
                        i.a.imgTrack("vtm-ready-exception", o)
                    }
                }, function(o) {
                    i.a.imgTrack("vtm-ready-error", o)
                })
            }, function(o) {
                i.a.imgTrack("voonto-ready-error", o)
            })
        } catch (o) {
            i.a.imgTrack("vtm-error-exception", o)
        }
        i.a.exportRootVars(), i.a.exportComscoreVars()
    },
    26: function(o, t) {
            return !1
            printAds: function() {
                return !1
            }
        }
    },
    27: function(o, t) {
            var c = t.getElementsByTagName("script")[0],
                i = t.createElement("script");
            i.async = !0, i.src = "https://www.googletagmanager.com/gtm.js?id=" + e, c.parentNode.insertBefore(i, c)
    }
});