/**
 * Salient Social.
 *
 * @author ThemeNectar
 */
/* global jQuery */

jQuery(document).ready(function($) {

    "use strict";

    function NectarSocial() {


        // Events.

        // Nectar Love

        // Fixed to bottom social sharing style.
        if ($('body').find('.nectar-social.fixed')) {
        }

    }



            return false;
        });

        $('body.single-product .nectar-social').addClass('woo');


            return false;
        });


        // Hover style
        // desktop

            var $socialTimeout;

                clearTimeout($socialTimeout);


                // Hide other sibling items when needed.
                if ($(this).parents('[id*="-meta"]').length > 0) {
                    $(this).parents('[id*="-meta"]').addClass('social-hovered');
                }
                if ($(this).parents('#single-below-header').length > 0) {
                    $(this).parents('#single-below-header').addClass('social-hovered');
                }

                $(this).parent().addClass('visible');


            });



                var $that = $(this);

                $socialTimeout = setTimeout(function() {

                    $that.removeClass('visible');

                    if ($that.parents('[id*="-meta"]').length > 0) {
                        $that.parents('[id*="-meta"]').removeClass('social-hovered');
                    }
                    if ($that.parents('#single-below-header').length > 0) {
                        $that.parents('#single-below-header').removeClass('social-hovered');
                    }

                }, 200);

            });

        }

        // Click triggered on mobile
        else {


                // Hide other sibling items when needed.
                if ($(this).parents('[id*="-meta"]').length > 0) {
                    $(this).parents('[id*="-meta"]').addClass('social-hovered');
                }
                if ($(this).parents('#single-below-header').length > 0) {
                    $(this).parents('#single-below-header').addClass('social-hovered');
                }

                $(this).parent().addClass('visible');

                return false;
            });

        }


    };



        return false;
    };


        return false;
    };


        var $pageTitle;

        if ($(".section-title h1").length > 0) {
            $pageTitle = encodeURIComponent($(".section-title h1").text());
        } else {
            $pageTitle = encodeURIComponent($(document).find("title").text());
        }
        return false;
    };

        return false;
    };

        var $pageTitle;

        if ($(".section-title h1").length > 0) {
            $pageTitle = encodeURIComponent($(".section-title h1").text());
        } else {
            $pageTitle = encodeURIComponent($(document).find("title").text());
        }
        return false;
    };

        return false;
    };

        var $sharingImg = ($('.single-portfolio').length > 0 && $('div[data-featured-img]').attr('data-featured-img') != 'empty') ? $('div[data-featured-img]').attr('data-featured-img') : $('#ajax-content-wrap img').first().attr('src');
        var $pageTitle;

        if ($(".section-title h1").length > 0) {
            $pageTitle = encodeURIComponent($(".section-title h1").text());
        } else {
            $pageTitle = encodeURIComponent($(document).find("title").text());
        }

        return false;
    };

        var $imgToShare = ($('img.attachment-shop_single').length > 0) ? $('img.attachment-shop_single').first().attr('src') : $('.single-product-main-image img').first().attr('src');
        return false;
    };




            var $loveLink = $(this),
                $id = $(this).attr('id'),
                $that = $(this);

            if ($loveLink.hasClass('loved') || $(this).hasClass('inactive')) {
                return false;
            }

            var $dataToPass = {
                action: 'nectar-love',
                loves_id: $id,
            };

                $loveLink.find('.nectar-love-count').html(data);
                $loveLink.addClass('loved').attr('title', 'You already love this!');
                $that.find('.icon-salient-heart-2').addClass('loved');
            });

            $(this).addClass('inactive');

            return false;
        });

    };




        // Move DOM postiion.
        $('.wpb_wrapper .nectar-social.fixed').each(function(i) {

            // Remove any after first instance.
            if (i !== 0) {
                $(this).remove();
            } else {

                var $fixedMarkup = $(this).clone();
                $('body').append($fixedMarkup);
                $(this).remove();
            }

        });

        function showFixedSharing() {

            if ($(window).scrollTop() > 150) {

                $('.nectar-social.fixed').addClass('visible');

                $(window).off('scroll', showFixedSharing);
                $(window).on('scroll', hideFixedSharing);
            }

        }

        function hideFixedSharing() {

            if ($(window).scrollTop() < 150) {

                $('.nectar-social.fixed').removeClass('visible');

                $(window).off('scroll', hideFixedSharing);
                $(window).on('scroll', showFixedSharing);
            }

        }


        if ($(window).width() < 1000 && $('.nectar-social.fixed').length > 0) {
            if ($(window).scrollTop() > 150) {
                $(window).on('scroll', hideFixedSharing);
            } else {
                $(window).on('scroll', showFixedSharing);
            }
        }

        $(window).on('smartresize', function() {

            if ($(window).width() > 1000) {
                $('.nectar-social.fixed').addClass('visible');
            } else if ($(window).scrollTop() < 150) {
                $(window).off('scroll', hideFixedSharing);
                $(window).on('scroll', showFixedSharing);
                $('.nectar-social.fixed').removeClass('visible');
            } else {
                $(window).off('scroll', showFixedSharing);
                $(window).on('scroll', hideFixedSharing);
            }

        });

    };





});