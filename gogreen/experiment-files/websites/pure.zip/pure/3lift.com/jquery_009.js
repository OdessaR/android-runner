/* Lazy Load XT 1.1.0 | MIT License */ ! function(m, y, e, o) {
    var p = "lazyLoadXT",
        w = "lazied",
        z = "load error",
        t = "lazy-hidden",
        C = e.documentElement || e.body,
        b = {
            autoInit: !0,
            selector: "img[data-src]",
            blankImage: "data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7",
            throttle: 99,
            forceLoad: y.onscroll === o || !!y.operamini || !C.getBoundingClientRect,
            loadEvent: "pageshow",
            updateEvent: "load orientationchange resize scroll touchmove focus",
            forceEvent: "lazyloadall",
            oninit: {
                removeClass: "lazy"
            },
            onshow: {
                addClass: t
            },
            onload: {
                removeClass: t,
                addClass: "lazy-loaded"
            },
            onerror: {
                removeClass: t
            },
            checkDuplicates: !0
        },
        n = {
            srcAttr: "data-src",
            edgeX: 0,
            edgeY: 0,
            visibleOnly: !0
        },
        a = m(y),
        E = m.isFunction,
        d = m.extend,
        T = m.data || function(e, t) {
            return m(e).data(t)
        },
        L = [],
        I = 0,
        r = 0;

    function c(e, t) {
        return e[t] === o ? b[t] : e[t]
    }

    function X() {
        var e = y.pageYOffset;
        return e === o ? C.scrollTop : e
    }

    function B(e, t) {
        var o = b["on" + e];
        o && (E(o) ? o.call(t[0]) : (o.addClass && t.addClass(o.addClass), o.removeClass && t.removeClass(o.removeClass))), t.trigger("lazy" + e, [t]), u()
    }

    function k(e) {
        B(e.type, m(this).off(z, k))
    }

    function i(e) {
        if (L.length) {
            var t, o, n = X(),
                a = y.innerHeight || C.clientHeight,
                r = y.innerWidth || C.clientWidth;
            for (t = 0, o = L.length; t < o; t++) {
                var i, s = L[t],
                    l = s[0],
                    d = s[p],
                    c = !1,
                    u = e || T(l, w) < 0;
                if (m.contains(C, l)) {
                    if (e || !d.visibleOnly || l.offsetWidth || l.offsetHeight) {
                        if (!u) {
                            var f = l.getBoundingClientRect(),
                                h = d.edgeX,
                                v = d.edgeY;
                            u = (i = f.top + n - v - a) <= n && f.bottom > -v && f.left <= r + h && f.right > -h
                        }
                        if (u) {
                            s.on(z, k), B("show", s);
                            var A = d.srcAttr,
                                g = E(A) ? A(s) : l.getAttribute(A);
                            g && (l.src = g), c = !0
                        } else i < I && (I = i)
                    }
                } else c = !0;
                c && (L.splice(t--, 1), o--)
            }
            o || B("complete", m(C))
        }
    }

    function s() {
        1 < r ? (r = 1, i(), setTimeout(s, b.throttle)) : r = 0
    }

    function u(e) {
        L.length && (e && "scroll" === e.type && e.currentTarget === y && I >= X() || (r || setTimeout(s, 0), r = 2))
    }

    function l() {
        a.lazyLoadXT()
    }

    function f() {
        i(!0)
    }
        var e, r = c(a = a || {}, "blankImage"),
            i = c(a, "checkDuplicates"),
            t = c(a, "scrollContainer"),
            s = c(a, "show"),
            l = {};
        for (e in m(t).on("scroll", u), n) l[e] = c(a, e);
            if (t === y) m(b.selector).lazyLoadXT(a);
            else {
                var o = i && T(t, w),
                    n = m(t).data(w, s ? -1 : 1);
                if (o) return void u();
                r && "IMG" === t.tagName && !t.src && (t.src = r), n[p] = d({}, l), B("init", n), L.push(n), u()
            }
        })
    }, m(e).ready(function() {
        B("start", a), a.on(b.updateEvent, u).on(b.forceEvent, f), m(e).on(b.updateEvent, u), b.autoInit && (a.on(b.loadEvent, l), l())
    })
}(window.jQuery || window.Zepto || window.$, window, document),
function(s) {
    var o = s.lazyLoadXT;
    o.selector += ",video,iframe[data-src],embed[data-src]", o.videoPoster = "data-poster", s(document).on("lazyshow", "video", function(e, t) {
        var a = t.lazyLoadXT.srcAttr,
            r = s.isFunction(a),
            i = !1;
        t.attr("poster", t.attr(o.videoPoster)), t.children("source,track").each(function(e, t) {
            var o = s(t),
                n = r ? a(o) : o.attr(a);
            n && (o.attr("src", n), i = !0)
    }), s(document).on("lazyshow", "embed", function(e, t) {
        s(this).removeClass("lazy-hidden")
    })
}(window.jQuery || window.Zepto || window.$);