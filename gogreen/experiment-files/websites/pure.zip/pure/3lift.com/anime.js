/*
 * anime.js v3.2.0
 * (c) 2020 Julian Garnier
 * Released under the MIT license
 * animejs.com
 */

! function(n, e) {
}(this, function() {
    "use strict";
    var k = {
            update: null,
            begin: null,
            loopBegin: null,
            changeBegin: null,
            change: null,
            changeComplete: null,
            loopComplete: null,
            complete: null,
            loop: 1,
            direction: "normal",
            autoplay: !0,
            timelineOffset: 0
        },
        C = {
            duration: 1e3,
            delay: 0,
            endDelay: 0,
            easing: "easeOutElastic(1, .5)",
            round: 0
        },
        t = ["translateX", "translateY", "translateZ", "rotate", "rotateX", "rotateY", "rotateZ", "scale", "scaleX", "scaleY", "scaleZ", "skew", "skewX", "skewY", "perspective", "matrix", "matrix3d"],
        p = {
            CSS: {},
            springs: {}
        };

    function B(n, e, t) {
        return Math.min(Math.max(n, e), t)
    }

    function i(n, e) {
        return -1 < n.indexOf(e)
    }

    function o(n, e) {
        return n.apply(null, e)
    }
    var O = {
        arr: function(n) {
            return Array.isArray(n)
        },
        obj: function(n) {
            return i(Object.prototype.toString.call(n), "Object")
        },
        pth: function(n) {
            return O.obj(n) && n.hasOwnProperty("totalLength")
        },
        svg: function(n) {
        },
        inp: function(n) {
        },
        dom: function(n) {
            return n.nodeType || O.svg(n)
        },
        str: function(n) {
            return "string" == typeof n
        },
        fnc: function(n) {
            return "function" == typeof n
        },
        und: function(n) {
            return void 0 === n
        },
        hex: function(n) {
            return /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(n)
        },
        rgb: function(n) {
            return /^rgb/.test(n)
        },
        hsl: function(n) {
            return /^hsl/.test(n)
        },
        col: function(n) {
            return O.hex(n) || O.rgb(n) || O.hsl(n)
        },
        key: function(n) {
            return !k.hasOwnProperty(n) && !C.hasOwnProperty(n) && "targets" !== n && "keyframes" !== n
        }
    };

    function h(n) {
        var e = /\(([^)]+)\)/.exec(n);
        return e ? e[1].split(",").map(function(n) {
            return parseFloat(n)
        }) : []
    }

    function u(a, t) {
        var n = h(a),
            e = B(O.und(n[0]) ? 1 : n[0], .1, 100),
            r = B(O.und(n[1]) ? 100 : n[1], .1, 100),
            o = B(O.und(n[2]) ? 10 : n[2], .1, 100),
            u = B(O.und(n[3]) ? 0 : n[3], .1, 100),
            i = Math.sqrt(r / e),
            c = o / (2 * Math.sqrt(r * e)),
            s = c < 1 ? i * Math.sqrt(1 - c * c) : 0,
            f = 1,
            l = c < 1 ? (c * i - u) / s : -u + i;

        function d(n) {
            var e = t ? t * n / 1e3 : n,
                e = c < 1 ? Math.exp(-e * c * i) * (f * Math.cos(s * e) + l * Math.sin(s * e)) : (f + l * e) * Math.exp(-e * i);
            return 0 === n || 1 === n ? n : 1 - e
        }
        return t ? d : function() {
            var n = p.springs[a];
            if (n) return n;
            for (var e = 0, t = 0;;)
                if (1 === d(e += 1 / 6)) {
                    if (16 <= ++t) break
                } else t = 0;
            var r = e * (1 / 6) * 1e3;
            return p.springs[a] = r
        }
    }

    function c(e) {
        return void 0 === e && (e = 10),
            function(n) {
                return Math.ceil(B(n, 1e-6, 1) * e) * (1 / e)
            }
    }
    var s = function(o, e, u, t) {
        if (0 <= o && o <= 1 && 0 <= u && u <= 1) {
            var i = new Float32Array(11);
            if (o !== e || u !== t)
                for (var n = 0; n < 11; ++n) i[n] = f(.1 * n, o, u);
            return function(n) {
                return o === e && u === t || 0 === n || 1 === n ? n : f(r(n), e, t)
            }
        }

        function r(n) {
                a = l(r, o, u);
            return .001 <= a ? function(n, e, t, r) {
                for (var a = 0; a < 4; ++a) {
                    var o = l(e, t, r);
                    if (0 === o) return e;
                    e -= (f(e, t, r) - n) / o
                }
                return e
            }(n, r, o, u) : 0 === a ? r : function(n, e, t, r, a) {
                for (var o, u, i = 0; 0 < (o = f(u = e + (t - e) / 2, r, a) - n) ? t = u : e = u, 1e-7 < Math.abs(o) && ++i < 10;);
                return u
            }(n, e, e + .1, o, u)
        }
    };

    function r(n, e) {
        return 1 - 3 * e + 3 * n
    }

    function a(n, e) {
        return 3 * e - 6 * n
    }

    function f(n, e, t) {
        return ((r(e, t) * n + a(e, t)) * n + 3 * e) * n
    }

    function l(n, e, t) {
        return 3 * r(e, t) * n * n + 2 * a(e, t) * n + 3 * e
    }
    var e, d, g = (e = {
        linear: function() {
            return function(n) {
                return n
            }
        }
    }, d = {
        Sine: function() {
            return function(n) {
                return 1 - Math.cos(n * Math.PI / 2)
            }
        },
        Circ: function() {
            return function(n) {
                return 1 - Math.sqrt(1 - n * n)
            }
        },
        Back: function() {
            return function(n) {
                return n * n * (3 * n - 2)
            }
        },
        Bounce: function() {
            return function(n) {
                for (var e, t = 4; n < ((e = Math.pow(2, --t)) - 1) / 11;);
                return 1 / Math.pow(4, 3 - t) - 7.5625 * Math.pow((3 * e - 2) / 22 - n, 2)
            }
        },
        Elastic: function(n, e) {
            void 0 === n && (n = 1), void 0 === e && (e = .5);
            var t = B(n, 1, 10),
                r = B(e, .1, 2);
            return function(n) {
                return 0 === n || 1 === n ? n : -t * Math.pow(2, 10 * (n - 1)) * Math.sin((n - 1 - r / (2 * Math.PI) * Math.asin(1 / t)) * (2 * Math.PI) / r)
            }
        }
    }, ["Quad", "Cubic", "Quart", "Quint", "Expo"].forEach(function(n, e) {
        d[n] = function() {
            return function(n) {
                return Math.pow(n, e + 2)
            }
        }
    }), Object.keys(d).forEach(function(n) {
        var r = d[n];
        e["easeIn" + n] = r, e["easeOut" + n] = function(e, t) {
            return function(n) {
                return 1 - r(e, t)(1 - n)
            }
        }, e["easeInOut" + n] = function(e, t) {
            return function(n) {
                return n < .5 ? r(e, t)(2 * n) / 2 : 1 - r(e, t)(-2 * n + 2) / 2
            }
        }
    }), e);

    function P(n, e) {
        if (O.fnc(n)) return n;
        var t = n.split("(")[0],
            r = g[t],
            a = h(n);
        switch (t) {
            case "spring":
                return u(n, e);
            case "cubicBezier":
                return o(s, a);
            case "steps":
                return o(c, a);
            default:
                return o(r, a)
        }
    }

    function v(n) {
        try {
        } catch (n) {
            return
        }
    }

    function I(n, e) {
        for (var t, r = n.length, a = 2 <= arguments.length ? e : void 0, o = [], u = 0; u < r; u++) {
            u in n && (t = n[u], e.call(a, t, u, n) && o.push(t))
        }
        return o
    }

    function m(n) {
        return n.reduce(function(n, e) {
            return n.concat(O.arr(e) ? m(e) : e)
        }, [])
    }

    function y(n) {
    }

    function b(n, e) {
        return n.some(function(n) {
            return n === e
        })
    }

    function x(n) {
        var e = {};
        for (var t in n) e[t] = n[t];
        return e
    }

    function T(n, e) {
        var t = x(n);
        for (var r in n) t[r] = e.hasOwnProperty(r) ? e[r] : n[r];
        return t
    }

    function D(n, e) {
        var t = x(n);
        for (var r in e) t[r] = O.und(n[r]) ? e[r] : n[r];
        return t
    }

    function M(n) {
        if (O.rgb(n)) return (t = /rgb\((\d+,\s*[\d]+,\s*[\d]+)\)/g.exec(e = n)) ? "rgba(" + t[1] + ",1)" : e;
        var e, t, r, a, o, u, i, c, s, f, l, d, p, h, g;
        if (O.hex(n)) return r = n.replace(/^#?([a-f\d])([a-f\d])([a-f\d])$/i, function(n, e, t, r) {
            return e + e + t + t + r + r
        }), a = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(r), "rgba(" + parseInt(a[1], 16) + "," + parseInt(a[2], 16) + "," + parseInt(a[3], 16) + ",1)";
        if (O.hsl(n)) return l = /hsl\((\d+),\s*([\d.]+)%,\s*([\d.]+)%\)/g.exec(o = n) || /hsla\((\d+),\s*([\d.]+)%,\s*([\d.]+)%,\s*([\d.]+)\)/g.exec(o), d = parseInt(l[1], 10) / 360, p = parseInt(l[2], 10) / 100, h = parseInt(l[3], 10) / 100, g = l[4] || 1, 0 == p ? c = s = f = h : (c = v(i = 2 * h - (u = h < .5 ? h * (1 + p) : h + p - h * p), u, d + 1 / 3), s = v(i, u, d), f = v(i, u, d - 1 / 3)), "rgba(" + 255 * c + "," + 255 * s + "," + 255 * f + "," + g + ")";

        function v(n, e, t) {
            return t < 0 && (t += 1), 1 < t && --t, t < 1 / 6 ? n + 6 * (e - n) * t : t < .5 ? e : t < 2 / 3 ? n + (e - n) * (2 / 3 - t) * 6 : n
        }
    }

    function E(n) {
        var e = /[+-]?\d*\.?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?(%|px|pt|em|rem|in|cm|mm|ex|ch|pc|vw|vh|vmin|vmax|deg|rad|turn)?$/.exec(n);
        if (e) return e[1]
    }

    function w(n, e) {
        return O.fnc(n) ? n(e.target, e.id, e.total) : n
    }

    function F(n, e) {
        return n.getAttribute(e)
    }

    function N(n, e, t) {
        if (b([t, "deg", "rad", "turn"], E(e))) return e;
        var r = p.CSS[e + t];
        if (!O.und(r)) return r;
        o.appendChild(a), a.style.position = "absolute", a.style.width = 100 + t;
        var u = 100 / a.offsetWidth;
        o.removeChild(a);
        var i = u * parseFloat(e);
        return p.CSS[e + t] = i
    }

    function A(n, e, t) {
        if (e in n.style) {
            var r = e.replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase(),
                a = n.style[e] || getComputedStyle(n).getPropertyValue(r) || "0";
            return t ? N(n, a, t) : a
        }
    }

    function L(n, e) {
        return O.dom(n) && !O.inp(n) && (F(n, e) || O.svg(n) && n[e]) ? "attribute" : O.dom(n) && b(t, e) ? "transform" : O.dom(n) && "transform" !== e && A(n, e) ? "css" : null != n[e] ? "object" : void 0
    }

    function j(n) {
        if (O.dom(n)) {
            for (var e, t = n.style.transform || "", r = /(\w+)\(([^)]*)\)/g, a = new Map; e = r.exec(t);) a.set(e[1], e[2]);
            return a
        }
    }

    function S(n, e, t, r) {
        var a, o = i(e, "scale") ? 1 : 0 + (i(a = e, "translate") || "perspective" === a ? "px" : i(a, "rotate") || i(a, "skew") ? "deg" : void 0),
            u = j(n).get(e) || o;
        return t && (t.transforms.list.set(e, u), t.transforms.last = e), r ? N(n, u, r) : u
    }

    function q(n, e, t, r) {
        switch (L(n, e)) {
            case "transform":
                return S(n, e, r, t);
            case "css":
                return A(n, e, t);
            case "attribute":
                return F(n, e);
            default:
                return n[e] || 0
        }
    }

    function $(n, e) {
        var t = /^(\*=|\+=|-=)/.exec(n);
        if (!t) return n;
        var r = E(n) || 0,
            a = parseFloat(e),
            o = parseFloat(n.replace(t[0], ""));
        switch (t[0][0]) {
            case "+":
                return a + o + r;
            case "-":
                return a - o + r;
            case "*":
                return a * o + r
        }
    }

    function X(n, e) {
        if (O.col(n)) return M(n);
        if (/\s/g.test(n)) return n;
        var t = E(n),
            r = t ? n.substr(0, n.length - t.length) : n;
        return e ? r + e : r
    }

    function Y(n, e) {
        return Math.sqrt(Math.pow(e.x - n.x, 2) + Math.pow(e.y - n.y, 2))
    }

    function Z(n) {
        for (var e, t = n.points, r = 0, a = 0; a < t.numberOfItems; a++) {
            var o = t.getItem(a);
            0 < a && (r += Y(e, o)), e = o
        }
        return r
    }

    function Q(n) {
        if (n.getTotalLength) return n.getTotalLength();
        switch (n.tagName.toLowerCase()) {
            case "circle":
                return o = n, 2 * Math.PI * F(o, "r");
            case "rect":
                return 2 * F(a = n, "width") + 2 * F(a, "height");
            case "line":
                return Y({
                    x: F(r = n, "x1"),
                    y: F(r, "y1")
                }, {
                    x: F(r, "x2"),
                    y: F(r, "y2")
                });
            case "polyline":
                return Z(n);
            case "polygon":
                return t = (e = n).points, Z(e) + Y(t.getItem(t.numberOfItems - 1), t.getItem(0))
        }
        var e, t, r, a, o
    }

    function V(n, e) {
        var t = e || {},
            r = t.el || function(n) {
                for (var e = n.parentNode; O.svg(e) && O.svg(e.parentNode);) e = e.parentNode;
                return e
            }(n),
            a = r.getBoundingClientRect(),
            o = F(r, "viewBox"),
            u = a.width,
            i = a.height,
            c = t.viewBox || (o ? o.split(" ") : [0, 0, u, i]);
        return {
            el: r,
            viewBox: c,
            x: +c[0],
            y: +c[1],
            w: u / c[2],
            h: i / c[3]
        }
    }

    function z(n, e) {
        var t = /[+-]?\d*\.?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?/g,
            r = X(O.pth(n) ? n.totalLength : n, e) + "";
        return {
            original: r,
            numbers: r.match(t) ? r.match(t).map(Number) : [0],
            strings: O.str(n) || e ? r.split(t) : []
        }
    }

    function H(n) {
        return I(n ? m(O.arr(n) ? n.map(y) : y(n)) : [], function(n, e, t) {
            return t.indexOf(n) === e
        })
    }

    function G(n) {
        var t = H(n);
        return t.map(function(n, e) {
            return {
                target: n,
                id: e,
                total: t.length,
                transforms: {
                    list: j(n)
                }
            }
        })
    }

    function R(n, e) {
        var t = [],
            r = e.keyframes;
        for (var a in r && (e = D(function(e) {
                for (var t = I(m(e.map(function(n) {
                        return Object.keys(n)
                    })), function(n) {
                        return O.key(n)
                    }).reduce(function(n, e) {
                        return n.indexOf(e) < 0 && n.push(e), n
                    }, []), a = {}, n = 0; n < t.length; n++) ! function(n) {
                    var r = t[n];
                    a[r] = e.map(function(n) {
                        var e = {};
                        for (var t in n) O.key(t) ? t == r && (e.value = n[t]) : e[t] = n[t];
                        return e
                    })
                }(n);
                return a
            }(r), e)), e) O.key(a) && t.push({
            name: a,
            tweens: function(n, r) {
                var e, t = x(r);
                /^spring/.test(t.easing) && (t.duration = u(t.easing)), O.arr(n) && (2 === (e = n.length) && !O.obj(n[0]) ? n = {
                    value: n
                } : O.fnc(r.duration) || (t.duration = r.duration / e));
                var a = O.arr(n) ? n : [n];
                return a.map(function(n, e) {
                    var t = O.obj(n) && !O.pth(n) ? n : {
                        value: n
                    };
                    return O.und(t.delay) && (t.delay = e ? 0 : r.delay), O.und(t.endDelay) && (t.endDelay = e === a.length - 1 ? r.endDelay : 0), t
                }).map(function(n) {
                    return D(n, t)
                })
            }(e[a], n)
        });
        return t
    }

    function W(f, l) {
        var d;
        return f.tweens.map(function(n) {
            var e = function(n, e) {
                    var t = {};
                    for (var r in n) {
                        var a = w(n[r], e);
                        O.arr(a) && 1 === (a = a.map(function(n) {
                            return w(n, e)
                        })).length && (a = a[0]), t[r] = a
                    }
                    return t.duration = parseFloat(t.duration), t.delay = parseFloat(t.delay), t
                }(n, l),
                t = e.value,
                r = O.arr(t) ? t[1] : t,
                a = E(r),
                o = q(l.target, f.name, a, l),
                u = d ? d.to.original : o,
                i = O.arr(t) ? t[0] : u,
                c = E(i) || E(o),
                s = a || c;
            return O.und(r) && (r = u), e.from = z(i, s), e.to = z($(r, i), s), e.start = d ? d.end : 0, e.end = e.start + e.delay + e.duration + e.endDelay, e.easing = P(e.easing, e.duration), e.isPath = O.pth(t), e.isColor = O.col(e.from.original), e.isColor && (e.round = 1), d = e
        })
    }
    var J = {
        css: function(n, e, t) {
            return n.style[e] = t
        },
        attribute: function(n, e, t) {
            return n.setAttribute(e, t)
        },
        object: function(n, e, t) {
            return n[e] = t
        },
        transform: function(n, e, t, r, a) {
            var o;
            r.list.set(e, t), e !== r.last && !a || (o = "", r.list.forEach(function(n, e) {
                o += e + "(" + n + ") "
            }), n.style.transform = o)
        }
    };

    function K(n, c) {
        G(n).forEach(function(n) {
            for (var e in c) {
                var t = w(c[e], n),
                    r = n.target,
                    a = E(t),
                    o = q(r, e, a, n),
                    u = $(X(t, a || E(o)), o),
                    i = L(r, e);
                J[i](r, e, u, n.transforms, !0)
            }
        })
    }

    function U(n, t) {
        return I(m(n.map(function(e) {
            return t.map(function(n) {
                return function(n, e) {
                    var t = L(n.target, e.name);
                    if (t) {
                        var r = W(e, n),
                            a = r[r.length - 1];
                        return {
                            type: t,
                            property: e.name,
                            animatable: n,
                            tweens: r,
                            duration: a.end,
                            delay: r[0].delay,
                            endDelay: a.endDelay
                        }
                    }
                }(e, n)
            })
        })), function(n) {
            return !O.und(n)
        })
    }

    function _(n, e) {
        function t(n) {
            return n.timelineOffset ? n.timelineOffset : 0
        }
        var r = n.length,
            a = {};
        return a.duration = r ? Math.max.apply(Math, n.map(function(n) {
            return t(n) + n.duration
        })) : e.duration, a.delay = r ? Math.min.apply(Math, n.map(function(n) {
            return t(n) + n.delay
        })) : e.delay, a.endDelay = r ? a.duration - Math.max.apply(Math, n.map(function(n) {
            return t(n) + n.duration - n.endDelay
        })) : e.endDelay, a
    }
    var nn = 0;
    var en, tn = [],
        n = [],

    function an() {
        en = requestAnimationFrame(on)
    }

    function on(n) {
        var e = tn.length;
        if (e) {
            for (var t = 0; t < e;) {
                var r, a = tn[t];
                a.paused ? -1 < (r = tn.indexOf(a)) && (tn.splice(r, 1), e = tn.length) : a.tick(n), t++
            }
            an()
        } else en = cancelAnimationFrame(en)
    }

    function un(n) {
        void 0 === n && (n = {});
        var o, u = 0,
            i = 0,
            c = 0,
            s = 0,
            f = null;

        function l(n) {
                return f = n
            });
            return n.finished = e
        }
        var e, t, r, a, d, p, h, g, O = (t = T(k, e = n), r = T(C, e), a = R(r, e), d = G(e.targets), p = U(d, a), h = _(p, r), g = nn, nn++, D(t, {
            id: g,
            children: [],
            animatables: d,
            animations: p,
            duration: h.duration,
            delay: h.delay,
            endDelay: h.endDelay
        }));
        l(O);

        function v() {
            var n = O.direction;
            "alternate" !== n && (O.direction = "normal" !== n ? "normal" : "reverse"), O.reversed = !O.reversed, o.forEach(function(n) {
                return n.reversed = O.reversed
            })
        }

        function m(n) {
            return O.reversed ? O.duration - n : n
        }

        function y() {
        }

        function b(n, e) {
            e && e.seek(n - e.timelineOffset)
        }

        function x(e) {
            for (var n = 0, t = O.animations, r = t.length; n < r;) {
                var a = t[n],
                    o = a.animatable,
                    u = a.tweens,
                    i = u.length - 1,
                    c = u[i];
                i && (c = I(u, function(n) {
                    return e < n.end
                })[0] || c);
                for (var s = B(e - c.start - c.delay, 0, c.duration) / c.duration, f = isNaN(s) ? 1 : c.easing(s), l = c.to.strings, d = c.round, p = [], h = c.to.numbers.length, g = void 0, v = 0; v < h; v++) {
                    var m = void 0,
                        y = c.to.numbers[v],
                        b = c.from.numbers[v] || 0,
                        m = c.isPath ? function(t, r) {
                            function n(n) {
                                void 0 === n && (n = 0);
                                var e = 1 <= r + n ? r + n : 0;
                                return t.el.getPointAtLength(e)
                            }
                            var e = V(t.el, t.svg),
                                a = n(),
                                o = n(-1),
                                u = n(1);
                            switch (t.property) {
                                case "x":
                                    return (a.x - e.x) * e.w;
                                case "y":
                                    return (a.y - e.y) * e.h;
                                case "angle":
                                    return 180 * Math.atan2(u.y - o.y, u.x - o.x) / Math.PI
                            }
                        }(c.value, f * y) : b + f * (y - b);
                    d && (c.isColor && 2 < v || (m = Math.round(m * d) / d)), p.push(m)
                }
                var x = l.length;
                if (x) {
                    g = l[0];
                    for (var M = 0; M < x; M++) {
                        l[M];
                        var w = l[M + 1],
                            k = p[M];
                        isNaN(k) || (g += w ? k + w : k + " ")
                    }
                } else g = p[0];
                J[a.type](o.target, a.property, g, o.transforms), a.currentValue = g, n++
            }
        }

        function M(n) {
            O[n] && !O.passThrough && O[n](O)
        }

        function w(n) {
            var e = O.duration,
                t = O.delay,
                r = e - O.endDelay,
                a = m(n);
            O.progress = B(a / e * 100, 0, 100), O.reversePlayback = a < O.currentTime, o && function(n) {
                if (O.reversePlayback)
                    for (var e = s; e--;) b(n, o[e]);
                else
                    for (var t = 0; t < s; t++) b(n, o[t])
        }
        return O.reset = function() {
            var n = O.direction;
            O.passThrough = !1, O.currentTime = 0, O.progress = 0, O.paused = !0, O.began = !1, O.loopBegan = !1, O.changeBegan = !1, O.completed = !1, O.changeCompleted = !1, O.reversePlayback = !1, O.reversed = "reverse" === n, O.remaining = O.loop, o = O.children;
            for (var e = s = o.length; e--;) O.children[e].reset();
            (O.reversed && !0 !== O.loop || "alternate" === n && 1 === O.loop) && O.remaining++, x(O.reversed ? O.duration : 0)
        }, O.set = function(n, e) {
            return K(n, e), O
        }, O.tick = function(n) {
        }, O.seek = function(n) {
            w(m(n))
        }, O.pause = function() {
            O.paused = !0, y()
        }, O.play = function() {
            O.paused && (O.completed && O.reset(), O.paused = !1, tn.push(O), y(), en || rn())
        }, O.reverse = function() {
            v(), O.completed = !O.reversed, y()
        }, O.restart = function() {
            O.reset(), O.play()
        }, O.reset(), O.autoplay && O.play(), O
    }

    function cn(n, e) {
        for (var t = e.length; t--;) b(n, e[t].animatable.target) && e.splice(t, 1)
    }
            return n.pause()
            return n.play()
        })
        for (var e = H(n), t = tn.length; t--;) {
            var r = tn[t],
                a = r.animations,
                o = r.children;
            cn(e, a);
            for (var u = o.length; u--;) {
                var i = o[u],
                    c = i.animations;
                cn(e, c), c.length || i.children.length || o.splice(u, 1)
            }
            a.length || o.length || r.pause()
        }
        var t = O.str(n) ? v(n)[0] : n,
            r = e || 100;
        return function(n) {
            return {
                property: n,
                el: t,
                svg: V(t),
                totalLength: Q(t) * (r / 100)
            }
        }
        var e = Q(n);
        return n.setAttribute("stroke-dasharray", e), e
        void 0 === e && (e = {});
        var s = e.direction || "normal",
            f = e.easing ? P(e.easing) : null,
            l = e.grid,
            d = e.axis,
            p = e.from || 0,
            h = "first" === p,
            g = "center" === p,
            v = "last" === p,
            m = O.arr(n),
            y = m ? parseFloat(n[0]) : parseFloat(n),
            b = m ? parseFloat(n[1]) : 0,
            x = E(m ? n[1] : n) || 0,
            M = e.start || 0 + (m ? y : 0),
            w = [],
            k = 0;
        return function(n, e, t) {
            if (h && (p = 0), g && (p = (t - 1) / 2), v && (p = t - 1), !w.length) {
                for (var r, a, o, u, i, c = 0; c < t; c++) {
                    l ? (r = g ? (l[0] - 1) / 2 : p % l[0], a = g ? (l[1] - 1) / 2 : Math.floor(p / l[0]), o = r - c % l[0], u = a - Math.floor(c / l[0]), i = Math.sqrt(o * o + u * u), "x" === d && (i = -o), "y" === d && (i = -u), w.push(i)) : w.push(Math.abs(p - c)), k = Math.max.apply(Math, w)
                }
                f && (w = w.map(function(n) {
                    return f(n / k) * k
                })), "reverse" === s && (w = w.map(function(n) {
                    return d ? n < 0 ? -1 * n : -n : Math.abs(k - n)
                }))
            }
            return M + (m ? (b - y) / k : y) * (Math.round(100 * w[e]) / 100) + x
        }
        var l = un(f);
        return l.duration = 0, l.add = function(n, e) {
            var t = tn.indexOf(l),
                r = l.children;

            function a(n) {
                n.passThrough = !0
            } - 1 < t && tn.splice(t, 1);
            for (var o = 0; o < r.length; o++) a(r[o]);
            var u = D(n, T(C, f));
            u.targets = u.targets || f.targets;
            var i = l.duration;
            u.autoplay = !1, u.direction = l.direction, u.timelineOffset = O.und(e) ? i : $(e, i), a(l), l.seek(u.timelineOffset);
            var c = un(u);
            a(c), r.push(c);
            var s = _(r, f);
            return l.delay = s.delay, l.endDelay = s.endDelay, l.duration = s.duration, l.seek(0), l.reset(), l.autoplay && l.play(), l
        }, l
        return Math.floor(Math.random() * (e - n + 1)) + n
});