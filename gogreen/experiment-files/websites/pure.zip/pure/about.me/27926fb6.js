(window.webpackJsonp = window.webpackJsonp || []).push([
    [50], {
        "7kpd": function(e, t, o) {
            var i = o("lJXq"),
                s = o("5Dbr"),
                n = o("gw6K"),
                a = o("trQm"),
                r = o("c83O"),
                u = o("Gh6Q"),
                c = o("pH9A"),
                l = o("YUth"),
                g = c.auth,
                h = o("Se7p").create("auth", "google"),
                p = i.Object.extend({
                    initialize: function() {
                    },
                    googleLoaded: function() {
                        try {
                                var e;
                                try {
                                } catch (e) {
                                    h("No google auth instance yet.")
                                }
                                if (e) g.trigger("google:initialized");
                                else try {
                                        client_id: u.get("pumpkinhead.globals.google_client_id"),
                                        cookiepolicy: "single_host_origin"
                                    }), g.trigger("google:initialized")
                                } catch (e) {
                                    l.captureException(e), g.trigger("google:failed")
                                }
                            })
                        } catch (e) {
                            l.captureException(e), g.trigger("google:failed")
                        }
                    },
                    googleFailed: function() {
                        g.trigger("google:failed")
                    },
                    attachClickHandler: function() {
                        function o(e) {
                            t.signUpWithGoogle(e)
                        }

                        function i() {
                            g.trigger("google:auth:fail")
                        }
                            s.attachClickHandler(t, {}, o, i)
                        })
                    },
                    signUpWithGoogle: function(e) {
                        var t;
                        try {
                            t = {
                                id_token: e.getAuthResponse().id_token
                            }
                        } catch (e) {
                            g.trigger("google:auth:fail", {
                                message: "Google user not found. Please try again."
                            })
                        }
                        n.ajax({
                            type: "POST",
                            url: "".concat(r.NODE_API, "/social/google"),
                            data: t
                        }).done(function(e) {
                            g.trigger("google:auth:success", {
                                output: e
                            })
                        }).fail(function(e) {
                            g.trigger("google:auth:fail", {
                                message: "We were unable to process your signup through Google. Please try another method."
                            })
                        })
                    }
                });
        },
        C3gR: function(e, t, o) {
            var i = o("5Dbr"),
                s = o("lJXq"),
                n = o("GJui"),
                a = o("7kpd"),
                r = (o("Se7p").create("social_auth"), s.Object.extend({
                    initialize: function(e) {
                        i.defaults(e, {
                            facebook: !0,
                            google: !0
                            element: e.google_button
                        }))
                    }
                }));
        },
        GJui: function(e, t, o) {
            var s = o("c83O"),
                n = o("gw6K"),
                i = o("lJXq"),
                a = o("trQm"),
                r = o("pH9A"),
                u = o("Gh6Q"),
                c = o("Se7p").create("auth", "facebook"),
                l = r.auth,
                g = "Facebook user not found. Please try again.",
                h = {
                    message: g
                },
                p = i.Object.extend({
                    initialize: function() {
                            return e.facebookLoaded()
                        }).fail(function() {
                            return e.facebookFailed()
                        })
                    },
                    facebookLoaded: function() {
                        c("facebookLoaded");
                        try {
                                appId: u.get("pumpkinhead.globals.facebook_app_id"),
                                cookie: !0,
                                xfbml: !0,
                                version: "v2.12"
                            }), c("loaded"), l.trigger("facebook:loaded")
                        } catch (e) {
                            c("failed"), l.trigger("facebook:failed")
                        }
                    },
                    facebookFailed: function() {
                        l.trigger("facebook:failed")
                    },
                    authorize: function() {
                        c("authorize");
                        var i = n.Deferred();
                            var s = setTimeout(function() {
                                i.reject({
                                    message: "We are unable to get your Facebook login status. Please try again later."
                                })
                            }, 5e3);
                                if (clearTimeout(s), "connected" === e.status) o.postToFacebook(e, i);
                                else if (["not_authorized", "unknown"].includes(e.status)) {
                                    var t = setTimeout(function() {
                                        i.reject({
                                            message: "We are unable to log you in via Facebook. Please try again later."
                                        })
                                    }, 5e3);
                                        clearTimeout(t), "connected" === e.status ? o.postToFacebook(e, i) : i.reject()
                                    }, {
                                        scope: "public_profile, email"
                                    })
                                } else i.reject(h)
                            })
                        } else i.reject({
                            message: "The Facebook API is not available. Please try again later."
                        });
                        return i.promise()
                    },
                    postToFacebook: function(t, o) {
                        var e, i = t.authResponse;
                        try {
                            e = {
                                access_token: i.accessToken,
                                id_token: i.userID
                            }
                        } catch (e) {
                            o.reject({
                                response: t,
                                message: g
                            })
                        }
                        n.ajax({
                            type: "POST",
                            url: "".concat(s.NODE_API, "/social/facebook"),
                            data: e
                        }).done(function(e) {
                            o.resolve({
                                output: e,
                                response: t
                            })
                        }).fail(function(e) {
                            o.reject({
                                output: e,
                                response: t,
                                message: "We were unable to authorize you via Facebook. Please try another method."
                            })
                        })
                    }
                });
        },
        Jwvl: function(e, t, o) {
            var i = o("lJXq"),
                s = o("5Dbr"),
                n = o("XBRs"),
                a = o("C3gR"),
                r = o("bcPl"),
                u = o("pH9A"),
                c = o("Se7p").create("home", "onboarding"),
                l = u.signup,
                g = u.metrics_signup,
                h = i.Object.extend({
                    initialize: function(e) {
                            google_button: e.google_button
                        })
                    },
                    initializeListeners: function() {
                        u.auth.on("click:signup:google", function() {
                            e.onClickSignupGoogle()
                        }), u.auth.on("click:signup:email", function() {
                            e.onClickSignupEmail()
                        }), u.auth.on("click:signup:facebook", function() {
                            e.onClickSignupFacebook()
                        })
                    },
                    onClickSignupEmail: function() {
                            method: "email"
                    },
                    onClickSignupFacebook: function() {
                            method: "facebook"
                        });
                        var e = u.auth.request("facebook:authorize");
                    },
                    oauthFBSuccess: function(e) {
                            o = e.output,
                            i = e.response.authResponse;
                            email_address: o.data.email,
                            facebook_uid: o.data.id,
                            facebook_access_token: i.accessToken
                        }).done(function() {
                            t.user.set("signup.oauth_status", "complete"), u.signup.request("save"), t.showSignupPage("/signup/name")
                        }).fail(function() {
                            u.signup.request("reset"), r.banner({
                                html: "We were unable to process your signup through Facebook. Please try another method.",
                                status: "warning"
                            })
                        }))
                    },
                    onClickSignupGoogle: function() {
                            method: "google"
                        })
                    },
                    oauthGoogleSuccess: function(e) {
                            o = e.output;
                            email_address: o.data.email,
                            first_name: o.data.given_name,
                            last_name: o.data.family_name,
                            google_access_token: o.data.google_id
                        }).done(function() {
                            t.user.set("signup.oauth_status", "complete"), u.signup.request("save"), t.showSignupPage("/signup/name")
                        }).fail(function() {
                            u.signup.request("reset"), r.banner({
                                html: "There was a problem signing in with Google. Please try another method.",
                                status: "warning"
                            })
                        })) : (u.signup.request("reset"), r.banner({
                            html: "There was a problem signing in with Google. Please try another method.",
                            status: "warning"
                        }))
                    },
                    oauthError: function(e) {
                        e && e.message && r.banner({
                            html: e.message,
                            status: "warning"
                        })
                    },
                    showSignupPage: function(e) {
                    }
                });
        },
        VwbQ: function(e, t, o) {
            var i = o("pH9A");
                i.signup.trigger("error", e)
            }
        },
        XBRs: function(e, t, o) {
            var i = o("lJXq"),
                s = o("c1OH"),
                n = o("91PW"),
                a = o("JRfB"),
                r = o("pH9A"),
                u = o("VwbQ"),
                c = o("Se7p").create("signup", "user"),
                l = r.signup,
                g = o("o2Sx"),
                h = i.Object.extend({
                    initialize: function() {
                            e.storeUser()
                            c("id", e.user.id), c(e.user.url())
                        });
                        var t = a.get(g, {});
                            return e.user
                            return e.profile_user
                    },
                    onUserEvent: function(e) {
                        c("user event", e)
                    },
                    onShowStep: function(e) {
                    },
                    purgeUser: function() {
                        a.deleteKey(g), c("purged")
                    },
                    resetUser: function() {
                            silent: !0
                            silent: !0
                    },
                    storeUser: function() {
                        a.set(g, e, {
                            TTL: 864e5
                        }), c("stored")
                    },
                    createProfileUser: function(e) {
                    }
                });
        },
        c1OH: function(e, t, o) {
            var i = o("c83O"),
                s = o("wkMn"),
                n = o("5Dbr"),
                a = o("UhFi"),
                r = o("91PW"),
                u = o("qQir"),
                c = (o("Se7p").create("signup_user"), r.extend({
                    urlRoot: function() {
                        return "".concat(i.NODE_API, "/signup")
                    },
                    idAttribute: "_id",
                    initialize: function(e) {
                    }
                }));
            c.prototype.relations.push({
                type: s.One,
                key: "signup",
                relatedModel: a.extend({
                    id: "signup"
                })
            }), n.extend(c.prototype.defaults, {
                signup: {
                    id: "signup"
                }
        },
        o2Sx: function(e, t) {
        },
        trQm: function(e, t, o) {
            var n = o("gw6K"),
                a = {};
                var o, i, s = a[e];
                return s || (o = e, i = t, i = n.extend(i || {}, {
                    dataType: "script",
                    url: o
                }), s = n.ajax(i), a[e] = s), s
            }
        }
    }
]);
//# sourceMappingURL=27926fb6.bundle.js.map