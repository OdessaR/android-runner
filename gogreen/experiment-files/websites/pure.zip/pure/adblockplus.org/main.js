"use strict";

(function() {

    function getComputedStyle(el) {
        return (style);
    }

    function isBlockShown(el) {
        return getComputedStyle(el).display === 'block';
    }

    function setBottomPadding(element, value) {
    }

    // Show "Change cookie settings" links and info text to EEA users

    // Prevent Cookies bar (desktop/mobile) from hiding footer contents
    function initPreventFooterOverlap() {
        var pageFooterBp = getComputedStyle(pageFooter).paddingBottom;
            .querySelectorAll(".cookies-submit"));

        setInterval(function() {
            if (isBlockShown(cookiePrompt))
                setBottomPadding(pageFooter, cookiePrompt.offsetHeight + "px");

            if (isBlockShown(cookieBar))
                setBottomPadding(pageFooter, cookieBar.offsetHeight + "px");
        }, 250)

        // close cookies prompt and reset padding
        cookiePromptCloseButton.forEach(function(btn) {
            btn.addEventListener('click', function() {
                setBottomPadding(pageFooter, pageFooterBp);
            });
        })

        cookieBarCloseButton.addEventListener('click', function() {
            setBottomPadding(pageFooter, pageFooterBp);
        });
    }

    function initLanguageSelection() {

        // skip if page does not have language selection (EG: blog)
        if (!locale) return;

        var localeOpen = false;

        locale.addEventListener("click", function() {
                .classList.toggle("visible");
            localeOpen = !localeOpen;
        }, false);


            if (localeOpen && !localeParent.contains(event.target)) {
                    .classList.remove("visible");
                localeOpen = false;
            }
        }, true);
    }

    function navigationClick(event) {
            .classList.toggle("visible");
    }

    function initMenu() {
            .addEventListener("click", navigationClick, false);

        var targetBlankLinks = [].slice.call(

        // close navbarMenu when target _blank links are clicked
        for (var i = 0; i < targetBlankLinks.length; i++) {
            targetBlankLinks[i].addEventListener("click", function() {
                    .classList.remove("visible");
            }, false)
        }
    }

    function initNavbarToggle() {
        var navbarHeight = navbar.offsetHeight;
        var scrollHandled = false;
        var lastScrollTop = 0;
        var desktopBreakpoint = 991;
        var newScrollAction = false;

        // IE9 does not support offsetHeight when element is fixed
        if (!navbarHeight)
            return;

            scrollHandled = false;
        });

            newScrollAction = false;
        });

        setInterval(function() {
                if (
                    !scrollHandled &&
                    ( // locale menu is not visible
                        !navbarLocale || // our blog doesn't have a locale menu
                        !navbarLocale.classList.contains("visible")
                    )
                ) {
                    scrollHandled = handleScroll();
                }
            } else {
                navbar.style.top = 0;
            }
        }, 250);

        function handleScroll() {

            setTimeout(function() {
                if (hash !== "" && currentScroll > navbarHeight) {
                    navbar.style.top = "-" + navbarHeight + "px";
                    newScrollAction = true;
                }
            }, 20)

            if (newScrollAction)
                hash = "";

            if (currentScroll > lastScrollTop && currentScroll > navbarHeight) {
                navbar.style.top = "-" + navbarHeight + "px";
            } else {
                navbar.style.top = 0;
            }

            lastScrollTop = currentScroll;
            return true;
        }
    }

    initLanguageSelection();
    initMenu();
    initNavbarToggle();
    initPreventFooterOverlap();
})();

(function() {


    /**
     * Creats a GDPR compatible video
     * @constructor
     * @param {Element} parent - video parent / container
     * @example
     * <div id="example-video" class="video-parent">
     *   <a
     *     class="video-link"
     *     target="_blank"
     *     href="http://example.com/iframe/video/src">
     *     <img
     *       class="video-thumbnail"
     *       alt="Short description of video"
     *       src="/img/video-thumbnail.png" />
     *     <img
     *       class="video-play"
     *       alt="Open video in separate window""
     *       src="/img/video-link.png" />
     *   </a>
     *   <p class="video-disclaimer">Disclaimer text</p>
     * </div>
     */
    function Video(parent) {
        /**
         * Video parent / container element
         * @member {Element}
         */

        /**
         * The last time that the play button was clicked
         * @member {number}
         */

        var videoLink = parent.querySelector(".video-link");

        /**
         * The iframe video src url
         * @member {string}
         */

        //remove disclaimer if disclaimer is shown by default

        //change external link icon into play button icon
        parent
            .querySelector(".video-play")
            .setAttribute("src", siteurl + "/img/video-play.png");

        //show disclaimer or replace thumbnail with video on click
    }


        _onPlayClick: function(event) {
            event.preventDefault();

            //prevent bypassing the disclaimer via double click
        },

        toggleDisclaimer: function() {
        },

        /** Replace video thumbnail with video iframe */
        insertVideo: function() {

            //replace static thumbnail with iframe video
                "<iframe " +
                "class='video-iframe' " +
                "frameborder=0 " +
                "allowfullscreen " +
                "</iframe>";
        }
    };

        .map(function(parent) {
        });
}());