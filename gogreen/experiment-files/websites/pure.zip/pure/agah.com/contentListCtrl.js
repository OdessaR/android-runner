'use strict';

app.controller('contentListCtrl', [
    '$http', 'categouryTypeId',
    function($http, categouryTypeId) {

        self.tabs = [];
        self.isLoading = false;
        self.page = {
            listGrid: [],
            tabId: 10,
            pageNumber: 1,
            take: 10,
            totalRecord: 0
        };

        var getData = function() {
            self.isLoading = true;
            $http.get('/Data/GetContentList', {
                params: {
                    categoryId: self.page.tabId,
                    pageNumber: self.page.pageNumber,
                    take: self.page.take
                }
            }).success(function(result) {
                self.isLoading = false;
                self.page.listGrid = result.Data;
                self.page.totalRecord = result.TotalCount;
            }).error(function() {
                self.isLoading = false;
            });;
        };

        self.changeTab = function(tab) {
            self.page.tabId = tab.Id;
            getData();
        };

        self.pageChanged = function() {
            getData();
        };

        var getCategoryList = function() {
            $http.get('/Admin/GetCategoryList', {
                    params: {
                        type: categouryTypeId
                    }
                })
                .success(function(result) {
                    self.tabs = result;
                    self.changeTab(self.tabs[0]);
                });
        };
        getCategoryList();

        self.openFilePage = function(item) {
        };

        self.downloadFile = function(item) {
        };

    }
]);