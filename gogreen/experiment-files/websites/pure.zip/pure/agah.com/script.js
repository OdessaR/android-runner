$(document).ready(function(e) {

    $(window).scroll(function() {
        var top = $(document).scrollTop();
        if (top >= 10) {
            $(".header").addClass("fixed");
        } else {
            $(".header").removeClass("fixed");
        }
    });

    //navigation click actions
    $('.scroll-link').on('click', function(event) {
        event.preventDefault();
        var href = $(this).attr("href");
        var sectionID = $(this).attr("data-id");
        scrollToID('#' + sectionID, 750, href);
    });
    // scroll to top action
    $('.scroll-top').on('click', function(event) {
        event.preventDefault();
        $('html, body').animate({
            scrollTop: 0
        }, 'slow');
    });

    // scroll function
    function scrollToID(id, speed, href) {
        var offSet = 50;
        if ($(id).offset()) {
            var targetOffset = $(id).offset().top;
            $('html,body').animate({
                scrollTop: targetOffset
            }, speed);

        } else {
            }
        }
    }

    var products = $(".products");
    var aboutAgah = $(".abuot-agah");
    var contact = $(".contact");
    var features = $(".features");
    var videoPart = $(".video-section");

    if (products && products.length && aboutAgah && aboutAgah.length && contact && contact.length && features && features.length) {
        $(window).scroll(function() {
            var top = $(document).scrollTop();
            //        $(".partition").removeClass('show');

            if (top >= 10) {
                $(".header").addClass("fixed");
            } else {
                $(".header").removeClass("fixed");
            }

            if (top >= videoPart.offset().top - 400) {
                $(".video-section").addClass("show");
            }

            if (top >= products.offset().top - 400) {
                $(".products").addClass("show");
            }
            if (top >= aboutAgah.offset().top - 400) {
                $(".abuot-agah").addClass("show");
            }

            if (top >= contact.offset().top - 400) {
                $(".contact").addClass("show");
            }

            if (top >= features.offset().top - 400) {
                $(".features").addClass("show");
            }
        });
    }

});