'use strict';

app.controller('contentCtrl', [
    '$http', 'fileUpload', 'toaster', 'userType',
    function($http, fileUpload, toaster, userType) {

        self.isLoading = false;
        self.model = {};
        self.CategoryList = [];

        self.tinymceOptions = {
            trusted: true,
            inline: false,
            height: 400,
            language: 'fa_IR',
            directionality: 'rtl',
            skin: 'lightgray',
            theme: 'modern',
            plugins: [
                "advlist autolink lists link image charmap print preview hr anchor pagebreak", "searchreplace wordcount visualblocks visualchars code fullscreen", "insertdatetime media nonbreaking save table contextmenu directionality", "template textcolor colorpicker textpattern imagetools"
                //,"emoticons paste"
            ],
            toolbar: "insertfile undo redo | styleselect fontsizeselect fontselect | forecolor backcolor bold italic | ltr rtl | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image | preview media", //emoticons, print
            menubar: true,
            image_advtab: true,
            relative_urls: false,
            remove_script_host: false
            //convert_urls: false,
            //,templates: [
            //    { title: 'Test template 1', content: '<h1>Test 1</h1>  <img src="" /> <p> content </p> ' }
            //]
        };

        self.myFile = {};
        self.saveContent = function() {
            var imageFile = self.imageFile;
            var attachFile = self.attachFile;
            if (!imageFile || !attachFile) {
                toaster.showError('لطفا فایلهای پیوستی را انتخاب نمایید');
            } else if (!self.model.CategoryId || self.model.CategoryId == 0) {
                toaster.showError('لطفا یک گروه انتخاب نمایید');
            } else if (!self.model.Title || self.model.Title.length <= 0 || !self.model.Body || self.model.Body.length <= 0) {
                toaster.showError('لطفا عنوان و متن را وارد نمایید');
            } else {
                var uploadUrl = "/Admin/SaveContent";
                fileUpload.uploadFileToUrl(self.model, imageFile, attachFile, uploadUrl);
            }
        };

        var getCategoryList = function() {
            $http.get('/Admin/GetCategoryList', {
                    params: {
                        type: userType
                    }
                })
                .success(function(result) {
                    self.CategoryList = result;
                });
        }
        getCategoryList();

        self.clickUploadImage = function() {
        };

        self.clickUploadAttach = function() {
        };
    }
]);