'use strict';

app.controller('sectionCtrl', ['$timeout', '$document',
    function($timeout, $document) {


        self.slides = [{
                Id: 0,
                Image: '/content/images/Agah-001.jpg',
                Position: 'bottom',
                Link: 'https://bashgah.com/blog/%D8%A7%D8%B7%D9%84%D8%A7%D8%B9-%D8%B1%D8%B3%D8%A7%D9%86%DB%8C-%D8%AF%D8%B3%D8%AA%D8%B1%D8%B3%DB%8C-%D8%B3%D8%A7%D9%85%D8%A7%D9%86%D9%87-%D8%A2%D8%B3%D8%A7%D8%AA%D8%B1%DB%8C%D8%AF%D8%B1/',
                Active: true
            }, {
                Id: 1,
                Image: '/content/images/22.jpg',
                Note: 'برای فعالیت در بازار سرمایه، ثبت نام در سامانه سجام الزامی است!',
                Title: 'ثبت اطلاعات در سجام',
                Position: 'bottom',
                Active: false
            }, {
                Id: 2,
                Image: '/content/images/222.jpg',
                Note: '<p>🥇بیشترین تعداد مشتریان در سال 97</p>' +
                    '<p>🥇بیشترین کد معاملاتی صادر شده توسط کارگزاری در سال 97</p>' +
                    '<p>🥇بیشترین کارگزاری از لحاظ اخذ مجوز خارجی در سال 97</p>' +
                    '<p>🥈بیشترین دفعات معاملات کارگزاری ها در سال 97</p>' +
                    '<p>🥈بیشترین ازش معاملات برخط در کل بورس ها در سال 97</p>' +
                    '<p>🥉بیشترین ارزش معاملات در بورس کالای ایران در سال 97</p>',
                Title: 'کارگزاری آگاه',
                Active: false,
                Position: 'left',
                Link: 'https://goo.gl/wkZuFE'
            },
            /*{
                       Id: 2,
                       Image: '/content/images/01.gif',
                       Active: false,
                       Position: 'bottom',
                       Link: 'https://bit.ly/2VgolHx'
                   },*/
            /*{
            Id: 1,
            Image: '/content/images/Artboard-1441.jpg',
            Active: false
        },*/
            {
                Id: 3,
                Image: '/content/images/Fund1.jpg',
                Active: false,
                Note: 'پربازده ترین صندوق سرمایه گذاری ایران با بیش از 3300% درصد بازده 10 ساله شد',
                Title: 'صندوق آگاه',
                Position: 'left',
                Link: 'https://goo.gl/j6JSHb'
            }, {
                Id: 4,
                Image: '/content/images/view1.jpg',
                ImageE: '/content/images/e1.jpg',
                Active: false,
                Title: 'باشگاه مشتریان کارگزاری آگاه',
                Subject: 'به قله ی توانمندی های خود صعود کنید... !',
                Note: 'بآشگاه مشتریان کارگزاری آگاه ، ابزاریست برای ارائه خدمات سازمان‌یافته به همه سرمایه‌گذاران بازار سرمایه و مشتریان آگاه که شامل تخفیف نقدی کارمزد معاملات سهام، دریافت اعتبار معاملاتی و وام قرض الحسنه برای انجام معاملات، تخفیف خرید بسته‌های مشاوره‌ای- تحلیلی و بسته‌های آموزشی می باشد. ',
                eTitle: 'آشنایی با سرمایه گذاری در بازار سرمایه',
                eContent: 'در دوره ” آشنایی با سرمایه گذاری در بازار سرمایه” مفاهیم و اصطلاحات کاربردی  و نحوه خرید و فروش سهام از طریق معاملات آنلاین به  دانش پذیران آموزش داده می شود.',
                Position: 'top',
                Link: 'https://bashgah.com/blog/%D8%A8%D8%A7%D8%B4%DA%AF%D8%A7%D9%87-%DA%86%DB%8C%D8%B3%D8%AA'
            }, {
                Id: 5,
                Image: '/content/images/view2.jpg',
                ImageE: '/content/images/e2.jpg',
                Active: false,
                Title: 'شما هم حرفه ای می شوید',
                Note: 'کارگزاری آگاه برنامه های آموزشی مقدماتی و تخصصی متنوع مربوط به بازار سرمایه را به صورت مستمر در محل کارگزاری و شعب آن و یا سازمان ها و ارگان های متقاضی با بهره گیری از اساتید مجرب و سرفصل های کاملا کاربردی برای همه مخاطبان خود برگزار می کند. ',
                eTitle: 'تحلیل تکنیکال مقدماتی',
                eContent: 'شناسایی روند بازار با استفاده از نمودارهای قیمت یکی از قوی ترین روش های پیش بینی رفتار بازار است.  این دوره به شناسایی  روند صحیح  بازار برای سرمایه گذاری موثر و  پر بازده کمک می نماید.',
                Position: 'top',
                Link: 'https://bashgah.com/blog/education'
            }, {
                Id: 6,
                Image: '/content/images/view3.jpg',
                ImageE: '/content/images/theme.jpg',
                Active: false,
                Title: 'مشاوره با متخصصین آگاه',
                Note: 'کارگزاری آگاه به منظور ارائه سرویس کامل و حرفه ای به مشتریان خود ، شرکت مشاور سرمایه گذاری آوای آگاه را به عنوان اولین شرکت مشاور سرمایه گذاری کشور در سال 89 تاسیس کرد. این شرکت خدمات تخصصی خود را در حوزه سرمایه گذاری در اوراق بهادار و بازار آتی سکه و ارز به صورت آنلاین و  اختصاصی با شرایط بسیار ویژه ای به مشتریان آگاه ارائه می نماید. ',
                eTitle: 'تحلیل تکنیکال پیشرفته',
                eContent: 'در تحلیل پیشرفته چگونگی استفاده صحیح از ابزارها، الگوها  و اندیكاتورها معرفی می شود تا بتوان بهترین زمان ورود و خروج به بازار را تشخیص داده و همچنین آینده قیمت بازار را با دقت بالایی پیش بینی نموده و در نهایت تحلیل صحیحی از نمودارهای قیمت داد.',
                Position: 'top',
                Link: '/investmentAdvice#investmentAdvice1'
            }, {
                Id: 7,
                Image: '/content/images/view4.jpg',
                ImageE: '/content/images/view3.jpg',
                Active: false,
                Title: 'معاملات برخط ',
                Note: 'نرم افزار آسا به عنوان نسل جدید نرم افزارهای معاملات برخط، با هدف سهولت و بهبود کیفیت خرید و فروش آنلاین سهام در بازار بورس اوراق بهادار طراحی شده است و به صورت اختصاصی در اختیار مشتریان کارگزاری آگاه قرار دارد. نرم افزار معاملات بر خط آسا با در نظر گرفتن سرعت، دسترسی آسانتر و دقت در انجام خرید و فروش اوراق بهادار، در اختیار سرمایه گذاران قرار گرفته‌است. ارائه نسخه موبایل و تبلت (اندروید) نرم افزار معاملات برخط آسا، باعث شده است تا سرمایه‌‍گذاران براحتی معاملات خود را در بازار بورس اوراق بهادار انجام دهند. ',
                eTitle: 'تحلیل بنیادی مقدماتی',
                eContent: ' تحلیل بنیادی سعی دارد تا با استفاده از تجزیه و تحلیل مفاهیمی چون ارزش ذاتی و بازاری یک دارایی، تحلیل صنعت، ارزش زمانی پول و ارزیابی جریانات نقدی تنزیل شده ، بررسی صورت های مالی اساسی و مدل های ارزش گذاری شرکت ها به تصمیم گیری صحیح کمک کند.',
                Position: 'top',
                Link: 'https://bashgah.com/blog/%D8%B1%D8%A7%D9%87%D9%86%D9%85%D8%A7%DB%8C-%D9%86%D8%B3%D8%AE%D9%87-%D9%88%DB%8C%D9%86%D8%AF%D9%88%D8%B2-%D9%86%D8%B1%D9%85-%D8%A7%D9%81%D8%B2%D8%A7%D8%B1-%D9%85%D8%B9%D8%A7%D9%85%D9%84%D8%A7%D8%AA'
            }
        ];

        var slideInterval;

        function setSlideShowInterval() {
            slideInterval = setInterval(function() {
                $timeout(function() {
                    var isActive = false;
                    var l = self.slides.length;
                    for (var i = 0; i < l; i++) {
                        var s = self.slides[i];
                        var sa = s.Active;
                        s.Active = isActive;
                        isActive = sa;
                    }
                    if (isActive) {
                        self.slides[0].Active = isActive;
                    }
                }, 0);
            }, 8000);
        };
        setSlideShowInterval();

        self.activeThisSlide = function(slide) {
            if (slideInterval) clearInterval(slideInterval);

            self.slides.forEach(function(s) {
            });

            setSlideShowInterval();
        };

        self.activePrevSlide = function(slide) {

            var index = self.slides.indexOf(slide);
            index--;
            if (index < 0) {
                index = self.slides.length - 1;
            }

            self.activeThisSlide(self.slides[index]);
        };

        self.activeNextSlide = function(slide) {

            var index = self.slides.indexOf(slide);
            index++;
            if (index > self.slides.length) {
                index = 0;
            }

            self.activeThisSlide(self.slides[index]);
        };

        //self.showMenuRight = false;
        $document.on('click', function(e) {
                if (e.target && e.target.className.indexOf('header') !== 0 && self.showMenuRight) {
                    self.showMenuRight = false;
                }
            }
        });

    }
]);