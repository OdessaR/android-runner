'use strict';

app.controller('footerCtrl', ['$http', 'toaster',
    function($http, toaster) {

        self.capthaUrl = '';
        self.model = {
            email: '',
            title: '',
            message: '',
            captchaCode: ''
        }

        self.refreshCaptcha = function() {
            self.capthaUrl = '/Home/GetCaptcha?' + new Date().getTime();
        };

        self.refreshCaptcha();

        self.sendEmail = function() {
            if (self.model.email.length > 0 && self.model.title.length > 0) {
                if (self.model.captchaCode.length > 0) {
                    $http.post('/Home/SendEmail', {
                        email: self.model.email,
                        title: self.model.title,
                        message: self.model.message,
                        captchaCode: self.model.captchaCode
                    }).success(function(result) {
                        if (result === true) {
                        } else {
                            toaster.showError('متن تصویر نادرست است');
                            self.refreshCaptcha();
                        }
                    });
                } else {
                    toaster.showError('لطفا متن تصویر را وارد نمایید');
                }
            } else {
                toaster.showError('لطفا ایمیل و عنوان را وارد نمایید');
            }
        }
    }
]);