'use strict';

app.controller('contentFileCtrl', [
    '$http',
    function($http) {

        self.ContentFile = {};

        var getContentFile = function() {
            $http.get('/Data/GetContentFile', {
                params: {
                    id: self.id
                }
            }).success(function(result) {
                self.ContentFile = result;
            });
        }
        getContentFile();

        self.downloadFile = function() {
        }
    }
]);