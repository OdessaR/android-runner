/*
    A simple jQuery modal (http://github.com/kylefox/jquery-modal)
    Version 0.8.2
*/

(function(factory) {
    // Making your jQuery plugin work better with npm tools
    // http://blog.npmjs.org/post/112712169830/making-your-jquery-plugin-work-better-with-npm
        factory(require("jquery"), window, document);
    } else {
        factory(jQuery, window, document);
    }
}(function($, window, document, undefined) {

    var modals = [],
        getCurrent = function() {
            return modals.length ? modals[modals.length - 1] : null;
        },
        selectCurrent = function() {
            var i,
                selected = false;
            for (i = modals.length - 1; i >= 0; i--) {
                if (modals[i].$blocker) {
                    modals[i].$blocker.toggleClass('current', !selected).toggleClass('behind', selected);
                    selected = true;
                }
            }
        };

        var remove, target;
            while ($.modal.isActive())
                $.modal.close(); // Close any open modals.
        modals.push(this);
        if (el.is('a')) {
            target = el.attr('href');
            //Select element by id from href
            if (/^#/.test(target)) {
                //AJAX
            } else {
                remove = function(event, modal) {
                    modal.elm.remove();
                };
                el.trigger($.modal.AJAX_SEND);
                $.get(target).done(function(html) {
                    if (!$.modal.isActive()) return;
                    el.trigger($.modal.AJAX_SUCCESS);
                    var current = getCurrent();
                    current.$elm.empty().append(html).on($.modal.CLOSE, remove);
                    current.hideSpinner();
                    current.open();
                    el.trigger($.modal.AJAX_COMPLETE);
                }).fail(function() {
                    el.trigger($.modal.AJAX_FAIL);
                    var current = getCurrent();
                    current.hideSpinner();
                    modals.pop(); // remove expected modal from the list
                    el.trigger($.modal.AJAX_COMPLETE);
                });
            }
        } else {
        }
    };

        constructor: $.modal,

        open: function() {
                setTimeout(function() {
                    m.show();
            } else {
            }
            $(document).off('keydown.modal').on('keydown.modal', function(event) {
                var current = getCurrent();
                if (event.which == 27 && current.options.escapeClose) current.close();
            });
                        $.modal.close();
                });
        },

        close: function() {
            modals.pop();
            if (!$.modal.isActive())
                $(document).off('keydown.modal');
        },

        block: function() {
            selectCurrent();
                    opacity: 1
            }
        },

        unblock: function(now) {
            else {
                selectCurrent();
                if (!$.modal.isActive())
            }
        },

        show: function() {
            }
                    opacity: 1
            } else {
            }
        },

        hide: function() {
                    _this.$elm.trigger($.modal.AFTER_CLOSE, [_this._ctx()]);
                });
            } else {
                    _this.$elm.trigger($.modal.AFTER_CLOSE, [_this._ctx()]);
                });
            }
        },

        showSpinner: function() {
        },

        hideSpinner: function() {
        },

        //Return context for custom events
        _ctx: function() {
            return {
            };
        }
    };

        if (!$.modal.isActive()) return;
        if (event) event.preventDefault();
        var current = getCurrent();
        current.close();
        return current.$elm;
    };

    // Returns if there currently is an active modal
        return modals.length > 0;
    }


        closeExisting: true,
        escapeClose: true,
        clickClose: true,
        closeText: 'Close',
        closeClass: '',
        modalClass: "modal",
        blockerClass: "jquery-modal",
        spinnerHtml: null,
        showSpinner: true,
        showClose: true,
        fadeDuration: null, // Number of milliseconds the fade animation takes.
        fadeDelay: 1.0 // Point during the overlay's fade-in that the modal begins to fade in (.5 = 50%, 1.5 = 150%, etc.)
    };

    // Event constants

        }
    };

    // Automatically bind links with rel="modal:close" to, well, close the modal.
    $(document).on('click.modal', 'a[rel~="modal:close"]', $.modal.close);
    $(document).on('click.modal', 'a[rel~="modal:open"]', function(event) {
        event.preventDefault();
        $(this).modal();
    });
}));