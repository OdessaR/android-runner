'use strict';

app.service('fileUpload', [
    '$http', 'toaster',
    function($http, toaster) {
            fd.append('imageFile', imageFile);
            fd.append('attachFile', attachFile);
            fd.append('title', content.Title);
            fd.append('categoryId', content.CategoryId);
            fd.append('body', content.Body);

            $http.post(uploadUrl, fd, {
                    headers: {
                        'Content-Type': undefined
                    }
                })
                .success(function(result) {
                    if (result && result.state === "UPLOADSIZEFAILED") {
                        toaster.showError('حجم فایل آپلود شده زیاد است');
                    } else if (result && result.state === "UPLOADEXTENTIONFAILED") {
                        toaster.showError('نوع فایل آپلود شده اشتباه است');
                    } else if (result && result.state === "Success") {
                        toaster.showSuccess('عملیات با موفقیت انجام شد');
                    } else {
                        toaster.showError("مشکلی رخ داده است، لطفا دوباره تلاش کنید");
                    }
                })
                .error(function(result) {
                    toaster.showError("مشکلی رخ داده است، لطفا دوباره تلاش کنید");
                });
        }
    }
]);