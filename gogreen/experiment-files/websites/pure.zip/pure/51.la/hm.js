(function() {
    var h = {},
        mt = {},
        c = {
            id: "bd18429bc8eb892f081d3f995c802e1e",
            dm: ["51.la"],
            js: "tongji.baidu.com/hm-web/js/",
            etrk: [],
            cetrk: [],
            cptrk: [],
            icon: '',
            ctrk: ["%5b%2251.la%22%5d"],
            nv: -1,
            vdur: 1800000,
            age: 31536000000,
            rec: 0,
            rp: [],
            trust: 0,
            vcard: 0,
            qiao: 0,
            lxb: 0,
            kbtrk: 0,
            pt: 0,
            spa: 0,
            oc: 0,
            aet: '',
            hca: '9CE3A4FF3C8C8A92',
            conv: 0,
            med: 0,
            cvcc: '',
            cvcf: [],
            apps: ''
        };
    var t = void 0,
        v = !0,
        x = null,
        y = !1;
    mt.cookie = {};
    mt.cookie.set = function(a, b, g) {
        var f;
        g.R && (f = new Date, f.setTime(f.getTime() + g.R));
    };
    mt.cookie.get = function(a) {
    };
    mt.cookie.rc = function(a, b) {
        try {
            var g = "Hm_ck_" + +new Date;
            mt.cookie.set(g, "is-cookie-enabled", {
                domain: a,
                path: b,
                R: t
            });
            var f = "is-cookie-enabled" === mt.cookie.get(g) ? "1" : "0";
            mt.cookie.set(g, "", {
                domain: a,
                path: b,
                R: -1
            });
            return f
            return "0"
        }
    };
    mt.lang = {};
    mt.lang.d = function(a, b) {
        return "[object " + b + "]" === {}.toString.call(a)
    };
    mt.lang.cb = function(a) {
        return mt.lang.d(a, "Number") && isFinite(a)
    };
    mt.lang.H = function(a) {
        return mt.lang.d(a, "String")
    };
    mt.lang.isArray = function(a) {
        return mt.lang.d(a, "Array")
    };
    mt.lang.h = function(a) {
        return a.replace ? a.replace(/'/g, "'0").replace(/\*/g, "'1").replace(/!/g, "'2") : a
    };
    mt.lang.trim = function(a) {
        return a.replace(/^\s+|\s+$/g, "")
    };
    mt.lang.G = function(a, b) {
        var g = y;
        if (a == x || !mt.lang.d(a, "Array") || b === t) return g;
        if (Array.prototype.indexOf) g = -1 !== a.indexOf(b);
        else
            for (var f = 0; f < a.length; f++)
                if (a[f] === b) {
                    g = v;
                    break
                } return g
    };
    mt.url = {};
    mt.url.m = function(a, b) {
        var g = a.match(RegExp("(^|&|\\?|#)(" + b + ")=([^&#]*)(&|$|#)", ""));
        return g ? g[3] : x
    };
    mt.url.Lc = function(a) {
    };
    mt.url.Vb = function(a) {
    };
    mt.url.L = function(a) {
    };
    mt.url.Fa = function(a) {
    };
    (function() {
        var a = mt.lang,
            b = mt.url;
        mt.f = {};
        mt.f.Wa = function(a) {
        };
        mt.f.Da = function(a) {
            if (!a) return x;
            try {
                a = String(a);
                if (0 === a.indexOf("!HMCQ!")) return a;
                    if (-1 < f[b].indexOf("#")) {
                        var e = f[b].split("#")[1];
                        f = f.splice(b + 1, f.length - (b + 1));
                        break
                    } for (a =
                    0; d && a < f.length;) {
                    var l = String(f[a]).toLowerCase();
                    if (!("html" === l || "body" === l)) {
                        var b = 0,
                            n = f[a].match(/\[(\d+)\]/i),
                            e = [];
                        if (n) b = n[1] - 1, l = l.split("[")[0];
                        else if (1 !== d.childNodes.length) {
                            for (var q = 0, s = 0, p = d.childNodes.length; s < p; s++) {
                                var r = d.childNodes[s];
                                1 === r.nodeType && r.nodeName.toLowerCase() === l && q++;
                                if (1 < q) return x
                            }
                            if (1 !== q) return x
                        }
                        if (!e[b]) return x;
                        d = e[b]
                    }
                    a++
                }
                return d
                return x
            }
        };
        mt.f.Fa = function(a, f) {
            var d = [],
                b = [];
            if (!a) return b;
            for (; a.parentNode != x;) {
                for (var e = 0, l = 0, n = a.parentNode.childNodes.length, q = 0; q < n; q++) {
                    var s = a.parentNode.childNodes[q];
                    if (s.nodeName === a.nodeName && (e++, s === a && (l = e), 0 < l && 1 < e)) break
                }
                if ((n = "" !== a.id) && f) {
                    d.unshift("#" + encodeURIComponent(a.id));
                    break
                } else n && (n = "#" + encodeURIComponent(a.id), n = 0 < d.length ? n + ">" + d.join(">") : n, b.push(n)), d.unshift(encodeURIComponent(String(a.nodeName).toLowerCase()) + (1 < e ? "[" + l + "]" : ""));
                a = a.parentNode
            }
            b.push(d.join(">"));
            return b
        };
        mt.f.ma = function(a) {
            return (a = mt.f.Fa(a, v)) && a.length ? String(a[0]) : ""
        };
        mt.f.Zb = function(a) {
            return mt.f.Fa(a, y)
        };
        mt.f.Xa = function(a) {
            var f;
            for (f = "A";
                (a = a.parentNode) && 1 == a.nodeType;)
                if (a.tagName == f) return a;
            return x
        };
        mt.f.Rb = function(a) {
            return 9 === a.nodeType ? a : a.ownerDocument || a.document
        };
        mt.f.Ya = function(a) {
            var f = {
                top: 0,
                left: 0
            };
            if (!a) return f;
            var d = mt.f.Rb(a).documentElement;
            "undefined" !== typeof a.getBoundingClientRect && (f = a.getBoundingClientRect());
            return {
                    (d.clientTop || 0),
            }
        };
        mt.f.getAttribute = function(a, f) {
            var d = a.getAttribute && a.getAttribute(f) || x;
            if (!d && a.attributes && a.attributes.length)
                for (var b = a.attributes, e = b.length, l = 0; l < e; l++) b[l].nodeName === f && (d = b[l].nodeValue);
            return d
        };
        mt.f.V = function(a) {
            var f = "document";
            a.tagName !== t && (f = a.tagName);
            return f.toLowerCase()
        };
        mt.f.bc = function(b) {
            var f = "";
            b.textContent ? f = a.trim(b.textContent) : b.innerText && (f = a.trim(b.innerText));
            f && (f = f.replace(/\s+/g,
                " ").substring(0, 255));
            return f
        };
        mt.f.U = function(g, f) {
            var d;
            return String(d || "").substring(0,
                255)
        };
        (function() {
            (mt.f.jb = function() {
                function a() {
                    if (!a.pa) {
                        a.pa = v;
                        for (var f = 0, d = b.length; f < d; f++) b[f]()
                    }
                }

                function f() {
                    try {
                    } catch (b) {
                        setTimeout(f, 1);
                        return
                    }
                    a()
                }
                var d = y,
                    b = [],
                    e;
                    a()
                });
                (function() {
                    if (!d)
                        var b = y;
                        try {
                    }
                })();
                return function(f) {
                    a.pa ? f() : b.push(f)
                }
            }()).pa = y
        })();
        return mt.f
    })();
    mt.event = {};
    mt.event.e = function(a, b, g) {
        a.attachEvent ? a.attachEvent("on" + b, function(f) {
            g.call(a, f)
        }) : a.addEventListener && a.addEventListener(b, g, y)
    };
    mt.event.preventDefault = function(a) {
    };
    (function() {
        var a = mt.event;
        mt.g = {};
        mt.g.Wb = function() {
            return a ? +a[1] || 0 : 0
        };
        mt.g.Nc = function() {
            try {
            } catch (a) {
                return y
            }
        };
        mt.g.W = function() {
            var a;
        };
        mt.g.M = function() {
        };
        mt.g.tb =
            0;
        mt.g.ec = function() {
        };
        mt.g.orientation = 0;
        (function() {
            function b() {
                var a = 0;
                mt.g.orientation = a;
                mt.g.tb = mt.g.ec()
            }
            b();
            a.e(window, "orientationchange", b)
        })();
        return mt.g
    })();
    mt.s = {};
    mt.s.parse = function(a) {
        return (new Function("return (" + a + ")"))()
    };
    mt.s.stringify = function() {
        function a(a) {
                var f = g[a];
                if (f) return f;
                f = a.charCodeAt();
                return "\\u00" + Math.floor(f / 16).toString(16) + (f % 16).toString(16)
            }));
            return '"' + a + '"'
        }

        function b(a) {
            return 10 > a ? "0" + a : a
        }
        var g = {
            "\b": "\\b",
            "\t": "\\t",
            "\n": "\\n",
            "\f": "\\f",
            "\r": "\\r",
            '"': '\\"',
            "\\": "\\\\"
        };
        return function(f) {
            switch (typeof f) {
                case "undefined":
                    return "undefined";
                case "number":
                    return isFinite(f) ? String(f) : "null";
                case "string":
                    return a(f);
                case "boolean":
                    return String(f);
                default:
                    if (f === x) return "null";
                    if (f instanceof Array) {
                        var d = ["["],
                            g = f.length,
                            e, l, n;
                        for (l = 0; l < g; l++) switch (n = f[l], typeof n) {
                            case "undefined":
                            case "function":
                            case "unknown":
                                break;
                            default:
                                e && d.push(","), d.push(mt.s.stringify(n)), e = 1
                        }
                        d.push("]");
                        return d.join("")
                    }
                    if (f instanceof Date) return '"' + f.getFullYear() + "-" + b(f.getMonth() + 1) + "-" + b(f.getDate()) + "T" + b(f.getHours()) + ":" + b(f.getMinutes()) + ":" + b(f.getSeconds()) + '"';
                    for (g in f)
                            case "undefined":
                            case "unknown":
                            case "function":
                                break;
                            default:
                        }
            }
        }
    }();
    mt.localStorage = {};
    mt.localStorage.xa = function() {
        if (!mt.localStorage.l) try {
            return y
        }
        return v
    };
    mt.localStorage.set = function(a, b, g) {
        var f = new Date;
        f.setTime(f.getTime() + g || 31536E6);
        try {
    };
    mt.localStorage.get = function(a) {
                var b = a.indexOf("|"),
                    g = a.substring(0, b) - 0;
                if (g && g > (new Date).getTime()) return a.substring(b + 1)
            }
        } else if (mt.localStorage.xa()) try {
        return x
    };
    mt.localStorage.remove = function(a) {
        else if (mt.localStorage.xa()) try {
    };
    mt.sessionStorage = {};
    mt.sessionStorage.set = function(a, b) {
        try {
    };
    mt.sessionStorage.get = function(a) {
        try {
            return x
        }
    };
    mt.sessionStorage.remove = function(a) {
        try {
    };
    mt.pb = {};
    mt.pb.log = function(a, b) {
            f = "mini_tangram_log_" + Math.floor(2147483648 * Math.random()).toString(36);
        g.onload = function() {
            g.onload = x;
            b && b(a)
        };
        g.src = a
    };
    mt.Na = {};
    mt.Na.dc = function() {
        var a = "";
            b && b.description && (a = b.description.replace(/^.*\s+(\S+)\s+\S+$/, "$1"))
        return a
    };
    mt.Na.Kc = function(a, b, g, f, d) {
        return '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" id="' + a + '" width="' + g + '" height="' + f + '"><param name="movie" value="' + b + '" /><param name="flashvars" value="' + (d || "") + '" /><param name="allowscriptaccess" value="always" /><embed type="application/x-shockwave-flash" name="' + a + '" width="' + g + '" height="' + f + '" src="' + b + '" flashvars="' + (d || "") + '" allowscriptaccess="always" /></object>'
    };
    h.A = {
        Mc: "http://tongji.baidu.com/hm-web/welcome/ico",
        Ma: "hm.baidu.com/hm.gif",
        Ab: /^(tongji|hmcdn).baidu.com$/,
        rb: "tongji.baidu.com",
        ic: "hmmd",
        jc: "hmpl",
        Hc: "utm_medium",
        hc: "hmkw",
        Jc: "utm_term",
        fc: "hmci",
        Gc: "utm_content",
        kc: "hmsr",
        Ic: "utm_source",
        gc: "hmcu",
        Fc: "utm_campaign",
        N: 0,
        J: Math.round(+new Date / 1E3),
        ra: "https:",
        Oc: 0,
        Gb: 6E5,
        Pc: 6E5,
        xc: 5E3,
        Hb: 5,
        P: 1024,
        Fb: 1,
        ca: 2147483647,
        qb: "hca kb cc cf ci ck cl cm cp cu cw ds vl ep et fl ja ln lo lt rnd si su v cv lv api sn r ww p ct u tt".split(" "),
        Y: v,
        Ta: ["a", "input", "button"],
        Qa: {
            id: "data-hm-id",
            ha: "data-hm-class",
            ga: "data-hm-xpath",
            content: "data-hm-content",
            ua: "data-hm-tag",
            link: "data-hm-link"
        },
        Sa: "data-hm-enabled",
        Ra: "data-hm-disabled",
        tc: "https://hmcdn.baidu.com/static/tongji/plugins/",
        ib: ["UrlChangeTracker", "OcpcCbHm"]
    };
    (function() {
        var a = {
            F: {},
            e: function(a, g) {
            },
            K: function(a, g) {
            }
        };
        return h.z = a
    })();
    (function() {
        var a = mt.lang,
            b = /^https?:\/\//,
            g = {
                Qb: function(a) {
                    var d;
                    try {
                        d = JSON.parse(decodeURIComponent(a[0]))
                    } catch (b) {}
                    return d
                },
                eb: function(a, d) {
                    b.test(a) || (g = g.replace(b, ""));
                    a = a.replace(/\/$/, "");
                    g = g.replace(/\/$/, "");
                    d && (g = g.replace(/^(https?:\/\/)?www\./, "$1"));
                    return RegExp("^" + a.replace(/[?.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$").test(g)
                },
                S: function(f, d) {
                    var b = g.Qb(f);
                    if (!a.d(b, "Undefined")) {
                        if (a.d(b, "Array")) {
                            for (var e = 0; e < b.length; e++)
                                if (g.eb(b[e],
                                        d)) return v;
                            return y
                        }
                        if (a.d(b, "Object")) {
                            var e = [],
                                l;
                            for (l in b) b.hasOwnProperty(l) && g.eb(l, d) && (e = e.concat(b[l]));
                            return e
                        }
                    }
                }
            };
        return h.ia = g
    })();
    (function() {
        function a(a, f) {
            d.charset = "utf-8";
            b.d(f, "Function") && (d.readyState ? d.onreadystatechange = function() {
                if ("loaded" === d.readyState || "complete" === d.readyState) d.onreadystatechange = x, f()
            } : d.onload = function() {
                f()
            });
            d.src = a;
            u.parentNode.insertBefore(d, u)
        }
        var b = mt.lang;
    })();
    (function() {
        var a = mt.cookie,
            b = mt.localStorage,
            g = mt.sessionStorage,
            f = {
                getData: function(f) {
                    try {
                        return a.get(f) || g.get(f) || b.get(f)
                },
                setData: function(d, u, e) {
                    try {
                        a.set(d, u, {
                            domain: f.T(),
                            path: f.la(),
                            R: e
                        }), e ? b.set(d, u, e) : g.set(d, u)
                },
                removeData: function(d) {
                    try {
                        a.set(d, "", {
                            domain: f.T(),
                            path: f.la(),
                            R: -1
                        }), g.remove(d), b.remove(d)
                },
                Z: function(a, f) {
                    a = "." + a.replace(/:\d+/, "");
                    f = "." + f.replace(/:\d+/, "");
                    var b = a.indexOf(f);
                    return -1 < b && b + f.length === a.length
                },
                qa: function(a, f) {
                    a = a.replace(/^https?:\/\//,
                        "");
                    return 0 === a.indexOf(f)
                },
                T: function() {
                        if (f.Z(a, c.dm[b])) return c.dm[b].replace(/(:\d+)?[/?#].*/, "");
                    return a
                },
                la: function() {
                    for (var a = 0, b = c.dm.length; a < b; a++) {
                        var e = c.dm[a];
                    }
                    return "/"
                }
            };
        return h.Aa = f
    })();
    (function() {
        var a = mt.lang,
            b = mt.s,
            g = h.Aa,
            f = {
                pageview: {},
                session: {},
                autoEventTracking: {},
                customEvent: {},
                user: {}
            },
            d = {
                user: 1,
                session: 2,
                pageview: 3,
                autoEventTracking: 3,
                customEvent: 3,
                others: 3
            },
            u = ["session", "user"],
            e = "Hm_up_" + c.id,
            l = {
                init: function() {
                    l.nc()
                },
                nc: function() {
                    try {
                        var d = b.parse(decodeURIComponent(g.getData(e)));
                        a.d(d, "Object") && (f.user = d)
                },
                B: function(a) {
                    var b = {};
                    f[a] !== t && (b = f[a]);
                    for (var d in b) b.hasOwnProperty(d) && (a[d] = b[d]);
                    return a
                },
                Ga: function() {
                    for (var a = {}, b, d = u.length -
                            1; 0 <= d; d--) {
                        b = f[u[d]];
                        for (var p in b) b.hasOwnProperty(p) && (a[p] = b[p])
                    }
                    return a
                },
                setProperty: function(d, e, g) {
                    var p = f[d];
                    if (a.d(p, "Object") && a.d(e, "Object")) {
                        for (var r in e)
                            if (e.hasOwnProperty(r)) {
                                var k = a.h(String(r));
                                if (g || !/^_/.test(k) && !/_$/.test(k) || /^(_iden|ei_|ec_|ex_|en_|et_|el_)$/.test(k)) {
                                    var m = e[r];
                                    if (m == x) delete p[k];
                                    else {
                                        if (a.d(m, "Object") || a.d(m, "Array")) m = b.stringify(m);
                                        m = a.h(String(m));
                                        l.qc(d, k, m) && (p[k] = {
                                            value: m,
                                            scope: l.$a(d)
                                        })
                                    }
                                }
                            }
                        "user" === d && l.Ka()
                    }
                },
                o: function(b) {
                    b !== t && ("userId" ===
                        b && a.d(f.user, "Object") ? (delete f.user.uid_, l.Ka()) : "user" === b && a.d(f.user, "Object") ? (b = f.user.uid_, f.user = b === t ? {} : {
                            uid_: b
                        }, l.Ka()) : f[b] !== t && (f[b] = {}))
                },
                Ka: function() {
                    try {
                        g.setData(e, encodeURIComponent(b.stringify(f.user)), c.age)
                    } catch (a) {}
                },
                qc: function(a, b, d) {
                    var p = v,
                        e = f[a];
                    if (256 < encodeURIComponent(String(b)).length || 256 < encodeURIComponent(String(d)).length) p = y;
                    else {
                        var k = e[b];
                        e[b] = {
                            value: d,
                            scope: l.$a(a)
                        };
                        a = l.O(l.B(a));
                        2048 < encodeURIComponent(a).length && (k !== t ? e[b] = k : delete e[b], p = y)
                    }
                    return p
                },
                O: function(a) {
                    var b = [],
                        f, d;
                    for (d in a) a.hasOwnProperty(d) && (f = [d, a[d].value], (1 === a[d].scope || 2 === a[d].scope) && f.push(a[d].scope), b.push(f.join("*")));
                    return b.join("!")
                },
                $a: function(a) {
                    a = d[a];
                    return a !== t ? a : d.others
                }
            };
        return h.Q = l
    })();
    (function() {
        var a = mt.f,
            b = mt.lang,
            g = h.z,
            f = h.ia,
            d = h.Q,
            u = d.O;
        if (b.isArray(c.cptrk) && 0 < c.cptrk.length) {
            var e = {
                hb: {},
                va: {},
                init: function() {
                    for (var a, d = f.S(c.cptrk) || [], q = 0; q < d.length; q++)
                        if (a = d[q], a.a !== t && b.d(a.a, "Object")) {
                            a = a.a;
                            for (var g in a) a.hasOwnProperty(g) && (e.va[g] = String(a[g]))
                        }
                },
                gb: function() {
                    var b, f, d;
                    for (d in e.va)
                        if (e.va.hasOwnProperty(d) && e.hb[d] === t && (b = e.va[d], b = a.Da(b))) f = f === t ? {} : f, f[d] = a.U(b, y), e.hb[d] = v;
                    return f
                },
                Ha: function() {
                    var a = e.gb();
                    a && e.zc(a)
                },
                mc: function() {
                    "MutationObserver" in
                        childList: v,
                        subtree: v
                },
                zc: function(a) {
                    if (b.d(a, "Object")) try {
                        d.setProperty("pageview", a);
                        var f = h.c.b.p,
                            e = h.c.b.ep;
                        h.c.b.et = 9;
                        h.c.b.ep = "";
                        h.c.b.p = u(d.B("pageview"));
                        h.c.i();
                        h.c.b.p = f;
                        h.c.b.ep = e;
                        d.o("pageview")
                    } catch (g) {}
                }
            };
            e.init();
            g.e("pv-b", function() {
                var a = e.gb();
                a && d.setProperty("pageview", a)
            });
            e.mc();
            a.jb(e.Ha)
        }
    })();
    (function() {
        var a = mt.lang,
            b = mt.f,
            g = h.ia,
            f = {
                ka: function(a, u) {
                    return function(e) {
                        var l = e.target || e.srcElement;
                        if (l) {
                            var n = g.S(u) || [],
                                q = l.getAttribute(a.wa);
                            if (q && q === e) l.removeAttribute(a.wa);
                            else if (0 < n.length && (l = b.Zb(l)) && l.length)
                                if (n = l.length, q = l[l.length - 1], 1E4 > n * q.split(">").length)
                                    for (q = 0; q < n; q++) f.ob(a, l[q]);
                                else f.ob(a, q)
                        }
                    }
                },
                ob: function(b, f) {
                    for (var e = {}, g = String(f).split(">").length, n = 0; n < g; n++) e[f] = "", f = f.substring(0, f.lastIndexOf(">"));
                    b && (a.d(b, "Object") && b.Ua) &&
                        b.Ua(e)
                },
                vc: function(a, b) {
                    return function(f) {
                        (f.target || f.srcElement).setAttribute(a.wa, f.clientX + ":" + f.clientY);
                    }
                }
            };
        return h.Ca = f
    })();
    (function() {
        var a = mt.f,
            b = mt.event,
            g = mt.lang,
            f = h.A,
            d = h.ia,
            u = h.Ca,
            e = h.Q,
            l = e.O,
            n = {
                wa: "HM_ce",
                vb: function() {
                    if (c.cetrk && 0 < c.cetrk.length) {
                        b.e(document, "click", u.ka(n, c.cetrk));
                        for (var f = d.S(c.cetrk) || [], e = 0, p = f.length; e < p; e++) {
                            var g = f[e],
                                k = g.p || ""; - 1 === k.indexOf(">") && (0 === k.indexOf("#") && (k = k.substring(1)), (k = a.Wa(k)) && b.e(k, "click", u.vc(n, g)))
                        }
                    }
                },
                Ua: function(a) {
                    for (var b = d.S(c.cetrk) || [], f = 0; f < b.length; f++) {
                        var e = b[f],
                            k = n.Tb(e.p, a);
                        k && n.w(e, k)
                    }
                },
                Tb: function(a, b) {
                    a = String(a);
                    if (0 < a.indexOf("*")) {
                        var f =
                            RegExp("^" + a.replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\*/, "\\d+") + "$"),
                            d;
                        for (d in b)
                            if (b.hasOwnProperty(d) && f.test(d)) return d;
                        return x
                    }
                    return b.hasOwnProperty(a) ? a : x
                },
                w: function(b, f) {
                    h.c.b.et = 7;
                    var d = b && b.k || "",
                        d = g.h(d),
                        r = {};
                    if (b && b.a && g.d(b.a, "Object")) {
                        var k = b.a,
                            m;
                        for (m in k)
                            if (k.hasOwnProperty(m)) {
                                var w = n.$b(k[m] || "", f),
                                    w = w ? a.U(w, y) : "";
                                r[m] = w
                            }
                    }
                    r = n.Ob(r, f || b && b.p);
                    r._iden = d;
                    e.setProperty("customEvent", r);
                    h.c.b.ep = "";
                    h.c.b.p = l(e.B("customEvent"));
                    h.c.i();
                    h.c.b.p = "";
                    e.o("customEvent")
                },
                Ob: function(b, d) {
                    var e = a.Da(d),
                        g = f.Qa;
                    e && (c.aet && c.aet.length ? (b.ei_ = a.getAttribute(e, g.id) || a.getAttribute(e, "id") || "", b.ec_ = a.getAttribute(e, g.ha) || a.getAttribute(e, "class") || "", b.ex_ = a.getAttribute(e, g.ga) || a.ma(e), b.en_ = a.getAttribute(e, g.content) || a.U(e, v), b.et_ = a.getAttribute(e, g.ua) || a.V(e), b.el_ = a.getAttribute(e, g.link) || a.getAttribute(e, "href") || "") : (b.ex_ = a.getAttribute(e, g.ga) || a.ma(e), b.en_ = a.getAttribute(e, g.content) || a.U(e, v)));
                    return b
                },
                $b: function(b, f) {
                    b = String(b);
                    f = String(f);
                    if (0 <
                        b.indexOf("*")) {
                        var d = /.*\[(\d+)\]$/.exec(f);
                        b = b.replace("*", d ? d[1] : "1")
                    }
                    return a.Da(b)
                }
            };
        h.z.e("pv-b", n.vb);
        return n
    })();
    (function() {
        var a = mt.f,
            b = mt.lang,
            g = mt.event,
            f = mt.g,
            d = h.A,
            u = h.ia,
            e = [],
            l = {
                ub: function() {
                    c.ctrk && 0 < c.ctrk.length && (g.e(document, "mouseup", l.Eb()), g.e(window, "unload", function() {
                        l.sa()
                    }), setInterval(function() {
                        l.sa()
                    }, d.Gb))
                },
                Eb: function() {
                    return function(a) {
                        if (u.S(c.ctrk, v) && (a = l.Pb(a), "" !== a)) {
                            var b = (d.ra + "//" + d.Ma + "?" + h.c.nb().replace(/ep=[^&]*/, "ep=" + encodeURIComponent(a))).length;
                            b + (d.ca + "").length > d.P || (b + encodeURIComponent(e.join("!") + (e.length ? "!" : "")).length + (d.ca + "").length > d.P && l.sa(), e.push(a),
                                (e.length >= d.Hb || /\*a\*/.test(a)) && l.sa())
                        }
                    }
                },
                Pb: function(e) {
                    var g = e.target || e.srcElement;
                    if (0 === d.Fb) {
                        var s = (g.tagName || "").toLowerCase();
                        if ("embed" == s || "object" == s) return ""
                    }
                    var p;
                    e = l.Xb(e, g, s, p);
                    switch (c.align) {
                        case 1:
                                r / 2;
                            break;
                        case 2:
                    }
                    r = [];
                    r.push(s);
                    r.push(p);
                    r.push(e.ba);
                    r.push(e.da);
                    r.push(e.uc);
                    r.push(b.h(e.sc));
                    r.push(e.fa);
                    r.push(e.X);
                    (g = "a" === (g.tagName || "").toLowerCase() ? g : a.Xa(g)) ? (r.push("a"), r.push(b.h(encodeURIComponent(g.href)))) : r.push("b");
                    return r.join("*")
                },
                Xb: function(d, e, g, p) {
                    d = a.ma(e);
                    var r = 0,
                        k = 0,
                        m = 0,
                        w = 0;
                    if (e && (r = e.offsetWidth || e.clientWidth, k = e.offsetHeight || e.clientHeight, w = a.Ya(e), m = w.left, w = w.top, b.d(e.getBBox, "Function") && (k = e.getBBox(), r = k.width, k = k.height), "html" === (e.tagName || "").toLowerCase())) r =
                        Math.max(r, e.clientWidth), k = Math.max(k, e.clientHeight);
                    return {
                        ba: Math.round(100 * ((g - m) / r)),
                        da: Math.round(100 * ((p - w) / k)),
                        uc: f.orientation,
                        sc: d,
                        fa: r,
                        X: k
                    }
                },
                sa: function() {
                    0 !== e.length && (h.c.b.et = 2, h.c.b.ep = e.join("!"), h.c.i(), e = [])
                }
            };
        h.z.e("pv-b", l.ub);
        return l
    })();
    (function() {
        var a = mt.lang,
            b = mt.f,
            g = mt.event,
            f = mt.g,
            d = h.A,
            u = h.z,
            e = h.Q,
            l = e.O,
            n = +new Date,
            q = [],
            s = {
                ka: function() {
                    return function(f) {
                        if (h.c && h.c.Y && c.aet && c.aet.length) {
                            var e = f.target || f.srcElement;
                            if (e) {
                                var g = h.c.Ta,
                                    m = b.getAttribute(e, d.Sa) != x ? v : y;
                                if (b.getAttribute(e, d.Ra) == x)
                                    if (m) s.ya(s.Ea(e, f));
                                    else {
                                        var w = b.V(e);
                                        if (a.G(g, "*") || a.G(g, w)) s.ya(s.Ea(e, f));
                                        else
                                            for (; e.parentNode != x;) {
                                                var m = e.parentNode,
                                                    w = b.V(m),
                                                    z = "a" === w && a.G(g, "a") ? v : y,
                                                    w = "button" === w && a.G(g, "button") ? v : y,
                                                    A = b.getAttribute(m, d.Sa) != x ? v : y;
                                                if (b.getAttribute(m, d.Ra) == x && (z || w || A)) {
                                                    s.ya(s.Ea(m, f));
                                                    break
                                                }
                                                e = e.parentNode
                                            }
                                    }
                            }
                        }
                    }
                },
                Ea: function(e, g) {
                    var k = {},
                        m = d.Qa;
                    k.id = b.getAttribute(e, m.id) || b.getAttribute(e, "id") || "";
                    k.ha = b.getAttribute(e, m.ha) || b.getAttribute(e, "class") || "";
                    k.ga = b.getAttribute(e, m.ga) || b.ma(e);
                    k.content = b.getAttribute(e, m.content) || b.U(e, v);
                    k.ua = b.getAttribute(e, m.ua) || b.V(e);
                    k.link = b.getAttribute(e, m.link) || b.getAttribute(e, "href") || "";
                    k.type = g.type || "click";
                    m = a.cb(e.offsetTop) ? e.offsetTop : 0;
                    "click" === g.type ? m = f.na ? g.clientY +
                    k.Ec = m;
                    k.ba = m.ba || 0;
                    k.da = m.da || 0;
                    k.fa = m.fa || 0;
                    k.X = m.X || 0;
                    k.Oa = m.Oa || "b";
                    return k
                },
                Sb: function(e) {
                    var d = e.target || e.srcElement,
                        g;
                    if (f.na) {
                        g = e.clientX + g;
                        e = e.clientY + m
                    } else g = e.pageX,
                        e = e.pageY;
                        z = 0,
                        A = 0;
                    return {
                        da: Math.round(100 * ((e - A) / w)),
                        X: w,
                        Oa: ("a" === (d.tagName || "").toLowerCase() ? d : b.Xa(d)) ? "a" : "b"
                    }
                },
                ya: function(b) {
                    var f = a.h;
                    b = [+new Date - (h.c.$ !== t ? h.c.$ : n), f(b.id), f(b.ha), f(b.ua),
                        f(b.ga), f(b.link), f(b.content), b.type, b.Ec, b.ba, b.da, b.fa, b.X, b.Oa
                    ].join("*");
                    s.za(b);
                },
                za: function(a) {
                    a.length > d.P || (encodeURIComponent(q.join("!") + a).length > d.P && (s.w(q.join("!")), q = []), q.push(a))
                },
                w: function(a) {
                    h.c.b.et = 5;
                    h.c.b.ep = a;
                    h.c.b.p = l(e.B("autoEventTracking"));
                    h.c.i();
                    h.c.b.p = ""
                },
                ea: function() {
                    return function() {
                        q && q.length && (s.w(q.join("!")), q = [])
                    }
                }
            };
        a.H(c.aet) && "" !== c.aet && u.e("pv-b", function() {
            g.e(document, "click", s.ka());
                g.e(window, "touchend", s.ka());
            g.e(window, "unload", s.ea())
        });
        return s
    })();
    (function() {
        var a = mt.lang,
            b = mt.event,
            g = mt.g,
            f = h.A,
            d = h.z,
            u = +new Date,
            e = [],
            l = x,
            n = {
                yb: function() {
                    a.H(c.aet) && "" !== c.aet && setInterval(n.mb, f.xc)
                },
                mb: function() {
                    var a = g.W() + g.M();
                    0 < a - h.c.b.vl && (h.c.b.vl = a)
                }
            },
            q = {
                Kb: function() {
                    return function() {
                            q.xb(g.W() + g.M())
                        }, 150))
                    }
                },
                xb: function(a) {
                    q.za([+new Date - (h.c.$ !== t ? h.c.$ : u), a].join("*"))
                },
                za: function(a) {
                    if (encodeURIComponent(e.join("!") + a).length > f.P || 3 < e.length) q.w(e.join("!")),
                        e = [];
                    e.push(a)
                },
                w: function(a) {
                    n.mb();
                    h.c.b.et = 6;
                    h.c.b.vh = g.M();
                    h.c.b.ep = a;
                    h.c.i()
                },
                ea: function() {
                    return function() {
                        e && e.length && (q.w(e.join("!")), e = [])
                    }
                }
            };
        a.H(c.aet) && "" !== c.aet && d.e("pv-b", function() {
            b.e(window, "scroll", q.Kb());
            b.e(window, "unload", q.ea());
            n.yb()
        });
        return q
    })();
    (function() {
        function a() {
            return function() {
                h.c.b.nv = 0;
                h.c.b.st = 4;
                h.c.b.et = 3;
                h.c.b.ep = h.Ba.Yb() + "," + h.Ba.Ub();
                h.c.b.hca = c.hca;
                h.c.i()
            }
        }

        function b() {
            clearTimeout(z);
            var a;
            l = "undefined" == typeof a ? v : a;
            if ((!e || !n) && l && q) k = v, p = +new Date;
            else if (e && n && (!l || !q)) k = y, r += +new Date - p;
            e = l;
            n = q;
            z = setTimeout(b, 100)
        }

        function g(a) {
                b = "";
            if (a in m) b = a;
            else
                for (var f = ["webkit", "ms", "moz", "o"], e = 0; e < f.length; e++) {
                    var d = f[e] + a.charAt(0).toUpperCase() + a.slice(1);
                    if (d in m) {
                        b = d;
                        break
                    }
                }
            return b
        }

        function f(a) {
        }
        var d = mt.event,
            u = h.z,
            e = v,
            l = v,
            n = v,
            q = v,
            s = +new Date,
            p = s,
            r = 0,
            k = v,
            m = g("visibilityState"),
            w = g("hidden"),
            z;
        b();
        (function() {
            var a = m.replace(/[vV]isibilityState/, "visibilitychange");
            d.e(document, a, b);
            d.e(window, "pageshow", b);
            d.e(window, "pagehide", b);
                "focus", f), d.e(window, "blur", f))
        })();
        h.Ba = {
            Yb: function() {
                return +new Date - s
            },
            Ub: function() {
                return k ? +new Date - p + r : r
            }
        };
        u.e("pv-b", function() {
            d.e(window, "unload", a())
        });
        u.e("duration-send", a());
        u.e("duration-done", function() {
            p = s = +new Date;
            r = 0
        });
        return h.Ba
    })();
    (function() {
        var a = mt.lang,
            b = h.A,
            g = h.load,
            f = {
                lc: function(f) {
                        var u = h.c.T();
                        g([b.protocol, "//datax.baidu.com/x.js?si=", c.id, "&dm=", encodeURIComponent(u)].join(""), f)
                    }
                },
                Dc: function(b) {
                }
            };
        return h.Ib = f
    })();
    (function() {
        function a(a, b, f, e) {
            if (!(a === t || b === t || e === t)) {
                if ("" === a) return [b, f, e].join("*");
                for (var d, g = y, k = 0; k < a.length; k++)
                    if (d = a[k].split("*"), String(b) === d[0]) {
                        d[1] = f;
                        d[2] = e;
                        g = v;
                        break
                    } g || a.push([b, f, e].join("*"));
                return a.join("!")
            }
        }

        function b(a) {
            for (var e in a)
                if ({}.hasOwnProperty.call(a, e)) {
                    var d = a[e];
                }
        }
        var g = mt.url,
            f = mt.lang,
            d = mt.s,
            u = mt.g,
            e = h.A,
            l = h.z,
            n = h.Ib,
            q = h.load,
            s = h.Aa,
            p = h.Q,
            r = p.O,
            k = {
                aa: [],
                ta: 0,
                Ja: y,
                D: {
                    Pa: "",
                    page: ""
                },
                init: function() {
                    k.j = 0;
                    p.init();
                    l.e("pv-b", function() {
                        k.Jb();
                        k.Lb()
                    });
                    l.e("pv-d", function() {
                        k.Mb();
                        k.D.page = ""
                    });
                    l.e("stag-b", function() {
                        h.c.b.api = k.j || k.ta ? k.j + "_" + k.ta : "";
                        h.c.b.ct = [decodeURIComponent(s.getData("Hm_ct_" + c.id) || ""), k.D.Pa, k.D.page].join("!")
                    });
                    l.e("stag-d", function() {
                        h.c.b.api = 0;
                        k.j = 0;
                        k.ta = 0
                    })
                },
                Jb: function() {
                        id: c.id,
                        cmd: {},
                        push: function() {
                                var m = arguments[b];
                                f.d(m, "Array") && (a.cmd[a.id].push(m), "_setAccount" === m[0] && (1 < m.length && /^[0-9a-f]{32}$/.test(m[1])) && (m = m[1], a.id = m, a.cmd[m] = a.cmd[m] || []))
                            }
                        }
                },
                Lb: function() {
                    if (a && a.cmd && a.cmd[c.id])
                        for (var b = a.cmd[c.id], f = /^_track(Event|MobConv|Order)$/, e = 0, d = b.length; e < d; e++) {
                            var g = b[e];
                            f.test(g[0]) ? k.aa.push(g) : k.La(g)
                        }
                    a.cmd[c.id] = {
                        push: k.La
                    }
                },
                Mb: function() {
                    if (0 < k.aa.length)
                        for (var a = 0, b = k.aa.length; a < b; a++) k.La(k.aa[a]);
                    k.aa = x
                },
                La: function(a) {
                    var b = a[0];
                    if (k.hasOwnProperty(b) && f.d(k[b], "Function")) k[b](a)
                },
                _setAccount: function(a) {
                    1 < a.length && /^[0-9a-f]{32}$/.test(a[1]) && (k.j |= 1)
                },
                _setAutoPageview: function(a) {
                },
                _trackPageview: function(a) {
                },
                _trackEvent: function(a) {
                    2 < a.length && (k.j |= 8, h.c.b.nv = 0, h.c.b.st = 4, h.c.b.et = 4, h.c.b.ep = f.h(a[1]) + "*" + f.h(a[2]) + (a[3] ? "*" + f.h(a[3]) : "") + (a[4] ? "*" + f.h(a[4]) : ""), h.c.b.p = r(p.Ga()), h.c.i(), h.c.b.p = "")
                },
                _setCustomVar: function(a) {
                    if (!(4 > a.length)) {
                        var b = a[1],
                            e = a[4] || 3;
                        if (0 < b && 6 > b && 0 < e && 4 > e) {
                            k.ta++;
                            for (var d = (h.c.b.cv || "*").split("!"), g = d.length; g < b - 1; g++) d.push("*");
                            d[b - 1] = e + "*" + f.h(a[2]) + "*" +
                                f.h(a[3]);
                            h.c.b.cv = d.join("!");
                            "" !== a ? s.setData("Hm_cv_" + c.id, encodeURIComponent(a), c.age) : s.removeData("Hm_cv_" + c.id)
                        }
                    }
                },
                _setUserTag: function(b) {
                    if (!(3 > b.length)) {
                        var e = f.h(b[1]);
                        if (e !== t && b !== t) {
                            var d = decodeURIComponent(s.getData("Hm_ct_" + c.id) || ""),
                                d = a(d, e, 1, b);
                            s.setData("Hm_ct_" + c.id, encodeURIComponent(d), c.age)
                        }
                    }
                },
                _setVisitTag: function(b) {
                    if (!(3 > b.length)) {
                        var e = f.h(b[1]);
                        if (e !== t && b !== t) {
                            var d = k.D.Pa,
                                d = a(d, e, 2, b);
                            k.D.Pa = d
                        }
                    }
                },
                _setPageTag: function(b) {
                    if (!(3 > b.length)) {
                        var e = f.h(b[1]);
                        if (e !== t && b !== t) {
                            var d = k.D.page,
                                d = a(d, e, 3, b);
                            k.D.page = d
                        }
                    }
                },
                _setReferrerOverride: function(a) {
                },
                _trackOrder: function(a) {
                    f.d(a, "Object") && (b(a), k.j |= 16, h.c.b.nv = 0, h.c.b.st = 4, h.c.b.et = 94, h.c.b.ep = d.stringify(a), h.c.b.p = r(p.Ga()), h.c.i(), h.c.b.p = "")
                },
                _trackMobConv: function(a) {
                            webim: 1,
                            tel: 2,
                            map: 3,
                            sms: 4,
                            callback: 5,
                            share: 6
                        } [a[1]]) k.j |= 32, h.c.b.et = 93, h.c.b.ep = a, h.c.i()
                },
                _setDataxId: function(a) {
                    n.lc();
                    n.Dc(a)
                },
                _setUserId: function(a) {
                    if (a !== t && (f.H(a) || f.cb(a))) {
                        var b = p.B("user").uid_;
                        if (!(b && b.value === f.h(String(a)))) {
                            var b = h.c.b.p,
                                e = h.c.b.ep;
                            h.c.b.et = 8;
                            h.c.b.ep = "";
                            h.c.b.p = "uid_*" + f.h(String(a));
                            h.c.i();
                            var d = {};
                            d.uid_ = a;
                            p.setProperty("user", d, v);
                            h.c.b.p = b;
                            h.c.b.ep = e
                        }
                    }
                },
                _clearUserId: function(a) {
                    1 < a.length && v === a[1] && p.o("userId")
                },
                _setUserProperty: function(a) {
                    f.d(a, "Object") && p.setProperty("user", a)
                },
                _clearUserProperty: function(a) {
                    1 < a.length && v === a[1] && p.o("user")
                },
                _setSessionProperty: function(a) {
                    f.d(a, "Object") && p.setProperty("session", a)
                },
                _clearSessionProperty: function(a) {
                    1 < a.length && v === a[1] && p.o("session")
                },
                _setPageviewProperty: function(a) {
                    f.d(a, "Object") && p.setProperty("pageview", a)
                },
                _clearPageviewProperty: function(a) {
                    1 < a.length && v === a[1] && p.o("pageview")
                },
                _setAutoEventTrackingProperty: function(a) {
                    f.d(a, "Object") && p.setProperty("autoEventTracking",
                        a)
                },
                _clearAutoEventTrackingProperty: function(a) {
                    1 < a.length && v === a[1] && p.o("autoEventTracking")
                },
                _setAutoTracking: function(a) {
                },
                _setAutoEventTracking: function(a) {
                },
                _trackPageDuration: function(a) {
                    l.K("duration-done")
                },
                _require: function(a) {
                },
                _providePlugin: function(a) {
                    if (1 <
                        a.length) {
                            d = a[1];
                            for (var g = 0, k = a.length; g < k; g++) {
                                var l = a[g][2] || {};
                                if (b.plugins[d] && !b.I[d]) b.I[d] = new b.plugins[d](l), b.C.shift();
                                else break
                            }
                    }
                },
                _requirePlugin: function(a) {
                    if (1 < a.length) {
                            d = a[1],
                            g = a[2] || {};
                        if (f.G(e.ib, d))
                            if (b.plugins = b.plugins || {}, b.I = b.I || {}, b.plugins[d] && !b.I[d]) b.I[d] = new b.plugins[d](g);
                            else {
                                b.C = b.C || [];
                                for (var g = 0, l = b.C.length; g < l; g++)
                                    if (b.C[g][1] === d) return;
                                b.C.push(a);
                                k._require([x, e.tc + d + ".js"])
                            }
                    }
                },
                _trackCustomEvent: function(a) {
                    if (1 < a.length) {
                        var b = a[1];
                        p.setProperty("customEvent", a);
                        h.c.b.et = 7;
                        h.c.b.ep = "";
                        h.c.b.p = r(p.B("customEvent"));
                        h.c.i();
                        h.c.b.p = "";
                        p.o("customEvent")
                    }
                }
            };
        k.init();
        h.Bb = k;
        return h.Bb
    })();
    (function() {
        var a = h.z;
        }))
    })();
    (function() {
        function a() {
        }
        var b = mt.url,
            g = mt.pb,
            f = mt.Na,
            d = mt.lang,
            u = mt.cookie,
            e = mt.g,
            l = mt.sessionStorage,
            n = mt.s,
            q = mt.event,
            s = h.Aa,
            p = h.Q,
            r = p.O,
            k = h.A,
            m = h.load,
            w = h.z;
            Z: function(a, b) {
                b = "." + b.replace(/:\d+/, "");
                var e = a.indexOf(b);
                return -1 < e && e + b.length === a.length
            },
            qa: function(a,
                b) {
                return 0 === a.indexOf(b)
            },
            oa: function(a) {
                for (var e = 0; e < c.dm.length; e++)
                    if (-1 < c.dm[e].indexOf("/")) {
                    } else {
                        var d = b.L(a);
                    } return y
            },
            T: function() {
                return a
            },
            la: function() {
                for (var a = 0, b = c.dm.length; a < b; a++) {
                    var e = c.dm[a];
                        "$1") + "/"
                }
                return "/"
            },
            ac: function() {
                var a = y;
                return a ? k.J - k.N > c.vdur ? 1 : 4 : 3
            },
            Bc: function() {
                var a, b, e, d, f, g;
                k.N = s.getData("Hm_lpvt_" + c.id) || 0;
                13 === k.N.length && (k.N = Math.round(k.N / 1E3));
                a = 4 !== b ? 1 : 0;
                if (g = s.getData("Hm_lvt_" + c.id)) {
                    d = g.split(",");
                    for (f = d.length - 1; 0 <= f; f--) 13 === d[f].length && (d[f] = "" + Math.round(d[f] /
                        1E3));
                    for (; 2592E3 < k.J - d[0];) d.shift();
                    f = 4 > d.length ? 2 : 3;
                    for (1 === a && d.push(k.J); 4 < d.length;) d.shift();
                    g = d.join(",");
                    d = d[d.length - 1]
                } else g = k.J, d = "", f = 1;
            },
            pc: function() {
                return !d.G("sjh.baidu.com isite.baidu.com ls.wejianzhan.com bs.wejianzhan.com product.weijianzhan.com qianhu.weijianzhan.com aisite.wejianzhan.com".split(" "),
                    a)
            },
            Nb: function() {
                    var d = a[b].split("=");
                    d.length && /Hm_(up|ct|cv|lp?vt)_[0-9a-f]{31}/.test(String(d[0])) && s.removeData(d[0]);
                    d.length && /Hm_ck_[0-9]{13}/.test(String(d[0])) && s.removeData(d[0])
                }
            },
            nb: function() {
                    var f = k.qb[d],
                    "undefined" !== typeof g && "" !== g && ("tt" !== f || "tt" === f && 0 === b) && ("ct" !== f || "ct" === f && 0 === b) && a.push(f + "=" + encodeURIComponent(g))
                }
                return a.join("&")
            },
            Cc: function() {
                    k.hc) || b.m(a, k.Jc) || "";
            },
            init: function() {
                try {
                    var b = [];
                    b.push("si=" + c.id);
                    g.log(k.ra + "//" + k.Ma + "?" + b.join("&"))
                }
            },
            yc: function() {
                function a() {
                    w.K("pv-d")
                }
                p.o("pageview")
            },
            i: function(a) {
                    b.b.rnd = Math.round(Math.random() * k.ca);
                    b.b.r = e.orientation;
                    b.b.ww = e.tb;
                    w.K("stag-b");
                    var f = k.ra + "//" + k.Ma + "?" + b.nb();
                    w.K("stag-d");
                    b.zb(f);
                    g.log(f, function(e) {
                        b.lb(e);
                        d.d(a, "Function") && a.call(b)
                    })
                }
            },
            Db: function() {
                    d = RegExp(c.id),
                    f =
                    b.m(a, "jn"),
                    g = /^select$/.test(f);
            },
            Cb: function() {
                try {
                        q.e(window, "message", function(d) {
                            if (b.L(d.origin) === k.rb) {
                                d = d.data || {};
                                var e = d.jn || "",
                                    f = /^customevent$|^heatmap$|^pageclick$/.test(e);
                                if (RegExp(c.id).test(d.sd || "") && f) a.b.rnd = Math.round(Math.random() * k.ca), m(k.protocol + "//" + c.js + e + ".js?" + a.b.rnd)
                            }
                        });
                            id: c.id,
                            status: "__Messenger__hmLoaded"
                        }, "*")
                    }
                } catch (d) {}
            },
            zb: function(a) {
                var b;
                try {
                    b = n.parse(l.get("Hm_unsent_" + c.id) || "[]")
                } catch (d) {
                    b = []
                }
                b.push(a.replace(/^https?:\/\//, "") + e);
                l.set("Hm_unsent_" + c.id,
                    n.stringify(b))
            },
            lb: function(a) {
                var b;
                try {
                    b = n.parse(l.get("Hm_unsent_" + c.id) || "[]")
                } catch (d) {
                    b = []
                }
                if (b.length) {
                    for (var e = 0; e < b.length; e++)
                        if (a.replace(/&u=[^&]*/, "") === b[e].replace(/&u=[^&]*/, "")) {
                            b.splice(e, 1);
                            break
                }
            },
            Va: function() {
                l.remove("Hm_unsent_" + c.id)
            },
            Ac: function() {
                    b;
                try {
                    b = n.parse(l.get("Hm_unsent_" + c.id) || "[]")
                } catch (d) {
                    b = []
                }
                if (b.length)
                    for (var e = function(b) {
                                g.log(k.ra + "//" + b, function(b) {
                                    a.lb(b)
                                })
                            },
                            f = 0; f < b.length; f++) e(b[f])
            },
            Za: function() {
                return Math.round(+new Date / 1E3) % 65535
            }
        };
    })();
    var B = h.A,
        C = h.load;
    c.pt && C([B.protocol, "//ada.baidu.com/phone-tracker/insert_bdtj?sid=", c.pt].join(""));
    (function() {
        var a = mt.g,
            b = mt.lang,
            g = mt.event,
            f = mt.s;
        if ("undefined" !== typeof h.c && (c.med || (!a.na || 7 < a.Wb()) && c.cvcc)) {
            var d, u, e, l, n = function(a) {
                    if (a.item) {
                        for (var b = a.length, d = Array(b); b--;) d[b] = a[b];
                        return d
                    }
                    return [].slice.call(a)
                },
                q = function(a, b) {
                    for (var d in a)
                        if (a.hasOwnProperty(d) && b.call(a, d, a[d]) === y) return y
                },
                s = function(a, g) {
                    var k = {};
                    k.n = d;
                    k.t = "clk";
                    k.v = a;
                    if (g) {
                        var l = g.getAttribute("href"),
                            n = g.getAttribute("onclick") ? "" + g.getAttribute("onclick") : x,
                            p = g.getAttribute("id") || "";
                        e.test(l) ? (k.sn =
                            "mediate", k.snv = l) : b.d(n, "String") && e.test(n) && (k.sn = "wrap", k.snv = n);
                        k.id = p
                    }
                    h.c.b.et = 86;
                    h.c.b.ep = f.stringify(k);
                    h.c.i();
                    for (k = +new Date; 400 >= +new Date - k;);
                };
            if (c.med) u = "/zoosnet", d = "swt", e = /swt|zixun|call|chat|zoos|business|talk|kefu|openkf|online|\/LR\/Chatpre\.aspx/i, l = {
                click: function() {
                        d.getAttribute("onclick"), d = d.getAttribute("href"), (e.test(f) || e.test(d)) && a.push(b[g]);
                    return a
                }
            };
            else if (c.cvcc) {
                u = "/other-comm";
                d = "other";
                e = c.cvcc.q || t;
                var p = c.cvcc.id || t;
                l = {
                    click: function() {
                            e.test(g) || p.test(d)) && a.push(b[k])) : (e.test(f) || e.test(g)) && a.push(b[k])) : p !== t && (d = d.getAttribute("id"), p.test(d) && a.push(b[k]));
                        return a
                    }
                }
            }
            if ("undefined" !== typeof l && "undefined" !== typeof e) {
                var r;
                u += /\/$/.test(u) ? "" : "/";
                var k = function(a, d) {
                    if (r === d) return s(u + a, d), y;
                    if (b.d(d, "Array") || b.d(d, "NodeList"))
                        for (var e = 0, f = d.length; e < f; e++)
                            if (r === d[e]) return s(u + a + "/" + (e + 1), d[e]), y
                };
                g.e(document, "mousedown", function(a) {
                    r = a.target || a.srcElement;
                    var d = {};
                    for (q(l, function(a, e) {
                            d[a] = b.d(e,
                })
            }
        }
    })();
    (function() {
        var a = mt.f,
            b = mt.lang,
            g = mt.event,
            f = mt.s;
        if ("undefined" !== typeof h.c && b.d(c.cvcf, "Array") && 0 < c.cvcf.length) {
            var d = {
                wb: function() {
                    for (var b = c.cvcf.length, e, f = 0; f < b; f++)(e = a.Wa(decodeURIComponent(c.cvcf[f]))) && g.e(e, "click", d.Ca())
                },
                Ca: function() {
                    return function() {
                        h.c.b.et = 86;
                        var a = {
                            n: "form",
                            t: "clk"
                        };
                        h.c.b.ep = f.stringify(a);
                        h.c.i()
                    }
                }
            };
            a.jb(function() {
                d.wb()
            })
        }
    })();
    (function() {
        var a = mt.event,
            b = mt.s;
        if (c.med && "undefined" !== typeof h.c) {
            var g = {
                    n: "anti",
                    sb: 0,
                    kb: 0,
                    clk: 0
                },
                f = function() {
                    h.c.b.et = 86;
                    h.c.b.ep = b.stringify(g);
                    h.c.i()
                };
            a.e(document, "click", function() {
                g.clk++
            });
            a.e(document, "keyup", function() {
                g.kb = 1
            });
            a.e(window, "scroll", function() {
                g.sb++
            });
            a.e(window, "load", function() {
                setTimeout(f, 5E3)
            })
        }
    })();
})();