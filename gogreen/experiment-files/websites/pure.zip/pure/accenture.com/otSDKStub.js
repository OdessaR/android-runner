var OneTrustStub = function(t) {
    "use strict";
    var c = new function() {
                country: "",
                state: ""
            }
        },
            if (e.OneTrust && e.OneTrust.geolocationResponse) {
                var i = e.OneTrust.geolocationResponse;
            } else {
                if (a || t.SkipGeolocation) {
                    var o = a.split(";")[0],
                        n = a.split(";")[1];
            }
            var e = "" + c.stubScriptElement.getAttribute("src").split(c.stubFileName)[0] + t.Version;
            return new RegExp("^file://", "i").test(e) && t.MobileSDK ? "./" + t.GeolocationUrl.replace(/^(http|https):\/\//, "").split("/").slice(1).join("/") + ".js" : t.GeolocationUrl
                e.setGeoLocation(t.country, t.state)
            void 0 === e && (e = ""), c.userLocation = {
                country: t,
                state: e
            }
            else {
                c.mobileOnlineURL.push(t);
                i.onload = function() {
                }, i.open("GET", t), i.send()
            }
                a = i[i.length - 1].split(".js")[0];
            })
                e()
            })
            var e, i, a, o = c.userLocation,
                n = t.RuleSet.filter(function(t) {
                    return !0 === t.Default
                });
            if (!o.country && !o.state) return n && 0 < n.length ? n[0] : null;
            for (var s = o.state.toLowerCase(), r = o.country.toLowerCase(), p = 0; p < t.RuleSet.length; p++)
                if (!0 === t.RuleSet[p].Global) a = t.RuleSet[p];
                else {
                    var l = t.RuleSet[p].States;
                    if (l[r] && 0 <= l[r].indexOf(s)) {
                        i = t.RuleSet[p];
                        break
                    }
                    0 <= t.RuleSet[p].Countries.indexOf(r) && (e = t.RuleSet[p])
                } return i || e || a
            return "true" === t || "false" === t
            if (s) {
                for (a = {}, o = s.split("&"), i = 0; i < o.length; i += 1) n = o[i].split("="), a[decodeURIComponent(n[0])] = decodeURIComponent(n[1]).replace(/\+/g, " ");
                return e && a[e] ? a[e] : e && !a[e] ? "" : a
            }
            return ""
                if (e) return e[t] || null
            }
            var i, a, o = t + "=",
            for (i = 0; i < n.length; i += 1) {
                for (a = n[i];
                    " " == a.charAt(0);) a = a.substring(1, a.length);
                if (0 == a.indexOf(o)) return a.substring(o.length, a.length)
            }
            return null
            var t, e = [];
                OnetrustActiveGroups: i
                OptanonActiveGroups: i
                event: "OneTrustLoaded",
                OnetrustActiveGroups: i
            }, {
                event: "OptanonLoaded",
                OptanonActiveGroups: i
            }], setTimeout(function() {
                    detail: e
                });
            })
            return t ? t.split(",") : []
            return -1 !== t.indexOf(e, t.length - e.length)
            return t.toString()
            var t = c.stubScriptElement.getAttribute("src");
            t && (c.isMigratedURL ? c.storageBaseURL = t.split("/consent/" + c.migratedCCTID)[0] : c.storageBaseURL = t.split("/scripttemplates/" + c.stubFileName)[0]), c.bannerBaseDataURL = c.storageBaseURL && c.storageBaseURL + "/consent/" + c.domainDataFileName, c.bannerDataParentURL = c.bannerBaseDataURL + "/" + c.domainDataFileName + ".json"

            function t(t, e) {
                e = e || {
                    bubbles: !1,
                    cancelable: !1,
                    detail: void 0
                };
                return i.initCustomEvent(t, e.bubbles, e.cancelable, e.detail), i
            }

    function i() {
            var e = null;
            l.iabTypeAdded && ("IAB" !== (e = l.getRegionSet(t)).Type && "IAB2" !== e.Type || (l.iabType = e.Type, l.intializeIabStub()));
            var i = c.stubScriptElement.cloneNode(!0),
                a = "";
            a = t.UseSDKRefactor ? (c.isMigratedURL && (i.src = c.storageBaseURL + "/scripttemplates/new/scripttemplates/" + c.stubFileName + ".js"), c.storageBaseURL + "/scripttemplates/new/scripttemplates/" + t.Version + "/" + c.bannerScriptName) : "5.11.0" === t.Version ? (c.isMigratedURL && (i.src = c.storageBaseURL + "/scripttemplates/old/scripttemplates/" + c.stubFileName + ".js"), c.storageBaseURL + "/scripttemplates/old/scripttemplates/5.11.0/" + c.bannerScriptName) : (c.isMigratedURL && (i.src = c.storageBaseURL + "/scripttemplates/" + c.stubFileName + ".js"), c.storageBaseURL + "/scripttemplates/" + t.Version + "/" + c.bannerScriptName);
            ["charset", "data-language", "data-document-language", "data-domain-script", "crossorigin"].forEach(function(t) {
                c.stubScriptElement.getAttribute(t) && i.setAttribute(t, c.stubScriptElement.getAttribute(t))
                domainData: t,
                stubElement: i,
                bannerBaseDataURL: c.bannerBaseDataURL,
                mobileOnlineURL: c.mobileOnlineURL,
                userLocation: c.userLocation,
                regionRule: e,
                crossOrigin: l.crossOrigin,
                isAmp: l.isAmp
            }, l.jsonp(a, null)
                e = "IAB" === l.iabType ? "__cmpLocator" : "__tcfapiLocator";
            !t.frames[e] && (t.document.body ? l.addLocator(e, "CMP") : setTimeout(l.addIabFrame, 5))
                e = "__cmpLocator";
            !t.frames[e] && (t.document.body ? l.addLocator(e, "CMP") : setTimeout(l.addIabFrame, 5));
            var i = "__tcfapiLocator";
            !t.frames[i] && (t.document.body ? l.addLocator(i, "TCF") : setTimeout(l.addIabFrame, 5))
                a = i.document.createElement("iframe");
            a.style.cssText = "display:none", a.name = t, a.setAttribute("title", e + " Locator"), i.document.body.appendChild(a)
            var o = "string" == typeof a.data,
                t = {};
            try {
                t = o ? JSON.parse(a.data) : a.data
            } catch (t) {}
            if (t.__cmpCall && "IAB" === l.iabType) {
                var n = t.__cmpCall.callId,
                    s = t.__cmpCall.command,
                    e = t.__cmpCall.parameter;
                l.executeCmpApi(s, e, function(t, e) {
                    var i = {
                        __cmpReturn: {
                            returnValue: t,
                            success: e,
                            callId: n,
                            command: s
                        }
                    };
                    a.source.postMessage(o ? JSON.stringify(i) : i, a.origin)
                })
            if (t.__tcfapiCall && "IAB2" === l.iabType) {
                var r = t.__tcfapiCall.callId,
                    p = t.__tcfapiCall.command,
                    i = (e = t.__tcfapiCall.parameter, t.__tcfapiCall.version);
                l.executeTcfApi(p, e, function(t, e) {
                    var i = {
                        __tcfapiReturn: {
                            returnValue: t,
                            success: e,
                            callId: r,
                            command: p
                        }
                    };
                    a.source.postMessage(o ? JSON.stringify(i) : i, a.origin)
                }, i)
            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
            l.iabType = "IAB";
            var i = t[0],
                a = t[1],
                o = t[2];
            if ("function" == typeof o && i)
                if (c.isStubReady && c.IABCookieValue) switch (i) {
                    case "ping":
                        l.getPingRequest(o, !0);
                        break;
                    case "getConsentData":
                        l.getConsentDataRequest(o);
                        break;
                    default:
                        l.addToQueue(i, a, o)
                } else l.addToQueue(i, a, o)
            for (var t = [], e = 0; e < arguments.length; e++) t[e] = arguments[e];
            var i = t[0],
                a = t[1],
                o = t[2],
                n = t[3];
            "function" == typeof o && i && (c.isStubReady && c.IABCookieValue && "ping" === i ? l.getPingRequest(o) : l.addToQueue(i, a, o, n))
                n = "IAB" === l.iabType ? "__cmp" : "__tcfapi";
            o[n].a = o[n].a || [], "ping" === t ? l.getPingRequest(i) : o[n].a.push([t, e, i, a])
            if (void 0 === e && (e = !1), t) {
                var i = {},
                    a = !1;
                "IAB" === l.iabType ? (i = {
                    gdprAppliesGlobally: c.oneTrustIABgdprAppliesGlobally,
                    cmpLoaded: e
                }, a = !0) : "IAB2" === l.iabType && (i = {
                    gdprApplies: c.oneTrustIABgdprAppliesGlobally,
                    cmpLoaded: !1,
                    cmpStatus: "stub",
                    displayStatus: "stub",
                    apiVersion: "2.0",
                    cmpVersion: void 0,
                    cmpId: void 0,
                    gvlVersion: void 0,
                    tcfPolicyVersion: void 0
                }, a = !0), t(i, a)
            }
            t && c.IABCookieValue && t({
                gdprApplies: c.oneTrustIABgdprAppliesGlobally,
                hasGlobalScope: c.hasIABGlobalScope,
                consentData: c.IABCookieValue
            }, !0)
    }
    var a = new e;
}({});