var Dmdbase_CDC = window.Dmdbase_CDC || {};
Dmdbase_CDC = {
    cookieName: "dmdbase_cdc",
    dimensions: {},
    logging: !1,
    enableTNT: !0,
    enableAnalytics: !0,
    DB_DEFAULT_VALUE: "ISP Visitor",
    NOT_IN_AWLIST: "Not In List",
    NOT_ASSIGNED_AWLIST_VALUE: "In List No Value",
    CompanyProfile: {},
    targetAttributes: "demandbase_sid industry sub_industry employee_range revenue_range audience audience_segment ip company_name state country_name watch_list_customer_type watch_list_customer_name watch_list_account_status watch_list_account_id annual_sales street_address city fortune_1000 forbes_2000 zip primary_sic isp".split(" "),
    useStorage: !0,
    useCookie: !0,
    init: function() {
    },
    setupDimensions: function() {
            demandbase_sid: 10,
            company_name: 40,
            industry: 40,
            sub_industry: 40,
            employee_range: 30,
            revenue_range: 10,
            audience: 30,
            audience_segment: 30
        };
            fortune_1000: 30,
            forbes_2000: 30,
            primary_sic: 30,
            city: 30,
            country_name: 30,
            watch_list_customer_name: 30,
            watch_list_customer_type: 30,
            watch_list_account_type: 30
        };
            placeholder_1: 30,
            watch_list_account_id: 30,
            placeholder_2: 30,
            placeholder_3: 30,
            placeholder_4: 30,
            placeholder_5: 30,
            placeholder_6: 30,
            placeholder_7: 30
        }
    },
    callback: function(a) {
        if (a) try {
        }
    },
    loadAnalytics: function() {
    },
    setAnalytics: function(a) {
        try {
            }
        }
    },
    storeSessionData: function(a) {
        var b =
    },
    setMbox: function(a) {
        try {
        }
    },
    flatten: function(a) {
        for (var b in a)
            if ("object" == typeof a[b] && null !== a[b] && a.hasOwnProperty(b)) {
                delete a[b]
            } return a
    },
    saveToCookie: function(a, b) {
        var c = new Date;
        c.setTime(c.getTime() + 18E5);
        c = "; expires=" + c.toGMTString();
    },
    getCookieByName: function(a) {
                c = 0; c < b.length; c++) {
            for (var d = b[c];
                " " == d.charAt(0);) d = d.substring(1);
            if (-1 != d.indexOf(a)) return decodeURIComponent(d.substring(a.length, d.length))
        }
        return ""
    },
    getHostName: function(a) {
        return null != a && 2 < a.length && "string" === typeof a[2] && 0 < a[2].length ? a[2] : null
    },
    getDomain: function(a) {
        if (null != a) {
            var c = a.split(".").reverse();
            null != c && 1 < c.length && (b = "." + c[1] + "." + c[0], -1 != a.toLowerCase().indexOf(".co.uk") && 2 < c.length && (b = "." + c[2] + "." +
                b))
        }
        return b
    },
    isCookieSet: function(a) {
    },
    buildDelimitedStrings: function(a, b) {
            d = [],
            g;
        for (g in c)
            if (c.hasOwnProperty(g)) {
                var f = "",
                    e;
                for (e in c[g])
                    if (c[g].hasOwnProperty(e)) {
                        f += h + a
                    } f = f.substring(0, f.length - 1);
                d.push(f)
            } return d
    },
    resizeStr: function(a, b) {
        return a
    },
    truthy: function(a, b) {
        return a || (!1 === a ? a : b)
    },
    cdc_getParamByName: function(a) {
        return null === a ? "" : decodeURIComponent(a[1].replace(/\+/g, " "))
    },
    set_mbox_variables: function(a) {
        try {
            var b =
                "",
                c;
            b.split(",")
        }
    }
};