/*<!--*/
(function() {
    var qss = "&cb=" + Math.floor(99999999999 * Math.random());
    try {
    try {
    try {
    var callDis = function(e, t, n, o) {
            function c() {
                callDisInternal(e, t, n, o)
            }
        },
        disCalled = !1,
        callDisInternal = function(e, t, n, o) {
            if (!disCalled) {
                disCalled = !0;
                var c = (n ? "https:" : "") + "//" + t + "/dis/dis.aspx",
                r.src = (c + "?p=" + e + qss).substring(0, 2e3);
                    event: "appendTag",
                    element: r
                })
            }
        };
    qss += '&idcpy=00000000-0000-0000-0000-000000000000';
    callDis(62444, 'widget.as.criteo.com', true, '<!-- default response -->');
})();


/*-->*/