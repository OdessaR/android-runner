! function() {
    "use strict";
    (() => {
            o = new Map,
            c = new Map;
        let l = !1,
            s = !1;
            if (!l) {
                return s = !0, new t
            }
            l = !1
            configurable: !0,
            writable: !0
            value: (n, a) => {
                const i = a.prototype,
                    r = class extends e {
                            super(), Object.setPrototypeOf(this, i), s || (l = !0, a.call(this)), s = !1
                        }
                    },
                    d = r.prototype;
            },
            configurable: !0,
            writable: !0
            value: e => c.get(e),
            configurable: !0,
            writable: !0
        })
    })()
}();