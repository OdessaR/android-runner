! function() {
    "use strict";

    function a(e, t) {
        return null !== (n = i && i[e]) && void 0 !== n ? n : t
    }
    var c = "5.6.2";

    function i(e) {
        try {
            return JSON.parse(e)
        } catch (e) {
            return
        }
    }
            try {
                t.frames.__cmpLocator && (e = t)
            } catch (e) {}
            t = t.parent
        }
        return e
        function i(e, t) {
            r.logger(t), clearTimeout(e), o()
        }
                i(n, "Timeout: Unable to get ping return after " + e + "ms")
            }, e);
            r.executeCommand("ping", null, function(e, t) {
                clearTimeout(o), t ? (r.logger("GDPR CMP ping returned"), !0 !== e.cmpLoaded && i(n, "GDPR ping returned cmpLoaded which is not true"), r.logger("GDPR ping returned cmpLoaded which is true")) : i(n, "Error sending ping to GDPR CMP")
            })
        }, t)
            i = !1,
                i = !0, n.logger("Timeout: Unable to resolve GDPR consent after " + n.timeout + "ms"), o(void 0)
                i = !0, n.logger("Timeout: Unable to ping GDPR API after " + n.pingTimeout + "ms"), o(void 0)
            });
            clearTimeout(a), i || (clearTimeout(r), t ? (n.logger("GDPR consent retrieved"), n.processConsentData(e, o)) : (n.logger("Error retrieving GDPR consent data from CMP"), o(void 0)))
        })
        if (e) {
            var o = {};
            void 0 !== e.consentData && (o.consentData = e.consentData), void 0 !== e.gdprApplies && (o.gdprApplies = !!e.gdprApplies), t(o)
                if (!a) return r.logger("GDPR CMP not found in any frame"), void o({
                    msg: "GDPR CMP not found in any frame"
                }, !1);
                var n = Math.random().toString(10),
                    i = {
                        __cmpCall: {
                            command: e,
                            parameter: t,
                            callId: n
                        }
                    };
                r.cmpCallbacks[n] = o, a.postMessage(i, "*")
                var t = "string" == typeof e.data ? i(e.data) : e.data;
                if (t && t.__cmpReturn && t.__cmpReturn.callId && t.__cmpReturn.returnValue) {
                    var o = t.__cmpReturn;
                    r.cmpCallbacks && r.cmpCallbacks[o.callId] && (r.cmpCallbacks[o.callId](o.returnValue, o.success), delete r.cmpCallbacks[o.callId])
                }
            }, !1)
        }

    function e(e, t, o) {
    }
            try {
                t.frames.__tcfapiLocator && (e = t)
            } catch (e) {}
            t = t.parent
        }
        return e
        function i(e, t) {
            r.logger(t), clearTimeout(e), n()
        }
                i(o, "Timeout: Unable to get TCFv2 ping return after " + e + "ms")
            }, e);
            r.executeCommand("ping", 2, function(e) {
                clearTimeout(t), r.logger("TCFv2 CMP ping returned in ms"), "error" === e.cmpStatus ? i(o, "Error status on ping to TCFv2 CMP") : !0 !== e.cmpLoaded ? i(o, "TCFv2 ping returned cmpLoaded = false") : r.logger("TCFv2 ping returned cmpLoaded = true")
            })
        }, t)
            i = !1,
                i = !0, n.logger("Timeout: Unable to resolve TCFv2 consent after " + n.timeout + "ms"), o(void 0)
                i = !0, n.logger("Timeout: Unable to ping TCFv2 API after " + n.pingTimeout + "ms"), o(void 0)
            });
            clearTimeout(a), i || (clearTimeout(r), t ? (n.logger("TCFv2 consent retrieved in ms"), n.processResponseData(e, o)) : (n.logger("Error retrieving TCFv2 consent data from CMP"), o(void 0)))
        }, [91])
        var o;
        if (e) {
            var n = {};
            void 0 !== e.tcString && (n.consentData = e.tcString), void 0 !== e.gdprApplies && (n.gdprApplies = !!e.gdprApplies), n.version = e.tcfPolicyVersion ? e.tcfPolicyVersion : 2, n.purposes = null === (o = null == e ? void 0 : e.purpose) || void 0 === o ? void 0 : o.consents, t(n)
                if (!c) return a.logger("TCFv2 CMP not found in any frame"), void o({
                    msg: "TCFv2 CMP not found in any frame"
                }, !1);
                var i = Math.random().toString(10),
                    r = {
                        __tcfapiCall: {
                            command: e,
                            version: t,
                            parameter: n,
                            callId: i
                        }
                    };
                a.cmpCallbacks[i] = o, c.postMessage(r, "*")
                var t = "string" == typeof e.data ? i(e.data) : e.data;
                if (t && t.__tcfapiReturn && t.__tcfapiReturn.callId && t.__tcfapiReturn.returnValue) {
                    var o = t.__tcfapiReturn;
                    a.cmpCallbacks && a.cmpCallbacks[o.callId] && "function" == typeof a.cmpCallbacks[o.callId] && (a.cmpCallbacks[o.callId](o.returnValue, o.success), delete a.cmpCallbacks[o.callId])
                }
            }, !1)
        }

    function t(e, t, o) {
    }
        t ? t.retrieveConsent(e) : e(void 0)

    function o(e, t, o, n) {
        var i = {
            tcfTimeout: t,
            tcfPingTimeout: o,
            tcfPingDelay: n
        };
    }
        try {
            return void 0 === t ? e() : e.apply(this, t)
        } catch (e) {
        }
            return o.catchAndStoreException(e)
        }, t)
        if (void 0 !== e && "function" == typeof e.addEventListener) return e.addEventListener(t, function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            return i.catchAndStoreException(o, e)
        }, n)
        if (void 0 !== e && "function" == typeof e.attachEvent) return e.attachEvent(t, function() {
            for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
            return n.catchAndStoreException(o, e)
        })

    function n() {
    }

    function p(e, t) {
        if (e instanceof Array)
            for (var o = 0, n = e; o < n.length; o++) {
                p(n[o], t)
            } else F(t, e) || t.push(e)
    }

    function F(e, t) {
            var a = r[i];
            if (a === t || o(a) === n) return !0
        }
        return !1
    }

    function l(e, t) {
        var o = [];
        if (void 0 === e) return void 0 === t ? o : t.slice();
        if (void 0 === t) return e.slice();
        for (var n = 0, i = t; n < i.length; n++) {
            var r = i[n];
            F(e, r) || o.push(r)
        }
        return e.concat(o)
    }

    function R(e, t) {
        if (void 0 === e && void 0 === t) return !0;
        if (void 0 === e || void 0 === t) return !1;
        if (!(e instanceof Array)) return R([e], t);
        if (!(t instanceof Array)) return R(e, [t]);
        if (e.length !== t.length) return !1;
        for (var o = 0, n = e; o < n.length; o++) {
            if (!F(t, n[o])) return !1
        }
        return !0
    }
        return t.href = e, t.hostname
        if (e && e.referrer) {
            var t = e.createElement("a");
            return t.href = e.referrer, t
        }
        return null
        var o;
        try {
            o = t.top.location.search
            var n = t;
            try {
                for (; n.parent.document !== n.document && n.parent.document;) n = n.parent
            if (n) {
                i && (o = i.search)
            }
        }
        return o
            n = o.topFrame;
        if (o.err) try {
            try {
                t = n.top.location.href
            } catch (e) {
                var i = n.location.ancestorOrigins;
                t = i[i.length - 1]
            }
        } catch (e) {
            t = n.document.referrer
        } else t = n.location.href;
        return t
        ! function e() {
        }()
        else {
            o.attachProtectedEvent(document, "onreadystatechange", n), o.attachProtectedEvent(window, "onload", n);
            var e = !1;
            try {
            } catch (e) {}
            if (e && e.doScroll) ! function t() {
                if (e) {
                    try {
                        e.doScroll("left")
                    } catch (e) {
                        return void o.setProtectedTimeout(t, 50)
                    }
                    n()
                }
            }();
            else {
                var t = !1,
                        return e.onload(t)
                    },
                        return e.onreadystatechange(t)
                    };
                }
            }
        }
        e.setProtectedTimeout(function() {
            null !== t && null !== t.parentElement && t.parentElement.removeChild(t)
        }, 3e4)
        if (!e) return null;
        return t.setAttribute("id", "criteo-tags-div"), t.style.display = "none", e.appendChild(t), t
        var t = e,
            o = !1;
        try {
            for (; t.parent.document !== t.document;) {
                if (!t.parent.document) {
                    o = !0;
                    break
                }
                t = t.parent
            }
        } catch (e) {
            o = !0
        }
        return {
            topFrame: t,
            err: o
        }

    function g() {}

    function I(e) {
        var t = e;
        if (e instanceof Function) return (t = e()) instanceof Function ? t : I(t);
        if (e instanceof Array) {
            t = [];
            for (var o = 0; o < e.length; ++o) t[o] = I(e[o])
        } else if (e && "[object Object]" === e.toString()) {
            t = {};
            for (var n = 0, i = Object.getOwnPropertyNames(e); n < i.length; n++) {
                var r = i[n];
                t[r] = I(e[r])
            }
        }
        return t
    }

    function x(e, t) {
        for (var o = 0, n = e; o < n.length; o++) {
            var i = n[o];
            if (i.event === t.event && R(t.account, i.account)) {
                for (var r in t) t.hasOwnProperty(r) && "account" !== r && (i[r] = t[r]);
                return
            }
        }
        e.push(t)
    }

    function E(e, t) {
        for (var o = 0, n = e; o < n.length; o++) {
            var i = n[o];
            if (i.event === t.event && R(t.account, i.account) && i.hash_method === t.hash_method) return void(void 0 !== t.email && (i.email = l(i.email instanceof Array || void 0 === i.email ? i.email : [i.email], t.email instanceof Array ? t.email : [t.email])))
        }
        e.push(t)
    }

    function A(e, t, o) {
        var n = I(o);
        return V(e, n), x(t, I(n)), 1
    }

    function V(e, t) {
        for (var o = 0, n = e; o < n.length; o++) {
            var i = n[o];
            if (i.event === t.event && void 0 === t.account && void 0 === i.account || R(t.account, i.account)) {
                for (var r in t) t.hasOwnProperty(r) && "account" !== r && (i[r] = t[r]);
                return
            }
        }
        e.push(t)
    }(m = h = h || {})[m.None = 0] = "None", m[m.Cookie = 1] = "Cookie", m[m.LocalStorage = 2] = "LocalStorage";
        try {
            var e = "criteo_localstorage_check";
            return !1
        }
            var o = t[e];
                var n = o.substr(o.indexOf("=") + 1);
            }
        }
        var e = null;
        return {
            value: t || e,
        }
        var o = new Date;
        o.setTime(o.getTime() + t);
        var n = "expires=" + o.toUTCString(),
        return {
        }
        var o = new Date;
        o.setTime(o.getTime() + t);
            var c = "domain=." + (r = i.slice(i.length - a - 1, i.length).join(".")),
            if (u && u === e) break
        }
        var o = h.None;
        return e && (o |= h.Cookie), t && (o |= h.LocalStorage), o

    function y(e, t) {
    }
        var t = f.getQueryString(e);
            var o = f.getAnchorWithReferrer(e.top.document);
        } catch (e) {}
        if (e.callbacks)
            for (var t = 0, o = "string" == typeof e.callbacks ? [e.callbacks] : e.callbacks; t < o.length; t++) {
                var n = o[t],
                i.setAttribute("style", "display:none;"), i.setAttribute("width", "1"), i.setAttribute("height", "1"), i.setAttribute("data-owner", "criteo-tag"), i.setAttribute("src", n);
        if (e && 1 < e.length) {
            var o = "&" + t + "=",
                n = e.indexOf(o);
            if (-1 !== n) {
                var i = e.indexOf("&", n + o.length);
                return e.slice(n + o.length, i < 0 ? void 0 : i)
            }
        }
        return null
            var e = new v("criteo_write_test", 1e4);
        var e = new v("cto_tld_test", 36e5),
            t = e.setOnMainDomain("woot");
        return e.removeOnMainDomain(), t
        if (e.isSafari) try {
            if ("function" == typeof t.openDatabase) return t.openDatabase(null, null, null, null), 1
        } catch (e) {
            return 2
        }
        return 0

    function k(e, t, o) {
    }
            a = f.getHighestAccessibleUrl(window),
            c = r(f.extractHostname(a)),
            s = {
                bundle: e.bundleCookie.toFragmentData(),
                cw: e.canWriteCookie,
                lwid: e.lwidCookie.toFragmentData(),
                optout: e.optoutCookie.toFragmentData(),
                pm: e.privateMode,
                sid: e.secureIdCookie.toFragmentData(),
                tld: e.tld,
                topUrl: c,
                uid: e.guidCookie.cookieValue,
                version: t.replace(/\./g, "_")
            },

    function w(e) {
    }
    var N = new RegExp(/^Mozilla\/5\.0 \([^)]+\) AppleWebKit\/[^ ]+ \(KHTML, like Gecko\) Version\/([^ ]+)( Mobile\/[^ ]+)? Safari\/[^ ]+$/i),
            }
            }

    function C() {
            initTime: null,
            pushTime: null
    }
        if (null != n) {
            var i = n.adBlockDetector;
                o.abe = e, t()
            }), e(t)) : t()
        } else t()
        }
        return void 0 === e || "" === e

    function b() {
    }
    var P, T = /^#(enable|disable)-criteo-tag-debug-mode(=(\d+))?$/;

    function U(e, t, o, n, i) {
        if (function() {
                if (!e || 4 !== e.length) return;
                var t = "enable" === e[1],
                    o = Number(e[3]);
        var r = function(e, t, o, n, i) {
            var a = {
                exceptions: e.exceptions,
                m_config: o,
                m_state: n,
                originalPush: e.push,
                performances: e.performances,
                push: function() {
                    for (var e = [], t = 0; t < arguments.length; t++) e[t] = arguments[t];
                },
                pushError: function(e) {
                },
                removeLater: e.removeLater,
                setProtectedTimeout: t.setProtectedTimeout,
                stagedErrors: [],
                stagedPushes: []
            };
                return function(e, t, o, n) {
                    var i = {
                        column: n,
                        lineNumber: o,
                        message: e,
                        url: t
                    };
                    return a.pushError(i), !(!r || "function" != typeof r) && r.apply(window, [e, t, o, n])
                }
        }(e, t, o, n, i);
        return function() {
            var e = "ld-tag-debug." + c + ".js",
            o.parentNode.insertBefore(t, o)
        }(), r
    }
            var C = new d,
                i = new L;
            i.startRecordingInit();
            var g = {
                    app: {
                        accounts: [],
                        actions: [],
                        bodyReady: !1,
                        disingScheduled: [],
                        domReady: !1,
                        eventSent: !1,
                        queue: []
                    },
                    cbs: new W
                },
                v = {
                    hooks: {},
                    shortNameMap: {
                        events: {
                            applaunched: "al",
                            viewitem: "vp",
                            viewhome: "vh",
                            viewlist: "vl",
                            viewbasket: "vb",
                            viewsearch: "vs",
                            viewpage: "vpg",
                            tracktransaction: "vc",
                            addtocart: "ac",
                            calldising: "dis",
                            setdata: "exd",
                            setemail: "ce"
                        },
                        properties: {
                            event: "e",
                            account: "a",
                            currency: "c",
                            product: "p",
                            item: "p",
                            "item.id": "i",
                            "item.price": "pr",
                            "item.quantity": "q",
                            "product.id": "i",
                            "product.price": "pr",
                            "product.quantity": "q",
                            data: "d",
                            keywords: "kw",
                            checkin_date: "din",
                            checkout_date: "dout",
                            deduplication: "dd",
                            delivery: "dl",
                            attribution: "at",
                            "attribution.channel": "ac",
                            "attribution.value": "v",
                            user_segment: "si",
                            new_customer: "nc",
                            customer_id: "ci",
                            email: "m",
                            hash_method: "h",
                            transaction_value: "tv",
                            client_revenue: "cr",
                            responseType: "rt",
                            page_name: "pn",
                            page_id: "pi",
                            page_number: "pnb",
                            category: "ca",
                            filters: "f",
                            "filters.name": "fn",
                            "filters.operator": "fo",
                            "filters.value": "fv",
                            retailer_visitor_id: "rvi",
                            price: "pr",
                            availability: "av",
                            sub_event_type: "se",
                            store_id: "s",
                            item_group_id: "sp",
                            sku_parent: "sp",
                            zipcode: "z"
                        }
                    },
                    trackingCallData: {
                        account: a("partnerId") || null,
                        customerInfo: [],
                        extraData: [],
                        handlerParams: {
                            v: c
                        },
                        handlerResponseType: "single",
                        handlerUrlPrefix: "https://sslwidget.criteo.com/event",
                        partnerPayload: null,
                        requestType: "pixel",
                        responseType: "js",
                        tagVersion: c
                    },
                    workflow: {
                        container: null,
                        disOnce: !1,
                        manualDising: !1,
                        manualFlush: !1,
                        noPartialFlush: !1,
                        partialDis: !1
                    }
                },
                e = function(e) {
                    var t = e.match(N),
                        o = null !== t;
                    return {
                        hasItp: null !== t && 11 <= parseFloat(t[1]),
                        isSafari: o
                    }
                k = new O(e),
                b = function(t) {
                    var n = !1,
                        i = void 0,
                        r = [];
                    return function(e) {
                        n ? e(i) : (r.push(e), 1 === r.length && t(function(e) {
                            n = !0, i = e;
                            for (var t = 0, o = r; t < o.length; t++) {
                                (0, o[t])(i)
                            }
                        }))
                    }
                }(t.retrieveConsent.bind(t));

            function l(e, t, o, n, i, r, a, c) {
                e.waitingForSyncframe && (e.waitingForSyncframe = !1, s(e, t, o, n, i, r, a, c))
            }

            function o(t, o, n, i, r, a, c, s, e) {
                if (t.shouldInjectSyncframe()) {
                    var u = t.createIframe(i, a.tagVersion, e, C);
                        ! function(e, t, o, n, i, r, a, c, s) {
                            var u = s.data;
                            if (!u || !u.isCriteoMessage) return;
                            s.stopPropagation(), n.checkCookies(u), e.waitingForSyncframe && l(e, t, o, n, i, r, a, c)
                        }(t, o, n, i, r, a, c, s, e)
                    }, !0), T(o, s, c, {
                        event: "appendtag",
                        element: u
                    }))
                }
            }

            function r(e, t) {
                ! function(e) {
                    var t = !1;
                    if (200 < e.length) t = !0;
                    else
                        for (var o = 0, n = e; o < n.length; o++) {
                            var i = n[o],
                                r = 0;
                            if (Object.keys) r = Object.keys(i).length;
                            else
                                for (var a in i) Object.prototype.hasOwnProperty.call(i, a) && (r += 1);
                            if (200 < r) {
                                t = !0;
                                break
                            }
                        }
                    t && (e.length = 0)
                }(e.extraData), e.customerInfo = [], t.clean()
            }

            function n() {
                for (var n = [], e = 0; e < arguments.length; e++) n[e] = arguments[e];
                C.catchAndStoreException(function() {
                    i.startRecordingPush();
                    for (var e = 0, t = n; e < t.length; e++) {
                        var o = t[e];
                        g.app.queue.push(o)
                    }
                    s(k, g.app, g.cbs, y, v.shortNameMap, v.trackingCallData, v.hooks, v.workflow), r(v.trackingCallData, g.cbs), i.stopRecordingPush()
                }, n), i.stopRecordingInit()
            }

            function s(e, t, o, n, i, r, a, c) {
                for (var s = [], u = t.queue, l = 0; l < u.length; ++l) {
                    var d = u[l];
                    if (d instanceof Array) {
                        var p = [l + 1, 0];
                        u.splice.apply(u, p.concat(d))
                    }
                    if (d instanceof Function) u.splice(l + 1, 0, d());
                    else if (d && "[object Object]" === d.toString()) switch (h(t, o, n, i, r, a, c, d, l, u, s)) {
                        case 0:
                            s.push(d);
                            break;
                        case -1:
                            s = s.concat(u.slice(l)), l = u.length
                    }
                }
                a.afterEval instanceof Function && a.afterEval(), t.queue = s || [], c.manualFlush || c.noPartialFlush && 0 !== t.queue.length || e.waitingForSyncframe || _(t, o, n, i, r, a, c, 0 !== t.queue.length)
            }

            function P(e, t, o) {
                var n = e.handlerResponseType;
            }

            function T(e, t, o, n) {
                var i = D(e, n);
                return null !== i ? i : w(e, t, o, n)
            }

            function w(e, t, o, n) {
                    var i = void 0;
                }
                    if (t.container || "script" !== n.element.tagName.toLowerCase() && !n.isImgUrl) {
                        if (!t.container) return 0;
                        t.container.appendChild(n.element), f.removeLater(C, n.element)
                    } else {
                        n.element.setAttribute("data-owner", "criteo-tag"), r.parentNode.insertBefore(n.element, r), f.removeLater(C, n.element)
                    } return 1
            }

            function D(e, t) {
                return !e.domReady && t.requiresDOM && "no" !== t.requiresDOM ? "blocking" === t.requiresDOM ? -1 : 0 : (delete t.requiresDOM, t.event ? (t.account && p(t.account, e.accounts), t.event = t.event.toLowerCase(), null) : (I(t), 1))
            }

            function h(e, t, o, n, i, r, a, c, s, u, l) {
                var d = c.event,
                    p = D(e, c);
                if (null !== p) return p;
                switch (c.event) {
                    case "setdata":
                        return A(i.extraData, e.actions, c);
                    case "setparameter":
                        for (var h in c) "event" !== h.toLowerCase() && c.hasOwnProperty(h) && (i.handlerParams[h] = c[h]);
                        return 1;
                    case "calldising":
                        P(i, e, c);
                        break;
                    case "setzipcode":
                    case "setstore":
                        return c.event = "setdata", A(i.extraData, e.actions, c);
                    case "setcustomerid":
                        return c.event = "setdata", c.customer_id = c.id, delete c.id, A(i.extraData, e.actions, c);
                    case "setretailervisitorid":
                        return t.enable(), c.event = "setdata", c.retailer_visitor_id = c.id, delete c.id, A(i.extraData, e.actions, c);
                    case "setgoogleadvertisingid":
                            event: "setdata",
                            site_type: "aa"
                        });
                    case "setappleadvertisingid":
                            event: "setdata",
                            site_type: "aios"
                        });
                    case "setemail":
                    case "sethashedemail":
                    case "ceh":
                        c.event = "setemail", c.hasOwnProperty("email") && (c.email instanceof Array || (c.email = [c.email]), c.email = function(e) {
                            for (var t = [], o = 0, n = e; o < n.length; o++) {
                                var i = n[o];
                                null != i && t.push(i)
                            }
                            return t
                        }(c.email));
                        var m = I(c);
                        return i.customerInfo.push(m), E(e.actions, I(c)), 1;
                    case "setsitetype":
                        var f = "d";
                        return "mobile" !== c.type && "m" !== c.type || (f = "m"), "tablet" !== c.type && "t" !== c.type || (f = "t"), c.event = "setdata", delete c.type, c.site_type = f, A(i.extraData, e.actions, c);
                    case "appendtag":
                        return w(e, a, r, c);
                    case "gettagstate":
                        return c.callback instanceof Function ? c.callback(g, v, y, k) : 1;
                    case "setuat":
                        return t.setUat(c.uat), 1;
                    case "viewsearchresult":
                    case "viewcategory":
                        t.trySetPageId(c, d), c.event = "viewlist";
                        break;
                    case "viewlist":
                        t.tryForceViewListPageId(c);
                        break;
                    case "viewitem":
                    case "viewhome":
                    case "viewbasket":
                    case "tracktransaction":
                    case "addtocart":
                        t.trySetPageId(c, d);
                        break;
                    case "viewstore":
                        t.trySetPageId(c, d), c.event = "viewHome", c.sub_event_type = "s";
                        break;
                    case "checkavailability":
                        t.trySetPageId(c, d), c.event = "viewBasket", c.sub_event_type = "a";
                        break;
                    case "reserveinstore":
                        t.trySetPageId(c, d), c.event = "viewBasket", c.sub_event_type = "r";
                        break;
                    case "flush":
                    case "flushevents":
                        return _(e, t, o, n, i, r, a, s !== u.length - 1 || 0 !== l.length), 1;
                    case "setaccount":
                        return i.account = c.account, 1;
                    case "seturl":
                        return i.handlerUrlPrefix = c.url, 1;
                    case "setcalltype":
                        return i.handlerResponseType = c.type, 1;
                    case "setresponsetype":
                        return i.responseType = c.type, 1;
                    case "setrequesttype":
                        return i.requestType = c.type, 1;
                    case "setpartnerpayload":
                        return i.partnerPayload = c.payload, 1;
                    case "oninitialized":
                        return r.onInitialized = c.callback, 1;
                    case "ondomready":
                        return r.onDOMReady = c.callback, 1;
                    case "beforeappend":
                        return r.beforeAppend = c.callback, 1;
                    case "aftereval":
                        return r.afterEval = c.callback, 1;
                    case "onflush":
                        return r.onFlush = c.callback, 1;
                    case "onurlgenerated":
                        return r.onUrlGenerated = c.callback, 1;
                    case "disonce":
                    case "manualdising":
                    case "manualflush":
                    case "nopartialflush":
                    case "disonpartialflush":
                }
                return e.actions.push(I(c)), 1
            }

            function _(o, n, e, t, i, r, a, c) {
                    for (var s = 0, u = i.extraData; s < u.length; s++) {
                        var l = u[s];
                        x(o.actions, l)
                    }
                    for (var d = 0, p = i.customerInfo; d < p.length; d++) {
                        var h = p[d];
                        E(o.actions, h)
                    }
                    if (!a.manualDising && (!c || a.partialDis)) {
                        for (var m = [], f = 0, g = o.accounts; f < g.length; f++) {
                            var v = g[f];
                            F(o.disingScheduled, v) || m.push(v)
                        }
                        0 < m.length && function(e, t, o) {
                            var n = D(t, o);
                            null !== n || (P(e, t, o), t.actions.push(I(o)))
                        }(i, o, {
                            event: "callDising",
                            account: m
                        })
                    }
                    var y = !1,
                        k = function(e, t, o, n, i) {
                            var r = e.actions,
                                a = [];
                            1 === e.accounts.length && (i.account = e.accounts[0]);
                            null !== i.account && a.push("a=" + S(n, i.account, []));
                            "js" !== i.responseType && a.push("rt=" + S(n, i.responseType, []));
                            if (i.handlerParams) {
                                var c = decodeURIComponent(S(n, i.handlerParams, []));
                                c && a.push(c)
                            }
                            t.tryAppendUatParameter(a);
                            for (var s = 0; s < r.length; ++s) {
                                var u = r[s];
                                u.account && R(null === i.account ? void 0 : i.account, null === u.account ? void 0 : u.account) && delete u.account, a.push("p" + s + "=" + S(n, u, []))
                            }
                            o.fillQueryStringParams(a), null !== i.partnerPayload && a.push("pp=" + S(n, i.partnerPayload, []));
                            return a.push("dtycbr=" + function() {
                                return Math.floor(1e5 * Math.random())
                            }()), a
                        }(o, n, e, t, i);
                    var w = function() {
                        if (!y) {
                            y = !0, n.tryAppendAdBlockerParameter(k);
                            var e = function(e) {
                                    return e.join("&")
                                }(k),
                                t = function(e, t) {
                                    return {
                                        event: "appendTag",
                                        isImgUrl: "gif" === e.responseType,
                                        url: e.handlerUrlPrefix + "?" + t
                                    }
                                }(i, e);
                        }
                    };
                    b(function(e) {
                        e && k.push.apply(k, function(e) {
                            var t = [];
                            return void 0 !== e.gdprApplies && t.push("gra=" + (e.gdprApplies ? 1 : 0)), void 0 !== e.consentData && t.push("grs=" + e.consentData), void 0 !== e.version && t.push("grv=" + e.version), t
                        }(e)), n.tryRunActionAfterAdBlockDetectionOrImmediate(w, function(e) {
                            return C.setProtectedTimeout(e, 500)
                        })
                    })
                }
            }

            function S(e, t, o) {
                var n, i, r, a = "";
                if (t instanceof Function) a = S(e, t(), o);
                else if (t instanceof Array) {
                    for (var c = [], s = 0; s < t.length; ++s) c[s] = S(e, t[s], o);
                    a += "[" + c.join(",") + "]"
                } else if (t && "[object Object]" === t.toString()) {
                    var u = [];
                    for (var l in t)
                        if (t.hasOwnProperty(l)) {
                            var d = o.concat([l]);
                            u.push((n = e, i = l, void 0, r = d.join("."), (n.properties[r] ? n.properties[r] : i) + "=" + S(e, t[l], d)))
                        } a += u.join("&")
                } else 1 === o.length && "event" === o[0] ? a += e.events[t.toLowerCase()] ? e.events[t.toLowerCase()] : t : a += t;
            }
            return C.catchAndStoreException(function() {
                return y.checkAcid(), y.checkClientSideIdentityStatus(), y.setCop(window),
                    function(e, t, o, n, i, r, a, c) {
                        e.setWaitingFlag(n), e.waitingForSyncframe && C.setProtectedTimeout(function() {
                            l(e, t, o, n, i, r, a, c)
                        }, 1e4)
                    }(k, g.app, g.cbs, y, v.shortNameMap, v.trackingCallData, v.hooks, v.workflow), y.ccpCookie.setValueFromExistingCookie(), f.onBodyReady(C, function() {
                            o(k, g.app, g.cbs, y, v.shortNameMap, v.trackingCallData, v.hooks, v.workflow, e)
                        }), s(k, g.app, g.cbs, y, v.shortNameMap, v.trackingCallData, v.hooks, v.workflow)
                    }), f.onDocumentReady(C, function() {
                    }),
                    function(e) {
                        try {
                            var t = f.getAnchorWithReferrer(document);
                            if (t)
                                    event: "setData",
                                    ref: t.protocol + "//" + t.hostname
                                })
                        } catch (e) {}
                    }(v.trackingCallData.extraData), a("visitEventEnabled", !1) && function(e, t) {
                        function o() {
                            t.eventSent || (e({
                                event: "setRequestType",
                                type: "beacon"
                            }), e({
                                event: "viewPage"
                            }))
                        }
                        var n = a("visitEventDelay", 3e4);
                        0 <= n && setTimeout(o, n)
                    }(n, g.app), U({
                        exceptions: C.exceptions,
                        performances: i.timings,
                        removeLater: function(e) {
                            return f.removeLater(C, e)
                        }
                    }, C, v, g, i)
            })
    }
}();