// For license information, see `https://assets.adobedtm.com/d4d114c60e50/f3fbfbe0e7ca/c4048fba911b/RCe603adad0e60478b927c5da4f78b4f0e-file.js`.
! function() {
        s = "adobePrivacy:Privacy",
        i = "OptanonChoice",
        a = new Date,
        r = {
            path: "/",
            samesite: "Lax",
            expires: (a.setFullYear(a.getFullYear() + 1), a)
        };
    t = function(e) {
        o || (o = !0, "oneTrust" === e ? (n = function() {
            var e, t, n, o, s, i, a, r = {},
                l = d.OneTrust.GetDomainData().Groups;
            for (o = 0, s = l.length; o < s; o++)
                if ((e = l[o]) && (t = e.Hosts))
                    for (i = 0, a = t.length; i < a; i++)(n = t[i]) && (r[n.HostName] = {
                        groupId: e.CustomGroupId,
                        hostId: n.HostId,
                        displayName: n.displayName
                    });
                return !(!(t = r[e]) || -1 === n.indexOf("," + t.hostId + ","))
                return !(!t || -1 === t.indexOf(e))
            return d.OneTrust
        }], {
            timeout: 1e4,
            interval: 100
            return !0
            return !0
    }, e = function(e) {
            t(e)
        }, !0)
    }), d.addEventListener(s + "Custom", function() {
    }), d.addEventListener(s + "Reject", function() {
    }))
}();