// For license information, see `https://assets.adobedtm.com/d4d114c60e50/f3fbfbe0e7ca/c4048fba911b/RC29e82c9b5c6e48a4a3a7a5958e0e76d4-file.js`.
_satellite._poll(function() {
}, [function() {
}], {
    timeout: 1e5,
    interval: 100
});