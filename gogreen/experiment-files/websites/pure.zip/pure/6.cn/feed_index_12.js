(function(a) {
        _callbacks: [],
        init: function() {
                return
            }
            a.ajax({
                dataType: "html",
                url: "/js/tpls/feed_v5.html",
                success: function(b) {
                }
            });
        },
        onReady: function(b) {
                b && b()
            } else {
            }
        },
        _templateReady: function() {
                c && c()
            })
        }
    }
})(jQuery);
(function(b) {
    var a = {
        extend: function(h, d, g) {
            var f = function(i) {
                var c = function() {};
                c.prototype = i.prototype;
                return new c()
            };
            var e = f(d);
            if (g) {
                b.extend(true, e, g)
            }
        },
        to_html: function(e, f) {
            if (!e) {
                return ""
            }
            b.each(f, function(h, i) {
            });
            var d = /({(\!|#)([^#]\w+)})+[\s\S]*\1+/g;
            var g = 0;
            var c = 10;
            while (g <= c && e.match(d)) {
                g++;
                    switch (k) {
                        case "#":
                            break;
                        case "!":
                            break
                    }
                    return i
                })
            }
            return e
        },
        formatDate: function(g, i) {
            var j = function(l) {
                return l < 10 ? "0" + l : l + ""
            };
            var k = new Date(g);
            var h = k.getFullYear();
            var f = j(k.getMonth() + 1);
            var c = j(k.getDate());
            var e = j(k.getHours());
            var d = j(k.getMinutes());
            return i.replace(/y|m|d|h|i/g, function(l) {
                switch (l) {
                    case "y":
                        return h;
                    case "m":
                        return f;
                    case "d":
                        return c;
                    case "h":
                        return e;
                    case "i":
                        return d
                }
            })
        },
        formatTime: function(e) {
            var c = +new Date;
            var g = new Date(new Date().toLocaleDateString()).getTime();
            var i = c - e;
            var j = g - e;
            var d = Math.floor(i / (60 * 1000));
            var k = Math.floor(i / (60 * 60 * 1000));
            var f = Math.ceil(j / (24 * 60 * 60 * 1000));
            var h = function(l) {
                return a.formatDate(e, l)
            };
            if (d <= 3) {
                return "刚刚"
            } else {
                if (d < 60) {
                    return d + "分钟前"
                } else {
                    if (k >= 1 && f < 1) {
                        return k + "小时前"
                    } else {
                        if (f == 1) {
                            return "昨天 " + h("h:i")
                        } else {
                            if (f == 2) {
                                return "前天 " + h("h:i")
                            } else {
                                if (f < 365) {
                                    return h("m-d h:i")
                                } else {
                                    return h("y-m-d h:i")
                                }
                            }
                        }
                    }
                }
            }
        }
    };
    a.parseClientSource = function(c) {
        if (c == "99") {
            return ""
        }
    };
    a.justifyBox = function(g, e, i, h) {
        var f = g / e;
        var d = i / h;
        var c;
        var j;
        if (g <= i && e <= h) {
            return {
                width: g,
                height: e,
                scale: 1
            }
        }
        if (f >= d) {
            c = i;
            j = c / f
        } else {
            j = h;
            c = j * f
        }
        return {
            width: c,
            height: j,
            scale: c / g
        }
    };
    a.justifySize = function(e, c, g, f) {
        var d = g * c / e;
        var i = (f - d) / 2;
        return {
            width: g,
            height: d,
            offset: i
        }
    };
    a.parseAtMessage = function(d, c) {
        return d.replace(/<remind>(\d+)<\/remind>/g, function(f, e) {
            for (var g = 0; g < c.length; g++) {
                if (c[g].uid == e) {
                    return '<a class="remind" href="/profile/index.php?rid=' + c[g].rid + '" target="_blank">@' + c[g].alias + "</a>"
                }
            }
            return ""
        })
    };
    a.parseListContent = function(d, c) {
        return d
    };
    a.getRoomConfig = function() {
        var c = {};
        } else {
            }
        }
        return c
    };
    a.getQueryString = function(d, c) {
        var e = new RegExp("(\\?|&)" + c + "=([^&]*)(&|$)", "i");
        var f = d.match(e);
        if (f != null) {
            return unescape(f[2])
        }
        return null
    };
    a.scrollTo = function(f, e) {
        var d = b(window).scrollTop();
        var c = true;
        if (e == "up") {
            c = f < d
        }
        if (e == "down") {
            c = f > d
        }
        if (c) {
            b("body, html").animate({
                scrollTop: f
            }, 200)
        }
    };
    b.extend(feed, a)
})(jQuery);
(function(c) {
    var b = {
        template: "",
        wrapper: ".win",
        roller: ".roll",
        prevBtnCls: "browser-prev",
        nextBtnCls: "browser-next",
        loop: 1,
        maxWidth: 84,
        maxHeight: 60,
        id_perfix: "carousel-item-"
    };
    var d = function(g, f) {
        g.on("click", c.proxy(this, "_clickHandler"))
    };
    c.extend(d.prototype, {
        load: function(g, e) {
        },
        jump: function(e) {
                return
            }
                return
            }
        },
        goToNext: function() {
                e = 0
            }
        },
        goToPrev: function() {
                e = f.length - 1
            }
        },
        resize: function() {
            }
        },
        clean: function() {
        },
        _bulidFragment: function(j) {
            for (var g = 0; g < j.length; g++) {
                var k = j[g];
                k.swidth = f.width;
                k.sheight = f.height;
                k.offset = f.offset || 0;
                if (!k.picid) {
                    k.picid = String.uniqueID()
                }
                if (!k.index) {
                    k.index = g
                }
            }
            for (var g = 0; g < j.length; g++) {
                var h = j[g];
                    id: h.picid,
                    width: h.swidth,
                    height: h.sheight,
                    offset: h.offset
                });
                e.appendChild(c(l)[0])
            }
            return e
        },
        _justifySize: function(g, e) {
            var i = f.maxWidth;
            var h = f.maxHeight;
        },
        _focus: function() {
            var e = h.picid;
            c("#" + g + e).addClass("on");
        },
        _roll: function() {
            var l = k.length;
            if (l <= 1) {
            }
            if (j == 0) {
            } else {
            }
            if (j >= l - 1) {
            } else {
            }
            var g = i.outerWidth(true);
            var f = g * l;
            var n = Math.floor(m / g);
            var e;
            if (n > l || j == 0) {
                e = 0
            } else {
                if (j + n > l) {
                    e = -1 * (f - m)
                } else {
                    e = -1 * (j - 1) * g
                }
            }
            h.width(f);
            h.stop(true);
            h.animate({
                left: e,
                duration: 100
            }, c.proxy(this, "_rollEnd"))
        },
        _rollEnd: function() {},
        getDataFromListById: function(e) {
            var f;
                if (h.picid == e) {
                    f = h;
                    return false
                }
            });
            return f
        },
        _clickHandler: function(g) {
            var j = c(g.target);
            var e;
            g.preventDefault();
            if ((c.nodeName(j[0], "img") || c.nodeName(j[0], "a")) && (e = j.attr("data-pid"))) {
            } else {
                if (j.hasClass(f.prevBtnCls)) {
                } else {
                    if (j.hasClass(f.nextBtnCls)) {
                    }
                }
            }
        }
    var a = function(f, e) {
    };
    c.extend(a.prototype, {
        init: function() {
            var f = c("#photo-gallery-template")[0].text;
            var e = {
                container: g.find(".photo-gallery-container"),
                stage: g.find(".js_photo_gallery_stage"),
                image: g.find(".js_mainImage"),
                stageArrowNext: g.find(".next"),
                stageArrowPrev: g.find(".previous")
            };
            for (var h in e) {
            }
                template: c("#photo-carousel-item")[0].text
            });
            g.on("click", c.proxy(this, "_clickHandler"));
        },
        show: function(f, e) {
            }
        },
        hide: function() {
                return
            }
        },
        playNext: function() {
        },
        playPrev: function() {
        },
        _resizeHandler: function(e) {
            }
        },
        _doResize: function() {
        },
        _update: function(e) {
        },
        _updatePhoto: function(f) {
            var e = c("<img>");
            g.replaceWith(e);
        },
        _changeStageSize: function() {
            e.css("width", h);
        },
        _changePhotoSize: function() {
            var h = g.attr("data-width");
            var f = g.attr("data-height");
            g.css("width", e.width || "auto").css("height", e.height || "auto");
            if (!e.width || !e.height) {
            } else {
            }
        },
        _attachResizeHandler: function() {
            c(window).on("resize", c.proxy(this, "_resizeHandler"))
        },
        _detacheResizeHandler: function() {
            c(window).off("resize", c.proxy(this, "_resizeHandler"))
        },
        _clickHandler: function(e) {
            var f = c(e.target);
            } else {
                } else {
                    if (f.hasClass("js_nextone")) {
                    } else {
                        if (f.hasClass("js_prevone")) {
                        } else {
                            if (f.hasClass("js_close")) {
                            }
                        }
                    }
                }
            }
        },
        _mousemoveHandler: function(h) {
            var g = h.pageX;
            var e = g - i;
            f.removeClass("next-highlight");
            j.removeClass("previous-highlight");
                j.addClass("previous-highlight")
            } else {
                f.addClass("next-highlight")
            }
        }
    });
})(jQuery);
(function(d) {
    var f = function(i, h) {
        f.superclass.constructor.call(this, i, h)
    };
        insert: function(j, h) {
            if (h) {
            } else {
            }
        },
        loading: function(h) {
            if (!h) {
                i.css("display", "none")
            } else {
                i.css("display", "block")
            }
        },
        reset: function() {
            }
        },
        checkEmpty: function(h) {
            return h.content.pageCount == 0
        },
        parseData: function(h) {
            return h
        },
        getPages: function(h) {
        },
        updatePage: function(j, h) {
            var i = getPageList({
                prevImg: "&lt;&lt;",
                nextImg: "&gt;&gt;",
                block_page: 10
            });
        }
    });
    var g = function(l, j, i) {
        if (l.type == 21 && l.content.picList.length == 1) {
        }
        var k = d("#feed_list_template_" + l.type)[0];
        if (!k) {
            return ""
        }
        var h = {
            list_type_str: k.text,
            userbar: d("#feed_tpl_userbar")[0].text,
            id: l.id,
            uid: l.uid,
            rid: l.rid,
            alias: l.alias,
            userpic: l.userpic,
            commnum: l.commnum || 0,
            likenum: l.likenum || 0,
            islike: l.islike,
            islive: l.islive,
            isfollow: l.isfollow,
            isquote: !!i,
            userlevel: function() {
                var m;
                if (!l.isanchor / 1) {
                    m = '<i class="rich{coin6rank}"></i>'
                } else {
                    m = '<i class="star{wealthrank}"></i>'
                }
                return m
            }(),
            wealthrank: l.wealthrank,
            coin6rank: l.coin6rank,
            isanchor: l.isanchor,
            location: l.location,
            cmt: function() {
                var n = "";
                var m = l.commnum == 0 || !l.commnum ? "" : "(<b>" + l.commnum + "</b>)";
                if (i) {
                    n += "原文评论"
                } else {
                    n += j.newFeed ? "有新评论！" : "评论"
                }
                n += m;
                return n
            }(),
            likestr: function() {
                return l.likenum > 0 ? "(<b>" + l.likenum + "</b>)" : ""
            }(),
            src: function() {
            }(),
            msg: l.content.msg,
            url: l.content.link || l.content.pic && l.content.pic.link,
            aud_name: l.content.audname,
            aid: function() {
                var n = l.content;
                var m;
                if (n.mp3) {
                    m = n.mp3.aid
                } else {
                    if (n.link && n.link.indexOf("aid=") > 0) {
                        m = n.link.match(/aid\=(\d+)/)[1]
                    }
                }
                return m
            }(),
            other: l.content.talias || l.content.falias,
            other_id: l.content.tuid || l.content.fuid,
            other_rid: l.content.trid,
            num: l.content.num,
            fid: l.content.fuid,
            fname: l.content.fname,
            id_prefix: j.id_prefix,
            game: l.content.game,
            quote: function() {
                return l.forward && l.forward.id ? d(g(l.forward, j, l.id)).html() : "原帖已被删除"
            }(),
            retweet: function() {
                var m = i ? "原文转发" : "转发";
                return l.forwardnum > 0 ? m + "(<em>" + l.forwardnum + "</em>)" : m
            }(),
            type: l.type,
            original_name: l.forward && l.forward.alias ? l.forward.alias : "",
            root_id: l.content.rootid,
            fansqid: !l.content.fuid && l.content.fansqid,
            fansqrid: l.content.fansqrid,
            fansqtitle: l.content.fanstitle,
            familyid: l.content.fuid,
            familytitle: l.content.fanstitle,
            isTop: l.content.top && l.content.top > 0,
            isHot: l.content.isHot && l.content.isHot > 0,
            isSing: l.content.isSing && l.content.isSing > 0,
            vid: l.content.vid,
            title: l.content.title,
            isShowAction: (typeof j.isShowAction == "undefined") ? 1 : j.isShowAction,
            isShowFollow: (typeof j.isShowFollow == "undefined") ? 1 : j.isShowFollow,
            isShowLive: (typeof j.isShowLive == "undefined") ? 1 : j.isShowLive,
            isShowLevel: (typeof j.isShowLevel == "undefined") ? 1 : j.isShowLevel,
            isShowTop: (typeof j.isShowTop == "undefined") ? 0 : j.isShowTop
        };
        if (l.content.picList) {
            h.gallery_cls = l.content.picList.length > 4 ? "many-img-m9" : "many-img-m4";
            h.gallery_list = (function() {
                var n = l.content.picList || [];
                if (n.length) {
                    var m = d("#feed_tpl_gallery_list")[0].text;
                    var o = [];
                    d.each(n, function(t, s) {
                        var v = 110;
                        var w = 110;
                        var p, x, q, u = 0,
                            r = 0;
                        if (y.width < v) {
                            q = v / y.width;
                            p = v;
                            x = y.height * q;
                            r = -1 * (x - v) / 2
                        }
                        if (y.height < w) {
                            q = w / y.height;
                            x = w;
                            p = y.width * q;
                            u = -1 * (p - w) / 2
                        }
                    });
                    return o.join("")
                }
                return ""
            })()
        }
        h.followstr = d("#feed_tpl_follow")[0].text.replace(/{uid}/g, l.uid);
        if (typeof l.isfollow != "undefined") {
            h["isfollow_" + l.isfollow] = true
        }
        if (h.isShowTop && h.isTop) {
            h.icon_top = d("#feed_tpl_top")[0].text
        } else {
            h.icon_top = ""
        }
    };
    var b = {
        newFeed: false,
        id_prefix: "flist",
        listWrap: ".flist",
        emptyWrap: ".noContent",
        loadingWrap: ".loading",
        pageWrap: ".g-paginator"
    };
    var c = function(i, h) {
        c.superclass.constructor.call(this, i, d.extend(b, h))
    };
        assemble: function(i) {
        },
        _parseList: function(k) {
            var j = i.template;
            var h = [];
            d.each(k, function(l, m) {
                h.push(g(m, i))
            });
            return h.join("")
        }
    });
    var a = {
        id_prefix: "ilist",
        listWrap: ".flist",
        emptyWrap: ".noContent",
        loadingWrap: ".loading",
        pageWrap: ".g-paginator"
    };
    var e = function(i, h) {
        e.superclass.constructor.call(this, i, d.extend(a, h))
    };
        assemble: function(i) {
        },
        _parseList: function(k) {
            var j = i.template;
            var h = [];
            var l = function(n) {
                var m = {
                    id: n.id,
                    type: n.type,
                    mid: n.mid,
                    id_prefix: i.id_prefix || "",
                    frid: n.fuserInfo.rid,
                    fuserpic: n.fuserInfo.userpic,
                    fuid: n.fuserInfo.uid,
                    falias: n.fuserInfo.alias,
                    fwealthrank: n.fuserInfo.wealthrank,
                    messageFlag: n.messageFlag,
                    tid: n.msgInfo ? n.msgInfo.id : "",
                    trid: n.msgInfo ? n.msgInfo.rid : "",
                    quote: function() {
                        var o;
                        if (n.msgInfo && n.msgInfo.id) {
                            o = g(n.msgInfo, {
                                newFeed: false,
                                isShowAction: false,
                                isShowLevel: (typeof i.isShowLevel == "undefined") ? 1 : i.isShowLevel,
                                id_prefix: i.id_prefix,
                                template: d("#feed_list_template")[0].text
                            })
                        }
                        if (n.type == 3) {
                            return n.content.commentFlag == 1 ? o : "该评论已被删除"
                        } else {
                            if (n.type == 4) {
                                return n.content.commentFlag == 1 ? (n.content.replyFlag == 1 ? o : "该回复已被删除") : "该评论已被删除"
                            } else {
                                return n.messageFlag == 1 ? o : "该动态已被删除"
                            }
                        }
                    }(),
                    content_pic: n.content.pic,
                    content_stm: n.content.stm,
                    content_commentMsg: n.content.commentFlag == 1 ? n.content.commentMsg : "原评论已被删除",
                    content_commentFlag: n.content.commentFlag,
                    isShowFollow: (typeof i.isShowFollow == "undefined") ? 1 : i.isShowFollow,
                    isShowLive: (typeof i.isShowLive == "undefined") ? 1 : i.isShowLive,
                    isShowLevel: (typeof i.isShowLevel == "undefined") ? 1 : i.isShowLevel
                };
                m["isType" + n.type] = true;
            };
            d.each(k, function(m, n) {
                h.push(l(n))
            });
            return h.join("")
        }
    });
})(jQuery);
(function(d) {
    var b = function(g) {
        if (!confirm("确定要删除吗?")) {
            return
        }
        var f = g.attr("data-prefix");
        var e = g.attr("href");
        var h = e.substring(e.indexOf("#") + 1);
        d.ajax({
            url: "/message/message_del.php",
            dataType: "json",
            data: "id=" + h,
            success: a,
            context: {
                id: h,
                prefix: f
            }
        })
    };
    var a = function(g) {
        if (g.flag == "001") {
            var e = d("#" + f + h);
            e.animate({
                height: 0
            }, {
                complete: c
            });
        } else {
            if (g.flag == "203") {
                alert("请重新登录。")
            } else {
                alert(g.content)
            }
        }
    };
    var c = function() {
        d(this).remove()
    };
})(jQuery);
(function(c) {
    var b = function(h) {
        if (h.hasClass("loading")) {
            return
        }
        var g, f;
        var i = h.attr("data-id");
        var e = Number(h.attr("data-num"));
        if (h.hasClass("active")) {
            f = 1;
            g = "/message/message_dellike.php"
        } else {
            f = 0;
            g = "/message/message_like.php"
        }
        h.addClass("loading");
        c.ajax({
            url: g,
            dataType: "json",
            data: "id=" + i,
            success: a,
            context: {
                id: i,
                num: e,
                isCancel: f
            }
        })
    };
    var d = function(f, e) {
        if (isNaN(f)) {
        } else {
            if (!e) {
            } else {
            }
        }
        return f
    };
    var a = function(h) {
        var i = c("#zan" + j);
        if (h.flag == "001") {
            f = d(f, e);
            if (e) {
                i.removeClass("active")
            } else {
                i.addClass("active")
            }
            i.attr("data-num", f).attr("title", "赞：" + numF(f));
            var g = i.html();
            if (f > 0) {
                if (i.find("b").length > 0) {
                    i.find("b").text(numF(f))
                } else {
                    i.html(g + "(<b>" + numF(f) + "</b>)")
                }
            } else {
                i.html(g.replace(/\(.+\)/, ""))
            }
        } else {
            alert(h.content)
        }
        i.removeClass("loading")
    };
})(jQuery);
(function(c) {
    var b = function(g) {
        if (g.hasClass("following")) {
            return
        }
        var e, d;
        var f = g.attr("data-uid");
        if (g.hasClass("followed")) {
            d = 1;
            e = "/message/follow_del.php"
        } else {
            d = 0;
            e = "/message/follow_add.php"
        }
        g.addClass("following");
        c.ajax({
            url: e,
            dataType: "json",
            data: {
                format: "json",
                tuid: f,
            },
            success: a,
            context: {
                uid: f,
                isCancel: d
            }
        })
    };
    var a = function(f) {
        var g = c('a.js-follow[data-uid="' + e + '"]');
        if (f.flag == "001") {
            if (d) {
                g.removeClass("followed").text("关注");
            } else {
                g.addClass("followed").text("已关注");
            }
        } else {
            alert(f.content)
        }
        g.removeClass("following")
    };
})(jQuery);
(function(e) {
    var n = String.uniqueID();
    var b = function(q, t) {
        var o = t.attr("src");
        var v = t.attr("alt");
        var s = q.find(".media-pre");
        var u = e("#" + n);
        r.onload = function() {
            var z = q.find(".media-expend");
            var B = e("#feed_media_img_template")[0].text;
                src: p,
                width: A.width,
                height: A.height,
                orginal: v
            }));
            z.empty().append(D).css("display", "block");
            s.css("display", "none");
        };
        if (u.length == 0) {
            var x = e("#feed_media_loading_template")[0].text;
        }
        var w = t.position();
        u.css({
            display: "block",
            left: w.left + 4,
            top: w.top + 10,
            width: t.width(),
            height: t.height()
        });
        s.append(u);
        r.src = p
    };
    var i = function(o) {
        o.find(".media-expend").empty().css("display", "none");
        o.find(".media-pre").css("display", "block");
        e("#" + n).css("display", "none")
    };
    var f = function(p, o) {
        d(o.find(".media-expend img")[0], p, o.find(".media-expend").width())
    };
    var d = function(q, p, o) {
        var r = Number(e(q).attr("angle")) || 0;
        r = p == "left" ? r - 90 : r + 90;
            m(q, r, o)
        } else {
            g(q, r, o)
        }
    };
    var h = function(u, r) {
        var v = u.find(".media-pre");
        var p = u.find(".media-expend");
        var o = [];
        var t = e("#feed_media_gallery_template")[0].text;
        e.each(v.find(".many-img img"), function() {
            var w = e(this);
            o.push({
                width: w.attr("data-width"),
                height: w.attr("data-height")
            })
        });
        v.css("display", "none");
        p.empty().html(t).css("display", "block");
        var q = r.attr("index");
        s.show(o, q);
        u.data("instance", s)
    };
    var k = function(q) {
        var p = q.find(".media-expend");
        var s = q.find(".media-pre");
        s.css("display", "block");
        p.empty().css("display", "none");
        try {
            var o = q.data("instance");
            if (o) {
                o = null
            }
    };
    var g = function(t, u, q) {
        var s = u * Math.PI / 180;
        var o = Math.sin(s);
        var r = Math.cos(s);
        var p = "M11=" + r + ",M12=" + (-o) + ",M21=" + o + ",M22=" + r;
        if (!t.dw) {
        }
        if (u == 0 || u == 180) {
        } else {
            if (t.dh > q) {
            }
        }
        e(t).attr("angle", u)
    };
    var m = function(s, r, z) {
        var p;
        var o;
        var t = r * Math.PI / 180;
        var x = Math.sin(t);
        var A = Math.cos(t);
        var y;
        var u;
        var v;
        var q;
        if (!s.canvas) {
            p.width = s.width;
            p.height = s.height;
            p.image = s;
            p.className = "feed-media-action feed-media-collapse smallCursor";
            s.parentNode.appendChild(p);
            o = p.getContext("2d");
            y = s.width;
            u = s.height;
            e(s).css("display", "none")
        } else {
            p = s.canvas;
            o = p.getContext("2d");
            y = s.width;
            u = s.height
        }
        v = Math.abs(A * y) + Math.abs(x * u);
        q = Math.abs(A * u) + Math.abs(x * y);
        if (v > z) {
            q = q * z / v;
            v = z
        }
        p.width = v;
        p.height = q;
        o.save();
        o.clearRect(0, 0, v, q);
        o.rotate(t);
        if (r == 90 || r == 270) {
            if (v < u) {
                y = y * v / u;
                u = v
            }
        }
        if (r == 0) {
            o.drawImage(s, 0, 0, y, u)
        }
        if (r == 90) {
            o.drawImage(s, 0, -u, y, u)
        }
        if (r == 180) {
            o.drawImage(s, -y, -u, y, u)
        }
        if (r == 270) {
            o.drawImage(s, -y, 0, y, u)
        }
        e(s).attr("angle", r)
    };
    var a = function(q, s) {
        var t = String.uniqueID();
        var r = s.attr("data-aid");
        var p = e("#feed_media_audio_template")[0].text;
        var o = {
            aid: r
        };
        q.find(".media-pre").css("display", "none");
        q.find(".media-expend .player").attr("id", t);
            flashvars: "aid=" + r,
            wmode: "transparent"
        })
    };
    var j = function(p, q) {
            vid: p.find(".mini-video img").attr("data-vid"),
            autoplay: true
        });
        p.data("mini-video", o);
        p.find(".mini-video-container").html(o.createBox());
        p.find(".mini-video").css("display", "none");
        o.loadPlayer()
    };
    var c = function(p, q) {
        var o = p.data("mini-video");
        o && o.destroyPlayer();
        o = null;
        p.data("mini-video", null);
        p.find(".mini-video-container").empty();
        p.find(".mini-video").css("display", "block")
    };
    var l = function(p) {
        var q = e(this);
        if (!q.hasClass("feed-media-action")) {
            return
        }
        p.preventDefault();
        var o = q.closest("li");
        o = o.length > 0 ? o : q.closest("dd");
        if (q.hasClass("feed-media-img")) {
            b(o, q)
        } else {
            if (q.hasClass("feed-media-collapse")) {
                i(o, q)
            } else {
                if (q.hasClass("feed-media-rotateLeft")) {
                    f("left", o)
                } else {
                    if (q.hasClass("feed-media-rotateRigth")) {
                        f("right", o)
                    } else {
                        if (q.hasClass("feed-media-gallery")) {
                            h(o, q)
                        } else {
                            if (q.hasClass("feed-media-gallery-collapse")) {
                                k(o, q)
                            } else {
                                if (q.hasClass("feed-meida-playAudio")) {
                                    a(o, q)
                                } else {
                                    if (q.hasClass("feed-media-playVideo")) {
                                        j(o, q)
                                    } else {
                                        if (q.hasClass("mini-video-collapse")) {
                                            c(o, q)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    };
        bind: function(o) {
            e(o).on("click.feed", "a, img", l)
        }
    }
})(jQuery);
(function(b) {
    var a = function(e) {
        var f = b(e.target);
        f = b.nodeName(f[0], "a") ? f : f.parent();
        if (!/\s?js-\w+\s?/.test(f.attr("class"))) {
            return
        }
            return false
        }
        if (f.hasClass("js-del")) {
        } else {
            if (f.hasClass("js-zan")) {
            } else {
                if (f.hasClass("js-retweet")) {} else {
                    if (f.hasClass("js-top")) {
                    } else {
                        if (f.hasClass("js-follow")) {
                        } else {
                            if (f.hasClass("js-black")) {} else {
                                if (f.hasClass("js-comment")) {
                                    var c = f.attr("href");
                                    var g = c.substring(c.indexOf("#") + 1);
                                    var d = f.attr("data-rid");
                                    if (f.hasClass("cmt-original")) {
                                    }
                                } else {
                                    if (f.hasClass("js-comment-del")) {
                                    } else {
                                        if (f.hasClass("js-comment-reply")) {
                                        } else {
                                            if (f.hasClass("js-reply")) {} else {
                                                if (f.hasClass("js-reply-del")) {
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        e.preventDefault()
    };
        bind: function(c) {
            b(c).on("click.feed", "a", a)
        }
    }
})(jQuery);
(function(e) {
    var g = {
        url: "",
        options: ".opt",
        textarea: "textarea",
        sendButton: ".send-btn",
        button_disable_cls: "g-btn-disabled",
        button_enable_cls: "g-btn-primary",
        component: {
            face: {
                btn: "a.face"
            }
        }
    };

    function f(m, o) {
        n.on("click", e.proxy(this, "submit"));
        p.on("click", e.proxy(this, "_clickHandler"));
    }
        submit: function(o) {
            var q = {};
            var n;
            o.preventDefault();
            var p = e.trim(l.val());
            var s = l.attr("data-placeholder") || "内容不能为空";
            if (e.trim(l.val()) == "") {
                alert(s);
                return
            }
                return
            }
            r.each(function(t, u) {
                if (u.checked) {
                    q[u.name] = u.value
                }
            });
            e.ajax({
                type: "POST",
                data: q,
                dataType: "json",
                success: e.proxy(this, "callback")
            });
        },
        callback: function(l) {
            if (l.flag != "001") {
            } else {
            }
        },
        focus: function() {
        },
        clearField: function() {
            l.val("");
            n.each(function(o, p) {
                e(p).attr("checked", false)
            });
        },
        enable: function() {
        },
        disable: function() {
        },
        focus: function() {
        },
        getConfig: function() {
        },
        getApi: function() {
        },
        getParam: function() {
            return {}
        },
        checkAvailable: function() {
            alert("did not overwrite");
            return true
        },
        _state: function(p) {
            l.attr("disabled", !p);
            n.find("button").attr("disabled", !p);
            n[p ? "removeClass" : "addClass"](o.button_disable_cls);
            n[p ? "addClass" : "removeClass"](o.button_enable_cls)
        },
        _clearHandler: function() {
            }
        },
        _clickHandler: function(m) {
            var n = e(m.target);
            e.each(l.conf.component, function(p, o) {
                var q = l.wrap.find(o.btn);
                if (n[0] == q[0] || e.contains(q[0], n[0])) {
                    l[p].visible(n, l.textarea);
                    m.preventDefault();
                    return false
                }
            })
        },
        _loadComponent: function() {
            e.each(l, function(o, n) {
                var p = i[o];
                if (p) {
                    m[o] = p
                }
            })
        }
    var h = '<div class="remind-wrap">		<div class="remind-box">			<div class="arrowIcon"><i class="ico">◆</i><i class="ico ico2">◆</i></div>			<a class="close close-big"></a>			<h3>可提醒相互关注的人看你的动态</h3>			<div class="seacher-box">			    <input class="searchInput" name="key" type="text" autocomplete="off" placeholder="输入房间号、昵称搜索">			    <a class="searchBtn" href="" title="搜索"><i></i></a>			</div>			<div class="list-scroll">				<div class="remind-list scroll-bar">					<ul></ul>				</div>			</div>		</div>	</div>';
    var k = '<li data-uid="{uid}" data-alias="{alias}">		<dl>			<dt class="avatar"><a target="_blank" href="/{rid}"><img src="{userpic}"></a></dt>			<dd>				<p>{alias}</p>				<p>主播：<i class="star{wealthrank}"></i> 富豪：<i class="rich{coin6rank}"></i></p>			</dd>		</dl>	</li>';
    var j = "/message/message_search.php";
    var d = "@{alias} ";
    var b = "[remind{uid}remind]";
    var c = /@([^@]+)\s/g;
    var a = {
        _list: {},
        visible: function(m, l) {
            }
        },
        hidden: function() {
                top: "-1000px",
                left: "-1000px",
                zIndex: -1,
                visibility: "hidden"
            });
        },
        destroy: function() {
                }
            }
        },
        search: function() {
            var m;
            if (l) {
                e.getJSON(j, {
                    type: isNaN(l / 1) ? "use" : "roomid",
                    key: encodeURIComponent(l),
                    format: "json"
                }).done(e.proxy(this, "_searchBack"))
            }
        },
        clearList: function() {
        },
        insert: function(m) {
            var n = l.val();
            var o = d.replace(/{alias}/, m.alias);
                l.val(n + o)
            }
        },
        transfer: function(m) {
            return m.replace(c, function(o, n) {
                var p;
                e.each(l, function(r, q) {
                    if (q.alias == n) {
                        p = r
                    }
                });
                return p ? b.replace(/{uid}/, p) : ""
            })
        },
        getUserList: function() {
        },
        _checkUser: function() {
            if (!e.isEmptyObject(l)) {
                e.each(l, function(p, n) {
                    var o = d.replace(/{alias}/, n.alias);
                    if (new RegExp(o).exec(m) === null) {
                        delete l[p]
                    } else {
                        if (!l[p]) {
                            l[p] = n
                        }
                    }
                })
            }
        },
        getFriendList: function() {
                e.getJSON("/message/remindList.php").done(function(m) {
                    var n = {};
                    if (m.flag == "001") {
                        e.each(m.content.list, function(o, p) {
                            n[p.uid] = p
                        });
                        l._friendList = n;
                        l.setList(n)
                    }
                })
            } else {
                if (e.isEmptyObject(l._friendList)) {
                    l.setList('<p class="no-result">您还没有好友，赶快添加吧</p>')
                } else {
                    l.setList(l._friendList)
                }
            }
        },
        _getList: function(m) {
            var l = [];
            e.each(m, function(n, o) {
                l.push(k.replace(/{rid}/g, o.rid).replace(/{uid}/g, o.uid).replace(/{userpic}/g, o.picuser || o.userpic).replace(/{alias}/g, o.alias).replace(/{wealthrank}/g, o.wealthrank).replace(/{coin6rank}/g, o.coin6rank))
            });
            return l.join("")
        },
        setList: function(l) {
        },
        _searchBack: function(l) {
            if (l.flag == "001") {
            }
        },
        _searchHandler: function(l) {
            l.preventDefault();
        },
        _listenSearchHandler: function(n) {
            var m = l.val();
            if (m.length == 0) {
            } else {
                if (m.length > 1) {
                }
            }
        },
        _fuckUserHandler: function(o) {
            o.preventDefault();
            var n = e(o.target).closest("li");
            var m = n.attr("data-uid");
            var l = n.attr("data-alias");
                uid: m,
                alias: l
            })
        },
        _setPos: function() {
                position: "absolute",
                top: l.top + 8,
                left: l.left - 60,
                zIndex: 1000
            })
        },
        _bindDocumentEvent: function() {
                    wrapper: "#feed_publish_wrap"
                })
            }
        },
        _unBindDocumentEvent: function() {
            }
        }
    };
    var i = {
        face: {
            init: function() {
                    fname: String.uniqueID()
                })
            },
            visible: function(m, l) {
                }
                var m = e(m);
                var l = e(l);
                var n = m.attr("placeholder") || "";
            },
            hidden: function() {
            },
            _createFace: function(l) {
            }
        },
        at: a
    };
})(jQuery);
(function(c) {
    var a = {
        triggerCls: "",
        triggerHook: "data-target",
        triggerType: "click",
        currentCls: "on",
        disabledCls: "disabled"
    };
    var b = function(e, d) {
    };
    c.extend(b.prototype, {
        initialize: function() {
        },
        _addTrigger: function() {
            var g = [];
            var e = f.find("." + d.triggerCls);
            c.each(e, function() {
                g.push(c(this))
            });
        },
        _addPanel: function() {
            var g = [];
            c.each(e, function(j, k) {
                var i = k.attr(d.triggerHook);
                var h = f.find(i);
                g.push(h)
            });
        },
        _bindTrigger: function() {
            var e = d.triggerType;
                g.attr("data-index", f)
            })
        },
        _triggerHandler: function(e) {
            var d = c(e.currentTarget);
            e.preventDefault();
        },
        _switchValid: function(d) {
                return false
            }
                return false
            }
                return false
            }
            return true
        },
        _switchPanel: function(f, d, e) {
            f && f.css("display", "none");
            d.css("display", "block")
        },
        _switchTrigger: function(h, d, f) {
            if (!h && !d) {
                return
            }
            var g = e.currentCls;
            h && h.removeClass(g);
            d.addClass(g)
        },
        switchTo: function(f) {
                return
            }
            d = typeof d == "undefined" ? -1 : d;
        },
        enable: function() {
        },
        disable: function() {
        }
})(jQuery);
(function(b) {
    var a = {
        _delay: 2 * 60 * 1000,
        init: function() {
        },
        repeat: function() {
        },
        request: function() {
            b.getJSON("/message/newmessage_watch.php").done(b.proxy(this, "_callback"))
        },
        _callback: function(c) {
        }
    };
})(jQuery);
(function(b) {
    var c = function(f, e) {
    };
    b.extend(c.prototype, {
        show: function() {
        },
        hide: function() {
        },
        hasNew: function() {
        },
        clear: function() {
        },
        setCount: function(e) {
        }
    });
    var a = new c(".js_newcmt", {
        text: "您有新的评论"
    });
    var d = new c(".js_newInteract", {
        text: "您有新的互动"
    });
})(jQuery);
(function(a) {
    var b = {
        init: function(c) {
                return
            }
        },
        show: function() {
        },
        hide: function() {
        },
        getType: function() {
        },
        togglePop: function() {
        },
        _toogleHandler: function(c) {
            c.preventDefault();
        },
        _changeType: function(f) {
            f.preventDefault();
            f.stopPropagation();
            var d = a(f.target);
            var g = d.text();
            var c = d.attr("data-type");
            }
        }
    };
    b.init();
})(jQuery);
(function() {
        uid: 0,
        t_v: 0,
        t_h: 0,
        _btn: 0,
        init: function() {
                var c = b.card.card;
                c.bind("mouseover", function() {
                    if (b.card.style == "btn") {
                        b.onBox = 1
                    }
                });
                c.bind("mouseout", function() {
                    b.onBox = 0
                });
                c = null;
                a(document).bind("mousemove", function(f) {
                    var d = a(f.target);
                    if (d.attr("usercard") || b.onBox) {
                        b.getCard(d.attr("usercard"), jQuery(d))
                    } else {
                        b.hCard()
                    }
                })
            })
        },
        tmp: 1,
        getCard: function(c, b) {
                return
            }
                d.card.style = "btn";
                d.uid = c;
                d.card.getCard(c, b)
            }, 600)
        },
        hCard: function() {
                    b.uid = 0;
                    b.card.hCard()
                }, 300)
            }
        }
    }
})();
(function(a) {
    var c = {
        template: "",
        form: "",
        list: ""
    };
    var b = function(g, e, d, f) {
    };
    a.extend(b.prototype, {
        build: function() {
            var f = e.template;
            });
            }
        },
        reset: function(f, e) {
            var d = {
                receiver: f,
                receiver_owner: e || 0
            };
        },
        _listPageCutHandler: function() {
                a("html, body").animate({
                    scrollTop: d.top
                }, 200)
            }
        },
        _sendFailHandler: function(d, e) {
            alert(e)
        },
        _sendSuccessHandler: function(d) {
        }
        var d = new b(null, {
            template: a("#feed_comment_template")[0].text,
            form: ".tweet-cmt-form",
            list: ".tweet-cmt-list"
        }, {
            template: a("#feed_comment_list_template")[0].text,
            replyListTemplate: a("#feed_comment_reply_list_template")[0].text,
            replyTemplate: a("#feed_comment_reply_text_template")[0].text,
            replyListWrap: "ul.comment-reply-list",
            listWrap: "ul.content",
            pageWrap: ".g-paginator",
            loadingWrap: ".loading",
            nextPageFn: "feed.comment.list.getPages"
        }, {
            textarea: ".js_comment_textarea",
            component: {
                face: {
                    btn: ".js_emotionButton"
                }
            }
        });
        a.extend(d, {
            recipient: "",
            detach: function() {
            },
            show: function(h, e, g) {
                }
                g.append(f);
                f.css("display", "block");
            },
            toggle: function(j) {
                var f = j.attr("href");
                var e = j.attr("data-prefix");
                var i = f.substring(f.indexOf("#") + 1);
                var h = a("#" + e + i);
                var g = j.attr("data-uid");
                } else {
                }
            }
        });
    })
})(jQuery);
(function(b) {
    var c = {
        url: "/message/comment_add.php"
    };
    var a = function(e, d) {
        a.superclass.constructor.call(this, e, b.extend(c, d))
    };
        getParam: function() {
            var h = b.trim(e.val());
            var f = e.attr("data-tuid");
            var d = e.attr("data-tm");
            var g = {
            };
            if (d) {
                g.tm = d
            } else {
                if (f) {
                    g.tuid = f
                }
            }
            h = h.replace(/^回复[^\:]*\:/, "");
            g.msg = h;
            return g
        },
        checkAvailable: function() {
                return false
            }
            if (!e.msg) {
                alert(d);
                return false
            }
            return true
        }
    });
})(jQuery);
(function(a) {
    var c = {
        url: "/message/comment_get.php",
        receiver: 0,
        receiver_owner: 0,
        template: "",
        replyTemplate: "",
        replyListTemplate: "",
        replyListWrap: "",
        ipp: 10,
        order: 1
    };
    var b = function(e, d) {
        b.superclass.constructor.call(this, e, a.extend(c, d))
    };
        parseData: function(d) {
            return d
        },
        assemble: function(e) {
        },
        insert: function(f, d) {
            if (d) {
            } else {
            }
        },
        insertReply: function(f, g) {
            f.append(d)
        },
        _parseList: function(j, i) {
            var g = f.template;
            var e = f.replyListTemplate;
            var d = [];
            var k = function(m) {
                var l = {
                    eid: "cmt" + m.stm,
                    alias: m.alias,
                    msg: m.msg,
                    content: function() {
                        var n = m.msg;
                        if (m.tuid) {
                                uid: m.tuid,
                                rid: m.trid,
                                alias: m.talias
                            }) + n
                        }
                        return ParseFaceSymobls(n)
                    },
                    rid: m.rid,
                    tuid: m.tuid,
                    trid: m.trid,
                    uid: m.uid,
                    userpic: m.userpic,
                    sit: m.sit,
                    stm: m.stm,
                    tm: m.tm,
                    tid: f.receiver,
                    isOwner: function() {
                    }(),
                    replyList: function() {
                        return m.reply && m.reply.length ? h._parseList(m.reply, true) : ""
                    }()
                };
            };
            a.each(j, function(l, m) {
                d.push(k(m))
            });
            return d.join("")
        },
        getParam: function() {
            return {
                _t: +new Date
            }
        },
        checkEmpty: function(d) {
            return d.content.length == 0
        }
    });
})(jQuery);
(function(f) {
    var b = "cmt";
    var e = "re";
    var c = function(j) {
        var g = j.hasClass("js-comment-del");
        var i = j.hasClass("js-reply-del");
        if (!g && !i) {
            return
        }
        if (!confirm("确定要删除吗?")) {
            return
        }
        var k = j.attr("data-id");
        var h = {
            id: j.attr("data-tid"),
            tm: k,
            uid: j.attr("data-uid")
        };
        f.ajax({
            url: "/message/comment_del.php",
            dataType: "json",
            data: h,
            success: a,
            context: {
                prefix: g ? b : e,
                id: k
            }
        })
    };
    var a = function(h) {
        if (h.flag == "001") {
            g.animate({
                height: 0
            }, {
                complete: d
            });
        } else {
            alert(h.content)
        }
    };
    var d = function() {
        f(this).remove()
    };
})(jQuery);
(function(b) {
    var a = {
        recipient: "",
        build: function() {
            var d = b("#feed_comment_reply_wrap_template")[0].text;
            });
            }
                textarea: ".js_comment_textarea",
                component: {
                    face: {
                        btn: ".js_emotionButton"
                    }
                }
            });
        },
        show: function(f, g, c, e) {
            }
            if (e.find("ul.comment-reply-list")[0]) {
                e.find("ul.comment-reply-list").before(d)
            } else {
                d.appendTo(e)
            }
            d.css("display", "block");
        },
        detach: function() {
            }
        },
        toggle: function(h) {
            var d = h.closest("li");
            var g = h.attr("data-uid");
            var f = h.attr("data-tid");
            var e = d.attr("id");
            var c = h.attr("data-id");
            } else {
            }
        },
        reset: function(e, d) {
            var c = {
                receiver: e || 0,
                receiver_owner: d || 0
            };
        },
        insertWord: function(f) {
            var e = f.attr("data-uid");
            var d = f.attr("data-alias");
            c.val("");
            c.val("回复" + d + " : ")
        },
        _sendFailHandler: function(c, d) {
            alert(d)
        },
        _sendSuccessHandler: function(f) {
            if (e) {
                var d = b("#" + e);
                var c = d.find("ul.comment-reply-list");
                if (!c[0]) {
                    c = d.parent("ul.comment-reply-list")
                }
            }
        }
    };
})(jQuery);
(function(d) {
    var c = "#feed_tpl_publish_wrap";
    var e = "image";
    var a = "//vj0.xiu123.cn/mini/js/base/fileuploader_4.js";
    var b = {
        _activeTag: {},
        init: function() {
            var f = d(c).html();
        },
        initForm: function() {
                component: {
                    face: {
                        btn: "a.face"
                    },
                    at: {
                        btn: "a.at"
                    }
                }
            });
            d.extend(f, {
                getApi: function() {
                    return g[g.tag].api
                },
                getValue: function() {
                },
                getParam: function() {
                    var h = g[g.tag];
                    var i = h.getParam();
                    d.extend(i, {
                    });
                    return i
                },
                checkAvailable: function() {
                    return g._verifyCheck()
                }
            });
            f.on("sendSuccess", d.proxy(this, "_sendSuccess"));
            f.on("sendFail", d.proxy(this, "_sendFail"))
        },
        show: function(f) {
            }
        },
        hide: function() {
            }
                g.clean()
            })
        },
        destroy: function() {
        },
        switchTab: function(f) {
                    g[f].init();
                    g._activeTag[f] = g[f]
                })
            }
        },
        _changeTab: function(h) {
            var g = h.parent("li");
            if (g.hasClass("on")) {
                return
            }
            var i = h.attr("rela");
            var f = d("#js_content_" + i);
            g.addClass("on").siblings().removeClass("on");
            f.css("display", "block").siblings().css("display", "none");
        },
        _sendSuccess: function(f) {
        },
        _sendFail: function(f, g) {
        },
        _verifyCheck: function() {
            if (!f) {
                return false
            }
                return false
            }
            return true
        },
        _clickHandler: function(g) {
            var f = d(g.target);
            if (f.hasClass("js-close")) {
                g.preventDefault();
            } else {
                if (f.hasClass("js-tab")) {
                    g.preventDefault();
                }
            }
        }
    };
    b.bind = function(g, f) {
        d(g).on("click.feed", function(h) {
            h.preventDefault();
            b.show(f)
        })
    };
})(jQuery);
(function(b) {
    var a = "#feed_tpl_publish_image";
    var c = {
        api: "/message/message_morePicMsg.php",
        _queue: [],
        _maxCount: 9,
        init: function() {
                return
            }
            var f = b(a).html();
                params: {
                    pid: 1001,
                    size: "s2,b1"
                }
            });
            e.on("ready", b.proxy(this, "_readyHandler"));
            e.on("process", b.proxy(this, "_processHandler"));
            e.on("start", b.proxy(this, "_startHandler"));
            e.on("progress", b.proxy(this, "_progressHandler"));
            e.on("complete", b.proxy(this, "_completeHandler"));
            e.on("end", b.proxy(this, "_endHandler"));
        },
        verify: function() {
                alert("图片上传中，请完成再试");
                return false
            }
                alert("为你的心情附上一些照片吧");
                return false
            }
            return true
        },
        getPicArr: function() {
            var d = [];
                var e = b(this).find("img");
                var f = e.attr("data-src");
                d.push(f)
            });
            return d
        },
        getParam: function() {
            return {
            }
        },
        setFileText: function(e, d) {
            b("#pic_" + e).find(".percent").text(d)
        },
        setDisplay: function(d) {
        },
        setViewport: function() {
        },
        clean: function() {
        },
        destroy: function() {
        },
        find: function(e) {
            var d;
                if (g.id == e) {
                    d = [f, g];
                    return false
                }
            });
            return d
        },
        _deleteHandler: function(h) {
            h.preventDefault();
            var g = b(h.target);
            var f = g.parents("li");
            var i = f.attr("data-id");
            if (d) {
                f.remove()
            }
        },
        _readyHandler: function(k) {
            var l = k;
            var j = 20 * 1024 * 1024;
            var m = ["jpg", "jpeg", "png", "gif"];
            for (var h = 0; h < l.length; h++) {
                var d = l[h].name;
                    return alert("文件类型错误 - " + d)
                }
                if (l[h].size && l[h].size > j) {
                    return alert("文件过大 - " + d)
                }
            }
            var e = l.length;
            if (f + e > g) {
                alert("每次最多上传 " + g + " 张图片" + (f == 0 ? "。" : "，本次您还能上传 " + (g - f) + " 张。"))
            } else {
            }
        },
        _processHandler: function(d, f) {
            var e = [];
            b.each(f, function(h, g) {
                e.push('<li class="pic" id="pic_' + g.id + '" data-id="' + g.id + '">    				<div class="uploading-box">						<span class="percent">0%</span>	    			</div>	    			<div class="pic-box">						<img src="">						<span class="picbg"></span>	        			<a href="javascript:;" class="del-btn"></a>	    			</div>	    		</li>')
            });
        },
        _startHandler: function(d) {
        },
        _progressHandler: function(e, d) {
        },
        _completeHandler: function(h, e) {
            if (h.flag == "001") {
                var g = 80;
                var f = 80;
                var j = b("#pic_" + e.id);
                var i = j.find("img");
                j.find(".uploading-box").remove();
                i.attr("src", h.content.s.link).attr("data-src", h.content.url.link);
                i.css("width", d.width || "auto").css("height", d.height || "auto");
                if (!d.width || !d.height) {
                    i.css("maxWidth", g);
                    i.css("maxHeight", f)
                } else {
                    i.css("position", "absolute").css("left", g / 2 - d.width / 2).css("top", f / 2 - d.height / 2)
                }
            } else {
            }
        },
        _endHandler: function(d) {
        }
    };
})(jQuery);
(function(b) {
    var a = "#feed_tpl_publish_music";
    var c = {
        api: "/message/message_musicMsg.php",
        init: function() {
                return
            }
            var f = b(a).html();
                params: {
                    act: "upload",
                    str: "7bbf7e",
                }
            });
            e.on("ready", b.proxy(this, "_readyHandler"));
            e.on("start", b.proxy(this, "_startHandler"));
            e.on("progress", b.proxy(this, "_progressHandler"));
            e.on("complete", b.proxy(this, "_completeHandler"));
            e.on("end", b.proxy(this, "_endHandler"));
        },
        getParam: function() {
            return {
                origin: d,
            }
        },
        verify: function() {
                alert("请上传音乐");
                return false
            }
            return true
        },
        clean: function() {
            try {
        },
        destroy: function() {
        },
        setState: function(d) {
            switch (d) {
                case 1:
                    break;
                case 2:
                    break;
                case 3:
                    break
            }
        },
        setTitle: function(d) {
        },
        setMessage: function(e, d) {
        },
        setProgress: function(e) {
            d.find(".percent").text(e + "%");
            d.find(".handler").css("width", e + "%");
        },
        _deleteHandler: function(d) {
            d.preventDefault();
        },
        _readyHandler: function(g) {
            var f = g[0];
            var d = 20 * 1024 * 1024;
            var e = ["mp3", "wav", "wmv", "mpeg", "flv", "avi", "3gp", "mp4", "m4a"];
                return alert("文件类型错误，支持" + e.join() + "格式")
            }
            if (f.size && f.size > d) {
                return alert("文件大小错误，单首歌曲最大15MB")
            }
        },
        _startHandler: function(d) {
        },
        _progressHandler: function(e, d) {
        },
        _completeHandler: function(e, d) {
            if (e.flag == "001") {
            } else {
            }
        },
        _endHandler: function(d) {
        }
    };
})(jQuery);
(function(e) {
    var g = e("#wbFeed");
    var h = function(l) {
        l.find("img[lazy]").lazyLoadImg("lazy")
    };
    var f = function(l) {
        if (l < e(window).scrollTop()) {
            e("body, html").animate({
                scrollTop: l
            }, 200)
        }
    };
    var b = function() {
    };
    var j = function(l) {
        l.find(".js_host").show()
    };
    var a = function(m, l) {
        if (!n) {
                url: "/message/message_get.php",
                template: l.template,
                nextPageFn: "feed.feedList.getPages",
                isShowFollow: false
            });
            n.getParam = function() {
                return {
                    size: 40,
                    p: n.page,
                    type: l.type
                }
            };
            n.on("dataSuccess", function(o) {
                h(n.listWrap);
                j(n.listWrap)
            });
            n.on("pageCut", b)
        }
        n.getData(1)
    };
    var k = function(m, l) {
        if (!n) {
                name: "guessList",
                url: "/message/recommend.php",
                template: l.template,
                nextPageFn: "feed.guessList.getPages"
            });
            n.getParam = function() {
                return {
                    p: n.page,
                    size: 40
                }
            };
            n.on("dataSuccess", function(o) {
                h(n.listWrap);
                j(n.listWrap)
            });
            n.on("pageCut", b)
        }
        n.getData(1)
    };
    var d = function(m, l) {
        if (!n) {
                url: "/message/interaction.php",
                template: l.template,
                nextPageFn: "feed.interactList.getPages",
                isShowFollow: false
            });
            n.getParam = function() {
                return {
                    p: n.page,
                    size: 40
                }
            };
            n.on("dataSuccess", function(o) {
                h(n.listWrap);
                j(n.listWrap)
            });
            n.on("pageCut", b)
        }
        n.getData(1)
    };
    });
    });
    });
            triggerCls: "js-tab"
        });
        m.on("onSwitch", function(p, n) {
            m.wrap.find(".line-on").animate({
                width: p.outerWidth(true),
                left: p.position().left
            }, 200);
            if (n == 0) {
                        return {
                            size: 40,
                            type: s
                        }
                    };
                });
                var r = e("#menubar .nav-feed span.new");
                r.find(".num").html(0);
                r.css("display", "none")
            } else {
            }
            var o = m.panels;
            var q = e("#feed_list_wrap_template")[0].text;
            q = q.replace(/{content}/, e("#feed_list_template")[0].text);
            switch (n) {
                case 0:
                    a(o[0], {
                        template: q,
                    });
                    break;
                case 1:
                    k(o[1], {
                        template: q
                    });
                    break;
                case 2:
                    d(o[2], {
                        template: e("#feed_list_interact_template")[0].text
                    });
                    break
            }
            h(o[n])
        });
            var l = e(".js-publish-btn").css("display", "block");
            });
            g.find(".js_host").show()
        }
        m.switchTo(0);
    });
            if (l.flag == "001") {
                if (l.content.interaction > 0) {
                    } else {
                    }
                }
                var m = e("#menubar .nav-feed span.new");
                if (l.content.msg > 0) {
                    } else {
                        m.find(".num").html(l.content.msg);
                        m.css("display", "inline-block")
                    }
                } else {
                    m.css("display", "none")
                }
                if (l.content.newfans != "0") {
                }
            }
        });
        var c = e("#wb_user .log-info");
    }
})(jQuery);