/*! LAB.js (LABjs :: Loading And Blocking JavaScript)
    v2.0.3 (c) Kyle Simpson
    MIT License 
*/
if (!window.isLab) {
    window.isLab = 1;
    /*! LAB.js (LABjs :: Loading And Blocking JavaScript)
        v2.0.3 (c) Kyle Simpson
        MIT License
    */
    (function(q) {
        var u = q.$LAB,
            j = "UseLocalXHR",
            p = "AlwaysPreserveOrder",
            m = "AllowDuplicates",
            l = "CacheBust"
            /*!START_DEBUG*/
            ,
            k = "Debug"
            /*!END_DEBUG*/
            ,
            e = "BasePath",
            B = /^\w+\:\/\/\/?[^\/]+/.exec(r)[0],
            /*!START_DEBUG*/
            ,
            c = function() {},
            n = c
            /*!END_DEBUG*/
            ,
            a = typeof z.preload == "boolean",
            w = a || (z.readyState && z.readyState == "uninitialized"),
            x = !w && z.async === true,
            y = !w && !x && !h;
        /*!START_DEBUG*/
        if (q.console && q.console.log) {
            if (!q.console.error) {
            }
            c = function(C) {
                q.console.log(C)
            };
            n = function(D, C) {
                q.console.error(D, C)
            };
            /*!END_DEBUG*/
        }

        function t(C) {
            return Object.prototype.toString.call(C) == "[object Function]"
        }

        function A(C) {
            return Object.prototype.toString.call(C) == "[object Array]"
        }

        function g(E, D) {
            var C = /^\w+\:\/\//;
            if (/^\/\/\/?/.test(E)) {
            } else {
                if (!C.test(E) && E.charAt(0) != "/") {
                }
            }
            return C.test(E) ? E : ((E.charAt(0) == "/" ? B : r) + E)
        }

        function i(D, E) {
            for (var C in D) {
                if (D.hasOwnProperty(C)) {
                }
            }
            return E
        }

        function b(D) {
            var E = false;
            for (var C = 0; C < D.scripts.length; C++) {
                if (D.scripts[C].ready && D.scripts[C].exec_trigger) {
                    E = true;
                    D.scripts[C].exec_trigger();
                }
            }
            return E
        }

        function d(E, D, C, F) {
                if ((E.readyState && E.readyState != "complete" && E.readyState != "loaded") || D[C]) {
                    return
                }
                F()
            }
        }

        function v(C) {
            for (var D = 0; D < C.finished_listeners.length; D++) {
                C.finished_listeners[D]()
            }
        }

        function s(E, F, D, G, C) {
            setTimeout(function() {
                var H, J = F.real_src,
                    I;
                if ("item" in f) {
                    if (!f[0]) {
                        setTimeout(arguments.callee, 25);
                        return
                    }
                    f = f[0]
                }
                if (F.type) {
                    H.type = F.type
                }
                if (F.charset) {
                    H.charset = F.charset
                }
                if (C) {
                    if (w) {
                        /*!START_DEBUG*/
                        if (E[k]) {
                            c("start script preload: " + J);
                            /*!END_DEBUG*/
                        }
                        if (a) {
                            H.preload = true;
                            H.onpreload = G
                        } else {
                            H.onreadystatechange = function() {
                                if (H.readyState == "loaded") {
                                    G()
                                }
                            }
                        }
                        H.src = J
                    } else {
                        if (C && J.indexOf(B) == 0 && E[j]) {
                            /*!START_DEBUG*/
                            if (E[k]) {
                                c("start script preload (xhr): " + J);
                                /*!END_DEBUG*/
                            }
                            I.onreadystatechange = function() {
                                if (I.readyState == 4) {
                                    I.onreadystatechange = function() {};
                                    G()
                                }
                            };
                            I.open("GET", J);
                            I.send()
                        } else {
                            /*!START_DEBUG*/
                            if (E[k]) {
                                c("start script preload (cache): " + J);
                                /*!END_DEBUG*/
                            }
                            H.type = "text/cache-script";
                            d(H, D, "ready", function() {
                                f.removeChild(H);
                                G()
                            });
                            H.src = J;
                            f.insertBefore(H, f.firstChild)
                        }
                    }
                } else {
                    if (x) {
                        /*!START_DEBUG*/
                        if (E[k]) {
                            c("start script load (ordered async): " + J);
                            /*!END_DEBUG*/
                        }
                        H.async = false;
                        d(H, D, "finished", G);
                        H.src = J;
                        f.insertBefore(H, f.firstChild)
                    } else {
                        /*!START_DEBUG*/
                        if (E[k]) {
                            c("start script load: " + J);
                            /*!END_DEBUG*/
                        }
                        d(H, D, "finished", G);
                        H.src = J;
                        f.insertBefore(H, f.firstChild)
                    }
                }
            }, 0)
        }

        function o() {
            var E = {},
                J = w || y,
                C = [],
                D = {},
                G;
            E[j] = true;
            E[p] = false;
            E[m] = false;
            E[l] = false;
            /*!START_DEBUG*/
            E[k] = false;
            /*!END_DEBUG*/
            E[e] = "";

            function I(M, O, L) {
                var K;

                function N() {
                    if (K != null) {
                        K = null;
                        v(L)
                    }
                }
                if (D[O.src].finished) {
                    return
                }
                if (!M[m]) {
                    D[O.src].finished = true
                }
                if (O.type) {
                    K.type = O.type
                }
                if (O.charset) {
                    K.charset = O.charset
                }
                d(K, L, "finished", N);
                if (L.elem) {
                } else {
                    if (L.text) {
                        K.onload = K.onreadystatechange = null;
                        K.text = L.text
                    } else {
                        K.src = O.real_src
                    }
                }
                f.insertBefore(K, f.firstChild);
                if (L.text) {
                    N()
                }
            }

            function F(M, Q, P, K) {
                var L, O, N = function() {
                        Q.ready_cb(Q, function() {
                            I(M, Q, L)
                        })
                    },
                    R = function() {
                        Q.finished_cb(Q, P)
                    };
                if (!D[Q.src]) {
                    D[Q.src] = {
                        items: [],
                        finished: false
                    }
                }
                O = D[Q.src].items;
                if (M[m] || O.length == 0) {
                    L = O[O.length] = {
                        ready: false,
                        finished: false,
                        ready_listeners: [N],
                        finished_listeners: [R]
                    };
                    s(M, Q, L, ((K) ? function() {
                        L.ready = true;
                        for (var S = 0; S < L.ready_listeners.length; S++) {
                            L.ready_listeners[S]()
                        }
                        L.ready_listeners = []
                    } : function() {
                        v(L)
                    }), K)
                } else {
                    L = O[0];
                    if (L.finished) {
                        R()
                    } else {
                        L.finished_listeners.push(R)
                    }
                }
            }

            function H() {
                var N, R = i(E, {}),
                    K = [],
                    M = 0,
                    O = false,
                    Q;

                function T(V, U) {
                    /*!START_DEBUG*/
                    if (R[k]) {
                        c("script preload finished: " + V.real_src);
                        /*!END_DEBUG*/
                    }
                    L()
                }

                function S(W, V) {
                    /*!START_DEBUG*/
                    if (R[k]) {
                        c("script execution finished: " + W.real_src);
                        /*!END_DEBUG*/
                    }
                    for (var U = 0; U < V.scripts.length; U++) {
                        if (!V.scripts[U].finished) {
                            return
                        }
                    }
                    L()
                }

                function L() {
                    while (M < K.length) {
                        if (t(K[M])) {
                            /*!START_DEBUG*/
                            if (R[k]) {
                                c("$LAB.wait() executing: " + K[M]);
                                /*!END_DEBUG*/
                            }
                            try {
                                K[M++]()
                                /*!START_DEBUG*/
                                if (R[k]) {
                                    n("$LAB.wait() error caught: ", U);
                                    /*!END_DEBUG*/
                                }
                            }
                            continue
                        } else {
                            if (!K[M].finished) {
                                if (b(K[M])) {
                                    continue
                                }
                                break
                            }
                        }
                        M++
                    }
                    if (M == K.length) {
                        O = false;
                        Q = false
                    }
                }

                function P() {
                    if (!Q || !Q.scripts) {
                        K.push(Q = {
                            scripts: [],
                            finished: true
                        })
                    }
                }
                N = {
                    script: function() {
                        for (var U = 0; U < arguments.length; U++) {
                            (function(Y, W) {
                                var X;
                                if (!A(Y)) {
                                }
                                for (var V = 0; V < W.length; V++) {
                                    P();
                                    if (t(Y)) {
                                    }
                                    if (!Y) {
                                        continue
                                    }
                                    if (A(Y)) {
                                        X = [].slice.call(Y);
                                        X.unshift(V, 1);
                                        [].splice.apply(W, X);
                                        V--;
                                        continue
                                    }
                                    if (typeof Y == "string") {
                                            src: Y
                                        }
                                    }
                                        ready: false,
                                        finished: false,
                                    });
                                    Q.finished = false;
                                    Q.scripts.push(Y);
                                    F(R, Y, Q, (J && O));
                                    O = true;
                                    if (R[p]) {
                                        N.wait()
                                    }
                                }
                            })(arguments[U], arguments[U])
                        }
                        return N
                    },
                    wait: function() {
                        if (arguments.length > 0) {
                            for (var U = 0; U < arguments.length; U++) {
                                K.push(arguments[U])
                            }
                            Q = K[K.length - 1]
                        } else {
                            Q = false
                        }
                        L();
                        return N
                    }
                };
                return {
                    script: N.script,
                    wait: N.wait,
                    setOptions: function(U) {
                        i(U, R);
                        return N
                    }
                }
            }
            G = {
                setGlobalDefaults: function(K) {
                    i(K, E);
                    return G
                },
                setOptions: function() {
                    return H().setOptions.apply(null, arguments)
                },
                script: function() {
                    return H().script.apply(null, arguments)
                },
                wait: function() {
                    return H().wait.apply(null, arguments)
                },
                queueScript: function() {
                    C[C.length] = {
                        type: "script",
                        args: [].slice.call(arguments)
                    };
                    return G
                },
                queueWait: function() {
                    C[C.length] = {
                        type: "wait",
                        args: [].slice.call(arguments)
                    };
                    return G
                },
                runQueue: function() {
                    var M = G,
                        K = C.length,
                        L = K,
                        N;
                    for (; --L >= 0;) {
                        N = C.shift();
                        M = M[N.type].apply(null, N.args)
                    }
                    return M
                },
                noConflict: function() {
                    return G
                },
                sandbox: function() {
                    return o()
                }
            };
            return G
        }
        (function(E, C, D) {
                }, false)
            }
        })("addEventListener", "DOMContentLoaded")
    })(this);
    (function() {
        var a = function(d, i) {
            var c = false,
                h = true,
                k = d.document,
                j = k.documentElement,
                n = k.addEventListener ? "addEventListener" : "attachEvent",
                l = k.addEventListener ? "removeEventListener" : "detachEvent",
                b = k.addEventListener ? "" : "on",
                m = function(o) {
                    if (o.type == "readystatechange" && k.readyState != "complete") {
                        return
                    }(o.type == "load" ? d : k)[l](b + o.type, m, false);
                    if (!c && (c = true)) {
                        i.call(d, o.type || o)
                    }
                },
                g = function() {
                    try {
                        j.doScroll("left")
                        setTimeout(g, 50);
                        return
                    }
                    m("poll")
                };
            if (k.readyState == "complete") {
                i.call(d, "lazy")
            } else {
                if (k.createEventObject && j.doScroll) {
                    try {
                        h = !d.frameElement
                    if (h) {
                        g()
                    }
                }
                k[n](b + "DOMContentLoaded", m, false);
                k[n](b + "readystatechange", m, false);
                d[n](b + "load", m, false)
            }
        };
        a(window, function() {
        });
                b()
            } else {
                a(this, b)
            }
        }
    })()
}
$LAB.setOptions({
    AlwaysPreserveOrder: true,
    Debug: true
});