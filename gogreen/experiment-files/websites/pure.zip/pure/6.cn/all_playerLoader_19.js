function all_playerLoader(params) {

    //====> 浏览器检测 =========================
    /*
    Due to IO restrictions, flv.js can support HTTP FLV live stream on Chrome 43+, FireFox 42+, Edge 15.15048+ and Safari 10.1+ for now.

    HTTP FLV live stream relies on stream IO, which has been introduced in fetch and stream spec. Now FetchStreamLoader works well on most of the modern browsers:

    Chrome: FetchStreamLoader works well on Chrome 43+
    FireFox: FireFox has fetch support but stream is missing, moz-chunked-arraybuffer xhr extension is used
    Edge: fetch + stream is broken on old version of Microsoft Edge, see Fetch API with ReadableStream has bug with data pumping. Got fixed in Creator Update (RS2).
    Safari: FetchStreamLoader works well since Safari 10.1 (macOS 10.12.4)
     */

    var _browser = {},
        sys = {},
        s;
    (s = ua.match(/edge\/([\d.]+)/)) ? sys.edge = s[1]:
        (s = ua.match(/rv:([\d.]+)\) like gecko/)) ? sys.ie = s[1] :
        (s = ua.match(/msie ([\d.]+)/)) ? sys.ie = s[1] :
        (s = ua.match(/firefox\/([\d.]+)/)) ? sys.firefox = s[1] :
        (s = ua.match(/chrome\/([\d.]+)/)) ? sys.chrome = s[1] :
        (s = ua.match(/opera.([\d.]+)/)) ? sys.opera = s[1] :
        (s = ua.match(/version\/([\d.]+).*safari/)) ? sys.safari = s[1] : 0;

    if (sys.edge) _browser = {
        name: "edge",
        version: sys.edge
    };
    if (sys.ie) _browser = {
        name: "ie",
        version: sys.ie
    };
    if (sys.firefox) _browser = {
        name: "firefox",
        version: sys.firefox
    };
    if (sys.chrome) _browser = {
        name: "chrome",
        version: sys.chrome
    };
    if (sys.opera) _browser = {
        name: "opera",
        version: sys.opera
    };
    if (sys.safari) _browser = {
        name: "safari",
        version: sys.safari
    };
    _browser.version = parseFloat(_browser.version);



    //
    var ver = _browser.version


    //var ver=Number(jQuery.browser.version.substring(0, 2))
    if (_browser.name == "chrome") {
        if (ver > 60 && ver < 90) {
        }

    } else if (_browser.name == "safari") {
        if (ver > 10) {
        }
    } else if (_browser.name == "firefox") {
        if (ver > 42) {
        }
    } else if (_browser.name == "edge") {
        if (ver > 15) {
        }
    }

    //---- palyerLoader 首选使用播放器类型
    if (params.fristPlayerType == 'h5') {
        } else {
        }

    } else if (params.fristPlayerType == 'flash') {
    }


    //===== homepage 判断支持flash 的首选flash =========
    if (params.mode == 'homepage' || params.mode == 'room' || params.mode == 'audio') {
        }
    }

    //----- 是否支持flash -----//
    function hasUsableFlash() {
        var flashObj;
        } else {
        }
        return flashObj ? true : false;
    }

    //===> 选择 h5 or flash 播放器 =============
        } else {
        }


    }




    //----- log -------//
    var showlog = {
        params: params,
    }
    //console.log('[PlayerLoader]==> ',showlog);
    //======= obj ==========================
    // h5 flash 统一对象名

    //======== url =========================

    //使用 room_videos.tpl 值
    try {
        //------ h5  --------
        }

        //----- flash -------
        switch (params.mode) {
            case 'audio':
            case 'room':
                break
            case 'homepage':
                break
            case 'activity':
                break
            case 'family':
                break
            default:
        };
    }
    //如果没加载到 room_videos.tpl 值
        //------ h5  --------

        //----- flash -------
        switch (params.mode) {
            case 'audio':
            case 'room':
                break
            case 'homepage':
                break
            case 'activity':
                break
            case 'family':
                break
            default:
                break;
        };
    }



    //----- init -------

    //-- 记录父节点 -- 在romove()后需要重新建立//


    //console.log('[V6_HF_liveplayer]==> ','this.params=',this.params)

    //------------------

    }





    //==================================
}
all_playerLoader.prototype = {

    //
    loadPlayer: function(_type) {

        if (_type) {
        }

            //V6player.js 是否已加载
                //没有加载 需要加载
                    that.player = createH5Player();
                });
            } else {
                //已加载 直接new
                //console.log('[V6_HF_liveplayer]==> ','V6player -->exist!',that.h5_player_url)

                that.player = createH5Player();
            }
        } else {
            //swfobject.js 是否已加载
                    that.player = createFlashPlayer();
                    // console.log('[V6_HF_liveplayer]==> ','swfobject-->loadFinish')
                });

            } else {
                //swfobject.js 已加载
                that.player = createFlashPlayer();
                //console.log('[V6_HF_liveplayer]==> ','swfobject-->exist!');
            }

        }
        //----------flash替换 div id ----------------
        function createFlashPlayer() {
            //console.log('[V6_HF_liveplayer]==> ',that.flash_player_url)
            var swfParams = that.params;

                that._parent_El.append('<div id=' + that.videoId + '></div>');
            }
            jQuery('#' + that.videoId).html('<div class="fInstall"><a href="https://get.adobe.com/cn/flashplayer/" target="_blank">请安装或者启用FLASH播放器</a></div>')
            // jQuery('#'+that.videoId).append('<style>'+'#'+that.videoId+' .fInstall { z-index: 200; position: absolute; left: 50%; top: 50%; width: 214px; height: 56px; margin: -28px 0 0 -107px; }'+"#"+that.videoId+' .fInstall a { display: block; width: 214px; height: 56px; line-height: 56px; background: #ff4443; border-radius: 3px; color: #fff; text-align: center; font-size: 14px; transition: all .35s ease-in-out 0s;text-decoration: none; cursor: pointer; } </style>')
                allowscriptaccess: 'always',
                wmode: 'Opaque',
                bgcolor: '#21201B'
            });
            return player;
        }

        function createH5Player() {
            var h5Params = that.params;

            //console.log('[V6_HF_liveplayer]==> ','V6player -->loadFinish',that.h5_player_url)
            return player;
        }

    },
    getPlayer: function() {

    },
    remove: function() {

        } else {
            try {

                var _parentElement = _element.parentNode;
                if (_parentElement) {
                    _parentElement.removeChild(_element);
                }

                //$('')
                // box.remove();

            }

        }
        //console.log('all_playerLoader==> remove()')
    }
}