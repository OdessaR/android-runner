var TEM = {
    tongji: function() {
    }
};
(function() {
        _curPanel: "home",
        init: function() {
                    jQuery(".nav-game").find(".-more-rich1, .-more-rich3").css("display", "block")
                } else {
                    jQuery(".nav-game").find(".-more-rich1").css("display", "block")
                }
            } else {
                jQuery(".nav-game").find(".-more-rich1, .-more-rich3").remove()
            }
            } else {
            }
            });
            a("#tougao").on("click", function(j) {
                j.preventDefault();
                var d = a(this);
                var h = d.siblings(".pop");
                var g = function() {
                    h.removeClass("pop-show");
                    a(document).off("mousedown.tougao")
                };
                var f = function() {
                    h.addClass("pop-show");
                    a(document).on("mousedown.tougao", function(l) {
                        var k = l.target;
                        if (k == d[0] || a.contains(d[0], k) || k == h[0] || a.contains(h[0], k)) {
                            return
                        }
                        if (h.hasClass("pop-show")) {
                            g()
                        }
                    })
                };
                if (h.hasClass("pop-show")) {
                    g()
                } else {
                    f()
                }
            });
            var c = a("#hotAffair .list-box");
            c.jsscroll({
                scrollBack: function() {
                    a.each(c.find("img[src2]"), function() {
                        a(this).attr("src", a(this).attr("src2"));
                        a(this).removeAttr("src2");
                        a(this).css("opacity", 1)
                    })
                }
            });
            a(window).on("resize", function() {
                c.jsscroll_remake(1)
            })
        },
        showMenu: function() {
                f = a("div.page-home"),
                h = a("div#menubar"),
                g = a("div.body-main"),
                e = a("div.side-tool"),
                k = e.find(".top"),
                l = 0,
                j = 1,
                d = 200;
            a(window).on("scroll", function() {
                    o = a(window).scrollTop(),
                    n = (g.offset().top - 120) || 0;
                if (o > 100) {
                    k.css("height", 36)
                } else {
                    k.css("height", 0)
                }
                if (n > o) {
                    e.fadeOut(300);
                    if (j) {
                        return
                    }
                    l = 0;
                    j = 1;
                    if (m < 1340) {
                        f.animate({
                            "padding-left": "0"
                        }, 800)
                    }
                    h.animate({
                        left: "-" + d
                    }, 800)
                } else {
                    }
                    if (m >= 1340) {
                        e.fadeIn(300);
                    } else {
                        e.fadeOut(300);
                    }
                    if (l) {
                        return
                    }
                    l = 1;
                    j = 0;
                    h.animate({
                        left: 0
                    }, 800)
                }
            });
            a(window).scroll();
            h.find(".menu-scroll").jsscroll();
            k.on("click", function() {
                a("html,body").stop().animate({
                    scrollTop: 0
                }, 300)
            })
        },
        menuSt: 0,
        resize: function() {
                e = a("div.page-home"),
                c = a("div#menubar");
            a(window).on("resize", function() {
                var g = c.css("left");
                if (h < 1320) {
                    f.attr("class", "page-w1320")
                } else {
                    if (h < 1560) {
                        f.attr("class", "page-w1560")
                    } else {
                        if (h > 1880) {
                            f.attr("class", "page-w1800 page-w1900")
                        } else {
                            if (h > 1760) {
                                f.attr("class", "page-w1800")
                            } else {
                                f.attr("class", "page-default")
                            }
                        }
                    }
                }
                if (h > 1850) {
                    c.addClass("menubar-big")
                } else {
                    if (h > 1680 && h < 1760) {
                        c.addClass("menubar-big")
                    } else {
                        c.removeClass("menubar-big")
                    }
                }
                if (e.children(".home-body-follow").size() > 0 || e.children(".home-body-zone").size() > 0 || e.children(".home-body-channel").size() > 0) {
                    e.css("padding-left", c.width() + "px")
                } else {
                    e.css("padding-left", 0)
                }
                clearTimeout(d.menuSt);
                d.menuSt = setTimeout(function() {
                    a("#menubar .menu-scroll").jsscroll_remake();
                    a(window).scroll()
                }, 300)
            });
            a(window).resize()
        },
        filterLives: {
            isFilterRich: 0,
            isFilterUser: 1,
            isGetInit: 0,
            getLoad: function() {
                }
            },
            getInit: function() {
                    a.getJSON("/api/index/getnew.php", {
                    }, function(d) {
                        c.isGetInit = 1;
                        if (d.flag == "001") {
                            c.parse(d.content)
                        } else {
                                c.isFilterRich = 1;
                            }
                        }
                    })
                } else {
                }
            },
            parse: function(c) {
            }
        },
        img_src_change: function() {
                return
            }
            var h = a("#headLines img[src2], div.body-main img[src2]");
            for (var f = 0; f < h.length; f++) {
                var e = h.eq(f),
                    d = h.eq(f)[0];
                        continue
                    }
                    e.on("load", function() {
                        a(this).css("opacity", 1)
                    });
                    d.removeAttribute("src2");
                    var g = e.attr("uid"),
                        c = e.parents("[data-tracing]").attr("data-tracing");
                    if (g && c) {
                    }
                }
            }
        }
    };
        HTML1: "",
        HTML2: "",
        getApi: "/liveAjax.html",
        listClass: {},
        cur: 0,
        $cells: 6,
        rankId: ["u7", "jc"],
        init: function() {
            var c = a("div#menubar");
            e.remove();
            var d = c.find("a[rela], dt[rela]").click(function(n) {
                n.preventDefault();
                var l = a(this),
                    r = l.attr("rela");
                d.removeClass("on");
                l.addClass("on");
                c.find("dl").removeClass("current");
                l.parents("dl").addClass("current");
                var j = g.btns.btn_home.find("em"),
                    m = j.html(),
                    k = a("div.home-focus-wrap");
                j.html("返回首页");
                    try {
                }
                switch (r) {
                    case "btn_home":
                        j.html("首页");
                        g.body.attr("class", "home-body home-body-main");
                        k.removeClass("home-focus-hide");
                        g.home.css("padding-left", 0);
                        a(window).scroll();
                        break;
                    case "btn_feed":
                            g.body.attr("class", "home-body home-body-feed");
                            k.addClass("home-focus-hide");
                            g.home.css("padding-left", 0);
                        } else {
                            j.html(m);
                        }
                        break;
                    case "btn_follow":
                            g.body.attr("class", "home-body home-body-follow");
                            k.addClass("home-focus-hide");
                            g.home.css("padding-left", c.width() + "px");
                            }
                        } else {
                            j.html(m);
                        }
                        break;
                    default:
                        k.addClass("home-focus-hide");
                            g.body.attr("class", "home-body home-body-channel");
                            g.home.css("padding-left", c.width() + "px");
                        } else {
                            g.body.attr("class", "home-body home-body-zone");
                            g.home.css("padding-left", c.width() + "px");
                            g.setList(r)
                        }
                }
                var o = a(document).scrollTop();
                if (o > 30) {
                    a("html,body").stop().animate({
                        scrollTop: 0
                    }, 300)
                }
            }).each(function() {
                var j = a(this),
                    k = j.attr("rela");
                g.btns[k] = j;
                g.listClass[k] = {
                    list: [],
                    nav: j.text(),
                    count: 0,
                    cls: k
                }
            });
                l.preventDefault();
                var j = a(this);
                var k = j.attr("rela");
                h.removeClass("on");
                j.addClass("on");
                g.setList(k, a.inArray(j.attr("rela"), g.rankId) > -1 ? false : true)
            }).each(function() {
                var j = a(this),
                    k = j.attr("rela");
                if (g.btns[k]) {
                    g.btns[k].push(j[0])
                } else {
                    g.btns[k] = j
                }
                if (!g.listClass[k]) {
                    g.listClass[k] = {
                        list: [],
                        nav: j.text(),
                        count: 0,
                        cls: k
                    }
                }
            });
                j.preventDefault();
                var k = a(this).attr("ord");
                g.listClass[g.cur].ord = k;
                g.setCurList(g.cur, "order")
            });
            }
            a("#family_star").find("a[rela]").each(function() {
                g.familyStar[a(this).attr("rela")] = 0
            });
                        if (j.flag) {
                                expires: 7,
                                path: "/"
                            });
                        }
                    })
                });
                c.find("dl.nav-feed, dl.nav-follow").css("display", "block")
            }
        },
        downFilter: function(e) {
            var d = 0,
                g = [],
            for (var c = 0; c < e.length; c++) {
                    g.push(e.splice(c, 1)[0]);
                    c--
                } else {
                    d++
                }
                if (d == 30) {
                    break
                }
            }
            return e.slice(0, 30).concat(g).concat(e.slice(30))
        },
        get_score: function() {
                return
            }
                }
            }
        },
        top_order: function(c) {
            return function(e, d) {
                switch (c) {
                    case "ord_random":
                        return [0, -1, 1][Number.random(0, 2)];
                    case "ord_moren":
                        if (e.score == d.score) {
                            return d.count / 1 - e.count / 1
                        } else {
                            return d.score - e.score
                        }
                        case "ord_renshu":
                            return d.count / 1 - e.count / 1;
                        case "ord_renqi":
                            return d.red - e.red;
                        case "ord_dengji":
                            return d.wealthrank - e.wealthrank;
                        case "ord_tim":
                            return d.realstarttime - e.realstarttime;
                        case "ord_weight":
                            return d.weight / 1 - e.weight / 1;
                        case "ord_allTopRec":
                            return e.allTopRecSort / 1 - d.allTopRecSort / 1;
                        case "ord_topRec":
                            return e.topRecSort / 1 - d.topRecSort / 1;
                        case "ord_event":
                            return d.eventSort / 1 - e.eventSort / 1;
                        case "ord_recSort":
                            return e.recSort / 1 - d.recSort / 1;
                        default:
                            return 0
                }
            }
        },
        set_order: function(m, f, g) {
            var f = f || "ord_moren",
                u = [],
                l = [],
                q = [],
                o = [];
                var v = a(this);
                if (v.attr("ord") == f) {
                    v.addClass("on")
                } else {
                    v.removeClass("on")
                }
            });
            for (var s = 0; s < m.length; s++) {
                if (m[s].honor.indexOf("10401") > -1) {
                    l.push(m[s])
                } else {
                    q.push(m[s])
                }
            }
            var n = [];
            if (h == "live_all" && f == "ord_moren") {
                n = q.splice(0, 10)
            }
            var j = ["u8", "fu1", "singer_all", "u2", "u3"];
            if (f == "ord_moren" && a.inArray(h, j) > -1) {
                f = "ord_weight"
            }
            if (f == "ord_moren" && g) {
            } else {
                if (h == "new") {
                } else {
                    if (f == "ord_moren" && q.length > 0) {
                        var c = ["S", "A", "B"],
                            t = [],
                            r = [];
                        a.each(q, function(w, v) {
                            if (a.inArray(v.rate, c) > -1) {
                                t.push(v)
                            } else {
                                r.push(v)
                            }
                        });
                        if (t.length > 5) {
                        }
                        q = t.concat(r)
                    }
                    if (n.length > 0) {
                        var k = function(y) {
                            var w = y.length;
                            var v;
                            var x;
                            while (w) {
                                x = Math.floor(Math.random() * w--);
                                v = y[w];
                            }
                            return y
                        };
                        n = n.concat(q.splice(0, (50 - n.length)));
                        k(n)
                    }
                }
            }
            }
            o = e.concat(d, u, l, n, q);
            return o
        },
        setList: function(g, d) {
            if (!d) {
            }
                c.removeClass("on").eq(0).addClass("on")
            }
                    e.setCurList(g)
                })
            } else {
                if (g == "pk") {
                } else {
                    } else {
                    }
                    } else {
                    }
                }
            }
            }
            return false
        },
        curList: [],
        setCurList: function(e, d) {
            if (e == "area") {
                }
                    return
                }
            } else {
            }
            } else {
                var c = e == "u7" ? true : false;
            }
            } else {
                } else {
                }
            }
            })
        },
        setLoading: function(c) {
        },
        defLoad: function(c) {
            if (d.length < 1) {
                    return
                }
            }
        },
        lt: 0,
        lazyLoad: function() {
                return
            }
                    if (!c.curList[c.$left]) {
                        if (c.cur == "area") {
                            c.setCurList("area")
                        } else {
                            c.setLoading(0);
                        }
                    } else {
                        c.visList(c.$left, c.$left + c.$cells * 3)
                    }
                }
            }, 50)
        },
        visList: function(m, c) {
                e = [];
            for (var j = m; j < c; j++) {
                var d = k[j];
                if (!d) {
                    break
                } else {
                }
            }
                if (!e.length || !k[c]) {
                }
            } else {
                if (!f[0]) {
                    var h = a('<ul class="mmlist-zone"></ul>');
                }
                var g = a(e.join(""));
                g.find(".img-box img").one("load", function() {
                    a(this).css("opacity", 1)
                });
                g.appendTo(f)
            }
        },
        getHtml: function(d) {
            var e = d.pic == "" ? "//vr0.xiu123.cn/imges/home2016/pic-default3.jpg" : d.pic;
                c = "";
            if (d.ut == 2) {
            } else {
                if (d.ut == 3) {} else {
                }
            }
            return c
        },
        getUserHtml: function(D, C) {
            var g = "";
            var v = D.pic == "" ? "//vr0.xiu123.cn/imges/home2016/pic-default3.jpg" : D.pic;
            var o = [],
                w = D.honor ? D.honor.split(",") : [];
            if (d) {
                var s = f.honor[d];
                if (s) {
                    o.push('<i title="' + s.title + '" class="' + s.cls + '"></i>')
                }
            } else {
                a.each(w, function(E, F) {
                    var F = f.honorConfig[F];
                    if (F) {
                        o.push('<i title="' + F.showMsg + '" class="ico-' + F.id + '" style="background:url(' + F.pic + ') no-repeat 0 0;"><b>' + F.title + "</b></i>")
                    }
                })
            }
            var j = "",
                u = "",
                h = "";
            if (D.eid > 0) {
                j = "e" + D.eid + "-recomm";
                h = '<div class="eids-dress e' + D.eid + '-dress"><b class="bgl"></b><b class="bgt"></b><b class="bgr"></b><b class="bgb"></b><i class="e-i1"></i><i class="e-i2"></i></div>';
                if (D.eid == "test") {
                    h += '<div class="test">这是测试，根据eid增加html结构</div>'
                } else {
                    if (D.eid == 20003) {
                        j = "birthday-cele"
                    } else {
                        if (D.eid == 20004) {
                            j = "year-cele"
                        } else {
                            if (D.eid == 20007) {
                                j = "score-exchange"
                            }
                        }
                    }
                }
            } else {
                if (D.topRecomm) {
                    j = "top-recomm";
                    if (D.fname) {
                        o.push('<i class="i-family-recom" title="' + D.fname + '家族"><b>' + D.fname + "</b></i>")
                    }
                    u = '<div class="dress-bg"><b class="bgl"></b><b class="bgt"></b><b class="bgr"></b><b class="bgb"></b></div>'
                } else {
                    if (D.eventRec) {}
                }
            }
            var c = "";
            if (D.tagids) {
                var r = f.cur != "u3";
                var e = f.cur.indexOf("tag") > -1;
            }
            var x = "",
                B = c != "" ? "live-title-bt" : "";
            if (D.livetitle) {
                x = '<span class="live-title ' + B + '">' + D.livetitle + "</span>"
            }
            var l = '<span class="icon-tags">' + c + "</span>";
            var m = o.length > 0 ? '<span class="icons">' + o.join("") + "</span>" : "";
            var k = "";
            if (D.isHotDance == 1) {
                k = '<i class="ico-hotdance">热舞中</i>'
            } else {
                if (D.isHotDance == 2) {
                    k = '<i class="ico-hotsing">嗨唱中</i>'
                } else {
                    if (parseInt(D.recordtype) > 1) {
                        k = '<i class="ico-mobile"></i>'
                    }
                }
            }
            m = x + m + k + l;
            var y = "";
            if (D.rtype == "u8") {
                var A = f.roomSeatList[D.uid];
                if (A) {
                    y = '<div class="vnaming" title="冠名位"><img src="' + A.picuser + '"/><span class="vn-bg"></span><span class="vn-user">' + A.alias + "</span></div>"
                }
            }
            var n = "",
                z, t;
                if (parseInt(D.recordtype) > 1) {
                    t = "http://v.6.cn/admin/anchorScoreNewList.php?act=look&ispc=0&tuid=" + D.uid
                } else {
                    t = "http://v.6.cn/admin/anchorScoreNewList.php?act=look&ispc=1&tuid=" + D.uid
                }
                z = D.recscore ? " score-on" : "";
                n = '<div class="score' + z + '"><span>' + D.score + '</span><a href="' + t + '" target="_blank">评分</a> | <span title="评级">' + D.rate + '</span> | <span title="权重">' + D.weight + '</span> | <span title="签约时间">' + D.tm + "</span></div>"
            }
            var q = "//v.6.cn/" + (D.rid > 930000000 ? "g/" + D.rid : +D.rid);
            return g
        },
        isLoadData: 0,
        loadData: function() {
                return
            }
                c.topRecomm.update(d.songRecomment, "singer_all");
                c.topRecomm.update(d.danceRecomment, "fu1");
                c.topRecomm.update(d.mcRecomment, "u2");
                c.topRecomm.update(d.chatRecomment, "u3");
                c.topRecomm.update(d.voiceRecomment, "u8");
                c.roomSeatList = d.roomSeatList || {};
                c.parseList({
                    list: d.roomList,
                    count: d.roomListNumAry,
                    fiveFamily: d.fiveFamily,
                    provinceNum: d.provinceNum
                }, 1);
                c.downFilterUids = d.downFilterUids;
                c.honorConfig = d.honorConfig;
                c.radioBanner = d.radioBanner;
                c.isLoadData = 1;
                if (c.btns[e]) {
                    c.btns[e].click();
                    setTimeout(function() {
                        a(window).resize();
                        if (e != "btn_home") {
                        }
                    }, 2000)
                } else {
                    if (e == "luck") {
                    }
                }
                c.autoGet();
                    } else {
                    }
                }
            })
        },
        parseList: function(o, l) {
                g = o.list,
                r = o.count,
                c = [],
                t = [];
            if (o.fiveFamily) {}
                    continue
                }
                    list: [],
                    count: 0,
                    cls: h
                }
            }
                if (!s.listClass["tag" + k]) {
                    s.listClass["tag" + k] = {}
                }
                s.listClass["tag" + k].nav = e.name;
                s.listClass["tag" + k].list = []
            });
            a.each(["r1", "r2", "r4", "r5", "r10"], function(e, k) {
                if (!s.listClass[k]) {
                    s.listClass[k] = {
                        count: 0,
                        cls: k
                    }
                }
                s.listClass[k].list = []
            });
                top: [],
                list: []
            };
            for (var j = 0; j < g.length; j++) {
                var n = g[j];
                if (n.ut == 3) {
                    continue
                }
                    continue
                }
                if (!parseInt(n.score)) {
                    n.score = 0
                }
                if (n.honor && n.honor.indexOf("10501") > -1) {
                    c.push(n)
                } else {
                    if (n.allTopRec) {
                        t.push(n)
                    } else {
                            if (n.isvideo / 1) {
                                if (n.rtype != "other") {
                                }
                                continue
                            }
                            if (a.inArray(n.rtype, ["u2", "u3", "u7", "u8", "fu1", "jc", "f1001", "other", "zy"]) > -1) {
                                    if (a.inArray(n.uid, m.uids) < 0) {
                                    }
                                } else {
                                }
                            }
                            if (a.inArray(n.rtype, ["r1", "r2", "r4", "r5", "r10"]) > -1) {
                                if (a.inArray(n.uid, m.uids) < 0) {
                                }
                            }
                            u.honor = u.honor.replace("10401", "").replace("10501", "");
                            }
                                if (a.inArray(u.rate, ["S", "A", "B"]) > -1) {
                                }
                            }
                            if (u.tagids) {
                                    if (!s.listClass["tag" + e]) {
                                        return true
                                    }
                                    s.listClass["tag" + e].list.push(u)
                                })
                            }
                        }
                    }
                }
                u.honor = u.honor.replace("10401", "");
                }
                }
                }
            }
            r.singer_all = r.song;
            r.singer = r.sountTop5;
            r.other = r.other;
            r.changzhan = r.tal;
            r.mobile_live = r.mobileLive;
            r.male_area = r.man;
            var f = 0;
            var d = a("#menubar").find("dl.nav-tags");
                if (!s.btns["tag" + k]) {
                    return true
                }
                if (s.listClass["tag" + k].list.length > 0) {
                    s.btns["tag" + k].css("display", "inline-block");
                    f = 1
                } else {
                    s.btns["tag" + k].css("display", "none")
                }
            });
            f ? d.css("display", "block") : d.css("display", "none");
                if (q && q[0]) {
                    q.html(r[h])
                }
            }
        },
        toZhangZhi: {
            recid: "",
            uidList: [],
            setRecid: function() {
            },
            showList: function() {
                }
            },
            lazyList: [],
            lazyTrace: false,
            lazyT: 0,
            recodeLazy: function(c, e) {
                    }
                }
                    d.submit(d.lazyList, d.lazyTrace, ZHANG_ZHI_RECID);
                    d.lazyList = [];
                    d.lazyTrace = false
                }, 200)
            },
            submit: function(e, f, d) {
                var c = {
                    func: "live",
                    recid: d || "",
                    ridlist: e.join("|")
                };
                toZhangZhi("showlist", f, c)
            }
        },
        honor: {
            10101: {
                title: "唱战2017",
                cls: "icoChangzhan"
            },
            10201: {
                title: "放声SHOW唱",
                cls: "ico1"
            },
            10202: {
                title: "放声SHOW唱",
                cls: "ico3"
            },
            10203: {
                title: "SHOW唱",
                cls: "icoShow"
            },
            10301: {
                title: "MC金牌",
                cls: "icoMcChampion"
            },
            10601: {
                title: "舞秀",
                cls: "ico1"
            },
            10602: {
                title: "舞秀",
                cls: "ico3"
            },
            10701: {
                title: "娱乐之星",
                cls: "icoAmuse"
            },
            10801: {
                title: "舞区金牌",
                cls: "icoDanceAreaGold"
            },
            11101: {
                title: "新主播pk赛",
                cls: "icoNewbiePk"
            },
            11201: {
                title: "排位赛",
                cls: "icoRankGame"
            },
            11301: {
                title: "魅力热舞",
                cls: "icoCharmDance"
            },
            11401: {
                title: "活力热舞",
                cls: "icoVitalityDance"
            },
            11601: {
                title: "王牌",
                cls: "icoTrump"
            },
            11701: {
                title: "火热",
                cls: "icoFiery"
            },
            11801: {
                title: "超星",
                cls: "icoSuperstar"
            },
            15001: {
                title: "网络大过年",
                cls: "icoYear2018"
            },
            12001: {
                title: "年度人气冠军",
                cls: "ico-12001"
            },
            12002: {
                title: "年度人气亚军",
                cls: "ico-12002"
            },
            12003: {
                title: "年度人气季军",
                cls: "ico-12003"
            },
            12004: {
                title: "年度人气第四名",
                cls: "ico-12004"
            },
            12005: {
                title: "年度人气第五名",
                cls: "ico-12005"
            },
            12006: {
                title: "年度人气第六名",
                cls: "ico-12006"
            },
            12007: {
                title: "年度人气第七名",
                cls: "ico-12007"
            },
            12008: {
                title: "年度人气第八名",
                cls: "ico-12008"
            },
            12009: {
                title: "年度人气第九名",
                cls: "ico-12009"
            },
            12010: {
                title: "年度人气第十名",
                cls: "ico-12010"
            },
            13001: {
                title: "年度唱将冠军",
                cls: "ico-13001"
            },
            13002: {
                title: "年度唱将亚军",
                cls: "ico-13002"
            },
            13003: {
                title: "年度唱将季军",
                cls: "ico-13003"
            },
            13004: {
                title: "年度唱将第四名",
                cls: "ico-13004"
            },
            13005: {
                title: "年度唱将第五名",
                cls: "ico-13005"
            },
            13006: {
                title: "年度唱将第六名",
                cls: "ico-13006"
            },
            13007: {
                title: "年度唱将第七名",
                cls: "ico-13007"
            },
            13008: {
                title: "年度唱将第八名",
                cls: "ico-13008"
            },
            13009: {
                title: "年度唱将第九名",
                cls: "ico-13009"
            },
            13010: {
                title: "年度唱将第十名",
                cls: "ico-13010"
            },
            14001: {
                title: "年度新秀冠军",
                cls: "ico-14001"
            },
            14002: {
                title: "年度新秀亚军",
                cls: "ico-14002"
            },
            14003: {
                title: "年度新秀季军",
                cls: "ico-14003"
            },
            14004: {
                title: "年度新秀第四名",
                cls: "ico-14004"
            },
            14005: {
                title: "年度新秀第五名",
                cls: "ico-14005"
            },
            14006: {
                title: "年度新秀第六名",
                cls: "ico-14006"
            },
            14007: {
                title: "年度新秀第七名",
                cls: "ico-14007"
            },
            14008: {
                title: "年度新秀第八名",
                cls: "ico-14008"
            },
            14009: {
                title: "年度新秀第九名",
                cls: "ico-14009"
            },
            14010: {
                title: "年度新秀第十名",
                cls: "ico-14010"
            },
            16001: {
                title: "季度赛人气冠军",
                cls: "ico-16001"
            },
            16002: {
                title: "季度赛人气亚军",
                cls: "ico-16002"
            },
            16003: {
                title: "季度赛人气季军",
                cls: "ico-16003"
            },
            17001: {
                title: "季度赛唱将冠军",
                cls: "ico-17001"
            },
            17002: {
                title: "季度赛唱将亚军",
                cls: "ico-17002"
            },
            17003: {
                title: "季度赛唱将季军",
                cls: "ico-17003"
            },
            18001: {
                title: "季度赛新秀冠军",
                cls: "ico-18001"
            },
            18002: {
                title: "季度赛新秀亚军",
                cls: "ico-18002"
            },
            18003: {
                title: "季度赛新秀季军",
                cls: "ico-18003"
            },
            19001: {
                title: "年中超级赛区冠军",
                cls: "ico-19001"
            },
            19002: {
                title: "年中超级赛区亚军",
                cls: "ico-19002"
            },
            19003: {
                title: "年中超级赛区季军",
                cls: "ico-19003"
            },
            19004: {
                title: "年中超级赛区第四名",
                cls: "ico-19004"
            },
            19005: {
                title: "年中超级赛区第五名",
                cls: "ico-19005"
            },
            19006: {
                title: "年中超级赛区第六名",
                cls: "ico-19006"
            },
            19007: {
                title: "年中超级赛区第七名",
                cls: "ico-19007"
            },
            19008: {
                title: "年中超级赛区第八名",
                cls: "ico-19008"
            },
            19009: {
                title: "年中超级赛区第九名",
                cls: "ico-19009"
            },
            19010: {
                title: "年中超级赛区第十名",
                cls: "ico-19010"
            },
            30001: {
                title: "年中新星赛区冠军",
                cls: "ico-30001"
            },
            30002: {
                title: "年中新星赛区亚军",
                cls: "ico-30002"
            },
            30003: {
                title: "年中新星赛区季军",
                cls: "ico-30003"
            },
            30004: {
                title: "年中新星赛区第四名",
                cls: "ico-30004"
            },
            30005: {
                title: "年中新星赛区第五名",
                cls: "ico-30005"
            },
            30006: {
                title: "年中新星赛区第六名",
                cls: "ico-30006"
            },
            30007: {
                title: "年中新星赛区第七名",
                cls: "ico-30007"
            },
            30008: {
                title: "年中新星赛区第八名",
                cls: "ico-30008"
            },
            30009: {
                title: "年中新星赛区第九名",
                cls: "ico-30009"
            },
            30010: {
                title: "年中新星赛区第十名",
                cls: "ico-30010"
            }
        },
        t: 0,
        expiration: 60 * 1000 * 3,
        autoGet: function() {
        },
        getList: function() {
        },
        getCallback: function(c) {
                list: c.roomList,
                provinceNum: c.provinceNum,
                count: c.roomListNumAry,
                fiveFamily: c.fiveFamily
            });
            } else {
            }
        },
        topRecomm: {
            ids: ["singer_all", "fu1", "u2", "u3", "u8"],
            init: function() {
                a.each(c.ids, function(d, e) {
                    c[e] = {
                        list: [],
                        uids: [],
                    }
                })
            },
            update: function(d, e) {
                }
                a.each(d, function(f, g) {
                    if (e != "u8") {
                    }
                    c[e].uids.push(g.uid)
                })
            }
        },
        zoneBanner: {
            update: function() {
                }
                    d = [];
                switch (c.cur) {
                    case "u8":
                        d = c.radioBanner;
                        break;
                    default:
                        d = null;
                        break
                }
                if (!d || d.length < 1) {
                    return
                }
                        delay: 5
                    })
                } else {
                }
            },
            visible: function(d) {
                if (d == 1) {
                    c.bodyZone.addClass("body-zone-banner")
                } else {
                    c.bodyZone.removeClass("body-zone-banner")
                }
            },
            setHtml: function(d) {
                var c = [];
                a.each(d, function(f, g) {
                    c.push('<a href="' + g.url + '" target="_blank" style="background-image:url(' + g.img + ");" + (f == 0 ? "display:block" : "") + '"></a>')
                });
            }
        },
        familyStar: {},
        getFamilyStar: function(c, d) {
            if (e < 1 || (new Date()).getTime() - e > 180 * 1000) {
                a.getJSON("family/getFamilyLive.php?id=" + c.replace("f", ""), function(g) {
                    if (g.flag == "001") {
                        f.familyStar[c] = (new Date()).getTime();
                        f.listClass[c].list = g.content
                    } else {
                        f.listClass[c].list = []
                    }
                    d(c)
                })
            } else {
                d(c)
            }
        },
        newArea: {
            cityList: {},
            cacheCount: {},
            defaultCity: 1,
            curCity: null,
            curOrder: "ord_moren",
            curCityList: [],
            init: function() {
                    var d = a(this);
                    var g = d.attr("rela");
                    var f = d.parents("li");
                    c.cityList[g] = {};
                    c.cityList[g].ele = a(this);
                    c.cityList[g].count = 0;
                    c.cityList[g].name = d.text().replace(/\(.*\)/, "");
                    c.cityList[g].area = f.attr("class");
                    c.cityList[g].areaName = f.find("h5").text()
                });
                    f.preventDefault();
                    var d = a(this);
                    if (d.hasClass("close")) {
                        c.setPop(0)
                    } else {
                        c.setList(d.attr("rela"));
                        c.setPop(0)
                    }
                });
                    c.setPop(!c._vis)
                });
                    g.preventDefault();
                    var d = a(this);
                    var f = d.attr("ord");
                    d.siblings().removeClass("on");
                    d.addClass("on");
                    c.curOrder = f;
                    c.setList(c.curCity)
                });
                a.getJSON("/api/index/getlocaiton.php").done(function(d) {
                    if (d.flag == "001") {
                        c.setList(d.content.pid)
                    } else {
                        c.setList(c.defaultCity)
                    }
                })
            },
            getCityList: function(e) {
                var d = [];
                    if (g.area == c) {
                        d[f == e ? "unshift" : "push"](f)
                    }
                });
                return d
            },
            getNextCity: function() {
                    return false
                }
            },
            getNextCityList: function() {
            },
            getList: function(e) {
                var d = [];
                    if (g.province / 1 == e / 1 && !g.isvideo / 1) {
                        d.push(g)
                    }
                });
                return d.sort(c)
            },
            setCount: function(d) {
                }
                    if (e) {
                        e.count = d[f];
                        e.ele.find("span").html("(" + (d[f] || 0) + ")")
                    }
                }
            },
            setPop: function(c) {
            },
            setList: function(d) {
                if (c) {
                    c.ele.addClass("on");
                }
            },
            setListHtml: function(d) {
                    return
                }
                if (!e[0]) {
                    var c = d.length ? d.join("") : '<div style="padding:20px;">暂无直播！</div>';
                } else {
                    e.find(".mmlist-zone").append(d.join(""))
                }
                e.find(".img-box img").on("load", function() {
                    a(this).css("opacity", 1)
                })
            }
        },
        rank: {
            area: 0,
            sHTML1: "",
            sHTML2: "",
            rHTML1: "",
            rHTML2: "",
            init: function(f) {
                    e = a("#rank_box"),
                    d = e.find("div.rank-gift .zone-top li"),
                    c = e.find("div.rank-rich .zone-top li");
                a.getJSON("/top/getSubareaTop.php", function(h) {
                    if (h) {
                        g.data = h;
                        g.set(f)
                    }
                })
            },
            append_event: function(c, d) {
                d.bind("click", function(f) {
                    var g = a(this);
                    f.preventDefault();
                    d.removeClass("on");
                    g.addClass("on");
                    g.parents(".zone-top-tab").find(".line-on").animate({
                        width: g.width(),
                        left: g.position().left
                    }, 200);
                    e.vis(c, g.attr("rela"))
                })
            },
            set: function(c) {
                    singer_all: 0,
                    fu1: 1,
                    u2: 2,
                    u3: 3,
                    u7: 7,
                    u8: 8,
                    jc: 21
                } [c];
                    return
                }
                if (c == "jc") {
                }
            },
            vis: function(c, j) {
                    return
                }
                    e = {
                        star: "gift",
                        rich: "custom"
                    } [c];
                    d = c == "star" ? "sHTML" : "rHTML",
                    f = [];
                a.each(g, function(k, m) {
                    var l;
                    if (!k) {
                        l = h[d + "1"]
                    } else {
                        l = h[d + "2"]
                    }
                    f.push('<li class="r' + (k + 1) + '">' + l.replace("{rank}", k + 1).replace(/\{rid\}/g, m.rid).replace(/\{uid\}/g, m.uid).replace("{pic}", m.picuser).replace("{alias}", m.alias).replace("{rich}", m.coin6rank).replace("{star}", m.wealthrank) + "</li>")
                });
            }
        },
        pk: {
            _data: {},
            _conf: {
                get: {
                    tpl: "#pk_get2_tpl",
                    content: ".list_pk .pk-zlist-2",
                    target: "ul.mmlist-zone",
                    api: "/room/pk/pkindex.php",
                    params: {
                        act: "get"
                    }
                },
                get3: {
                    tpl: "#pk_get3_tpl",
                    content: ".list_pk .pk-zlist-3",
                    target: "ul.mmlist-zone"
                }
            },
            init: function() {
                    c.preventDefault();
                    jQuery(this)[c.type == "mouseenter" ? "addClass" : "removeClass"]("help-on")
                });
                setInterval(function() {
                    }
                }, 2 * 60 * 1000);
                })
            },
            bindEvent: function(e, d) {
                e.on("click", function(g) {
                    g.preventDefault();
                    var f = jQuery(this);
                    if (f.hasClass("on")) {
                        return
                    }
                    e.removeClass("on");
                    f.addClass("on");
                    if (d == "week") {
                        c._conf.rank.week = f.attr("week");
                        c.getList(c.getCurrentBtn("rank"))
                    } else {
                        c._conf[d].type = f.attr("type");
                        f.parents(".zone-top-tab").find(".line-on").animate({
                            width: f.width(),
                            left: f.position().left
                        }, 200);
                        c.getList(f)
                    }
                })
            },
            getCurrentBtn: function(c) {
                var d;
                switch (c) {
                    case "get":
                        d = jQuery("#menubar .nav-menu .list a[rela=pk]");
                        break;
                    case "best":
                        break;
                    case "rank":
                        break
                }
                return d
            },
            getCurrentData: function(c) {
                }
                if (c) {
                } else {
                        if (d == "get3") {
                            return true
                        }
                    })
                }
            },
            getList: function(f) {
                var e = f.attr("act");
                var d = Number(f.attr("expires"));
                var j = Number(f.attr("lasttm")) || 0;
                    if (e == "get") {
                    }
                } else {
                    var h = {};
                    if (e == "best" || e == "rank") {
                        if (e == "rank") {
                        }
                    }
                }
            },
            getData: function(c, j, h) {
                var f = e.api;
                var g = jQuery(e.content);
                    act: c,
                    t: +new Date
                }, j || {});
                g.empty();
                var k = setTimeout(function() {
                    g.html('<div class="loading">加载中…</div>')
                }, 500);
                var d = function(n) {
                    k && clearTimeout(k);
                    if (n.flag == "001") {
                        var m = [];
                            m.push(o)
                        });
                        if (c == "get") {
                            var l = [];
                                l.push(o)
                            });
                        }
                    }
                };
                if (h) {
                    d(h)
                } else {
                    if (c == "get3") {} else {
                    }
                }
            },
            setHtml: function(m, e) {
                var g = l.tpl;
                var k = jQuery(l.content);
                var j = l.target;
                var o = [];
                    var u = (s.uid || s.assistsuid) >= 1900000000;
                    if (m == "rank") {
                    }
                        no: t + 1
                    });
                    o[(s.honor && s.honor.indexOf(10401) > -1) ? "unshift" : "push"](r._parseData(g, s))
                });
                if (o.length > 0) {
                    if (m == "get3") {
                        k.css("display", "block")
                    }
                    var h = k.find(j);
                    if (!h[0]) {
                        var f = j.split(/\.|#/);
                        var d = f[0];
                        var q = f[1] || "";
                        var n = "<" + d + ' class="' + q + '"/>';
                        k.empty();
                        if (m == "get3") {
                            jQuery('<div class="pk-title">三人PK</div>').appendTo(k)
                        } else {
                            if (m == "get") {
                                jQuery('<div class="pk-title">PK</div>').appendTo(k)
                            }
                        }
                        h = jQuery(n).appendTo(k)
                    }
                    h.html(o.join(""));
                } else {
                    if (m == "get3") {
                        k.css("display", "none")
                    } else {
                        k.html('<p class="no-data">暂无' + c.text() + "</p>")
                    }
                }
            },
            _cacheData: function(c, h) {
                }
                var d = !!(typeof h == "object" && h != null);
                if (e.week) {
                    var g = e.week == 1 ? "now" : "last";
                    var j = e.type == 1 ? "rich" : "anchor";
                    if (d) {
                    } else {
                    }
                } else {
                    if (e.type) {
                        var f = {
                            1: "day",
                            2: "week",
                            3: "month"
                        } [e.type];
                        if (d) {
                        } else {
                        }
                    } else {
                        if (d) {
                        } else {
                        }
                    }
                }
                return h
            },
            _setCacheDate: function(c) {
                if (d.attr("expires")) {
                    d.attr("lasttm", +new Date)
                }
            },
            _checkExpires: function(f, c) {
                var e = +new Date;
                var d = c * 1000;
                return e - f > d
            },
            _bianping: function(e) {
                var c = {};
                var d = function(f, g) {
                        if (typeof j == "object" && j != null) {
                            d(j, "_" + h)
                        } else {
                            c[h + (g || "")] = j
                        }
                    })
                };
                d(e);
                return c
            },
            _parseData: function(c, d) {
                var c = jQuery(c);
                if (!c[0] || !d) {
                    return
                }
                var e = c.html();
                    var h = new RegExp("{" + g + "}", "g");
                    if (!!e.match(h)) {
                        e = e.replace(h, f)
                    }
                });
                return e
            },
            _lazyloadImage: function() {
                    var f = jQuery(".list_pk img[data-src]");
                    for (var d = 0; d < f.length; d++) {
                        var c = f.eq(d);
                            var e = c.attr("data-src");
                            if (!e) {
                                continue
                            }
                            c.on("load", function() {
                                a(this).css("opacity", 1)
                            });
                            c.attr("src", e).removeAttr("data-src")
                        }
                    }
                }
            }
        }
    };
    var b = function(c, e, d) {
    };
        loadFlash: function() {
            d.html('<div id="' + j + '"></div>');
            var h = {
                mode: "homepage",
                fristPlayerType: "h5",
                videoId: j,
                ruid: f.uid,
                fileName: f.flvtitle,
                mute: 1,
                hideControlBar: 1,
                isPhoneLive: f.recordtype > 1 ? 1 : 0,
                bg: f.pic || "",
                toRoomUrl: f.link || "",
                readyFun: g,
                stopFun: c,
                tracing: f.tracing || "",
                chID: 0,
                swfData: {
                    allowscriptaccess: "always",
                    wmode: "opaque",
                    bgcolor: "#333333"
                }
            };
                e._playerLoader.loadPlayer()
            })
        },
        getSwf: function() {
            if (c && c.JsStartLive && c.videoPause && c.setEnterRoomURL) {
                return c
            }
            return null
        },
        ready: function() {
            }
        },
        start: function() {
            } else {
                    isphoneLive: c.recordtype > 1 ? 1 : 0,
                    bgUrl: c.pic || ""
                });
            }
        },
        pause: function() {
            }
        },
        stop: function() {
            try {
                c.pause();
                c._playerLoader.remove();
                c._playerLoader = null;
                c._player = null;
        }
    });
        area: {
            singer_all: 0,
            fu1: 1,
            u2: 2,
            u3: 3
        },
        getApi: "/subareaIndex/getSubareaIndexNew.php",
        cur: null,
        curName: "",
        btns: {},
        listClass: {},
        init: function() {
                return
            }
            var c = a("div#menubar");
                d.btns[f] = c.find('a[rela="' + f + '"]');
                d.listClass[f] = {
                    list: [],
                    nav: d.btns[f].text(),
                    lasttm: 0
                }
            })
        },
        setList: function(d) {
            }
                return
            }
            } else {
            }
        },
        update: function() {
            setTimeout(function() {
                c.zoneList.setList(c.cur);
                c.hotRank.getList()
            }, 300)
        },
        getData: function(e) {
            }, function(g) {
                if (g.flag == "001") {
                    var f = g.content,
                        h = c.listClass[e];
                    h.lasttm = +new Date;
                    c.overTime(f.second / 1);
                    h.subareaIndexBanner = f.subareaIndexBanner;
                    h.bigLiveList = f.bigLiveList;
                    h.videoList = f.videoList;
                    h.list = f.liveList;
                    d.downFilterUids = f.downFilterUids;
                    d.honorConfig = f.honorConfig;
                        c.update()
                    }
                    c.startAutoRefresh(e, function() {
                        return c.cur == "fu1"
                    })
                }
            })
        },
        stopAutoRefresh: function() {
        },
        startAutoRefresh: function(e, d) {
            c.stopAutoRefresh();
            c._atm = setTimeout(function() {
                    c.getData(e)
                }
            }, 3 * 60 * 1000)
        },
        overTime: function(d) {
            if (d < 0) {
                    c.listClass[f].lasttm = 0
                });
                return
            }
                c.overTime(d - 5)
            }, 5 * 1000)
        },
        checkExpires: function(e, c) {
            var d = +new Date;
            return d - e > c
        },
        setLoading: function(c) {
        },
        zoneList: {
            cur: null,
            curTag: null,
            _tracing: "",
            tagList: {},
            $cells: 5,
            $left: 0,
            init: function() {
                    return
                }
                    f.preventDefault();
                    var g = a(this).attr("ord");
                    c.tagList[c.cur].ord = g;
                    c.setCurList(c.curTag)
                });
                a.each(d.ids, function(f, g) {
                    c.tagList[g] = {
                        ord: "ord_weight",
                        tagid: []
                    }
                });
                    h.preventDefault();
                    var f = a(this);
                    var g = f.attr("rela");
                    e.removeClass("on");
                    f.addClass("on");
                    c._tracing = f.attr("data-tracing");
                    c.box.attr("data-tracing", c._tracing);
                    c.moreBox.attr("data-tracing", c._tracing + "_more");
                    c.setCurList(g)
                }).each(function() {
                    var f = a(this),
                        g = f.attr("rela");
                        return true
                    }
                    }
                })
            },
            setList: function(k) {
                }
                    j = f.listClass[k],
                    g = d.tagList[k];
                a.each(g.tagid, function(l, m) {
                    g["tag" + m].list = []
                });
                a.each(j.list, function(m, l) {
                    a.each(l.tagids.split(","), function(n, o) {
                        if (a.inArray(o / 1, g.tagid) > -1) {
                            g["tag" + o].list.push(l)
                        }
                    })
                });
                    h = k
                }
                g[h].btn.addClass("on").siblings("a").removeClass("on");
                g[k].list = j.list;
                d._tracing = g[h].btn.attr("data-tracing");
                d.box.attr("data-tracing", d._tracing);
                d.moreBox.attr("data-tracing", d._tracing + "_more");
                var e = 0,
                    c = g[h].btn.parents(".tagtab-base");
                a.each(g.tagid, function(l, m) {
                    var n = g["tag" + m];
                    if (n.list.length > 0) {
                        e = 1;
                        n.btn.css("display", "inline-block")
                    } else {
                        n.btn.css("display", "none")
                    }
                });
                c.siblings(".tagtab-base").hide();
                if (e) {
                    c.show()
                } else {
                    c.hide()
                }
            },
            setCurList: function(d) {
                    h = f[d];
                if (g.hasClass("page-w1320") || g.hasClass("page-w1560")) {
                } else {
                }
            },
            defLoad: function() {
                c.mvideo.reset();
                if (d.length < 1) {
                    c.setLoading(0);
                    c.mvideo.setList();
                    return
                }
                c.setLoading(1);
                    c.mvideo.setList()
                }
                })
            },
            lt: null,
            lazyLoad: function() {
                    return
                }
                        d.mvideo.setList();
                        if (!c.curList[c.$left]) {
                            d.setLoading(0);
                        } else {
                            c.visList(c.$left, c.$left + c.$cells * 3)
                        }
                    }
                }, 50)
            },
            hotDance: {
                ids: ["singer_all", "fu1"],
                videos: {},
                list: [],
                setUser: function(c) {
                    if (c.isRecHotDance && c.flvtitle) {
                    }
                },
                load: function() {
                        if (!c.videos[d.uid]) {
                            f.prepend('<div class="hot-video-box"></div>');
                            c.videos[d.uid] = new b(f.find(".hot-video-box"), d);
                            c.videos[d.uid].start()
                        }
                    })
                },
                execute: function(c) {
                        if (typeof d[c] == "function") {
                            d[c]()
                        }
                    })
                },
                reset: function() {
                }
            },
            visList: function(q, c) {
                o.toZhangZhi.setRecid();
                    f = [];
                for (var j = q; j < c; j++) {
                    var e = m[j];
                    if (!e) {
                        l.setLoading(0);
                        break
                    } else {
                        if (a.inArray(l.cur, n.hotDance.ids) > -1) {
                            n.hotDance.setUser(e)
                        }
                    }
                }
                }
                var g = d.find("ul.mmlist-zone");
                if (!g[0]) {
                    var h = a('<ul class="mmlist-zone"></ul>');
                    g = h.appendTo(d)
                }
                var k = a(f.join(""));
                k.find(".img-box img").one("load", function() {
                    a(this).css("opacity", 1)
                });
                k.appendTo(g);
                if (a.inArray(l.cur, n.hotDance.ids) > -1) {
                    n.hotDance.load()
                }
                o.toZhangZhi.showList()
            },
            setOrder: function(h, g) {
                var g = g || "ord_weight",
                    d = [],
                    l = [],
                    c = [],
                    m = [],
                    e = [],
                    f = [],
                    j = [],
                    k = [];
                    var n = a(this);
                    if (n.attr("ord") == g) {
                        n.addClass("on")
                    } else {
                        n.removeClass("on")
                    }
                });
                a.each(h, function(o, n) {
                    if (n.honor.indexOf("10501") > -1) {
                        d.push(n)
                    } else {
                        if (n.allTopRec) {
                            l.push(n)
                        } else {
                            if (n.topRecomm) {
                                c.push(n)
                            } else {
                                if (n.eventRec) {
                                    m.push(n)
                                } else {
                                    if (n.honor.indexOf("10401") > -1) {
                                        e.push(n)
                                    } else {
                                        if (n.isRec) {
                                            f.push(n)
                                        } else {
                                            j.push(n)
                                        }
                                    }
                                }
                            }
                        }
                    }
                });
                k = d.concat(l, c, m, e, f, j);
                return k
            }
        },
        mvideo: {
            reset: function() {
                }
            },
            init: function() {
                    return
                }
                    f.preventDefault();
                    var d = jQuery(this);
                    var g = 3 * 1000;
                    if (d.hasClass("disabled")) {
                        return
                    }
                    d.addClass("disabled");
                    c.getList();
                    clearTimeout(c._tm);
                    c._tm = setTimeout(function() {
                        d.removeClass("disabled")
                    }, g)
                })
            },
            getList: function() {
                    subarea: d.area[d.cur],
                    t: +new Date
                }).done(function(e) {
                    if (e.flag == "001") {
                        var f = e.content.videoList;
                        d.listClass[d.cur].videoList = f;
                        c.parseData(f)
                    }
                })
            },
            setList: function() {
                }
                    return
                }
                    e = d.listClass[d.cur];
                if (a.inArray(d.cur, ["singer_all", "fu1"]) > -1) {
                } else {
                    return
                }
            },
            parseData: function(e) {
                    d = [];
                a.each(e, function(f, g) {
                    d.push(c.tpl.replace("{vid}", g.vid).replace("{index}", f).replace("{bigpicurl}", g.bigpicurl).replace("{title}", g.title).replace("{alias}", g.alias).replace("{picuser}", g.picuser).replace("{vnum}", numF(g.vnum)))
                });
                    a(this).css("opacity", 1)
                })
            }
        },
        video: {
            init: function() {
                    if (a(this).attr("target")) {
                        c.pause()
                    }
                })
            },
            update: function(c) {
                }
            },
            parseData: function(f) {
                    d = a('<ul class="list"></ul>'),
                    e = [];
                a.each(f, function(h, g) {
                    j.data("user", g);
                    j.appendTo(d);
                    e.push(g.uid)
                });
                    a(this).css("opacity", 1)
                });
            },
            play: function(c) {
                        isphoneLive: c.recordtype > 1 ? 1 : 0,
                        bgUrl: c.pic.replace("_s", "_b")
                    });
                } else {
                }
            },
            pause: function() {
                try {
                    }
            },
            next: function() {
                    e = d.next("li"),
                if (e[0]) {
                    e.click()
                } else {
                    c.click()
                }
            },
            writeSwf: function(d) {
                    c._player = c._playerLoader.getPlayer();
                    c.pause();
                    var g = c.listBox.find("li:eq(0)");
                    g.addClass("on");
                    c.play(g.data("user"))
                };
                var f = {
                    mode: "homepage",
                    fristPlayerType: "h5",
                    videoId: e,
                    ruid: d.uid,
                    fileName: d.flvtitle,
                    isPhoneLive: d.recordtype > 1 ? 1 : 0,
                    bg: d.pic,
                    readyFun: "_channelPlayerReady",
                    stopFun: "_channelPlayerStop",
                    chID: 0,
                    swfData: {
                        allowscriptaccess: "always",
                        wmode: "opaque",
                        bgcolor: "#333333"
                    }
                };
                    if (c._playerLoader) {
                        c._playerLoader.remove();
                        c._playerLoader = null
                    }
                    c._playerLoader.loadPlayer()
                })
            },
            setUser: function(e) {
                    f = "";
                if (!e.eid) {
                    f = '<div class="rec-base"><em class="ch-title">' + d + "</em></div>"
                } else {
                    if (e.eid == 10002) {
                        f = '<div class="rec-hot"><span class="t">火爆推荐</span><em class="ch-title">' + d + "</em></div>"
                    } else {
                        if (e.eid == 10000) {
                            f = '<div class="rec-svip"><span class="u" title="' + e.recName + '">' + e.recName + "</span></div>"
                        }
                    }
                }
            },
            getUrl: function(c) {
                return c
            },
            eventClass: "",
            eventRecom: function(c) {
                }
                if (c / 1) {
                } else {
                }
            }
        },
        hotRank: {
            getApi: "/subareaIndex/getFieryRank.php",
            getSt: null,
            etm: 0,
            init: function() {
            },
            event: function() {
                    if (a(this).data("rid") < 1) {
                        f.preventDefault()
                    }
                });
                    c.showBig(f.type == "mouseenter")
                })
            },
            showBig: function(d) {
                    if (d) {
                        c.box.addClass("video-hot-show")
                    } else {
                        c.box.removeClass("video-hot-show")
                    }
                }, d ? 100 : 1000)
            },
            getList: function() {
                }
            },
            getData: function() {
                    e = d.cur;
                    return
                }
                    subarea: d.area[e]
                }, function(f) {
                    if (f.flag == "001") {
                        c.etm = f.content.endSecond;
                        c.parse(f.content);
                        c.timeFormat()
                    }
                    c.getSt = setTimeout(a.proxy(c.getData, c), 60 * 1000)
                })
            },
            parse: function(g) {
                    f = g.rankList,
                    e = [];
                    if (!d || !d.rid) {
                        d = {
                            uid: 0,
                            rid: 0,
                            alias: "虚位以待"
                        }
                    }
                }
                if (g.isAnchor && g.endSecond > 0) {
                } else {
                }
            },
            timeFormat: function() {
                if (c < 10) {
                    c = "0" + c
                }
                if (d < 10) {
                    d = "0" + d
                }
                } else {
                }
            }
        },
        banner: {
            update: function(c) {
                }
                if (c.length < 1) {
                    return
                }
                        delay: 5
                    })
                } else {
                }
            },
            setHtml: function(d) {
                var c = [];
                a.each(d, function(f, g) {
                    c.push('<a href="' + g.url + '" target="_blank" style="background-image:url(' + g.img + ");" + (f == 0 ? "display:block" : "") + '"></a>')
                });
            }
        }
    };
        HTML: "",
        cur: 100,
        list: {},
        config: {
            0: {
                id: 0,
                name: "默认"
            },
            9999: {
                id: 9999,
                name: "六现场",
                pri: 0,
                bg_color: 1
            }
        },
        init: function() {
                f = a("div.mm-taglist"),
                c = f.find(".mm-mod-tab"),
                e = f.find("ul.template");
            e.remove();
            a(window).on("resize", function() {
                d.setDefStyle()
            });
            c.on("click", "a", function(k) {
                if (a(this).attr("href")) {
                    return
                }
                k.preventDefault();
                var m = a(this),
                    h = m.attr("data-tagid");
                d.btns.removeClass("on");
                m.addClass("on");
                if (h == 0) {
                    f.parent().addClass("mm-taglist-def")
                } else {
                    f.parent().removeClass("mm-taglist-def")
                }
                m.parents(".mm-mod-tab").find(".line-on").animate({
                    width: Math.max(28, m.outerWidth()),
                    left: m.position().left
                }, 200);
                try {
                    d.hotDance.reset()
                if (a.inArray(h / 1, d.hotDance.ids) > -1 && d.getListById(h)) {
                    var g = d.listBox.find("ul.j-taglist" + h);
                    g.html(d.getHtml(h));
                    d.hotDance.load(h)
                }
                var j = d.listBox.find("ul.mmlist").css("display", "none").filter(".j-taglist" + h);
                j.css("display", "block");
                j.find("img").each(function() {
                    a(this).attr("src2", a(this).attr("src3"))
                });
                j.attr("data-tracing", "livetag" + h);
                d.cur = h;
            });
        },
        setDefStyle: function() {
            var c = d.hasClass("page-w1560") || d.hasClass("page-w1320");
            if (e.find("li").length < 12) {
                if (c) {
                    e.css("height", 272)
                } else {
                    e.css("height", 264)
                }
            } else {
                if (c) {
                    e.css("height", 544)
                } else {
                    e.css("height", 528)
                }
            }
        },
        updateConfig: function(c) {
        },
        update: function(d) {
            if (d.length > 0) {
                jQuery(".mm-taglist-area").show()
            } else {
                jQuery(".mm-taglist-area").hide();
                return
            }
                var k = f.id;
                var j = c.btns.filter('[data-tagid="' + k + '"]');
                var e = c.getListById(k);
                if (!j[0]) {
                    return true
                }
                if (e != "undefined" && e.list && e.list.length > 0) {
                    j.css("display", "inline-block");
                    var h = c.listBox.find("ul.j-taglist" + k);
                    if (!h[0]) {
                        h = a('<ul class="mmlist-pic j-taglist' + k + '"/>').appendTo(c.listBox)
                    }
                    h.html(c.getHtml(k))
                } else {
                    j.css("display", "none")
                }
            });
            } else {
            }
        },
        getListById: function(d) {
            var c;
                if (f.id == d) {
                    c = f;
                    return false
                }
            });
            return c
        },
        getIconHtml: function(f, d) {
            var e = [];
            if (f) {
                    var g = c.config[j];
                    if (!g) {
                        return true
                    }
                    if (d && g.subarea != 999) {
                        return true
                    }
                        return true
                    }
                    e.push('<i class="i-tags-' + g.bg_color + '">' + g.name + "</i>")
                })
            }
            e.sort(function(h, g) {
                return h.pri - g.pri
            });
            return e.join("")
        },
        getHtml: function(g) {
                e = [],
                d = g == 0 ? 12 : 24;
            a.each(f, function(l, o) {
                if (l >= d) {
                    return false
                }
                if (!o) {
                    return true
                }
                if (a.inArray(g / 1, c.hotDance.ids) > -1) {
                    c.hotDance.setUser(o)
                }
                var h = c.getIconHtml(o.tagid);
                var k = "",
                    n = h != "" ? "live-title-bt" : "";
                if (o.livetitle) {
                    k = '<span class="live-title ' + n + '">' + o.livetitle + "</span>"
                }
                var m = '<span class="icon-tags">' + h + "</span>";
                var j = k + m;
                if (o.isHotDance == 1) {
                    j = j + '<i class="ico-hotdance">热舞中</i>'
                } else {
                    if (o.isHotDance == 2) {
                        j = j + '<i class="ico-hotsing">嗨唱中</i>'
                    }
                }
                e.push(c.HTML.replace(/\{rid\}/g, o.rid).replace("{uid}", o.uid).replace(/\{url\}/g, o.url && o.url != "" ? o.url : "//v.6.cn/" + o.rid).replace("{game-huanpeng}", o.url && o.url != "" ? "game-huanpeng" : "").replace("{iconTags}", j).replace(/\{alias\}/g, o.username).replace(/\{pic\}/, o.pic || "//vr0.xiu123.cn/imges/home2016/pic-default3.jpg").replace(/\{count\}/, numF(o.count)).replace("{status}", o.isvideo / 1 ? "i-video" : "i-live").replace(/\{time\}/, o.starttime))
            });
            return e.join("")
        },
        hotDance: {
            ids: [1000000, 1000009],
            videos: {},
            list: [],
            setUser: function(c) {
                if (c.isRecHotDance && c.flvtitle) {
                }
            },
            load: function(c) {
                    if (!d.videos[f.uid]) {
                        var h = e.find(".j-taglist" + c + ' li a[target="room' + f.rid + '"]').filter(".pic");
                        h.prepend('<div class="hot-video-box"></div>');
                        d.videos[f.uid] = new b(h.find(".hot-video-box"), f);
                        d.videos[f.uid].start()
                    }
                })
            },
            execute: function(c) {
                    if (typeof d[c] == "function") {
                        d[c]()
                    }
                })
            },
            reset: function() {
            }
        }
    };
        HTML: "",
        cur: "follow",
        page: 1,
        pages: 0,
        cells: 0,
        getHtml: function(c) {
            var d = c.pic == "" ? "//vr0.xiu123.cn/imges/home2016/pic-default3.jpg" : c.pic;
        },
        getHtml2: function(c) {
            var d = c.pic == "" ? "//vr0.xiu123.cn/imges/home2016/pic-default3.jpg" : c.pic;
        },
        update: function(d, c) {
                return
            }
            }
        },
        init: function(g) {
                return
            }
                f = a("#my_follow");
                k.preventDefault();
            });
                var m = a(this),
                    l = m.attr("rela");
                if (!m.hasClass("on")) {
                    c.btns1.removeClass("on");
                    c.boxes1.css("display", "none");
                    m.addClass("on");
                    m.parents(".mm-mod-tab").find(".line-on").animate({
                        width: m.outerWidth(),
                        left: m.position().left
                    }, 200);
                    c.boxes1.filter(".my-" + l).css("display", "block");
                    c.setData(l)
                }
                return false
            });
            var j = a("div.body-follow");
                var m = a(this),
                    l = m.attr("rela");
                if (!m.hasClass("on")) {
                    c.btns2.removeClass("on");
                    c.boxes2.css("display", "none");
                    m.addClass("on");
                    m.parents(".mm-mod-tab").find(".line-on").animate({
                        width: m.outerWidth(),
                        left: m.position().left
                    }, 200);
                    c.boxes2.filter("." + l + "-list-box").css("display", "block");
                    c.setData(l)
                }
                return false
            });
            d.on("click", function(m) {
                m.preventDefault();
                var k = a(this);
                var l = k.attr("rela");
                if (k.hasClass("on")) {
                    return
                }
                d.removeClass("on");
                h.css("display", "none");
                k.parent().find(".line-on").animate({
                    width: k.outerWidth(),
                    left: k.position().left
                }, 200);
                k.addClass("on");
                h.filter("." + l).css("display", "block");
                if (l == "follow-video-box") {
                    c.setData("mvideo-left")
                }
            });
            a("#tpl-my-follow").remove();
            a("#tpl-follow-list-box").remove();
                if (k.type == "mouseover") {
                    c.follow_over(a(this))
                } else {
                    c.follow_out()
                }
            });
            a("div.body-follow div.follow-list-box").on("mouseover mouseout", "a.name", function(k) {
                if (k.type == "mouseover") {
                    c.follow_over(a(this))
                } else {
                    c.follow_out()
                }
            });
                vis: function() {
                    var l = c.cur_user_elm.offset(),
                        k = c.cur_user_elm.width(),
                        n = a(this),
                        m;
                    n.find("a").css("display", "none");
                    if (c.cur_user_elm.attr("sfollow") == "block") {
                        m = "a.focus-off"
                    } else {
                        if (c.cur_user_elm.attr("manage") == "1") {
                            m = "a.manage-off"
                        } else {
                            m = "a.focus-on"
                        }
                    }
                    n.find(m).css("display", "block");
                    n.css({
                        left: l.left + k,
                        top: l.top - 3,
                        display: "block"
                    })
                },
                hid: function() {
                    a(this).css("display", "none")
                },
                mouseover: c.follow_over,
                mouseout: c.follow_out
            });
                l.preventDefault();
                var m = a(this);
                if (m.hasClass("manage-off")) {
                    c.del_manage(c.cur_user_elm)
                } else {
                    var k = m.attr("class") == "focus-on" ? "add" : "del";
                    c.set_follow(k)
                }
                c.handle_box.trigger("hid")
            });
                k.preventDefault();
                if (a(this).hasClass("prev")) {
                    c.prev()
                } else {
                    c.next()
                }
            });
                k.preventDefault();
                c.pageTurn(a(this).html())
            });
        },
        setData: function(c) {
            switch (c) {
                case "manage":
                    break;
                case "safe":
                    break;
                case "fansg":
                    break;
                case "mvideo-left":
                    break;
                case "mvideo":
                    break;
                default:
                    return
            }
        },
        pageTurn: function(d) {
            } else {
                if (d < 1) {
                }
            }
                scrollLeft: c
            }, "fast")
        },
        next: function() {
        },
        prev: function() {
        },
        follow_users: {
            all: "",
            pri: "",
            consume: ""
        },
        isLoaded: 0,
        get_follow: function() {
            a.getJSON("/user/countFansUid.php", {
            }, function(d) {
                if (d && d.flag == "001") {
                    c.createNav(d.content);
                    var e = d.content.consume || [];
                    c.follow_users.all = "," + c.group_users[c._cur].join(",") + ",";
                    c.follow_users.pri = "," + c.group_users_pri[c._cur].join(",") + ",";
                    c.follow_users.consume = "," + e.join(",") + ",";
                    c.parse_follow();
                    c.isLoaded = 1
                }
            })
        },
        group_users: {},
        group_users_pri: {},
        _cur: 0,
        createNav: function(h) {
            if (!h.all) {
                return
            }
            var d = a('<div class="sub-group-tab"></div>');
            var g = [];
            var c = [];
            a.each(h.all, function(m, l) {
                var j = m == f._cur ? 'class="on"' : "";
                g.push("<a " + j + ' data-id="' + m + '" rela="mmlist-zone-' + m + '" href="">' + l.name + "</a>");
                c.push('<ul class="mmlist-zone mmlist-zone-' + m + '"></ul>');
                f.group_users[m] = l.list;
                f.group_users_pri[m] = f.getGroupPri(l.list, h.pri)
            });
            d.html(g.join("")).appendTo(e);
            e.append(c.join(""));
            d.on("click", "a", function(k) {
                k.preventDefault();
                var j = a(this).attr("data-id");
                a(this).addClass("on").siblings().removeClass("on");
                e.find(".mmlist-zone").css("display", "none");
                e.find(".mmlist-zone-" + j).css("display", "block");
                f.follow_users.all = "," + f.group_users[j].join(",") + ",";
                f.follow_users.pri = "," + f.group_users_pri[j].join(",") + ",";
                f._cur = j;
                f.parse_follow()
            })
        },
        getGroupPri: function(e, c) {
            var d = [];
            a.each(e, function(g, f) {
                if (a.inArray(f, c) > -1) {
                    d.push(f)
                }
            });
            return d
        },
        setGroupPri: function(c, d) {
                if (a.inArray(c, f) > -1) {
                    if (d == "add") {
                        e.group_users_pri[h].push(c)
                    } else {
                        var g = a.inArray(c, e.group_users_pri[h]);
                        if (g > -1) {
                            e.group_users_pri[h].splice(g, 1)
                        }
                    }
                }
            })
        },
        parse_follow: function() {
                return
            }
            h.follows = {
                pri: [],
                all: []
            };
            var g = [],
                j = [],
                c = [],
                e = [];
            a.each(h.all_list, function(n, m) {
                if (h.follow_users.pri.indexOf("," + m.uid + ",") > -1) {
                    if (m.isvideo / 1) {
                        j.push(m)
                    } else {
                        g.push(m)
                    }
                } else {
                    if (h.follow_users.all.indexOf("," + m.uid + ",") > -1) {
                        if (m.isvideo / 1) {
                            e.push(m)
                        } else {
                            c.push(m)
                        }
                    }
                }
            });
            var d = function(n, m) {
                return m.count - n.count
            };
            g.sort(d);
            j.sort(d);
            c.sort(d);
            e.sort(d);
            h.follows.pri = g.concat(j);
            h.follows.all = c.concat(e);
            var l = [],
                f = [];
            a.each(h.follows.pri, function(m, n) {
                if (n.isvideo / 1 > 0) {
                    f.push(n)
                } else {
                    l.push(n)
                }
            });
            h.follows.pri = l.concat(f);
            l = [];
            f = [];
            a.each(h.follows.all, function(m, n) {
                if (n.isvideo / 1 > 0) {
                    f.push(n)
                } else {
                    l.push(n)
                }
            });
            h.follows.all = l.concat(f);
            f = l = null;
                var k = h.follows.pri.length + h.follows.all.length;
                if (k > 0) {
                    h.btn2Count.find(".num").html(k);
                    h.btn2Count.css("display", "inline-block")
                } else {
                    h.btn2Count.css("display", "none")
                }
                }
            }
            }
        },
        setList: function() {
                g = 5;
            if (h.hasClass("page-w1560") || h.hasClass("page-w1320")) {
                g = 4
            }
            var c = [],
                j = g * 5;
            for (var e = 0; e < j; e++) {
                if (!f[e]) {
                    break
                } else {
                }
            }
            if (j < f.length) {
            } else {
            }
            var d = a("#my_follow");
            if (f.length > 0) {
                d.css("display", "block")
            } else {
                d.css("display", "none")
            }
        },
        vCells: 5,
        vLeft: 0,
        vList: function() {
            }
                d.html("")
            } else {
                d.html('<div style="padding:20px; width:300px; margin:0 auto">' + c + "</div>")
            }
            var f = a(document).scrollTop();
            if (f > 30) {
                    scrollTop: 30
                }, 300)
            }
            })
        },
        loadT: 0,
        lazyLoad: function() {
                return
            }
                if (d >= c - 1) {
                } else {
                }
                d = Math.min(d, c);
            }
        },
        vParse: function(j) {
                h = [],
                g = [];
                var c = e[f];
                if (!c) {
                    break
                }
                g.push(c.uid)
            }
            var d = a(h.join(""));
            d.find(".img-box img").on("load", function() {
                a(this).css("opacity", 1)
            });
        },
        t: 0,
        t2: 0,
        follow_over: function(d) {
            clearTimeout(c.t);
            clearTimeout(c.t2);
            c.cur_user_elm = d.attr ? d : c.cur_user_elm;
            c.t = setTimeout(function() {
                c.handle_box.trigger("vis")
            }, 200)
        },
        follow_out: function() {
            clearTimeout(c.t);
            clearTimeout(c.t2);
            c.t2 = setTimeout(function() {
                c.cur_user_elm = null;
                c.handle_box.trigger("hid")
            }, 500)
        },
        set_follow: function(c) {
            var f = e.cur_user_elm.attr("uid");
            if (c == "del" || c == "delf") {
                if (!confirm("确定取消" + (c == "del" ? "重点关注" : "关注") + "吗？")) {
                    return
                }
            }
            var d = c == "delf" ? "/message/follow_del.php" : "/message/special.php";
            a.getJSON(d, {
                act: c,
                tuid: f,
                msgtype: "json"
            }, function(g) {
                if (g.flag == "001") {
                    switch (c) {
                        case "add":
                            e.follow_users.all = e.follow_users.all.replace("," + f + ",", ",");
                            e.follow_users.pri += f + ",";
                            e.setGroupPri(f, "add");
                            break;
                        case "del":
                            e.follow_users.pri = e.follow_users.pri.replace("," + f + ",", ",");
                            e.follow_users.all += f + ",";
                            e.setGroupPri(f, "del");
                            break;
                        case "delf":
                            break
                    }
                    e.parse_follow()
                } else {
                    alert(g.content)
                }
            })
        },
        getManage: function() {
                return
            }
            a.getJSON("/user/countfans.php?t=a", function(f) {
                if (f && f.flag == "001") {
                    d.manages = f.content;
                    d.parseManage()
                }
            });
            c.remove();
            e.remove();
                if (f.type == "mouseover") {
                    d.follow_over(a(this))
                } else {
                    d.follow_out()
                }
            });
                if (f.type == "mouseover") {
                    d.follow_over(a(this))
                } else {
                    d.follow_out()
                }
            })
        },
        parseManage: function() {
                return
            }
            if (!j || j.length < 1) {
                return
            }
            var k = {};
                k[m.uid] = {
                    count: m.count,
                    isvideo: m.isvideo / 1
                }
            });
            var h = [],
                e = [];
            for (var g = 0; g < j.length; g++) {
                var c = j[g];
                c.pic = c.picuser || c.pic;
                delete c.picuser;
                var f = k[c.uid];
                if (f) {
                    c.on = 1;
                    c.isvideo = f.isvideo;
                    c.count = f.count;
                    h.push(c)
                } else {
                    c.on = 0;
                    e.push(c)
                }
            }
            k = null
        },
        setManageList: function() {
                d = [],
                d.push(e.replace("{uid}", f.uid).replace("{count}", numF(f.count)).replace("{nolive}", f.on == 1 ? "" : "nolive").replace(/\{rid\}/g, f.rid).replace(/\{alias\}/g, f.username).replace("{pic}", f.pic).replace("{status}", f.isvideo ? "i-video" : "i-live").replace("{expire}", f.expire > 0 ? c.getTimeStamp(f.expire) : "").replace("{hasexpire}", f.expire > 0 ? "hasexpire" : "").replace("{priv}", f.priv == 5 ? "priv" : ""))
            });
        },
        del_manage: function(c) {
                if (d) {
                    var e = c.attr("uid");
                    a.getJSON("user/delAdmin.php?rid=" + e, function(f) {
                        if (f.flag == "001") {
                            c.parents("li").remove()
                        } else {
                        }
                    })
                }
            })
        },
        getSafe: function() {
                return
            }
            d.remove();
            a.getJSON("/user/countfans.php?t=safe", function(e) {
                if (e && e.flag == "001") {
                    c.safes = e.content;
                    c.parseSafe()
                }
            })
        },
        parseSafe: function() {
            if (!j || j.length < 1) {
                var d = '<div class="not-my-data">没有守护的主播！</div>';
                return
            }
            var k = {};
                k[m.uid] = {
                    count: m.count,
                    isvideo: m.isvideo / 1
                }
            });
            var h = [],
                e = [];
            for (var g = 0; g < j.length; g++) {
                var c = j[g];
                c.pic = c.picuser || c.pic;
                delete c.picuser;
                var f = k[c.uid];
                if (f) {
                    c.on = 1;
                    c.isvideo = f.isvideo;
                    c.count = f.count;
                    h.push(c)
                } else {
                    c.on = 0;
                    e.push(c)
                }
            }
            h.sort(function(m, l) {
                return l.count - m.count
            });
            k = null
        },
        setSafeList: function() {
            var c = [],
                c.push(d.replace("{uid}", e.uid).replace("{count}", numF(e.count)).replace("{nolive}", e.on == 1 ? "" : "nolive").replace(/\{rid\}/g, e.rid).replace(/\{alias\}/g, e.username).replace("{pic}", e.pic).replace("{status}", e.isvideo ? "i-video" : "i-live"))
            });
        },
        fansg: {
            lasttm: 0,
            init: function() {
            },
            getList: function() {
                }
                var d = +new Date,
                }
            },
            getData: function() {
                a.getJSON("/fansbrand/myFansBrandIndex.php", function(d) {
                    if (d.flag == "001") {
                        c.lasttm = +new Date;
                        c.parse(d.content)
                    }
                })
            },
            parse: function(d) {
                if (d.length > 0) {
                } else {
                }
            },
            getHtml: function(e) {
                    d = [];
                a.each(e, function(g, f) {
                });
                return d.join("")
            }
        },
        getTimeStamp: function(c) {
            var f, e;
            f = new Date(c * 1000);
            e = f.getFullYear() + "-";
            e += ("0" + (f.getMonth() + 1)).slice(-2) + "-";
            e += ("0" + f.getDate()).slice(-2);
            return e
        }
    };
    (function() {
            parseList: function(j) {
                var h = [];
                var f = jQuery("#tpl-min-video-list").html();
                var e = jQuery("#tpl-min-video-block").html();
                    var k = g._parseSingleList(l, f, e);
                    h.push(k)
                });
                return h.join("")
            },
            _parseSingleList: function(k, h, g) {
                var j = [];
                var e;
                    j.push(h.replace(/{picurl}/g, m.picurl).replace(/{title}/g, m.title).replace(/{sec}/g, m.sec).replace(/{znum}/g, m.znum).replace(/{vid}/g, m.vid))
                });
                e = g.replace(/{num}/g, k.num).replace(/{alias}/g, k.alias).replace(/{rid}/g, k.rid).replace(/{uid}/g, k.uid).replace(/{picuser}/g, k.picuser).replace(/{unreadNum}/g, k.unreadNum).replace(/{unreadCls}/g, +k.unreadNum ? "" : "update-num-hide").replace(/{list}/g, j.join(""));
                return e
            },
            insertHtml: function(f) {
            }
        });
        var d = {
            update: function() {
                e.attr("data-update", 1);
                }
            },
            updateList: function() {
            },
            setBtnClick: function() {
                if (e.attr("data-update") == "1") {
                }
            },
            setData: function(f) {
                if (e) {
                } else {
                }
            },
            insertHtml: function(f) {
            }
        };
            _data: {},
            setCache: function(f, e) {
            },
            getCache: function(e) {
            },
            clearCache: function() {
            }
        };
        var c = {
            url: "/minivideo/follow.php",
            listWrap: ".list-wrap",
            emptyWrap: ".list-empty",
            loadingWrap: ".list-loading",
            pageSize: 6
        };
            pages: 4,
            cur: "follow",
            btn: jQuery(".body-follow .region-title a").filter("[rela=follow-video-box]").attr({
                "data-update": 1
            }),
            addScrollEvent: function() {
                    mvideo: function() {
                            return
                        }
                        var g = e.listWrap;
                        var j = g.offset().top;
                        var f = g.outerHeight();
                        if (h > (j + f - 10)) {
                            e.getNextPage()
                        }
                    }
                })
            },
            delScrollEvent: function() {
            },
            getNextPage: function() {
                }
            },
            getPages: function(f) {
            },
            setPages: function() {
                    var e = getPageList({
                        nextPageStr: "Index.MvideoLeft.getPages",
                        page: k,
                        total_page: g,
                        prevImg: "&lt;&lt;",
                        nextImg: "&gt;&gt;",
                        block_page: 10
                    });
                    j.html(e).css("display", "block")
                } else {
                    j.css("display", "none")
                }
            }
        }, d);
            }
                jQuery("html,body").scrollTop(0)
            }
        });
            max: 4,
            cur: "home",
            btn: jQuery("#my_follow .mm-mod-tab a").filter("[rela=mvideo]").attr({
                "data-update": 1
            }),
            showMore: function(e) {
                if (e) {
                    f.css("display", "block")
                } else {
                    f.css("display", "none")
                }
                f.on("click", function(g) {
                    g.preventDefault();
                })
            }
        }, d);
            var h = g.content.list.length > e;
            if (h) {
                f.content.list = f.content.list.slice(0, e)
            }
        })
    })();
        HTML: "",
        getHtml: function(c) {
        },
        init: function() {
                return
            }
            if (!f) {
                return
            }
            var g = jQuery("#vistor_track");
                f = f.split(","),
                e = [];
            for (var d = 0; d < c.length; d++) {
                if (a.inArray(c[d].uid, f) > -1) {
                    if (e.length > 23) {
                        break
                    }
                }
            }
            if (e.length > 0) {
                g.css("display", "block");
            }
        }
    };
        52600834: 12001,
        49901385: 12002,
        88215916: 12003,
        20018775: 12004,
        64542642: 12005,
        55629188: 12006,
        65407096: 12007,
        43784405: 12008,
        57983923: 12009,
        55747491: 12010,
        79434946: 13001,
        84186601: 13002,
        23299753: 13003,
        61462803: 13004,
        52761088: 13005,
        53988693: 13006,
        70196473: 13007,
        63170490: 13008,
        24701501: 13009,
        52033569: 13010,
        84978712: 14001,
        88449602: 14002,
        89658896: 14003,
        85718484: 14004,
        82399985: 14005,
        85469171: 14006,
        80887009: 14007,
        80129060: 14008,
        88269274: 14009,
        80938703: 14010
    };
        84186601: 19001,
        79434946: 19002,
        72711331: 19003,
        49901385: 19004,
        61462803: 19005,
        99780325: 19006,
        55629188: 19007,
        75061317: 19008,
        56719261: 19009,
        88609945: 19010,
        98781051: 30001,
        99720054: 30002,
        98260800: 30003,
        94340470: 30004,
        92930902: 30005,
        84799976: 30006,
        85458812: 30007,
        94612118: 30008,
        80887539: 30009,
        84919959: 30010
    });
        fmPage: 1,
        init: function() {
            var f = a("#v_recom"),
                c = f.find("ul.template");
            c.remove();
            var g = a("#family_recom");
            var e = g.find("ul.template");
            e.remove();
            g.find("a.btn-change").on("click", function() {
                d.fmChange()
            })
        },
        v: function(f) {
            if (f.length > 0) {
                a("#mmRecomd").show()
            } else {
                a("#mmRecomd").hide();
                return
            }
                d = [];
            a.each(f, function(m, h) {
                var n = "",
                    l = h.pic;
                if (m == 0) {
                    n = "focus";
                    l = l.replace("_s.", "_b.")
                }
                var k = "";
                if (h.eid > 0) {
                    k = '<div class="eids-dress e' + h.eid + '-dress"><b class="bgl"></b><b class="bgt"></b><b class="bgr"></b><b class="bgb"></b><i class="e-i1"></i><i class="e-i2"></i></div>'
                }
                var o = e.vHTML.replace("{focus}", n).replace("{darenLink}", h.darenLink).replace("{rid}", h.rid).replace("{uid}", h.uid).replace(/\{link\}/g, h.link).replace(/\{alias\}/g, h.alias).replace("{pic}", l).replace("{count}", numF(h.count)).replace("{livetitle}", h.livetitle ? '<span class="live-title">' + h.livetitle + "</span>" : "").replace("{eventHtml}", k);
                if (h.recHonour == 1) {
                    o = o.replace("{changzhan}", g || "").replace(/{changzhan_title}/g, j ? j.title : "").replace("{jinpai}", "").replace("{daren}", "").replace("{renqi}", "").replace("{remen}", "").replace("{yearfamily}", "").replace("{nvtuan}", "").replace("{year2018}", "")
                } else {
                    o = o.replace("{jinpai}", h.recHonour == 2 ? "jinpai" : "").replace("{changzhan}", "").replace(/{changzhan_title}/g, "").replace("{daren}", h.recHonour == 3 ? "daren" : "").replace("{renqi}", h.recHonour == 4 ? "renqi" : "").replace("{remen}", h.recHonour == 5 ? "remen" : "").replace("{yearfamily}", h.recHonour == 6 ? "yearfamily" : "").replace("{nvtuan}", h.recHonour == 7 ? "nvtuan" : "").replace("{year2018}", h.recHonour == 8 ? "year2018" : "")
                }
                d.push(o)
            });
            var c = a(d.join(""));
            c.find(".img-box img").on("load", function() {
                a(this).css("opacity", 1)
            });
        },
        f: function(e) {
            if (e.length > 0) {
                a("#family_recom").show()
            } else {
                a("#family_recom").hide();
                return
            }
            var f = "block";
            if (e.length < 1) {
                f = "none"
            }
            a("#family_recom").css("display", f);
                c = [];
            a.each(e, function(h, g) {
                c.push(d.fHTML.replace(/\{link\}/g, "/" + g.rid).replace(/\{alias\}/g, g.alias).replace("{pic}", g.pospic == "" ? g.picuser : g.pospic).replace("{uid}", g.uid).replace("{spic}", g.spic).replace("{fuid}", g.fuid).replace(/\{fname\}/g, g.fname.st(8)).replace("{count}", numF(g.count)).replace("{livetitle}", g.livetitle ? '<span class="live-title">' + g.livetitle + "</span>" : ""))
            });
            }
        },
        fmChange: function() {
            a.ajax({
                url: "/family/recanchorchange.php?page=" + c.fmPage,
                dataType: "json",
                success: function(e) {
                    c.fmPage = e.content.next_page;
                    var d = [];
                    if (e.content.list.length > 0) {
                        a.each(e.content.list, function(g, f) {
                            d.push(c.fHTML.replace(/\{link\}/g, "/" + f.rid).replace(/\{alias\}/g, f.alias).replace("{uid}", f.uid).replace("{pic}", f.pospic == "" ? f.picuser : f.pospic).replace("{spic}", f.spic).replace("{fuid}", f.fuid).replace(/\{fname\}/g, f.fname.st(8)).replace("{count}", numF(f.count)).replace("{livetitle}", f.livetitle ? '<span class="live-title">' + f.livetitle + "</span>" : ""))
                        });
                        c.fbox.html(d.join(""));
                    }
                }
            })
        }
    };
        init: function() {
                return
            }
            var f = a("#mmVoice"),
                d = f.find("ul.template");
            d.remove();
            var h = a("#mmFunny"),
                e = h.find("ul.template");
            e.remove();
            var g = a("#mmDance"),
                c = g.find("ul.template");
            c.remove()
        },
        updateVoice: function(d) {
            if (d.length > 0) {
                a("#mmVoice").show()
            } else {
                a("#mmVoice").hide();
                return
            }
        },
        updateDance: function(d) {
            if (d.length > 0) {
                a("#mmDance").show()
            } else {
                a("#mmDance").hide();
                return
            }
        },
        updateFunny: function(d) {
            if (d.length > 0) {
                a("#mmFunny").show()
            } else {
                a("#mmFunny").hide();
                return
            }
        },
        getHtml: function(e, d) {
                c = [];
            a.each(e, function(g, j) {
                h = a(h).attr("data-recid", j.recId);
                c.push(h.prop("outerHTML"))
            });
            return c.join("")
        }
    };
        t: 0,
        HTML: "",
        init: function() {
            var e = a("#headLines"),
                d = e.find("ul.template"),
                c = e.attr("time");
            d.remove();
        },
        get: function() {
            a.getJSON("/event/getNewHeadLine.php", function(e) {
                var d = 300 * 1000;
                if (e.flag == "001") {
                    c.update(e.content.top);
                    d = e.content.countdown
                }
                clearTimeout(c.t);
                c.t = setTimeout(c.get, Math.min(120, d) * 1000)
            })
        },
        tongJi: function() {
                return
            }
            for (var e = 0; e < f.length; e++) {
                var d = f.eq(e);
                var c = d.parents("[data-tracing]").attr("data-tracing");
            }
        },
        update: function(f) {
            if (f.length > 0) {
                a("#headLines").show()
            } else {
                a("#headLines").hide();
                return
            }
                d = [],
                g = "//vr0.xiu123.cn/imges/home2016/pic-default3.jpg";
            a.each(f, function(j, l) {
                var h = "",
                    m = "",
                    n = "";
                switch (l.htype / 1) {
                    case 1:
                        h = "shenhao";
                        m = "1c52rshe";
                        n = '<div class="rich-rec"><span>神豪</span><a href="//v.6.cn/profile/index.php?rid=' + l.recRid + '" target="_blank">' + l.recAlias + "</a><span>推荐</span></div>";
                        break;
                    case 2:
                        h = "toutiao";
                        m = "ipvafi4h-" + (l.idx || 1);
                        n = '<a class="i-top">本轮头条</a>';
                        break;
                    case 3:
                        h = "daren";
                        m = "ipvafi4l";
                        n = '<a class="i-top" href="//v.6.cn/event/headLine/index.php" target="_blank">头条达人</a>';
                        break;
                    case 4:
                        h = "hot";
                        m = "ipvafi4k";
                        n = '<a class="i-top" title="根据房间的消费热度，系统自动推荐">本场火爆</a>';
                        break;
                    case 5:
                        h = "luandou";
                        m = "1c52rshe";
                        n = '<div class="melee-rec"><span>斗神</span><a href="//v.6.cn/profile/index.php?rid=' + l.recRid + '" target="_blank">' + l.recAlias + "</a><span>推荐</span></div>";
                        break;
                    case 6:
                        h = "shenhao";
                        m = "1c52rshe";
                        n = '<div class="ranking2019-rich-rec"><span>神豪</span><a href="//v.6.cn/profile/index.php?rid=' + l.recRid + '" target="_blank">' + l.recAlias + "</a><span>推荐</span></div>";
                        break
                }
                d.push(e.HTML.replace("{class}", h).replace("{tracing}", m).replace("{iconTop}", n).replace(/\{rid\}/g, l.rid).replace("{count}", numF(l.count)).replace("{pic}", l.pic || g).replace(/\{alias\}/g, l.alias).replace("{uid}", l.uid))
            });
            if (d.length > 0) {
                var c = a(d.join(""));
                c.find(".img-box img").on("load", function() {
                    a(this).css("opacity", 1)
                });
                e.listBox.html(c)
            }
        }
    };
        init: function() {
            }
        },
        update: function(e) {
            if (e.length > 0) {
                a("#mm-cute-new").show()
            } else {
                a("#mm-cute-new").hide();
                return
            }
                c = [];
            a.each(e, function(f, g) {
                c.push(d.tpl.replace("{pic}", g.pospic).replace(/\{name\}/g, g.username).replace(/\{rid\}/g, g.rid).replace("{uid}", g.uid).replace("{viewer}", numF(g.count)).replace("{mobile}", parseInt(g.recordtype) > 1 ? "mobile" : "").replace("{livetitle}", g.livetitle ? '<span class="live-title">' + g.livetitle + "</span>" : ""))
            });
            if (c.length > 4) {
            } else {
            }
            c = null
        }
    };
        getUrl: "/getIndexRankList.php",
        lasttm: 0,
        init: function() {
                rank_top: function() {
                        return
                    }
                        var d = (+new Date) - c.lasttm > 5 * 60 * 1000;
                        if (!c.lasttm || d) {
                            c.get()
                        }
                    }
                }
            });
                c.get()
            }
        },
        get: function() {
                return
            }
                return
            }
            a.ajax({
                dataType: "json",
                url: c.getUrl,
                success: function(e) {
                    c.isGetting = 0;
                    c.lasttm = +new Date;
                    if (e.flag == "001") {
                        var d = e.content;
                        c.setStar.parseList(d.getwealth);
                        c.setRich.parseList(d.postwealth);
                        c.setShenhao.parseList(d.realtimeRank)
                    }
                }
            })
        },
        setStar: {
            box: 0,
            HTML1: "",
            HTML2: "",
            parseList: function(d) {
                }
                    g = c.find("li"),
                }
                }
                c.html("");
                e.find("a").off("click").on("click", function() {
                    var k = a(this);
                    e.find("a").removeClass("on");
                    k.addClass("on");
                    k.parents(".toplist-tab").find(".line-on").animate({
                        width: k.width(),
                        left: k.position().left
                    }, 200);
                    var j = d[k.attr("rela")],
                        h = [];
                    a.each(j, function(n, l) {
                        var o = n < 3 ? "top " : "";
                        var m = n < 3 ? f.HTML1 : f.HTML2;
                        h.push('<li class="' + o + "r" + (n + 1) + '">' + m.replace("{rank}", n + 1).replace(/\{url\}/g, l.islive ? "/" + l.rid : "/profile/index.php?rid=" + l.rid).replace("{pic}", l.picuser).replace(/\{alias\}/g, l.username).replace("{star}", l.wealthrank).replace("{live}", l.islive ? "i-live-on" : "") + "</li>")
                    });
                    c.html(h.join(""))
                }).eq(0).click()
            }
        },
        setRich: {
            isInit: 0,
            parseList: function(f) {
                    return
                }
                var f = f,
                    j = a("#rankRichBox"),
                    e = j.find("ol"),
                    h = e.find("li"),
                    d = h.eq(0).html().replace("src3", "src"),
                    c = h.eq(1).html().replace("src3", "src"),
                    g = j.find(".toplist-tab");
                e.html("");
                g.find("a").on("click", function() {
                    var m = a(this);
                    if (!m.hasClass("on")) {
                        g.find("a").removeClass("on");
                        m.addClass("on");
                        m.parents(".toplist-tab").find(".line-on").animate({
                            width: m.width(),
                            left: m.position().left
                        }, 200);
                        var l = f[m.attr("rela")],
                            k = [];
                        a.each(l, function(q, n) {
                            var r = q < 3 ? "top " : "";
                            var o = q < 3 ? d : c;
                            k.push('<li class="' + r + "r" + (q + 1) + '">' + o.replace("{rank}", q + 1).replace(/\{rid\}/g, n.rid).replace("{uid}", n.cid).replace("{pic}", n.picuser).replace(/\{alias\}/g, n.username).replace("{rich}", n.coin6rank) + "</li>")
                        });
                        e.html(k.join(""))
                    }
                }).eq(0).click()
            }
        },
        setShenhao: {
            tpl: "",
            init: function() {
                    return
                }
                c.find("a").on("click", function() {
                    var f = a(this);
                    c.find("a").removeClass("on");
                    f.addClass("on");
                    if (f.hasClass("on")) {
                        var g = f.attr("rela"),
                            e = d.datas[g];
                        d.listBox.html(d.getHtml(e))
                    }
                })
            },
            parseList: function(c) {
            },
            getHtml: function(d) {
                    c = [];
                a.each(d, function(g, f) {
                    if (g > 4) {
                        return false
                    }
                    c.push('<li class="fix t' + (g + 1) + '">' + e.tpl.replace("{rank}", g + 1).replace(/\{url\}/g, f.islive ? "/" + f.rid : "/profile/index.php?rid=" + f.rid).replace("{pic}", f.picuser).replace("{alias}", f.username).replace("{star}", f.wealthrank).replace("{percent}", f.percent).replace("{numText}", g == 0 ? "暂居第一" : "与前一名差<em>" + numF(f.cvalue) + "</em>币").replace("{live}", f.islive ? "i-live-on" : "") + "</li>")
                });
                return c.join("")
            }
        }
    };
        HTML: "",
        page: 0,
        pageSize: 15,
        init: function() {
            c.remove();
            if (d.hasClass("page-w1320") || d.hasClass("page-w1560")) {
            }
                f.preventDefault();
            });
                e.get()
            }
        },
        lazyTest: function() {
                hotMore: function() {
                        c.get()
                    }
                }
            })
        },
        get: function() {
            var c = {
            };
            a.getJSON("/getVisitorMoreList.php", c, function(e) {
                if (e.flag == "001") {
                    d.parse(e.content)
                } else {
                }
            })
        },
        parse: function(c) {
                g = [],
                f = [];
            a.each(c.data, function(l, k) {
                var j = h.HTML.replace(/\{rid\}/g, k.rid).replace("{pic}", k.pic).replace(/\{alias\}/g, k.username).replace("{count}", numF(k.count)).replace("{mobile}", parseInt(k.recordtype) > 1 ? "mobile" : "").replace("{time}", k.starttime).replace("{livetitle}", k.livetitle ? '<span class="live-title">' + k.livetitle + "</span>" : "");
                g.push(j);
                f.push(k.uid)
            });
            var e = a(g.join(""));
            e.find(".img-box img").css("opacity", 0).on("load", function() {
                a(this).css("opacity", 1)
            });
            } else {
            }
        }
    };
        init: function() {
                return
            }
            var c = '<div class="notice-push"><a class="close" title="关闭"></a><p class="cmt">您有<span style="color:#f00;">1</span>条新消息，<a>查看</a></p><p class="fans">您有<span></span>个新粉丝，<a target="_blank" href="/profile/fans.php" onclick="TEM.tongji()">查看</a></p></div>';
                if (!a(this).attr("href")) {
                    e.preventDefault()
                }
                var f = a(this);
                if (f.hasClass("close")) {
                    d.hide()
                } else {
                    if (f.parents("p").hasClass("cmt")) {
                        });
                        d.hideElm(f.parents("p"))
                    } else {
                        d.hideElm(f.parents("p"))
                    }
                }
            })
        },
        show: function(c, d) {
            switch (c) {
                case "cmt":
                    break;
                case "fans":
                    break
            }
        },
        hide: function() {
        },
        hideElm: function(c) {
            c.css("display", "none");
            }
        }
    }
})();
var myTrack;
(function() {
        API: {
            getFriend: "/message/message_get.php",
            myNewCmt: "/message/newcomment_get.php",
            getGift: "/message/sysmessage_get.php",
            getAsk: "/message/newmessage_watch.php",
            getNewMsg: "/message/newmessage_get.php"
        },
        loadElm: '<div class="loading">加载中…</div>',
        friendBox: 0,
        newCmtBox: 0,
        newCmtSug: 0,
        cmtBox: 0,
        curBtn: 0,
        curBox: 0,
        askDelay: 1000 * 60 * 2,
        newid: 0,
        cmtNum: 0,
        _Rep_num: 0,
        toScrollTop: function() {
                a("body,html").animate({
                }, 200)
            }
        },
        toScrollTop3: function() {
            a("body,html").animate({
                scrollTop: 0
            }, 200)
        },
        init: function() {
                return
            }
                return
            }
            var b = a("#wbFeed");
            var j = b.find(".feed-list");
            var h = b.find(".feed-new");
            j.bind("click", function(e) {
                d.changeVis(e, {
                    btn: j,
                    box: d.friendBox
                })
            });
            h.bind("click", function(e) {
                d.changeVis(e, {
                    btn: h,
                    box: d.newCmtBox
                })
            });
                var u = a(r.target);
                if (u.is("em")) {
                    u = u.parent()
                }
                var q;
                var v;
                if (u.is("a")) {
                    v = u.attr("cm");
                    if (v) {
                        r.preventDefault();
                        q = v.split("|");
                        var x = u.attr("href").split("#")[1];
                            return
                        }
                        switch (x) {
                            case "cmt":
                                } else {
                                        a: u,
                                        uid: q[0],
                                        id: q[1],
                                        num: q[2],
                                        pos: q[3],
                                        alias: q[4]
                                    });
                                    if (q[4] == "m") {
                                        u.html("已读！").addClass("fcmt-readed")
                                    }
                                }
                                break;
                            case "rt":
                                var w = u.parents("dd:eq(0)");
                                var t = w.find("a.mini-video-collapse");
                                if (t[0]) {
                                }
                                var s = w.find("div.frelayCon"),
                                    o = w.find("div.fuser")[0].innerHTML + "：" + w.find("p.fbody")[0].innerHTML;
                                if (s[0]) {
                                    s = s.find("div.fuser")[0].innerHTML + "：" + s.find("p.fbody")[0].innerHTML
                                }
                                    btn: u,
                                    msg: s && s[0] ? s : o,
                                    reMsg: s ? o : 0,
                                    sendId: q[1]
                                });
                                break;
                            case "rtr":
                                var w = u.parents("dd:eq(0)");
                                var t = w.find("a.mini-video-collapse");
                                if (t[0]) {
                                }
                                var s = w.find("div.frelayCon"),
                                    k = s.find("div.fuser")[0].innerHTML + "：" + s.find("p.fbody")[0].innerHTML;
                                    btn: u,
                                    msg: k,
                                    reMsg: 0,
                                    sendId: q[1]
                                });
                                break;
                            case "rep":
                                    id: q[0],
                                    alias: q[1],
                                    btn: u
                                });
                                break;
                            case "del":
                                    id: q[0],
                                    uid: q[1],
                                    tm: q[2]
                                });
                                break;
                            case "collapse":
                                break;
                            case "rotateLeft":
                                var l = u.parents(".media-expend:eq(0)").find("img:eq(0)");
                                break;
                            case "rotateRight":
                                var l = u.parents(".media-expend:eq(0)").find("img:eq(0)");
                                break;
                            case "collapseAudio":
                                break;
                            case "collapseMiniVideo":
                                break
                        }
                    }
                    if (u.attr("data-fansq")) {
                        setTimeout(function() {
                            y.fansqAr = y.fansqAr.erase(Number(u.parent().id.substring(11)));
                            u.parent().remove();
                            if (y.fansqAr.length == 0) {
                                y.friendBoxCon3.find("ul").remove();
                                y.friendBoxCon3.find("p").remove()
                            }
                            y = null
                        }, 500)
                    }
                } else {
                    if (v = u.is("img") && u.attr("cm")) {
                        r.preventDefault();
                        q = v.split("|");
                        var m = q[0];
                        switch (m) {
                            case "showBigPic":
                                break;
                            case "collapse":
                                break;
                            case "playAudio":
                                break;
                            case "miniVideo":
                                break
                        }
                    } else {
                        if (u.is("sup") && u.parent().hasClass("mini-video")) {
                            r.preventDefault();
                            var n = u.siblings("img");
                            var v = n.attr("cm");
                            q = v.split("|");
                        } else {
                            if (u.is("canvas")) {
                            }
                        }
                    }
                }
            }, this));
                d.changeVis(e, {
                    btn: h,
                    box: d.newCmtBox
                })
            });
            var c = function(e) {
                d.changeVis(e, {
                    btn: h,
                    box: d.newCmtBox,
                    formYellow: true
                })
            };
            a("#see_new_comment").bind("click", function(e) {
                e.preventDefault();
                c(e);
            });
            try {
            var g = a("#wb_user .log-info");
        },
        getData: function() {
            var b = a(document).scrollTop();
            if (b > 30) {
                    scrollTop: 30
                }, 300)
            }
                }
            } else {
            }
        },
        showPicStage: function(d) {
            var b = d.parent();
            var e = d.attr("src");
            c.onload = function() {
                var j = d.parents("p.fbody:eq(0)");
                var g = a("<div/>", {
                    "class": "media-expend"
                });
                g.html('<div class="arrow-icon"><i class="ico">◆</i><i class="ico ico2">◆</i></div>				<p class="feed-media-action-wrap">				<a href="#collapse" class="feed-media-action feed-media-action-collapse" cm="uid"><i></i>收起</a> <span class="vline">|</span> 				<a href="' + b[0].href + '" target="_blank" class="originalImg"><i></i>查看大图</a> <span class="vline">|</span> 				<a href="#rotateLeft" class="feed-media-action feed-media-action-rotateLeft" cm="in"><i></i>向左转</a> <span class="vline">|</span> 				<a href="#rotateRight" class="feed-media-action feed-media-action-rotateRigth"  cm="in"><i></i>向右转</a></p>				<div class="feed-media-bigImg">				<img class="feed-media-action feed-media-action-collapse smallCursor" cm="collapse" width="' + h.width + '" height="' + h.height + '" src="' + f + '" />				</div>');
                j.after(g);
                b.removeClass("aPic-waiting");
                b.css("display", "none");
            };
            b.addClass("aPic-waiting");
            b.parents("dl:eq(0)")[0] && b.parents("dl[0]").css("height", "auto");
            c.src = f;
        },
        dropPicStage: function(b) {
            b.parents("dd:eq(0)").find(".aPic").css("display", "block");
            b.parents(".media-expend:eq(0)").remove()
        },
        playAudio: function(f, d) {
            var e = f.parents("p.fbody:eq(0)");
            var b = a("<div/>", {
                "class": "media-expend"
            });
            var g = String.uniqueID();
            var c = "https://v.6.cn/apple/musicPlayer/mp3player1.5.swf";
            b.html('<div class="arrow-icon"><i class="ico">◆</i><i class="ico ico2">◆</i></div><p class="feed-media-action-wrap"><a href="#collapseAudio" cm="in" class="feed-media-action feed-media-action-collapse"><i></i>收起</a></p>						<div class="feed-meida-audioPlayer">						<span class="player" id="' + g + '"></span>						</div>');
            e.after(b);
            e.parents("dl:eq(0)")[0] && e.parents("dl:eq(0)").css("height", "auto");
            f.css("display", "none");
                flashvars: "aid=" + d,
                wmode: "transparent"
            })
        },
        dropAudio: function(b) {
            b.parents("dd:eq(0)").find(".audioIcon").css("display", "block");
            b.parents(".media-expend").remove()
        },
        playMiniVideo: function(f, b) {
            var d = f.parents("p.fbody");
            var e = f.attr("cm").split("|");
                vid: e[1],
                autoplay: 1
            });
            d.append(c.createBox());
            d.find(".mini-video").css("display", "none");
            d.data("mini-video", c);
            c.loadPlayer()
        },
        dropMiniVideo: function(d) {
            var c = d.parents("p.fbody");
            var b = c.data("mini-video");
            b && b.destroyPlayer();
            b = null;
            c.find(".mini-video-expand").remove();
            c.find(".mini-video").css("display", "block")
        },
        rotateImage: function(d, c, b) {
            var e = +(d.attr("angle") || 0);
            e = c == "left" ? e - 90 : e + 90;
            } else {
            }
        },
        canvasRotate: function(f, e, n) {
            var c;
            var b;
            var g = e * Math.PI / 180;
            var l = Math.sin(g);
            var o = Math.cos(g);
            var m;
            var j;
            var k;
            var d;
            if (!f.canvas) {
                c.width = f.width;
                c.height = f.height;
                c.image = f;
                c.className = "feed-media-action feed-media-action-collapse smallCursor";
                f.parentNode.appendChild(c);
                b = c.getContext("2d");
                m = f.width;
                j = f.height;
            } else {
                c = f.canvas;
                b = c.getContext("2d");
                m = f.width;
                j = f.height
            }
            k = Math.abs(o * m) + Math.abs(l * j);
            d = Math.abs(o * j) + Math.abs(l * m);
            if (k > n) {
                d = d * n / k;
                k = n
            }
            c.width = k;
            c.height = d;
            b.save();
            b.clearRect(0, 0, k, d);
            b.rotate(g);
            if (e == 90 || e == 270) {
                if (k < j) {
                    m = m * k / j;
                    j = k
                }
            }
            if (e == 0) {
                b.drawImage(f, 0, 0, m, j)
            }
            if (e == 90) {
                b.drawImage(f, 0, -j, m, j)
            }
            if (e == 180) {
                b.drawImage(f, -m, -j, m, j)
            }
            if (e == 270) {
                b.drawImage(f, -m, 0, m, j)
            }
            b.restore();
            a(f).attr("angle", e)
        },
        filterRotate: function(h, j, e) {
            var g = j * Math.PI / 180;
            var c = Math.sin(g);
            var f = Math.cos(g);
            var d = "M11=" + f + ",M12=" + (-c) + ",M21=" + c + ",M22=" + f;
            if (!a(h).data("args")) {
                a(h).data("args", {
                    dw: h.width,
                    dh: h.height,
                    cs: h.style.cssText,
                    pcs: h.parentNode.style.cssText
                })
            }
            var b = a(h).data("args");
            if (j == 0 || j == 180) {
            } else {
                if (b.dh > e) {
                }
                a(h).parent.css({
                    osition: "relative",
                    height: h.width
                });
                a(h).css({
                    position: "absolute",
                    top: 0,
                    left: Math.abs((e - h.height) / 2)
                })
            }
            a(h).attr("angle", j)
        },
        giftInit: 0,
        getFansq: function(c) {
            var b;
                return
            }
            } else {
                    a.getJSON("/message/groupmessage_get.php?t=fansq", {
                        p: c || 1
                }
            }
            if (c) {
            }
        },
        fansqBack: function(g) {
            var b;
            var e;
            var c;
            var d;
            var f;
            if (g.flag != "001") {
                alert(g.content);
                return
            }
            if (g.content.content.length == 0) {
                return
            }
            b.empty();
            d.className = "topic-list";
            d.appendChild(f);
            b.append(d);
            if (g.content.pageCount > 1) {
                e = getPageList({
                    nextPageStr: "myTrack.getFansq",
                    page: g.content.p,
                    total_page: g.content.pageCount,
                    prevImg: "<em>&lt;前页</em>",
                    nextImg: "<em>后页&gt;</em>"
                });
                c.className = "fpage";
                c.innerHTML = e;
                b.append(c)
            }
        },
        fansqNewestBack: function(f) {
            var c;
            var b;
            var e;
            var d;
            if (f.flag != "001") {
                alert(f.content);
                return
            }
            if (!f.content.content) {
                return
            }
            b = c.find(".topic-list");
            d = a("<ul/>", {
                "class": "topic-list"
            }).append(e);
            d.before(b)
        },
        assembleFansq: function(c) {
            a.each(c, function(g, m) {
                var f = m.content;
                var e = f.isgood && f.isgood > 0 ? '<em class="metal metal-good"></em>' : "";
                var j = f.istop && f.istop > 0 ? '<em class="metal metal-top"></em>' : "";
                var h = 70;
                var k = f.msg.length > h ? f.msg.substring(0, h) + "..." : f.msg;
                l.className = "fix";
                b.appendChild(l)
            });
            return b
        },
        getFamily: function(c) {
            var b;
                return
            }
            } else {
                    a.getJSON("/message/groupmessage_get.php?t=family", {
                        p: c || 1
                }
            }
            if (c) {
            }
        },
        familyBack: function(g) {
            var b;
            var e;
            var c;
            var d;
            var f;
            if (g.flag != "001") {
                alert(g.content);
                return
            }
            if (g.content.content.length == 0) {
                return
            }
            b.empty();
            d.className = "topic-list";
            d.appendChild(f);
            b.append(d);
            if (g.content.pageCount > 1) {
                e = getPageList({
                    nextPageStr: "myTrack.getFamily",
                    page: g.content.p,
                    total_page: g.content.pageCount,
                    prevImg: "<em>&lt;前页</em>",
                    nextImg: "<em>后页&gt;</em>"
                });
                c.className = "fpage";
                c.innerHTML = e;
                b.append(c)
            }
        },
        familyNewestBack: function(f) {
            var c;
            var b;
            var e;
            var d;
            if (f.flag != "001") {
                alert(f.content);
                return
            }
            if (!f.content.content) {
                return
            }
            b = c.find(".topic-list");
            d = a("<ul/>", {
                "class": "topic-list"
            }).append(e);
            d.before(b)
        },
        assembleFamily: function(c) {
            a.each(c, function(g, m) {
                var f = m.content;
                var e = f.isgood && f.isgood > 0 ? '<em class="metal metal-good"></em>' : "";
                var j = f.istop && f.istop > 0 ? '<em class="metal metal-top"></em>' : "";
                var h = 70;
                var k = f.msg.length > h ? f.msg.substring(0, h) + "..." : f.msg;
                l.className = "fix";
                b.appendChild(l)
            });
            return b
        },
        postModule: {
            sendApi: "/message/message_add.php",
            alt: "说点啥吧",
            init: function() {
                var g = a("#wbForm"),
                    d = g.find("button.send:eq(0)"),
                    b = g.find("a.face:eq(0)"),
                    f = g.find("textarea");
                    fname: "wb"
                });
                b.bind("click", function(h) {
                    h.preventDefault();
                    c.visible(b[0], f[0], e.alt)
                });
            },
            setSend: function() {
            },
            deSend: function(b) {
                if (b == "001") {
                }
            },
            send: function() {
                    return
                }
                a.ajax({
                    type: "POST",
                    dataType: "json",
                    data: {
                        msg: b,
                    },
                })
            },
            sendBack: function(d) {
                if (d.flag == "001") {
                    c.post_ok.fadeIn(100);
                    setTimeout(function() {
                        c.post_ok.fadeOut(100)
                    }, 1500);
                    var d = d.content;
                    var b = {
                        flag: "001",
                        content: {
                            newid: d.newid,
                            content: [a.extend(d, {
                                type: 1,
                                content: {
                                    msg: d.msg,
                                    mp3: d.mp3,
                                    pic: d.pic
                                }
                            })]
                        }
                    };
                } else {
                    if (d.flag == "203") {
                    } else {
                        alert(d.content)
                    }
                }
            },
            post_ready: function() {
                a("body,html").animate({
                    scrollTop: 0
                }, 100);
                setTimeout(function() {
                    b.file_post.textarea.focus()
                }, 200)
            },
            file_post: {
                area_info: {
                    alt: "说点啥吧",
                    h_min: 32,
                    h_max: 80
                },
                init: function() {
                    var c = a("#wbForm");
                        var d = a(this);
                        if (d.val() == b.area_info.alt) {
                            d.val("")
                        }
                        d.addClass("focus")
                    });
                        a(this).removeClass("focus")
                    });
                        d.preventDefault();
                        if (!confirm("确定删除吗？")) {
                            return
                        }
                            b.del_audio()
                        } else {
                            b.del_photo()
                        }
                    });
                        d.preventDefault();
                        b.up_box_def(1)
                    });
                    c.find(".wb-media .photo, .wb-media .mp3").bind("click", function(d) {
                        d.preventDefault();
                            b.up_photo()
                        }
                                b.up_mp3()
                            } else {
                            }
                        }
                    });
                },
                up_mp3: function() {
                        }
                    }
                    return false
                },
                up_photo: function() {
                        }
                    }
                    return false
                },
                up_box_def: function(b) {
                    if (b != 1) {
                    }
                },
                del_photo: function() {
                    }
                },
                del_audio: function() {
                    }
                },
                up_photo_init: function() {
                        d = c.photo_box.find("form"),
                        b = d.find("input");
                    b.bind("change", function() {
                        d.trigger("submit_c")
                    });
                    d.bind("submit_c", function(g) {
                        var h = b.val();
                        var f = "jpg,jpeg,png,gif";
                        if (c.checkExtension(h, f) == false) {
                            return false
                        }
                        var j = String.uniqueID();
                        d.append(a("<input/>", {
                            name: "callbackFun",
                            type: "hidden",
                            value: "top." + j
                        }));
                        d.append(a("<input/>", {
                            name: "callbackUrl",
                            type: "hidden",
                        }));
                        d.append(a("<input/>", {
                            name: "pid",
                            type: "hidden",
                            value: "1001"
                        }));
                        d.append(a("<input/>", {
                            name: "size",
                            type: "hidden",
                            value: "s23,b1"
                        }));
                            delete c.uploading;
                            if (k.flag != "001") {
                                c.up_box_def()
                            } else {
                                c.photo_box.find("img").unbind();
                                c.photo_box.find("img").bind("load", function() {
                                    c.photo_box.attr("class", "photoBox is_info")
                                });
                                var l = h.split(/\\|\//);
                                var e = l.pop();
                                c.imageTitle = e.slice(0, e.lastIndexOf("."));
                                if (c.textarea.val() == "" || c.textarea.val() == c.alt) {
                                    c.textarea.val("分享照片-")
                                }
                            }
                        };
                        c.photo_box.attr("class", "photoBox is_loading");
                        c.uploading = 1;
                        d.submit()
                    })
                },
                up_mp3_init: function() {
                    var d = c.mp3_box.find("form");
                    var b = d.find("input[type=file]");
                    b.bind("change", function() {
                        d.trigger("submit_c")
                    });
                    d.bind("submit_c", function(g) {
                        var h = b.val();
                        var f = "mp3,WAV,WMV,MPEG,flv,avi,3gp,mp4";
                        c.mp3_origin = d.find("input[type=radio]:checked").val();
                        if (c.checkExtension(h, f) == false) {
                            return false
                        }
                        if (!c.mp3_origin) {
                            return false
                        }
                        var j = String.uniqueID();
                        d.append(a("<input/>", {
                            name: "callbackFun",
                            type: "hidden",
                            value: "parent." + j
                        }));
                        d.append(a("<input/>", {
                            name: "callbackUrl",
                            type: "hidden",
                        }));
                            delete c.uploading;
                            if (e.flag != "001") {
                                c.up_box_def()
                            } else {
                                c.audio = e.content;
                                var k = e.content.title;
                                c.mp3_box.find(".uploadinfo em").html(k);
                                if (c.textarea.val() == "" || c.textarea.val() == c.alt) {
                                    c.textarea.val(k + "-")
                                }
                                c.mp3_box.attr("class", "mp3Box is_info")
                            }
                        };
                        c.mp3_box.attr("class", "mp3Box is_loading");
                        c.uploading = 1;
                        d.submit()
                    })
                },
                checkExtension: function(d, c) {
                    var b = d.substring(d.lastIndexOf(".") + 1).toLowerCase();
                    if (c.indexOf(b) < 0) {
                        return false
                    }
                    return true
                }
            }
        },
        cmtBoxInit: function() {
            var b = a("#cmtBox");
                API: {
                    getComment: "/message/comment_get.php",
                    sendComment: "/message/comment_add.php",
                    delComment: "/message/comment_del.php"
                },
                left: 0,
                image: "",
                parBox: b.parent(),
                isToPar: 0,
                toPar: function() {
                },
                box: b,
                listBox: b.find("div.wb-cmt-list"),
                sendInput: b.find(".inputWrap textarea"),
                faceBtn: b.find("a.face"),
                sendBtn: b.find("button.fbtn"),
                uploadButton: b.find(".uploadButton"),
                previewImage: b.find(".previewImage"),
                previewImageClose: b.find(".previewImageClose"),
                loading: b.find("div.loading"),
                toMy: b.find("span.toMy input:eq(0)"),
                toRoot: b.find("span.toRoot input:eq(0)"),
                toRootName: b.find("span.toRoot em:eq(0)"),
                toScrollTop: function() {
                        a("body,html").animate({
                        }, 200)
                    }
                },
                init: function() {
                        fname: "wb"
                    });
                        c.visible(d.faceBtn, d.sendInput);
                        return false
                    });
                        a(this).addClass("focus")
                    });
                        a(this).removeClass("focus")
                    })
                },
                setDef: function() {
                },
                getHtml: function(j, k) {
                        h = '(来自 <a href=""></a> 的粉丝吧)',
                },
                parseList: function(k) {
                    var h = k.content;
                    if (h.length < 1) {
                        return false
                    }
                    for (var f = 0; f < h.length; f++) {
                        var j = h[f];
                        d.id = "cmt_" + j.stm;
                        g.appendChild(d)
                    }
                    var c = getPageList({
                        nextPageStr: "myTrack.cmtBox.getComment",
                        page: k.p,
                        total_page: k.pageCount,
                        prevImg: "<em>&lt;前页</em>",
                        nextImg: "<em>后页&gt;</em>"
                    });
                    if (c != "") {
                        l.className = "fpage";
                        l.innerHTML = c;
                    }
                    }
                },
                newComment: function(f) {
                    var c = a("<li/>", {
                        id: "cmt_" + f.stm,
                    });
                    if (!d[0]) {
                    }
                },
                visComment: function(d) {
                    var c = d.a[0].parentNode.parentNode.parentNode;
                    c.parentNode.style.height = "auto";
                    if (d.num > 0) {
                    }
                },
                geting: 0,
                getComment: function(c) {
                        return
                    }
                        id: d,
                        p: c,
                },
                commentBack: function(c) {
                    if (c.flag == "001") {
                        }
                    } else {
                    }
                },
                sending: 0,
                addCmt: function() {
                        d = "",
                        e = 0;
                        var c = f.split("：");
                        d = c.shift();
                        f = c.join("");
                    }
                    if (f == "") {
                        return
                    }
                    return false
                },
                setSend: function() {
                },
                deSend: function() {
                },
                sendComment: function(f, c) {
                        return
                    }
                        id: g,
                        msg: f,
                        isforward: e,
                        isroot: d,
                        quote: c,
                },
                sendBack: function(c) {
                    if (!c) {
                        return
                    }
                    if (c.flag == "001") {
                        }
                    } else {
                        if (c.flag == "203") {
                        } else {
                        }
                    }
                },
                toUid: 0,
                reply: function(c) {
                },
                deling: 0,
                delComment: function(c) {
                        return false
                    }
                    if (confirm("确定删除吗？")) {
                            id: c.id,
                            uid: c.uid,
                            tm: c.tm
                    }
                },
                delCommentBack: function(c) {
                    if (c.flag == "001") {
                    } else {
                    }
                }
            };
        },
        curTab: "msg",
        changeVis: function(c, b) {
            c.preventDefault();
            if (b.btn.hasClass("feed-new")) {
            } else {
            }
            b.btn.addClass("on");
            b.box.css("display", "block");
            b.btn.parents(".wb-tab").find(".line-on").animate({
                width: b.btn.outerWidth(),
                left: b.btn.position().left
            }, 200)
        },
        parseSame: function(d) {
            var b = {};
            for (var c = 0; c < d.length; c++) {
                var f = d[c];
                if (!b[f.uid]) {
                    b[f.uid] = []
                }
                b[f.uid].push(f)
            }
            return b
        },
        geting: 0,
        getFriendInit: 0,
        getFriendCurrentPage: 0,
        getFriendTotalPage: 0,
        getFriend: function(d, b) {
                return
            }
                p: d
                setTimeout(function() {
                        getFriend: a.proxy(c.getFriendAuto, c)
                    })
                }, 1000)
            } else {
            }
        },
        getFriendByClick: function(b) {
        },
        getFriendAuto: function() {
            var b = a("#friend_pagelist");
                b.html('<div class="loading">加载中…</div>');
            }
        },
        getFriendDD: function(d) {
            var c;
            var f = "";
            if (c = d.forward && d.forward.content) {
                if (c.fuid) {
                } else {
                    if (c.fansqrid) {
                    }
                }
            }
        },
        friendBack: function(k) {
            if (k.flag == "001") {
                var k = k.content;
                if (k.newid && k.newid / 1 > 2) {
                }
                if (k.content.length < 1 && k.pageCount < 2) {
                    if (g[0]) {
                        g.remove()
                    }
                        a("#batchFollow").html('您刚来，还没有个人动态。您可以 <a href="" onclick="myTrack.postModule.post_ready(); return false">发条动态</a> 或者 <a href="" onclick="Lives.setList(\'r5\'); return false">看看热门直播。</a>');
                        a("#batchFollow").css({
                            padding: "20px 10px",
                            display: "block"
                        })
                    }
                    return
                }
                var h = k.content,
                    d = h[0] && h[0].uid;
                for (var l = 0; l < h.length; l++) {
                    var n = h[l];
                    if (!l || n.uid != d) {
                        var m = a("<dl/>", {
                        });
                        o.appendChild(m[0]);
                        d = n.uid
                    }
                }
                try {
                    }
                var j = Math.ceil(k.pageCount / 2);
                var c = Math.ceil(k.p / 2);
                var f = getPageList({
                    nextPageStr: "myTrack.getFriendByClick",
                    page: c,
                    total_page: j,
                    prevImg: "<em>&lt;前页</em>",
                    nextImg: "<em>后页&gt;</em>"
                });
                if (f != "") {
                    var b = a("#friend_pagelist");
                    if (!b[0]) {
                        var b = a("<div/>", {
                            "class": "fpage",
                            id: "friend_pagelist"
                        })
                    }
                    b.html(f);
                }
            } else {
                if (k.flag != "203") {
                }
            }
        },
        ask_t: 0,
        askGet: function() {
        },
        askBack: function(c) {
            if (!c) {
                return
            }
            if (c.flag == "001") {
                if (c.content.msg > 0) {
                    } else {
                        b.msgCountBox.find(".num").html(c.content.msg);
                        b.msgCountBox.css("display", "inline-block")
                    }
                } else {
                    b.msgCountBox.css("display", "none")
                }
                if (c.content.com == 1) {
                    } else {
                    }
                }
                if (c.content.newfans != "0") {
                }
            } else {}
        },
        newMsgs: [],
        mT: 0,
        getNewMsg: function() {
        },
        newMsgBack: function(c) {
            if (c.flag == "001") {
                }
                var b = c.content.newid;
                if (b && b / 1 > 2) {
                }
            } else {}
        },
        get_img_src: function(c) {
            var b = c.match(/([^"]+?_s\.(?:jpg|png|gif))/g);
            return b
        },
        parseNewMsg: function(d) {
                return
            }
            var j = "#feed-" + h.id;
                return
            }
            var c = a("<dl/>", {
                id: j,
            });
                g = f.get_img_src(c.html());
            if (g) {
                b.onload = function() {
                    f.insertChild(c, f.friendBox);
                    c = null
                };
                b.src = g[0]
            } else {
                f.insertChild(c, f.friendBox);
                c = null
            }
            if (f.newMsgs.length > 0) {
                f.mT = setTimeout(a.proxy(f.parseNewMsg, f), 200)
            }
        },
        isNewCmt: 0,
        newCmts: [],
        cT: 0,
        getNewCmt: function() {
                return
            }
            if (b.length < 1) {
            }
        },
        newCmtBack: function(c) {
            if (!c) {
                return
            }
            if (c.flag == "001") {
                    return
                }
                    }
                } else {
                }
                if (c.newid && c.newid.length > 2) {
                }
            } else {}
        },
        getCmtHtml: function(b) {
            var c = "";
            if (b.content.fuid) {
            } else {
                if (b.content.fansqrid) {
                }
            }
        },
        getNewCmtDl: function(b) {
            return a("<dl/>", {
            })
        },
        parseNewCmt: function() {
                return
            }
        },
        parseNewCmtList: function() {
            }
        },
        clearNewCmtReaded: function() {
            if (!c[0]) {
                return
            }
            for (var b = 0; b < c.length; b++) {
                if (c.eq(b).hasClass("readed")) {
                    c.eq(b).remove()
                }
            }
            }
        },
        insertChild: function(d, c) {
            c.prepend(d);
            var b = d.height();
            if (!b) {
                return
            }
                return
            } else {
                d.css({
                    height: Math.ceil(b / 4),
                    opacity: 0
                });
                d.animate({
                    height: b,
                    opacity: 1
                }, 200, function() {
                    d.css("height", "auto")
                })
            }
        },
        removeChild: function(b) {
            b.remove()
        }
    }
})();
(function() {
        uid: 0,
        t_v: 0,
        t_h: 0,
        _btn: 0,
        init: function() {
                var c = b.card.card;
                c.bind("mouseover", function() {
                    if (b.card.style == "btn") {
                        b.onBox = 1
                    }
                });
                c.bind("mouseout", function() {
                    b.onBox = 0
                });
                c = null;
                a(document).bind("mousemove", function(f) {
                    var d = a(f.target);
                    if (d.attr("usercard") || b.onBox) {
                        b.getCard(d.attr("usercard"), jQuery(d))
                    } else {
                        b.hCard()
                    }
                })
            })
        },
        tmp: 1,
        getCard: function(c, b) {
                return
            }
                d.card.style = "btn";
                d.uid = c;
                d.card.getCard(c, b)
            }, 600)
        },
        hCard: function() {
                    b.uid = 0;
                    b.card.hCard()
                }, 300)
            }
        }
    }
})();
var WinScroll = {
    init: function() {
    },
    fns: {},
    getCount: function() {
        var a = 0;
            a++
        }
        return a
    },
    addFn: function(a) {
        }
    },
    delFn: function(a) {
            }
        }
    },
    scroll: function() {
        }
    },
    testPos: function(d, c) {
        return b > a
    },
    getTop: function() {
        var b = c.documentElement.scrollTop || c.body.scrollTop,
        return b + a
    },
    getPosition: function(a) {
        var d = a,
            c = 0,
            b = 0;
        while (d) {
            b += d.offsetTop;
            d = d.offsetParent
        }
        return {
            top: b,
            bottom: b + a.offsetHeight
        }
    }
};
(function() {
    };
        delay: 5000,
        cur: 0,
        initialize: function(d) {
                b = a(d.box);
                if (e.type == "mouseenter") {
                    c.stop();
                    b.addClass("focus-slide-show")
                } else {
                    c.start();
                    b.removeClass("focus-slide-show")
                }
            });
                e.preventDefault();
                c.change(a(this).attr("index") / 1)
            });
            b.find("a.prev").click(function() {
                c.next(0)
            });
            b.find("a.next").click(function() {
                c.next(1)
            });
        },
        reset: function() {
                d = [];
                d.push('<a index="' + b + '"></a>')
            }
                c.find(".pagechange").fadeIn(500);
            } else {
                c.find(".pagechange").hide()
            }
        },
        tm: 0,
        start: function() {
                b.next(1)
        },
        stop: function() {
        },
        next: function(b) {
            var c;
            if (b) {
            } else {
            }
                c = 0
            }
            if (c < 0) {
            }
        },
        change: function(b) {
                return
            }
            c.numBox.find("a").removeClass("cur").eq(b).addClass("cur");
            c.start()
        }
    })
})();
(function(c) {
    var a = '<div class="anchor-invite-pop-new">		<a class="close-big"></a>		<a class="mask" href="/{rid}" target="_blank" data-tracing="im_anchor_rec_go"></a>		<div class="anchor-box">			<dl class="fix">				<dt><img src="{picuser}"></dt>				<dd>					<span class="anchor">{alias}</span>					<span class="line"></span>					<span class="">{area}</span>				</dd>			</dl>			<div class="fans-box"><span class="live">直播</span>粉丝：{fans_num}人</div>		</div>		<div class="video-box">			<div id="minivideo_bd" style="visibility:hidden;"></div>		</div>		<a class="link-btn">去看看</a>		<p class="tip">房间人气爆满！<em>{watch_num}</em>人正在看</p>	</div>';
    var b = {
        singer_all: "歌区",
        fu1: "舞区",
        u2: "脱口秀",
        u3: "聊区"
    };
        id: "#minivideo_bd",
        _cd: 40 * 1000,
        init: function() {
            }
        },
        test: function() {
            c.getJSON("/event/regGift/recomAnchor.php", {
                t: +new Date
            }).done(function(e) {
                if (e.flag == "001") {
                    if (e.content.vurl.length) {
                        d.play(e.content)
                    }
                }
            })
        },
        play: function(d) {
                vid: d.vurl[0].vid,
                cover: d.vurl[0].picurl || "",
                user: {
                    rid: d.rid,
                    alias: d.username,
                    area: b[d.rtype] || "",
                    picuser: d.picuser,
                    fans_num: d.fansNum,
                    watch_num: d.count
                }
            };
        },
        loadBox: function() {
            var e = c.proxy(this, "remove");
            var f = a.replace(/{rid}/g, d.user.rid).replace(/{alias}/g, d.user.alias).replace(/{area}/g, d.user.area).replace(/{picuser}/g, d.user.picuser).replace(/{fans_num}/g, numF(d.user.fans_num)).replace(/{watch_num}/g, numF(d.user.watch_num));
                g.preventDefault();
                e()
            toZhangZhi("load", "im_anchor_rec")
        },
        setBoxView: function(d) {
                opacity: d ? 1 : 0,
                pointerEvents: d ? "auto" : "none"
            })
        },
        loadVideo: function() {
                vid: f.vid,
                width: "100",
                height: "100%",
                replay: true,
                autoplay: 1
            });
            var j = d.getPlayerType();
            var h = function() {
                var m = jQuery(l).replaceWith('<div id="' + k + '" ></div>');
                d.loadPlayer();
                d.on("ready", function() {
                    g.setBoxView(1);
                    var n = g.player = d._player;
                    n.setVolume(0);
                    setTimeout(function() {
                        n.play()
                    }, 200)
                });
                if (j == "no-support") {
                    g.remove()
                }
            };
            if (j == "flash" && e < 1) {
                jQuery(l).css("visibility", "visible")
            } else {
                h()
            }
        },
        remove: function() {
            try {
        }
    }
})(jQuery);
(function(f) {
    var o = '<div class="guide-visitor-pack">			<a class="close" data-tracing="closeBoxPullNew"></a>			<ul class="gift-list fix"></ul>			<a class="btn" data-tracing="clickBoxPullNew">登录领取</a>		</div>';
    var g = '<li>			<div class="img-box"><img src="{bsrc}"></div>			<p class="name">{name}</p>		</li>';
    var j = '<div class="guide-visitor-pack-new">			<a class="mask"></a>			<div class="guide-visitor-ani"></div>		</div>';
    var b = '<div class="guide-visitor-ani"></div>';
    var k = [{
        title: "喜欢你",
        bsrc: "//vr0.xiu123.cn/images/room2020/guide_gift_g1_b.png"
    }, {
        title: "充值返利券",
        bsrc: "//vr0.xiu123.cn/images/room2020/guide_gift_g2_b.png"
    }, {
        title: "首充大礼包",
        bsrc: "//vr0.xiu123.cn/images/room2020/guide_gift_g3_b_v1.png"
    }];
    var a = function(r) {
        var q = [];
        f.each(k, function(s, t) {
            q.push(r.replace(/{title}/g, t.title).replace(/{bsrc}/g, t.bsrc))
        });
        return q.join("")
    };
    var c = true;
    var e = {
        _cd: 10 * 1000,
        init: function() {
            setTimeout(function() {
                    e.test()
                } else {
                        e.test()
                    })
                }
        },
        test: function() {
            f.getJSON("/event/regGift/regGift.php", {
                act: "pop",
            }).done(function(q) {
                if (q.flag == "001") {
                    e.vis()
                }
            })
        },
        vis: function() {
            }
            if (c) {
                }
            }
        },
        hid: function(q) {
            }
        },
        review: function() {
        },
        _clickHandler: function(s) {
            s.preventDefault();
            var q = f(s.target);
            if (q.hasClass("close")) {
            } else {
                if (q.hasClass("mask")) {
                    } else {
                    }
                } else {
                }
            }
        },
        getAward: function() {
            var q = {
                act: "getAward",
                rid: 0,
            };
            f.extend(q, zhangZhiParam());
            f.getJSON("/event/regGift/regGift.php", q).done(function(s) {
                if (s.flag == "001") {
                    if (r.box) {
                        setTimeout(function() {
                            r.box.off().remove()
                        }, 1000)
                    }
                    }
                    setTimeout(function() {
                        h.vis()
                    }, 1000 * 5);
                    setTimeout(function() {
                        h.destroy()
                    }, 1000 * 15)
                } else {
                }
            })
        },
        _bindDocumentEvent: function() {},
        _unBindDocumentEvent: function() {}
    };
    var l = {
        loaded: false,
        index: 0,
        imgs: [],
        url: "//vr0.xiu123.cn/images/room2020/zadan/v2/",
        init: function() {
            for (var r = 1; r <= 17; r++) {
                q.onload = function() {
                    s.loadTest()
                };
                q.onerror = function() {
                    s.loadTest()
                };
                q.src = t;
            }
        },
        loadTest: function() {
            }
        },
        play: function(q, r) {
                return
            }
        },
        _shan: function() {
            });
            } else {
            }
        },
        setAni: function(t) {
                s, q;
                s = +new Date();
                t(s);
                q = +new Date();
                r.timeout = 1000 / 4
            }, r.timeout)
        }
    };
        replayIndex: 0,
        replay: function(s, t, u) {
            var q = function() {
                r.replayIndex++;
                if (r.replayIndex < t) {
                } else {
                    r.replayIndex = 0;
                    u && u()
                }
            };
        }
    });
    var d = '<div class="logined-visitor-pack">			<a class="close"></a>			<ul class="gift-list fix"></ul>			<p class="btn-line">				<a class="btn">我知道了</a>			</p>		</div>';
    var m = '<li>				<div class="img-box">					<img src="{bsrc}" alt="">				</div>				<h4>{title}</h4>			</li>';
    var h = {
        vis: function() {
                return
            }
            }
        },
        hid: function() {
                var q = f.proxy(this, "destroy");
            }
        },
        destroy: function() {
            }
        },
        _clickHandler: function(q) {
            q.preventDefault();
        }
    };
    var n = f.cookie("logtm");
        })
    }
})(jQuery);
(function(a) {
        init: function() {
            b.box.find(".getBtn").click(function() {
                a.getJSON("/crystalNoble/dailyGift.php", function(c) {
                    b.box.remove()
                })
            });
            b.box.find(".close").click(function() {
                b.box.remove()
            })
        }
    };
            b.on("onVisible", function() {
            })
        })
    }
})(jQuery);