/*!
 * isVis - v0.5.5 Aug 2011 - Page Visibility API Polyfill
 * Copyright (c) 2011 Addy Osmani
 * Dual licensed under the MIT and GPL licenses.
 */
(function() {
        b: null,
        p: undefined,
        prefixes: ["webkit", "ms"],
        props: ["VisibilityState", "visibilitychange", "Hidden"],
        m: ["focus", "blur"],
        visibleCallbacks: [],
        hiddenCallbacks: [],
        _callbacks: [],
        onVisible: function(a) {
        },
        onHidden: function(a) {
        },
        isSupported: function() {
        },
        _supports: function(a) {
        },
        runCallbacks: function(a) {
            if (a) {
                }
            }
        },
        _visible: function() {
        },
        _hidden: function() {
        },
        _nativeSwitch: function() {
        },
        listen: function() {
            try {
                    } else {
                    }
                } else {
                    }, 1)
                }
        },
        init: function() {
        }
    };
})();
(function() {
    var userAgent = navigator.userAgent;
    var isIE = /MSIE|Edge|Trident/i.test(userAgent);
    var isMobile = /Android|webOS|iPhone|iPad|iPod|BB10|IEMobile/i.test(userAgent);
    var isApp = /^\S+(\sSonic\/[\d.]+)?$/.test(userAgent);
    var LANCE_API = "//shrek.6.cn/live.6.cn/e6u2/rp.php";
    var LANCE_CALLBACK = (new Date().getTime()).toString(36);
    var ZHANG_ZHI_API = "//sclick.xiu123.cn/s.html";
    var ZHANG_ZHI_QUERY_NAME = "_tra_";
    var ZHANG_ZHI_COOKIE_NAME = "_tracing";
    var ZHANG_ZHI_COOKIE_DOMAIN = isIE ? "" : "6.cn";
    if (isApp) {
        return
    }
    via._h = via._h || [];
    via.uuid = "";
    via.ready = function(handler) {
        }
    };
    via.triggerReady = function() {
        var handler;
        while (handler = handlerList.shift()) {
        }
    };
    var cookie = {
        _createCookieString: function(name, value, options) {
            var text = name + "=" + encodeURIComponent(value);
            var options = options || {};
            var expires = options.expires;
            var domain = options.domain;
            var path = options.path || "/";
            if (expires instanceof Date) {
                text += ";expires=" + expires.toUTCString()
            }
            if (domain) {
                text += ";domain=" + domain
            }
            if (path) {
                text += ";path=" + path
            }
            if (options.secure === true) {
                text += ";secure"
            }
            return text
        },
        _parseCookieString: function(text) {
            if (!text) {
                return null
            }
            var cookies = {};
            var cookiePark = text.split(/;\s/g);
            var cookieNameValue;
            for (var i = 0; i < cookiePark.length; i++) {
                cookieNameValue = cookiePark[i].split("=");
                cookies[cookieNameValue[0]] = decodeURIComponent(cookieNameValue[1])
            }
            return cookies
        },
        get: function(name) {
            if (cookies && cookies[name] !== undefined) {
                return cookies[name]
            }
            return null
        },
        set: function(name, value, options) {
            doc.cookie = text
        },
        remove: function(name, options) {
        }
    };
    var getFlashVersion = function() {
        var result = "-";
        if (navigator.plugins && navigator.plugins.length) {
            for (var c = 0; c < navigator.plugins.length; c++) {
                if (navigator.plugins[c].name.indexOf("Shockwave Flash") > -1) {
                    result = navigator.plugins[c].description.split("Shockwave Flash ")[1];
                    break
                }
            }
        } else {
                for (var c = 10; c >= 2; c--) {
                    try {
                        if (eval("new ActiveXObject('ShockwaveFlash.ShockwaveFlash." + c + "');")) {
                            result = c + ".0";
                            break
                        }
                }
            }
        }
        return result
    };
    var stripProtocal = function(url) {
        return encodeURIComponent(url.replace(/^https?\:\/\//, ""))
    };
    var getUid = function() {
        var result = "0";
        var vinfo = cookie.get("_vinfo");
        var coin6 = cookie.get("_coin6");
        var ticket = cookie.get("ticket_v");
        if (ticket && vinfo && vinfo != "deleted" && coin6) {
            result = coin6.split(":")[0]
        }
        return result
    };
    var insertScript = function(url) {
        script.type = "text/javascript";
        script.src = url;
        head.insertBefore(script, head.firstChild)
    };
    var toLance = function() {
    };
    var checkCrawler = function() {
        var reg = new RegExp("Baiduspider|Googlebot|\\sSlurp|iaskspider|YodaoBot|msnbot|\\sspider", "i");
        return reg.test(userAgent)
    };
    var identifyPageName = function() {
        var pathname = loc.pathname;
        var result = pathname;
        if (pathname == "/") {
        } else {
            if (/^\/\d+$/.test(pathname)) {
                result = "room";
                        result = "room_dating"
                    } else {
                            result = "room_voice"
                        } else {
                                result = "room_voice_personal"
                            }
                        }
                    }
                }
            } else {
                if (/^\/minivideo\/$/.test(pathname)) {
                    result = "mvideo"
                } else {
                    if (/^\/profile\/watchMini\.php$/.test(pathname)) {
                        result = "vplay"
                    } else {
                        if (/^\/f\/\d+$/.test(pathname)) {
                            result = "room_family"
                        } else {
                            if (/^\/f\/p\/\d+\.html$/.test(pathname)) {
                                result = "family_index"
                            } else {
                                if (/^\/video\/\d+\.html$/.test(pathname)) {
                                    result = "video_play"
                                } else {
                                    result = pathname
                                }
                            }
                        }
                    }
                }
            }
        }
        return result
    };
    var identifyPageId = function(pageName) {
        var url = loc.href;
        var pathname = loc.pathname;
        var reg = [];
        var result = "";
        if (pageName == "room" || pageName == "room_family" || pageName == "room_dating" || pageName == "room_voice" || pageName == "room_voice_personal") {
        } else {
            if (pageName == "vplay") {
            } else {
                if (pageName == "family_index") {
                } else {
                    if (pageName == "video_play") {
                        reg = pathname.match(/^\/video\/(\d+)\.html$/);
                        result = reg[1]
                    } else {
                        if (pageName.indexOf("coopgame/play.php") > -1) {
                        } else {
                            result = ""
                        }
                    }
                }
            }
        }
        return result
    };
    var identifyClickTarget = function(target) {
        var event = "click";
        var mod = "noname";
        var url = "";
        var topageid = "";
        var parentAnchor = null;
        while (target && target.parentNode) {
            if (target.tagName.toLowerCase() == "a") {
                var href = target.getAttribute("href");
                if (href && href.indexOf("#") < 0) {
                    event = "in";
                    url = href;
                    parentAnchor = target;
                    var reg = href.match(/\/(\d+)\/?/) || href.match(/\?vid=(\d+)\/?/) || [];
                    topageid = reg[1] || ""
                }
            }
            var dataRecid;
            if ((dataRecid = target.getAttribute("data-recid"))) {
                recid = dataRecid
            }
            var dataTracing;
            if ((dataTracing = target.getAttribute("data-tracing"))) {
                mod = dataTracing;
            } else {
            }
        }
        return {
            event: event,
            mod: mod,
            url: url,
            recid: recid,
            topageid: topageid,
            parentAnchor: parentAnchor
        }
    };
    var makeTracingCode = function(pageName, mdouleId) {
        return pageName + "-" + mdouleId
    };
    var _serialize = function(obj) {
        var str = [];
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]))
            }
        }
        return str.join("&")
    };
    var _toZhangZhi = function(event, mod, extraData) {
        var resolution = screen.width + "/" + screen.height;
        var _rid = "";
        } else {
            }
        }
        var params = {};
        var extraData = extraData || {};
        var url = extraData.url || "";
        $.extend(params, extraData, {
            event: event,
            module: mod || "noname",
            rid: _rid,
            data: userInfo,
            recid: recid,
        });
        if (event == "in") {
            $.extend(params, {
                topageid: extraData.topageid || "",
                url: url
            })
        }
        if (event == "load") {
            $.extend(params, {
                resolution: resolution,
                url: url,
            })
        }
        if (event == "in") {
            if (url && (url.indexOf("payshow.php") > -1 || url.indexOf("replacePayshow.php") > -1 || url.indexOf("paygame.php") > -1 || url.indexOf("ylPayShow.php") > -1)) {
                    return
                }
                    domain: ZHANG_ZHI_COOKIE_DOMAIN
                })
            } else {
                    domain: ZHANG_ZHI_COOKIE_DOMAIN
                })
            }
        }
    };
    var establishZhangZhiAnalytic = function(uuid, reft) {
                    return
                }
                var loadModule = "";
                if (pageName == "index") {
                        var recid = "";
                        var pattern = /recid\=([^\&\#]+)(?:\&|$|\#)/;
                        var match = pattern.exec(url);
                        var recid = match && match[1] || "";
                        _toZhangZhi("in", tracing || "ipvafi4f", {
                            url: url,
                            recid: recid
                        })
                    }
                }
                if (pageName == "room") {
                        _toZhangZhi("in", "iqrfeduc", {
                            url: "https://v.6.cn" + url
                        })
                    }
                }
                if (pageName == "room" || pageName == "vplay" || pageName == "room_dating" || pageName == "room_voice" || pageName == "room_voice_personal" || pageName.indexOf("coopgame/play.php") > -1) {
                    var count = 0;
                    var accumulator = 0;
                    var setTimeoutTime = 0;
                    var beatPaused = true;
                    var timer = null;
                    loadModule = "live";
                    if (pageName == "vplay") {
                        loadModule = "video"
                    } else {
                        if (pageName.indexOf("coopgame/play.php") > -1) {
                            loadModule = "play"
                        }
                    }
                    var getInterval = function() {
                        var result = 60;
                        if (count < 3) {
                            result = 5
                        } else {
                            if (count < 6) {
                                result = 10
                            } else {
                                if (count < 9) {
                                    result = 30
                                }
                            }
                        }
                        return result
                    };
                    var prepareNextBeat = function() {
                        cancelNextBeat();
                        setTimeoutTime = (new Date()).getTime();
                        timer = setTimeout(heartBeat, getInterval() * 1000)
                    };
                    var cancelNextBeat = function() {
                        clearTimeout(timer)
                    };
                    var startHeartBeat = function() {
                        if (beatPaused) {
                            prepareNextBeat();
                            beatPaused = false
                        }
                    };
                    var pauseHeartBeat = function() {
                        if (!beatPaused) {
                            cancelNextBeat();
                            reportHeartBeat();
                            beatPaused = true
                        }
                    };
                    var reportHeartBeat = function() {
                        var now = (new Date()).getTime();
                        var durationFromLast = Math.round((Math.min(now - setTimeoutTime, 60 * 1000)) / 1000);
                        var lookType = 0;
                        var param = {};
                        accumulator += durationFromLast;
                        }
                        var _rid = 0;
                        } else {
                            }
                        }
                        param = {
                            tm: durationFromLast,
                            looktm: accumulator,
                            lookType: lookType,
                            event: "loop",
                            module: loadModule,
                            rid: _rid,
                            data: userInfo,
                        };
                        if (durationFromLast > 3) {
                        }
                    };
                    var heartBeat = function() {
                        count++;
                        reportHeartBeat();
                        prepareNextBeat()
                    };
                    var mouseoverHandler = function(event) {
                        startHeartBeat();
                        $(document).off("mouseover", mouseoverHandler)
                    };
                    var detectAction = function() {
                        $(document).on("mouseover", mouseoverHandler);
                        pauseHeartBeat();
                        setTimeout(detectAction, 15 * 60 * 1000)
                    };
                    startHeartBeat();
                    setTimeout(detectAction, 15 * 60 * 1000)
                }
                if (pageName == "index" || pageName == "room" || pageName == "mvideo" || pageName == "vplay") {
                    $(document).on("click", function(event) {
                        if (event.originalEvent) {
                            var target = event.target;
                            var identity = identifyClickTarget(target);
                            if (identity.event == "in") {
                                _toZhangZhi(identity.event, identity.mod, {
                                    url: identity.url,
                                    recid: identity.recid,
                                    topageid: identity.topageid
                                })
                            } else {
                                if (identity.mod) {
                                    _toZhangZhi(identity.event, identity.mod, {
                                        url: identity.url,
                                        recid: identity.recid
                                    })
                                }
                            }
                            if (isIE && identity.event == "in" && loc.hostname == "www.6.cn" && identity.url.indexOf(ZHANG_ZHI_QUERY_NAME) < 0 && identity.parentAnchor) {
                                var url = identity.url;
                                var explodeByHash = url.split("#");
                                var hash = explodeByHash[1] ? "#" + explodeByHash[1] : "";
                                var urlWithoutHash = explodeByHash[0];
                                url += (urlWithoutHash.indexOf("?") > -1 ? "&" : "?") + ZHANG_ZHI_QUERY_NAME + "=" + tracingCode + hash;
                                identity.parentAnchor.href = url
                            }
                        }
                    })
                } else {
                    $(document).on("click", function(event) {
                        if (event.originalEvent) {
                            var target = event.target;
                            var identity = identifyClickTarget(target);
                            if (identity.event == "in") {
                                _toZhangZhi(identity.event, identity.mod, {
                                    url: identity.url,
                                    recid: identity.recid,
                                    topageid: identity.topageid
                                })
                            }
                        }
                    })
                }
                setTimeout(function() {
                    _toZhangZhi("load", loadModule, {
                        url: loc.href
                    })
                }, 500);
                if (loc.search.indexOf(ZHANG_ZHI_QUERY_NAME + "=") > -1) {
                    var pattern = new RegExp(ZHANG_ZHI_QUERY_NAME + "\\=(.*)(?:$|\\&)");
                    var matchObj = pattern.exec(loc.search);
                    var tracingCookie = matchObj ? matchObj[1].split("|") : [];
                } else {
                    var tracingCookie = (cookie.get(ZHANG_ZHI_COOKIE_NAME) || "").split("|");
                }
                cookie.remove(ZHANG_ZHI_COOKIE_NAME, {
                    domain: ZHANG_ZHI_COOKIE_DOMAIN
                });
                if (loc.search.indexOf(ZHANG_ZHI_QUERY_NAME + "=") == -1) {
                    $(window).on("beforeunload", function() {
                                domain: ZHANG_ZHI_COOKIE_DOMAIN
                            })
                        }
                    })
                }
            })
        }
    };
        cookie.set("shrek_uuid", data.u || "", {
            expires: new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000)
        });
        var _reft = data.r || 0,
            _reftCK = cookie.get("shrek_reft");
        if (_reftCK) {
            _reftCK = _reftCK.split("|");
            if (_reftCK[1] == data.t) {
                _reft = _reftCK[0]
            }
        }
        cookie.set("shrek_reft", _reft + "|" + data.t, {
            domain: "6.cn",
            expires: new Date(new Date().getTime() + 30 * 24 * 60 * 60 * 1000)
        });
        if (isMobile && data.u && data.t) {
            cookie.set("shrek", data.u + "|" + data.t + "|" + _reft, {
                domain: "6.cn"
            })
        }
        via.uuid = data.u || 0;
        via.triggerReady();
        setTimeout(function() {
            establishZhangZhiAnalytic(data.u || "", _reft)
        }, 500);
        if (data.o) {
            cookie.set("_apkReft", data.o, {
                path: "/event/liveClient"
            })
        }
    };
    toLance()
})();