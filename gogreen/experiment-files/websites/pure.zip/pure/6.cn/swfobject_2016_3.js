/*!    SWFObject v2.3.20130521 <http://github.com/swfobject/swfobject>
    is released under the MIT License <http://www.opensource.org/licenses/mit-license.php>
*/
var swfobject = function() {
    var C = "undefined",
        q = "object",
        T = "Shockwave Flash",
        Z = "ShockwaveFlash.ShockwaveFlash",
        p = "application/x-shockwave-flash",
        S = "SWFObjectExprInst",
        w = "onreadystatechange",
        V = false,
        X = [],
        n = [],
        P = [],
        K = [],
        H, o, D, A, L = false,
        a = false,
        l, F, j = true,
        J = false,
        O = function() {
            var ad = typeof h.getElementById !== C && typeof h.getElementsByTagName !== C && typeof h.createElement !== C,
                ak = s.userAgent.toLowerCase(),
                ab = s.platform.toLowerCase(),
                ah = ab ? /win/.test(ab) : /win/.test(ak),
                af = ab ? /mac/.test(ab) : /mac/.test(ak),
                ai = /webkit/.test(ak) ? parseFloat(ak.replace(/^.*webkit\/(\d+(\.\d+)?).*$/, "$1")) : false,
                aa = s.appName === "Microsoft Internet Explorer",
                aj = [0, 0, 0],
                ae = null;
            if (typeof s.plugins !== C && typeof s.plugins[T] === q) {
                ae = s.plugins[T].description;
                if (ae && (typeof s.mimeTypes !== C && s.mimeTypes[p] && s.mimeTypes[p].enabledPlugin)) {
                    V = true;
                    aa = false;
                    ae = ae.replace(/^.*\s+(\S+\s+\S+$)/, "$1");
                    aj[0] = m(ae.replace(/^(.*)\..*$/, "$1"));
                    aj[1] = m(ae.replace(/^.*\.(.*)\s.*$/, "$1"));
                    aj[2] = /[a-zA-Z]/.test(ae) ? m(ae.replace(/^.*[a-zA-Z]+(.*)$/, "$1")) : 0
                }
            } else {
                if (typeof Q.ActiveXObject !== C) {
                    try {
                        if (ag) {
                            ae = ag.GetVariable("$version");
                            if (ae) {
                                aa = true;
                                ae = ae.split(" ")[1].split(",");
                                aj = [m(ae[0]), m(ae[1]), m(ae[2])]
                            }
                        }
                }
            }
            return {
                w3: ad,
                pv: aj,
                wk: ai,
                ie: aa,
                win: ah,
                mac: af
            }
        }(),
        i = function() {
            if (!O.w3) {
                return
            }
            if ((typeof h.readyState !== C && (h.readyState === "complete" || h.readyState === "interactive")) || (typeof h.readyState === C && (h.getElementsByTagName("body")[0] || h.body))) {
                f()
            }
            if (!L) {
                if (typeof h.addEventListener !== C) {
                    h.addEventListener("DOMContentLoaded", f, false)
                }
                if (O.ie) {
                    h.attachEvent(w, function aa() {
                        if (h.readyState === "complete") {
                            h.detachEvent(w, aa);
                            f()
                        }
                    });
                        (function ac() {
                            if (L) {
                                return
                            }
                            try {
                                h.documentElement.doScroll("left")
                                setTimeout(ac, 0);
                                return
                            }
                            f()
                        }())
                    }
                }
                if (O.wk) {
                    (function ab() {
                        if (L) {
                            return
                        }
                        if (!/loaded|complete/.test(h.readyState)) {
                            setTimeout(ab, 0);
                            return
                        }
                        f()
                    }())
                }
            }
        }();

    function f() {
            return
        }
        try {
            var ac, ad = B("span");
            ad.style.display = "none";
            ac = h.getElementsByTagName("body")[0].appendChild(ad);
            ac.parentNode.removeChild(ac);
            ac = null;
            ad = null
            return
        }
        L = true;
        var aa = X.length;
        for (var ab = 0; ab < aa; ab++) {
            X[ab]()
        }
    }

    function M(aa) {
        if (L) {
            aa()
        } else {
            X[X.length] = aa
        }
    }

    function r(ab) {
        if (typeof Q.addEventListener !== C) {
            Q.addEventListener("load", ab, false)
        } else {
            if (typeof h.addEventListener !== C) {
                h.addEventListener("load", ab, false)
            } else {
                if (typeof Q.attachEvent !== C) {
                    g(Q, "onload", ab)
                } else {
                    if (typeof Q.onload === "function") {
                        var aa = Q.onload;
                        Q.onload = function() {
                            aa();
                            ab()
                        }
                    } else {
                        Q.onload = ab
                    }
                }
            }
        }
    }

    function Y() {
        var aa = h.getElementsByTagName("body")[0];
        var ae = B(q);
        ae.setAttribute("style", "visibility: hidden;");
        ae.setAttribute("type", p);
        var ad = aa.appendChild(ae);
        if (ad) {
            var ac = 0;
            (function ab() {
                if (typeof ad.GetVariable !== C) {
                    try {
                        var ag = ad.GetVariable("$version");
                        if (ag) {
                            ag = ag.split(" ")[1].split(",");
                            O.pv = [m(ag[0]), m(ag[1]), m(ag[2])]
                        }
                        O.pv = [8, 0, 0]
                    }
                } else {
                    if (ac < 10) {
                        ac++;
                        setTimeout(ab, 10);
                        return
                    }
                }
                aa.removeChild(ae);
                ad = null;
                G()
            }())
        } else {
            G()
        }
    }

    function G() {
        var aj = n.length;
        if (aj > 0) {
            for (var ai = 0; ai < aj; ai++) {
                var ab = n[ai].id;
                var ae = n[ai].callbackFn;
                var ad = {
                    success: false,
                    id: ab
                };
                if (O.pv[0] > 0) {
                    var ah = c(ab);
                    if (ah) {
                        if (E(n[ai].swfVersion) && !(O.wk && O.wk < 312)) {
                            v(ab, true);
                            if (ae) {
                                ad.success = true;
                                ad.ref = y(ab);
                                ad.id = ab;
                                ae(ad)
                            }
                        } else {
                            if (n[ai].expressInstall && z()) {
                                var al = {};
                                al.data = n[ai].expressInstall;
                                al.width = ah.getAttribute("width") || "0";
                                al.height = ah.getAttribute("height") || "0";
                                if (ah.getAttribute("class")) {
                                    al.styleclass = ah.getAttribute("class")
                                }
                                if (ah.getAttribute("align")) {
                                    al.align = ah.getAttribute("align")
                                }
                                var ak = {};
                                var aa = ah.getElementsByTagName("param");
                                var af = aa.length;
                                for (var ag = 0; ag < af; ag++) {
                                    if (aa[ag].getAttribute("name").toLowerCase() !== "movie") {
                                        ak[aa[ag].getAttribute("name")] = aa[ag].getAttribute("value")
                                    }
                                }
                                R(al, ak, ab, ae)
                            } else {
                                b(ah);
                                if (ae) {
                                    ae(ad)
                                }
                            }
                        }
                    }
                } else {
                    v(ab, true);
                    if (ae) {
                        var ac = y(ab);
                        if (ac && typeof ac.SetVariable !== C) {
                            ad.success = true;
                            ad.ref = ac;
                            ad.id = ac.id
                        }
                        ae(ad)
                    }
                }
            }
        }
    }
    X[0] = function() {
        if (V) {
            Y()
        } else {
            G()
        }
    };

    function y(ac) {
        var aa = null,
            ab = c(ac);
        if (ab && ab.nodeName.toUpperCase() === "OBJECT") {
            if (typeof ab.SetVariable !== C) {
                aa = ab
            } else {
                aa = ab.getElementsByTagName(q)[0] || ab
            }
        }
        return aa
    }

    function z() {
        return !a && E("6.0.65") && (O.win || O.mac) && !(O.wk && O.wk < 312)
    }

    function R(ad, ae, aa, ac) {
        var ah = c(aa);
        a = true;
        D = ac || null;
        A = {
            success: false,
            id: aa
        };
        if (ah) {
            if (ah.nodeName.toUpperCase() === "OBJECT") {
                H = I(ah);
                o = null
            } else {
                H = ah;
                o = aa
            }
            if (typeof ad.width === C || (!/%$/.test(ad.width) && m(ad.width) < 310)) {
            }
            if (typeof ad.height === C || (!/%$/.test(ad.height) && m(ad.height) < 137)) {
            }
            var ag = O.ie ? "ActiveX" : "PlugIn",
                af = "MMredirectURL=" + encodeURIComponent(Q.location.toString().replace(/&/g, "%26")) + "&MMplayerType=" + ag + "&MMdoctitle=" + encodeURIComponent(h.title.slice(0, 47) + " - Flash Player Installation");
            if (typeof ae.flashvars !== C) {
            } else {
            }
            if (O.ie && ah.readyState != 4) {
                var ab = B("div");
                ab.setAttribute("id", aa);
                ah.parentNode.insertBefore(ab, ah);
                ah.style.display = "none";
                x(ah)
            }
            t(ad, ae, aa)
        }
    }

    function b(ab) {
        if (O.ie && ab.readyState != 4) {
            var aa = B("div");
            ab.parentNode.insertBefore(aa, ab);
            aa.parentNode.replaceChild(I(ab), aa);
            x(ab)
        } else {
            ab.parentNode.replaceChild(I(ab), ab)
        }
    }

    function I(af) {
        var ae = B("div");
        if (O.win && O.ie) {
            ae.innerHTML = af.innerHTML
        } else {
            var ab = af.getElementsByTagName(q)[0];
            if (ab) {
                var ag = ab.childNodes;
                if (ag) {
                    var aa = ag.length;
                    for (var ad = 0; ad < aa; ad++) {
                        if (!(ag[ad].nodeType == 1 && ag[ad].nodeName === "PARAM") && !(ag[ad].nodeType == 8)) {
                            ae.appendChild(ag[ad].cloneNode(true))
                        }
                    }
                }
            }
        }
        return ae
    }

    function k(aa, ab) {
        var ac = B("div");
        ac.innerHTML = "<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000'><param name='movie' value='" + aa + "'>" + ab + "</object>";
        return ac.firstChild
    }

    function t(ai, ah, ab) {
        var aa, ae = c(ab);
        if (O.wk && O.wk < 312) {
            return aa
        }
        if (ae) {
            var ad = (O.ie) ? B("div") : B(q),
                ag, ac, af;
            if (typeof ai.id === C) {
            }
            for (af in ah) {
                if (ah.hasOwnProperty(af) && af.toLowerCase() !== "movie") {
                    e(ad, af, ah[af])
                }
            }
            if (O.ie) {
                ad = k(ai.data, ad.innerHTML)
            }
            for (ag in ai) {
                if (ai.hasOwnProperty(ag)) {
                    ac = ag.toLowerCase();
                    if (ac === "styleclass") {
                        ad.setAttribute("class", ai[ag])
                    } else {
                        if (ac !== "classid" && ac !== "data") {
                            ad.setAttribute(ag, ai[ag])
                        }
                    }
                }
            }
            if (O.ie) {
                P[P.length] = ai.id
            } else {
                ad.setAttribute("type", p);
                ad.setAttribute("data", ai.data)
            }
            ae.parentNode.replaceChild(ad, ae);
            aa = ad
        }
        return aa
    }

    function e(ac, aa, ab) {
        var ad = B("param");
        ad.setAttribute("name", aa);
        ad.setAttribute("value", ab);
        ac.appendChild(ad)
    }

    function x(ac) {
        var ab = c(ac);
        if (ab && ab.nodeName.toUpperCase() === "OBJECT") {
            if (O.ie) {
                ab.style.display = "none";
                (function aa() {
                    if (ab.readyState == 4) {
                        for (var ad in ab) {
                            if (typeof ab[ad] === "function") {
                                ab[ad] = null
                            }
                        }
                        ab.parentNode.removeChild(ab)
                    } else {
                        setTimeout(aa, 10)
                    }
                }())
            } else {
                ab.parentNode.removeChild(ab)
            }
        }
    }

    function U(aa) {
        return (aa && aa.nodeType && aa.nodeType === 1)
    }

    function W(aa) {
        return (U(aa)) ? aa.id : aa
    }

    function c(ac) {
        if (U(ac)) {
            return ac
        }
        var aa = null;
        try {
            aa = h.getElementById(ac)
        return aa
    }

    function B(aa) {
        return h.createElement(aa)
    }

    function m(aa) {
        return parseInt(aa, 10)
    }

    function g(ac, aa, ab) {
        ac.attachEvent(aa, ab);
        K[K.length] = [ac, aa, ab]
    }

    function E(ac) {
        var ab = O.pv,
            aa = ac.split(".");
        aa[0] = m(aa[0]);
        aa[1] = m(aa[1]) || 0;
        aa[2] = m(aa[2]) || 0;
        return (ab[0] > aa[0] || (ab[0] == aa[0] && ab[1] > aa[1]) || (ab[0] == aa[0] && ab[1] == aa[1] && ab[2] >= aa[2])) ? true : false
    }

    function u(af, ab, ag, ae) {
        var ad = h.getElementsByTagName("head")[0];
        if (!ad) {
            return
        }
        var aa = (typeof ag === "string") ? ag : "screen";
        if (ae) {
            l = null;
            F = null
        }
        if (!l || F != aa) {
            var ac = B("style");
            ac.setAttribute("type", "text/css");
            ac.setAttribute("media", aa);
            l = ad.appendChild(ac);
            if (O.ie && typeof h.styleSheets !== C && h.styleSheets.length > 0) {
                l = h.styleSheets[h.styleSheets.length - 1]
            }
            F = aa
        }
        if (l) {
            if (typeof l.addRule !== C) {
                l.addRule(af, ab)
            } else {
                if (typeof h.createTextNode !== C) {
                    l.appendChild(h.createTextNode(af + " {" + ab + "}"))
                }
            }
        }
    }

    function v(ad, aa) {
        if (!j) {
            return
        }
        var ab = aa ? "visible" : "hidden",
            ac = c(ad);
        if (L && ac) {
            ac.style.visibility = ab
        } else {
            if (typeof ad === "string") {
                u("#" + ad, "visibility:" + ab)
            }
        }
    }

    function N(ab) {
        var ac = /[\\\"<>\.;]/;
        var aa = ac.exec(ab) !== null;
    }
    var d = function() {
        if (O.ie) {
                var af = K.length;
                for (var ae = 0; ae < af; ae++) {
                    K[ae][0].detachEvent(K[ae][1], K[ae][2])
                }
                var ac = P.length;
                for (var ad = 0; ad < ac; ad++) {
                    x(P[ad])
                }
                for (var ab in O) {
                    O[ab] = null
                }
                O = null;
                }
            })
        }
    }();
    return {
        registerObject: function(ae, aa, ad, ac) {
            if (O.w3 && ae && aa) {
                var ab = {};
                ab.id = ae;
                ab.swfVersion = aa;
                ab.expressInstall = ad;
                ab.callbackFn = ac;
                n[n.length] = ab;
                v(ae, false)
            } else {
                if (ac) {
                    ac({
                        success: false,
                        id: ae
                    })
                }
            }
        },
        getObjectById: function(aa) {
            if (O.w3) {
                return y(aa)
            }
        },
        embedSWF: function(af, al, ai, ak, ab, ae, ad, ah, aj, ag) {
            var ac = W(al),
                aa = {
                    success: false,
                    id: ac
                };
            if (O.w3 && !(O.wk && O.wk < 312) && af && al && ai && ak && ab) {
                v(ac, false);
                M(function() {
                    var an = {};
                    if (aj && typeof aj === q) {
                        for (var aq in aj) {
                            an[aq] = aj[aq]
                        }
                    }
                    an.data = af;
                    an.width = ai;
                    an.height = ak;
                    var ar = {};
                    if (ah && typeof ah === q) {
                        for (var ao in ah) {
                            ar[ao] = ah[ao]
                        }
                    }
                    if (ad && typeof ad === q) {
                        for (var am in ad) {
                            if (ad.hasOwnProperty(am)) {
                                var ap = (J) ? encodeURIComponent(am) : am,
                                    at = (J) ? encodeURIComponent(ad[am]) : ad[am];
                                if (typeof ar.flashvars !== C) {
                                    ar.flashvars += "&" + ap + "=" + at
                                } else {
                                    ar.flashvars = ap + "=" + at
                                }
                            }
                        }
                    }
                    if (E(ab)) {
                        var au = t(an, ar, al);
                        if (an.id == ac) {
                            v(ac, true)
                        }
                        aa.success = true;
                        aa.ref = au;
                        aa.id = au.id
                    } else {
                        if (ae && z()) {
                            an.data = ae;
                            R(an, ar, al, ag);
                            return
                        } else {
                            v(ac, true)
                        }
                    }
                    if (ag) {
                        ag(aa)
                    }
                })
            } else {
                if (ag) {
                    ag(aa)
                }
            }
        },
        switchOffAutoHideShow: function() {
            j = false
        },
        enableUriEncoding: function(aa) {
            J = (typeof aa === C) ? true : aa
        },
        ua: O,
        getFlashPlayerVersion: function() {
            return {
                major: O.pv[0],
                minor: O.pv[1],
                release: O.pv[2]
            }
        },
        createSWF: function(ac, ab, aa) {
            if (O.w3) {
                return t(ac, ab, aa)
            } else {
                return undefined
            }
        },
        showExpressInstall: function(ac, ad, aa, ab) {
            if (O.w3 && z()) {
                R(ac, ad, aa, ab)
            }
        },
        removeSWF: function(aa) {
            if (O.w3) {
                x(aa)
            }
        },
        createCSS: function(ad, ac, ab, aa) {
            if (O.w3) {
                u(ad, ac, ab, aa)
            }
        },
        getQueryParamValue: function(ad) {
            var ac = h.location.search || h.location.hash;
            if (ac) {
                if (/\?/.test(ac)) {
                    ac = ac.split("?")[1]
                }
                if (!ad) {
                    return N(ac)
                }
                var ab = ac.split("&");
                for (var aa = 0; aa < ab.length; aa++) {
                    if (ab[aa].substring(0, ab[aa].indexOf("=")) == ad) {
                        return N(ab[aa].substring((ab[aa].indexOf("=") + 1)))
                    }
                }
            }
            return ""
        },
        expressInstallCallback: function() {
            if (a) {
                var aa = c(S);
                if (aa && H) {
                    aa.parentNode.replaceChild(H, aa);
                    if (o) {
                        v(o, true);
                        if (O.ie) {
                            H.style.display = "block"
                        }
                    }
                    if (D) {
                        D(A)
                    }
                }
                a = false
            }
        },
        version: "2.3"
    }
}();
(function() {
    var a = {},
        d = {},
        c;
    (c = b.match(/edge\/([\d.]+)/)) ? d.edge = c[1]: (c = b.match(/rv:([\d.]+)\) like gecko/)) ? d.ie = c[1] : (c = b.match(/msie ([\d.]+)/)) ? d.ie = c[1] : (c = b.match(/firefox\/([\d.]+)/)) ? d.firefox = c[1] : (c = b.match(/chrome\/([\d.]+)/)) ? d.chrome = c[1] : (c = b.match(/opera.([\d.]+)/)) ? d.opera = c[1] : (c = b.match(/version\/([\d.]+).*safari/)) ? d.safari = c[1] : 0;
    if (d.edge) {
        a = {
            name: "edge",
            version: d.edge
        }
    }
    if (d.ie) {
        a = {
            name: "ie",
            version: d.ie
        }
    }
    if (d.firefox) {
        a = {
            name: "firefox",
            version: d.firefox
        }
    }
    if (d.chrome) {
        a = {
            name: "chrome",
            version: d.chrome
        }
    }
    if (d.opera) {
        a = {
            name: "opera",
            version: d.opera
        }
    }
    if (d.safari) {
        a = {
            name: "safari",
            version: d.safari
        }
    }
    a.version = parseFloat(a.version);
})();