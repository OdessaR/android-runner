! function(a) {
    var b = {
        uid: 48671,
        sections: "homepage",
        domain: "abc.net.au",
        flickerControl: !1,
        authors: ""
    };
        function d(a) {
            b.type = "text/javascript", b.async = !0, b.src = a, c.parentNode.insertBefore(b, c)
        }
    }
}(window);