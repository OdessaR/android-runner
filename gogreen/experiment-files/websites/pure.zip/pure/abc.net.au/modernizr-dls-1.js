/*! modernizr 3.5.0 (Custom Build) | MIT *
 * https://modernizr.com/download/?-cssgrid_cssgridlegacy-supports-setclasses !*/
! function(e, n, t) {
    function r(e, n) {
        return typeof e === n
    }

    function s() {
        var e, n, t, s, o, i, l;
        for (var a in C)
            if (C.hasOwnProperty(a)) {
                if (e = [], n = C[a], n.name && (e.push(n.name.toLowerCase()), n.options && n.options.aliases && n.options.aliases.length))
                    for (t = 0; t < n.options.aliases.length; t++) e.push(n.options.aliases[t].toLowerCase());
                for (s = r(n.fn, "function") ? n.fn() : n.fn, o = 0; o < e.length; o++) i = e[o], l = i.split("."), 1 === l.length ? Modernizr[l[0]] = s : (!Modernizr[l[0]] || Modernizr[l[0]] instanceof Boolean || (Modernizr[l[0]] = new Boolean(Modernizr[l[0]])), Modernizr[l[0]][l[1]] = s), w.push((s ? "" : "no-") + l.join("-"))
            }
    }

    function o(e) {
        var n = _.className,
            t = Modernizr._config.classPrefix || "";
        if (x && (n = n.baseVal), Modernizr._config.enableJSClass) {
            var r = new RegExp("(^|\\s)" + t + "no-js(\\s|$)");
            n = n.replace(r, "$1" + t + "js$2")
        }
        Modernizr._config.enableClasses && (n += " " + t + e.join(" " + t), x ? _.className.baseVal = n : _.className = n)
    }

    function i(e, n) {
        return !!~("" + e).indexOf(n)
    }

    function l() {
        return "function" != typeof n.createElement ? n.createElement(arguments[0]) : x ? n.createElementNS.call(n, "http://www.w3.org/2000/svg", arguments[0]) : n.createElement.apply(n, arguments)
    }

    function a() {
        var e = n.body;
        return e || (e = l(x ? "svg" : "body"), e.fake = !0), e
    }

    function u(e, t, r, s) {
        var o, i, u, f, d = "modernizr",
            p = l("div"),
            c = a();
        if (parseInt(r, 10))
        return o = l("style"), o.type = "text/css", o.id = "s" + d, (c.fake ? c : p).appendChild(o), c.appendChild(p), o.styleSheet ? o.styleSheet.cssText = e : o.appendChild(n.createTextNode(e)), p.id = d, c.fake && (c.style.background = "", c.style.overflow = "hidden", f = _.style.overflow, _.style.overflow = "hidden", _.appendChild(c)), i = t(p, e), c.fake ? (c.parentNode.removeChild(c), _.style.overflow = f, _.offsetHeight) : p.parentNode.removeChild(p), !!i
    }

    function f(e) {
        return e.replace(/([A-Z])/g, function(e, n) {
            return "-" + n.toLowerCase()
        }).replace(/^ms-/, "-ms-")
    }

    function d(n, t, r) {
        var s;
        if ("getComputedStyle" in e) {
            var o = e.console;
            if (null !== s) r && (s = s.getPropertyValue(r));
            else if (o) {
                var i = o.error ? "error" : "log";
                o[i].call(o, "getComputedStyle returning null, its possible modernizr test results are inaccurate")
            }
        } else s = !t && n.currentStyle && n.currentStyle[r];
        return s
    }

    function p(n, r) {
        var s = n.length;
        if ("CSS" in e && "supports" in e.CSS) {
            for (; s--;)
                if (e.CSS.supports(f(n[s]), r)) return !0;
            return !1
        }
        if ("CSSSupportsRule" in e) {
            for (var o = []; s--;) o.push("(" + f(n[s]) + ":" + r + ")");
            return o = o.join(" or "), u("@supports (" + o + ") { #modernizr { position: absolute; } }", function(e) {
                return "absolute" == d(e, null, "position")
            })
        }
        return t
    }

    function c(e) {
        return e.replace(/([a-z])-([a-z])/g, function(e, n, t) {
            return n + t.toUpperCase()
        }).replace(/^-/, "")
    }

    function m(e, n, s, o) {
        function a() {
            f && (delete E.style, delete E.modElem)
        }
            var u = p(e, s);
            if (!r(u, "undefined")) return u
        }
        for (var f, d, m, g, y, v = ["modernizr", "tspan", "samp"]; !E.style && v.length;) f = !0, E.modElem = l(v.shift()), E.style = E.modElem.style;
        for (m = e.length, d = 0; m > d; d++)
            if (g = e[d], y = E.style[g], i(g, "-") && (g = c(g)), E.style[g] !== t) {
                if (o || r(s, "undefined")) return a(), "pfx" == n ? g : !0;
                try {
                    E.style[g] = s
                if (E.style[g] != y) return a(), "pfx" == n ? g : !0
            } return a(), !1
    }

    function g(e, n) {
        return function() {
            return e.apply(n, arguments)
        }
    }

    function y(e, n, t) {
        var s;
        for (var o in e)
            if (e[o] in n) return t === !1 ? e[o] : (s = n[e[o]], r(s, "function") ? g(s, t || n) : s);
        return !1
    }

    function v(e, n, t, s, o) {
        var i = e.charAt(0).toUpperCase() + e.slice(1),
            l = (e + " " + P.join(i + " ") + i).split(" ");
        return r(n, "string") || r(n, "undefined") ? m(l, n, s, o) : (l = (e + " " + T.join(i + " ") + i).split(" "), y(l, n, t))
    }

    function h(e, n, r) {
        return v(e, t, t, n, r)
    }
    var C = [],
        S = {
            _version: "3.5.0",
            _config: {
                classPrefix: "",
                enableClasses: !0,
                enableJSClass: !0,
                usePrefixes: !0
            },
            _q: [],
            on: function(e, n) {
                setTimeout(function() {
                    n(t[e])
                }, 0)
            },
            addTest: function(e, n, t) {
                C.push({
                    name: e,
                    fn: n,
                    options: t
                })
            },
            addAsyncTest: function(e) {
                C.push({
                    name: null,
                    fn: e
                })
            }
        },
        Modernizr = function() {};
    Modernizr.prototype = S, Modernizr = new Modernizr;
    var w = [],
        _ = n.documentElement,
        x = "svg" === _.nodeName.toLowerCase(),
        b = "Moz O ms Webkit",
        P = S._config.usePrefixes ? b.split(" ") : [];
    S._cssomPrefixes = P;
    var z = {
        elem: l("modernizr")
    };
    Modernizr._q.push(function() {
        delete z.elem
    });
    var E = {
        style: z.elem.style
    };
    Modernizr._q.unshift(function() {
        delete E.style
    });
    var T = S._config.usePrefixes ? b.toLowerCase().split(" ") : [];
    var N = "CSS" in e && "supports" in e.CSS,
        j = "supportsCSS" in e;
    Modernizr.addTest("supports", N || j), s(), o(w), delete S.addTest, delete S.addAsyncTest;
    for (var k = 0; k < Modernizr._q.length; k++) Modernizr._q[k]();
}(window, document);