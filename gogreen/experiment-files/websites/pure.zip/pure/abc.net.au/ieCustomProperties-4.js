/*! ie11CustomProperties.js v4.0.1-modified | MIT License | https://git.io/fjXMN */ ! function() {
    "use strict";
        if (e.style.setProperty("--x", "y"), "y" === e.style.getPropertyValue("--x") || !e.msMatchesSelector) return;
        var t, r = [],

        function o(e, t) {
            try {
                return e.querySelectorAll(t)
            } catch (e) {
                return []
            }
        }

        function i(e, i) {
            for (var c, l = {
                    selector: e,
                    callback: i,
                    elements: new WeakMap
                }, u = o(n, l.selector), f = 0; c = u[f++];) l.elements.set(c, !0), l.callback.call(c, c);
                childList: !0,
                subtree: !0
            }), s(l)
        }

        function s(e, t) {
            var r, i = 0,
                s = [];
            try {
                t && t.matches(e.selector) && s.push(t)
            } catch (e) {}
            for (l && Array.prototype.push.apply(s, o(t || n, e.selector)); r = s[i++];) e.elements.has(r) || (e.elements.set(r, !0), e.callback.call(r, r))
        }

        function c(e) {
            for (var t, n = 0; t = r[n++];) s(t, e)
        }

        function a(e) {
            for (var t, r, n, o, i = 0; r = e[i++];)
                for (n = r.addedNodes, t = 0; o = n[t++];) 1 === o.nodeType && c(o)
        }
        var l = !1;

        function u(e, t, r) {
            var n = Object.getOwnPropertyDescriptor(t, e);
            Object.defineProperty(r, e, n)
        }
            l = !0
            get: function() {
            }
        });
        var f = {},
            p = new Set,
            d = !1,
            m = !1,
            v = /([\s{;])(--([A-Za-z0-9-_]*)\s*:([^;!}{]+)(!important)?)(?=\s*([;}]|$))/g,
            y = /([{;]\s*)([A-Za-z0-9-_]+\s*:[^;}{]*var\([^!;}{]+)(!important)?(?=\s*([;}$]|$))/g,
            h = /-ieVar-([^:]+):/g,
            S = /-ie-([^};]+)/g,
            E = /:(hover|active|focus|target|visited|link|:before|:after|:first-letter|:first-line)/;

        function P(e) {
            return e.replace(v, (function(e, t, r, n, o, i) {
                return t + "-ie-" + (i ? "❗" : "") + n + ":" + o
            })).replace(y, (function(e, t, r, n) {
                return t + "-ieVar-" + (n ? "❗" : "") + r + "; " + r
            }))
        }
        i('link[rel="stylesheet"]', (function(e) {
            var t, r, n;
            t = e.href, r = function(t) {
                var r = P(t);
                if (t !== r) {
                    r = function(e, t) {
                        return t.replace(/url\(([^)]+)\)/g, (function(t, r) {
                            return (r = r.trim().replace(/(^['"]|['"]$)/g, "")).match(/^([a-z]+:|\/)/) ? t : "url(" + (e = e.replace(/\?.*/, "")) + "./../" + r + ")"
                        }))
                    }(e.href, r), e.disabled = !0;
                    e.media && n.setAttribute("media", e.media), e.parentNode.insertBefore(n, e), C(n, r)
                }
                n.status >= 200 && n.status < 400 && r(n.responseText)
            }, n.send()
        })), i("style", (function(e) {
            if (!e.ieCP_polyfilled && !e.ieCP_elementSheet) {
                var t = e.innerHTML,
                    r = P(t);
                t !== r && C(e, r)
            }
        })), i("[ie-style]", (function(e) {
            var t = P("{" + e.getAttribute("ie-style")).substr(1);
            e.style.cssText += ";" + t;
            var r = g(e.style);
            r.getters && T(e, r.getters, "%styleAttr"), r.setters && M(e, r.setters)
        }));

        function g(e) {
            e["z-index"] === e && x();
            const t = e.cssText;
            var r, n, o = t.match(h);
            if (o) {
                var i = [];
                for (r = 0; n = o[r++];) {
                    let t = n.slice(7, -1);
                    "❗" === t[0] && (t = t.substr(1)), i.push(t), f[t] || (f[t] = []), f[t].push(e)
                }
            }
            var s = t.match(S);
            if (s) {
                var c = {};
                for (r = 0; n = s[r++];) {
                    let e = n.substr(4).split(":"),
                        t = e[0],
                        r = e[1];
                    "❗" === t[0] && (t = t.substr(1)), c[t] = r
                }
            }
            return {
            }
        }

        function C(e, t) {
            e.innerHTML = t, e.ieCP_polyfilled = !0;
            for (var r, n = e.sheet.rules, o = 0; r = n[o++];) {
                const e = g(r.style);
                e.getters && b(r.selectorText, e.getters), e.setters && L(r.selectorText, e.setters);
                const t = r.parentRule && r.parentRule.media && r.parentRule.media.mediaText;
                t && (e.getters || e.setters) && matchMedia(t).addListener((function() {
                }))
            }
            _()
        }

        function b(e, t) {
            A(e), i(H(e), (function(r) {
                T(r, t, e), O(r)
            }))
        }

        function T(e, t, r) {
            var n, o, i = 0;
            const s = r.split(",");
            for (e.setAttribute("iecp-needed", !0), e.ieCPSelectors || (e.ieCPSelectors = {}); n = t[i++];)
                for (o = 0; r = s[o++];) {
                    const t = r.trim().split("::");
                    e.ieCPSelectors[n] || (e.ieCPSelectors[n] = []), e.ieCPSelectors[n].push({
                        selector: t[0],
                        pseudo: t[1] ? "::" + t[1] : ""
                    })
                }
        }

        function L(e, t) {
            A(e), i(H(e), (function(e) {
                M(e, t)
            }))
        }

        function M(e, t) {
            for (var r in e.ieCP_setters || (e.ieCP_setters = {}), t) e.ieCP_setters["--" + r] = 1;
            k(e)
        }

        function _() {
            for (var e in f) {
                let o = f[e];
                for (var t, r = 0; t = o[r++];)
                    if (!t.owningElement) {
                        var n = t["-ieVar-" + e];
                            t[e] = n
                        } catch (e) {}
                    }
            }
        }
        var w = {
            hover: {
                on: "mouseenter",
                off: "mouseleave"
            },
            focus: {
                on: "focusin",
                off: "focusout"
            },
            active: {
                on: "CSSActivate",
                off: "CSSDeactivate"
            }
        };

        function A(e) {
            for (var t in e = e.split(",")[0], w) {
                var r = e.split(":" + t);
                if (r.length > 1) {
                    var n = r[1].match(/^[^\s]*/);
                    let e = H(r[0] + n);
                    const o = w[t];
                    i(e, (function(e) {
                        e.addEventListener(o.on, D), e.addEventListener(o.off, D)
                    }))
                }
            }
        }
        var V = null;

        function H(e) {
            return e.replace(E, "").replace(":not()", "")
        }

        function O(e) {
            p.add(e), d || (d = !0, requestAnimationFrame((function() {
                d = !1, m = !0, p.forEach(q), p.clear(), setTimeout((function() {
                    m = !1
                }))
            })))
        }
            setTimeout((function() {
                    t.initEvent("CSSActivate", !0, !0), (V = e.target).dispatchEvent(t)
                }
            }))
            if (V) {
                e.initEvent("CSSDeactivate", !0, !0), V.dispatchEvent(e), V = null
            }
        }));
        var B = 0;

        function q(e) {
            e.ieCP_unique || (e.ieCP_unique = ++B, e.classList.add("iecp-u" + e.ieCP_unique));
            var t = getComputedStyle(e);
            let r = "";
            for (var n in e.runtimeStyle.cssText = "", e.ieCPSelectors) {
                var o = t["-ieVar-❗" + n];
                let l = o || t["-ieVar-" + n];
                if (l) {
                    var i = {},
                        s = N(t, l, i);
                    o && (s += " !important");
                    for (var c, a = 0; c = e.ieCPSelectors[n][a++];) "%styleAttr" === c.selector && (e.style[n] = s), (o || !1 === i.allByRoot) && (c.pseudo ? r += c.selector + ".iecp-u" + e.ieCP_unique + c.pseudo + "{" + n + ":" + s + "}\n" : e.runtimeStyle[n] = s)
                }
            }! function(e, t) {
                if (!e.ieCP_styleEl && t) {
                }
                e.ieCP_styleEl && (e.ieCP_styleEl.innerHTML = t)
            }(e, r)
        }

        function k(e) {
            if (e) {
                var t = e.querySelectorAll("[iecp-needed]");
                e.hasAttribute && e.hasAttribute("iecp-needed") && O(e);
                for (var r, n = 0; r = t[n++];) O(r)
            }
        }

        function D(e) {
            k(e.target)
        }

        function N(e, t, r) {
            return function(e, t) {
                let r, n, o = 0,
                    i = null,
                    s = 0,
                    c = "",
                    a = 0;
                for (; r = e[a++];) {
                    if ("(" === r && (++o, null === i && e[a - 4] + e[a - 3] + e[a - 2] === "var" && (i = o, c += e.substring(s, a - 4), s = a), e[a - 5] + e[a - 4] + e[a - 3] + e[a - 2] === "calc" && (n = o)), ")" === r && i === o) {
                        let r, o = e.substring(s, a - 1).trim(),
                            l = o.indexOf(","); - 1 !== l && (r = o.slice(l + 1), o = o.slice(0, l)), c += t(o, r, n), s = a, i = null
                    }
                    ")" === r && (--o, n === o && (n = null))
                }
                return c += e.substring(s), c
            }(t, (function(t, n, o) {
                var i = e.getPropertyValue(t);
            }))
        }
            if (!m)
                for (var t, r = 0; t = e[r++];) "iecp-needed" !== t.attributeName && k(t.target)
        }));
        setTimeout((function() {
            R.observe(document, {
                attributes: !0,
                subtree: !0
            })
        }));
        addEventListener("hashchange", (function(e) {
            if (t) {
                k(t), k(r)
            } else k(document);
        }));
            z = F.get;
        F.get = function() {
            const e = z.call(this);
            var t = $.apply(this, arguments);
            return t.computedFor = e, t
        };
            I = G.getPropertyValue;
        G.getPropertyValue = function(e) {
            const t = e.substr(2),
                r = "-ie-" + t,
                n = "-ie-❗" + t;
                if (void 0 === o || Z[o]) {
                    if (Z[o] || !X[e] || X[e].inherits) {
                        for (; 1 === t.nodeType;) {
                            if (t.ieCP_setters && t.ieCP_setters[e]) {
                                var i = getComputedStyle(t),
                                    s = i[n] || i[r];
                                if (void 0 !== s) {
                                    break
                                }
                            }
                            t = t.parentNode
                        }
                    }
                if ("initial" === o) return ""
            }
            return void 0 === o && X[e] && (o = X[e].initialValue), void 0 === o ? "" : o
        };
        var Z = {
                inherit: 1,
                revert: 1,
                unset: 1
            },
            W = G.setProperty;
        G.setProperty = function(e, t, r) {
            if ("-" !== e[0] || "-" !== e[1]) return W.apply(this, arguments);
        var X = {};
            X[e.name] = e
        }
    }
}();