/*
 Nielsen SDK package v6.0.0.63 
 (c) 2017 The Nielsen Company 
*/
/* GLCFG build v5.5.5.2*/
window.NOLCMB.registerLib("GLCFG", function(n) {
    function e(n) {
        function e() {
        }
        try {
            if (n) {
                var i = n.getConfigParams().ggParams,
                    a = n.name,
                    d = 0;
            }
        } catch (n) {
        }
    }
    var o = "NOLCMB",
        t = "NOLBUNDLE",
        i = "5.5.5.2",
        r = 5;
        function(n, e) {
                nlsQ: function(o, t, i, r, s, a) {
                        g: i,
                        ggPM: function(o, i, r, s, a) {
                        }
                    }, n[e][t]
                }
            }
        }(window, t);
    return s && Object.keys(s).forEach(function(n) {
        e(s[n])
    }), {
        registerListener: function(n, i) {
            function r(r) {
                var s = i,
                    a = n;
            }
            i && "ggPM" === n && i.addListener(n, r)
        }
    }
});