! function() {
    var e;
    e = function() {
}();