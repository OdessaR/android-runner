/*
Copyright 2010 Google Inc.
Copyright 2016 Akamai Technolgies

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

     http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

See the source code here:
     http://code.google.com/p/episodes/
*/


! function() {
    function e(e, s) {
        function u() {
        }

        function d(e, t) {
            return n
        }

        function p(e, t) {
            if (e && e.hasAttribute("rel"))
                for (var n = e.rel.split(/[\u0009\u000A\u000C\u000D\u0020]+/), r = 0; r < n.length;) {
                    var o = n[r++].toLowerCase();
                        break
                    }
                }
        }
        var f = e.RT;
        if (!f.version && "undefined" != typeof e.AKSB.version && void 0 !== Object.keys) {
            f.version = "0.2";
            var m = {
                prefetch: 1,
                preload: 2,
                prerender: 3,
                stylesheet: 4
            };
            f.init = function() {
                f.getW3CTimings()
            }, f.getW3CTimings = function() {
                    c = f.getResourceTimingAPI(),
                    l = s.createElement("a"),
                    S = d(l, "script"),
                    v = d(l, "link");
                for (var g in c)
                    if ("undefined" != typeof c[g].duration) {
                        var E = [c[g].initiatorType];
                        if ("script" === c[g].initiatorType || "link" === c[g].initiatorType) {
                            var y = S[c[g].name];
                            y && (y.async ? E.push("async") : y.defer && E.push("defer"))
                        }
                        "link" === c[g].initiatorType && p(v[c[g].name], E), m.insert(c[g].name, t([Math.round(c[g].redirectStart), Math.round(c[g].redirectEnd), Math.round(c[g].fetchStart), Math.round(c[g].domainLookupStart), Math.round(c[g].domainLookupEnd), Math.round(c[g].connectStart), Math.round(c[g].connectEnd), Math.round(c[g].secureConnectionStart), Math.round(c[g].requestStart), Math.round(c[g].responseStart), Math.round(c[g].responseEnd), Math.round(c[g].duration), E.join("_"), c[g].nextHopProtocol, c[g].transferSize, c[g].encodedBodySize, c[g].decodedBodySize]))
                    } f.radtree = m, f.baseurl = s.location.protocol.toLowerCase() + "//" + s.location.hostname.toLowerCase() + s.location.pathname;
                var h = function(t) {
                        n.open("POST", ("https:" === e.document.location.protocol ? "https:" : "http:") + "//ds-aksb-a.akamaihd.net/RRT", !0), n.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
                        var u = {
                                nt: escape(JSON.stringify(t)),
                                rt: escape(JSON.stringify(f.radtree.data)),
                                rid: e.AKSB.prof.requestid,
                                gh: e.AKSB.prof.ghostip,
                                b: e.AKSB.bf.get(),
                                c: e.AKSB.prof.custid,
                                us: e.AKSB.prof.ustr,
                                ol: e.AKSB.prof.originlat,
                                cr: e.AKSB.prof.clientrtt,
                                ua: r,
                                pl: o,
                                mt: a,
                                mb: i,
                                vc: e.AKSB.aksbVersion(),
                                bpcip: e.AKSB.getMangledAddress(),
                                akTX: e.AKSB.akTX,
                                akTI: e.AKSB.akTI,
                                ai: e.AKSB.prof.ai,
                                rf: "string" == typeof s.referrer ? encodeURIComponent(s.referrer.replace(/\?.*/, "?")) : ""
                            },
                            d = [];
                        for (var p in u) u.hasOwnProperty(p) && u[p] && d.push(p + "=" + u[p]);
                        n.send(d.join("&"))
                    },
                    k = e.performance && e.performance.timing;
                if (k) {
                    var b = e.performance.timing,
                        T = function() {
                            if (b.loadEventEnd > 0) {
                                var e = [b.domainLookupEnd - b.domainLookupStart, b.connectStart - b.domainLookupStart, b.connectEnd - b.domainLookupStart, b.secureConnectionStart ? b.secureConnectionStart - b.domainLookupStart : null, b.requestStart - b.domainLookupStart, b.responseStart - b.domainLookupStart, b.responseEnd - b.domainLookupStart, b.domLoading - b.domainLookupStart, b.domInteractive - b.domainLookupStart, n(b), b.domContentLoadedEventStart - b.domainLookupStart, b.domContentLoadedEventEnd - b.domainLookupStart, b.domComplete - b.domainLookupStart, b.loadEventStart - b.domainLookupStart, b.loadEventEnd - b.domainLookupStart],
                                    r = {};
                                r[f.baseurl] = t(e), h(r)
                            } else b.loadEventEnd <= 0 && setTimeout(T, 100)
                        };
                    T()
                } else {
                    var L = function() {
                        if ("AKSB" in e && "measures" in e.AKSB && "t_plt" in e.AKSB.measures) {
                            var t = [null, null, null, 0, null, null, null, null, null, null, null, null, null, e.AKSB.measures.t_onload, e.AKSB.measures.t_plt],
                                n = {};
                            n[f.baseurl] = t, h(n)
                        } else setTimeout(L, 100)
                    };
                    L()
                }
            }, f.getResourceTimingAPI = function() {
                if ("performance" in e) {
                    if ("getEntriesByType" in e.performance) return e.performance.getEntriesByType("resource");
                    if ("webkitGetEntriesByType" in e.performance) return e.performance.webkitGetEntriesByType("resource")
                }
                return null
                        o = r[0],
                        a = r[1];
                    if (!o || "string" != typeof o || "string" != typeof a) break;
                    var i = o.length;
                    if (o !== a) {
                        var s = a.slice(i, a.length),
                            u = n[a];
                }
                return n[e] = e ? t : null, !0
                function n(e, t) {
                    return e.length < t.length ? -1 : e.length > t.length ? 1 : 0
                }

                function r(e, t) {
                }
                if (t.sort(n), "undefined" != typeof e) {
                    var o = e[0];
                    for (var a in t)
                        if (r(t[a], o))
                            for (var i = e.length; i >= 1; i--)
                                if (r(t[a], e.slice(0, i))) return [e.slice(0, i), t[a]]
                }
                return ["", null]
            };
            var c = e.AKSB.prof.akTT;
            if (e.performance && (e.performance.getEntries || e.performance.webkitGetEntries))
                if ("R" === c) f.init();
                else {
                    if ("O" !== c && void 0 !== c || !(e.document.location.search.search("akamai-rum-rt=on") >= 0) && 10 <= 100 * Math.random()) return;
                    f.init()
                }
        }
    }

    function t(e) {
        return e
    }

    function n(e) {
                if ("first-paint" === t[n].name) return Math.round(t[n].startTime);
    }
    var r, o, a, i;
    ! function(t) {
        var s = t.document;
        var u = t.AKSB;
        if (void 0 != u.prof && u.prof.origin === !0) {
            var d = "number" == typeof u.prof.beaconrate ? parseInt(u.prof.beaconrate, 10) : 10;
            if (d <= 100 * Math.random()) return
        }
        if (u.q = u.q || [], u.autorun = "undefined" == typeof u.autorun || u.autorun, !u.version && "X" !== t.AKSB.prof.akTT) {
            u.version = 17;
            var p, f, m, c, l, S;
            u.init = function() {
                u.bDone = !1, u.marks = {}, u.measures = {}, u.starts = {}, u.getClientProf(), u.processQ();
                var e = u.findStartWebTiming();
            }, u.processQ = function() {
                for (var e = u.q.length, t = 0; t < e; t++) {
                    var n = u.q[t],
                        r = n[0];
                    "mark" === r ? u.mark(n[1], n[2]) : "measure" === r ? u.measure(n[1], n[2], n[3]) : "done" === r && u.done(n[1])
                }
            }, u.getClientProf = function() {
                u.prof = u.prof || {}, p = u.prof.ipv6 === !0 || "true" === u.prof.ipv6, f = u.prof.beaconUrl || ("https:" === s.location.protocol ? "https:" : "http:") + "//ds-aksb-a.akamaihd.net/2/" + u.prof.custid + "/b", r = escape(t.navigator.userAgent), o = escape(t.navigator.platform), m = escape(s.location.protocol.toLowerCase() + "//" + s.location.hostname.toLowerCase() + s.location.pathname);
                var e = t.navigator.connection || t.navigator.mozConnection || t.navigator.webkitConnection,
                    n = "",
                    d = "";
                if (e && "number" == typeof e.type ? e.type == e.WIFI ? (n = "wifi", d = 7e6) : e.type == e.CELL_2G ? (n = "cellular", d = 384) : e.type == e.CELL_3G ? (n = "cellular", d = 42e3) : e.type == e.CELL_4G ? (n = "cellular", d = 1e5) : e.type == e.ETHERNET ? (n = "ethernet", d = 1e7) : e.type == e.NONE ? (n = "none", d = 0) : n = "unknown" : e && "string" == typeof e.type && (n = e.type, e.downlinkMax && (d = Math.round(1e3 * e.downlinkMax))), a = escape(n), i = d, c = s.visibilityState || s.webkitVisibilityState || s.mozVisibilityState || s.msVisibilityState, l = "undefined" != typeof t.aFeoApplied, S = "" !== s.location.search, u.prof.pct) {
                    var v = !(parseInt(u.prof.pct, 10) <= 100 * Math.random());
                    if (v && void 0 !== u.prof.clientip) {
                        var g = u.getMangledAddress(),
                            E = p ? "j" : "i";
                        f = ("https:" === s.location.protocol ? "https:" : "http:") + "//" + E + g + "-ds-aksb-a.akamaihd.net/2/" + u.prof.custid + "/b"
                    }
                }
            }, u.getMangledAddress = function() {
                if (void 0 === u.prof.clientip) return "";
                var e;
                return p ? (e = u.prof.clientip.split(":"), ("" == e[0] ? "" : parseInt(e[0], 16).toString(32)) + "z" + ("" == e[1] ? "" : parseInt(e[1], 16).toString(32)) + "z" + ("" == e[2] ? "" : parseInt(e[2], 16).toString(32))) : (e = u.prof.clientip.split("."), ("00000000" + (256 * (256 * (256 * +e[0] + +e[1]) + +e[2]) + 0).toString(16)).slice(-8))
            }, u.mark = function(e, t) {
                e && (u.marks[e] = parseInt(t || (new Date).getTime(), 10), "firstbyte" === e ? u.measure("t_fb", "starttime", "firstbyte") : "onload" === e ? u.measure("t_onload", "starttime", "onload") : "done" === e && u.measure("t_plt", "starttime", "done"))
            }, u.measure = function(e, t, n) {
                if (e) {
                    var r;
                    if ("undefined" == typeof t) r = "number" == typeof u.marks[e] ? u.marks[e] : (new Date).getTime();
                    else if ("number" == typeof u.marks[t]) r = u.marks[t];
                    else {
                        if ("number" != typeof t) return;
                        r = t
                    }
                    var o;
                    if ("undefined" == typeof n) o = (new Date).getTime();
                    else if ("number" == typeof u.marks[n]) o = u.marks[n];
                    else {
                        if ("number" != typeof n) return;
                        o = n
                    }
                    u.starts[e] = parseInt(r, 10), u.measures[e] = parseInt(o - r, 10)
                }
            }, u.done = function(e) {
                u.mark("done");
                var t = function() {
                        u.bDone = !0, u.autorun && u.sendBeacon(), "function" == typeof e && e()
                    },
                    r = u.getNavTimingAPI(),
                    o = r.navigation,
                    a = r.timing;
                if (void 0 !== r) {
                    var i = function() {
                            for (var e in a) u.mark(e, a[e]);
                            u.measure("dE", "domainLookupStart", "domainLookupEnd"), u.measure("cS", "domainLookupStart", "connectStart"), a.secureConnectionStart && u.measure("sS", "domainLookupStart", "secureConnectionStart"), u.measure("cE", "domainLookupStart", "connectEnd"), u.measure("rqS", "domainLookupStart", "requestStart"), u.measure("rsS", "domainLookupStart", "responseStart"), u.measure("rsE", "domainLookupStart", "responseEnd");
                            var r = n(a);
                            "undefined" != typeof r && r > 0 && (u.measures.fp = r), u.measure("dl", "domainLookupStart", "domLoading"), u.measure("di", "domainLookupStart", "domInteractive"), u.measure("dlS", "domainLookupStart", "domContentLoadedEventStart"), u.measure("dlE", "domainLookupStart", "domContentLoadedEventEnd"), u.measure("dc", "domainLookupStart", "domComplete"), u.measure("leS", "domainLookupStart", "loadEventStart"), u.measure("leE", "domainLookupStart", "loadEventEnd"), t()
                        },
                        s = function() {
                            o && (0 === o.type || 1 === o.type) && a && a.loadEventEnd > 0 ? i() : a && a.loadEventEnd <= 0 && setTimeout(s, 100)
                        };
                    s()
                }
            }, u.aksbVersion = function() {
                return "" + (void 0 === u.prof.blver ? 0 : u.prof.blver) + ":" + (void 0 === u.version ? 0 : u.version)
            }, u.sendBeacon = function(n, d) {
                var p = "";
                u.bf = u.bitField(), u.createBitField();
                var c = {
                    dE: u.measures.dE,
                    cS: u.measures.cS,
                    cE: u.measures.cE,
                    rqS: u.measures.rqS,
                    rsS: "undefined" != typeof u.measures.rsS ? u.measures.rsS : u.measures.t_fb,
                    rsE: u.measures.rsE,
                    sS: u.measures.sS,
                    dl: u.measures.dl,
                    di: u.measures.di,
                    fp: u.measures.fp,
                    dlS: u.measures.dlS,
                    dlE: "undefined" != typeof u.measures.dlE ? u.measures.dlE : u.measures.t_onready,
                    dc: u.measures.dc,
                    leS: "undefined" != typeof u.measures.leS ? u.measures.leS : u.measures.t_onload,
                    leE: "undefined" != typeof u.measures.leE ? u.measures.leE : u.measures.t_plt,
                    to: u.measures.to,
                    ol: u.prof.originlat,
                    cr: u.prof.clientrtt,
                    mt: a,
                    mb: i,
                    b: u.bf.get(),
                    u: m,
                    ua: r,
                    pl: o,
                    us: u.prof.ustr,
                    gh: u.prof.ghostip,
                    t: u.prof.token,
                    rid: u.prof.requestid,
                    r: u.prof.region,
                    akM: u.prof.akM,
                    akN: u.prof.akN,
                    vc: u.aksbVersion(),
                    bpcip: u.getMangledAddress(),
                    akTX: u.prof.akTX,
                    akTI: u.prof.akTI,
                    ai: u.prof.ai,
                    pmgn: u.prof.pmgn,
                    pmgi: u.prof.pmgi,
                    pmp: u.prof.pmp
                };
                if (c)
                    for (var l in c) p += "&" + escape(l) + "=" + ("undefined" == typeof c[l] ? "" : c[l]);
                if (p) {
                    if (p = p.substring(1), d)
                        for (var S in d) d.hasOwnProperty(S) && (p += "&" + escape(S) + "=" + escape(d[S]));
                    return v.src = n + "?" + p, e(t, s), v.src
                }
                return ""
            }, u.bitField = function(e) {
                var t = Math.abs(e),
                    n = function() {};
                return n.prototype.set = function(e) {
                }, n.prototype.hasbit = function(e) {
                    return e > t ? 0 : t & e
                }, n.prototype.get = function() {
                    return t
                }, new n
            }, u.createBitField = function() {
                var e = {
                    MS_NT: 1,
                    IPv6: 16,
                    FEO: 32,
                    VIA_SPDY: 64,
                    VIS_HIDDEN: 128,
                    VIS_VISIBLE: 256,
                    VIS_PRERENDERED: 512,
                    QUERY_TRUNCATED: 2048,
                    RUM_AT_ORIGIN: 4096,
                    ONLOAD_HAS_FIRED: 8192,
                    VIA_HTTP_TWO: 131072,
                    TXN_ENABLED: 262144,
                    RUA_APPLIED: 524288,
                    VIA_QUIC: 1048576
                };
                u.bf.set(e.MS_NT);
                var t = u.prof.protocol;
                void 0 !== t && ("h2" == t.slice(0, 2) ? u.bf.set(e.VIA_HTTP_TWO) : "spdy" == t.slice(0, 4) && u.bf.set(e.VIA_SPDY));
                var n = u.prof.qc;
                "string" == typeof n && "" !== n && "0" !== n && u.bf.set(e.VIA_QUIC), p && u.bf.set(e.IPv6), l && u.bf.set(e.FEO), "hidden" === c && u.bf.set(e.VIS_HIDDEN), "visible" === c && u.bf.set(e.VIS_VISIBLE), "prerendered" === c && u.bf.set(e.VIS_PRERENDERED), S && u.bf.set(e.QUERY_TRUNCATED), u.prof.origin === !0 && u.bf.set(e.RUM_AT_ORIGIN), u.onloadHasFired === !0 && u.bf.set(e.ONLOAD_HAS_FIRED), "true" === u.prof.ra && u.bf.set(e.RUA_APPLIED), u.prof.akTT && "O" != u.prof.akTT && u.bf.set(e.TXN_ENABLED)
            }, u.findStartWebTiming = function() {
                var e = void 0,
                    t = u.getNavTimingAPI();
                return "undefined" != typeof t && "undefined" != typeof t.timing && "undefined" != typeof t.timing.navigationStart && (e = r.match(/Firefox\/[78]\./i) ? t.timing.unloadEventStart || t.timing.fetchStart : t.timing.navigationStart), e
            }, u.onready = function() {
                u.mark("onready", (new Date).getTime()), u.measure("t_onready", "starttime", "onready")
            }, u.onload = function() {
                u.mark("onload", (new Date).getTime()), u.autorun && u.done()
            }, u.addEventListener = function(e, n, r) {
                return "undefined" != typeof t.attachEvent ? t.attachEvent("on" + e, n) : t.addEventListener ? t.addEventListener(e, n, r) : void 0
            }, u.getNavTimingAPI = function() {
                return t.performance || t.mozPerformance || t.msPerformance || t.webkitPerformance
            }, u.init()
        }
    }(window);
    var s = 2147483647
}();