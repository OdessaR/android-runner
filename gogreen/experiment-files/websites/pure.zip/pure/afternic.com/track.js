/*
 * track events with google analytics
 */
$(document).ready(function() {
    $('#search-mainbar').submit(function() {
        if ($('#search-mainbar-text').val().trim() != '') {
        }
        return true;
    });

    $('#mainnav-largesearch-button').click(function() {
    });

    $('#search-big-blue').submit(function() {
        if ($('#search-big-blue-text').val().trim() != '') {
        }
        return true;
    });
    /* more info */
    $('a.results-header-domain-moreinfo').click(function() {
        var dom, act2i = 'More Info - Top Alt TLD';
        dom = $(this).attr('href').replace('/domain/', '');
    });

    $('a#results-header-buynow').click(function() {
        var tld = '',
            price = '',
            dom = $(this).attr('href').replace('/confirmbuy/', '');
        var a_dom = dom.split('.');
        tld = a_dom[1];
        price = $('span#results-header-buynow-price').text().replace(/[^0-9]/g, '');
        var act21 = ($('#searchTldSelected').val() == tld) ? 'Buy Now – Top Exact Match' : 'Buy Now - Top Exact Match Alt TLD';

        var link = $(this).attr('href');
        });
        return false;
    });

    $('#results-header-offerform-submit').click(function() {
        var tld = '',
            price = '',
            dom = $("a#results-header-domain").attr('href').replace('/domain/', '');
        var a_dom = dom.split('.');
        tld = a_dom[1];
        price = $('INPUT#reaults-header-offer-entry').val().replace(/[^0-9]/g, '');
        var act21 = ($('#searchTldSelected').val() == tld) ? 'Make Offer - Top Exact Match' : 'Make Offer - Top Exact Match Alt TLD';
    });

    $('table#search-results').on('click', 'a.search-domain', function() {
        var link = $(this).attr('href');
        var dom = $(this).text().trim(),
            tld = '',
            a_dom;
        a_dom = dom.split('.');
        tld = a_dom[1];
        var act22 = ($('#search-mainbar-text').val() == a_dom[0]) ? (($('#searchTldSelected').val() == tld) ? 'Domain Name - Listed Results Exact Match' : 'Domain Name - Listed Results Exact Match Alt TLD') : 'Domain Name - Listed Results Alt Domain';
        });
        return false;
    });

    $('table#search-results').on('click', 'a.button-buy-generic', function() {
        var tld = '',
            price, a_dom, dom = $(this).attr('href').replace('/confirmbuy/', '');
        a_dom = dom.split('.');
        tld = a_dom[1];
        var act23 = ($('#search-mainbar-text').val() == a_dom[0]) ? (($('#searchTldSelected').val() == tld) ? 'Buy Now - Listed Results Exact Match' : 'Buy Now - Listed Results Exact Match Alt TLD') : 'Buy Now - Listed Results Alt Domain';

        var link = $(this).attr('href');
        });
        return false;
    });


    $('table#search-results').on('click', 'a.button-makeoffer-generic', function() {
        var tld = '',
            price, a_dom, dom = $(this).attr('href').replace('/domain/', '');
        a_dom = dom.split('.');
        tld = a_dom[1];
        var act24 = ($('#search-mainbar-text').val() == a_dom[0]) ? (($('#searchTldSelected').val() == tld) ? 'Make Offer - Listed Results Exact Match' : 'Make Offer - Listed Results Exact Match Alt TLD') : 'Make Offer - Listed Results Alt Domain';

        var link = $(this).attr('href');
        });
        return false;
    });


    $('table#search-results').on('click', 'a.button-bid-generic', function() {
        var tld = '',
            price, a_dom, dom = $(this).attr('href').replace('/domain/', '');
        a_dom = dom.split('.');
        tld = a_dom[1];
        var act24 = ($('#search-mainbar-text').val() == a_dom[0]) ? (($('#searchTldSelected').val() == tld) ? 'Bid - Listed Results Exact Match' : 'Bid - Listed Results Exact Match Alt TLD') : 'Bid - Listed Results Alt Domain';

        var link = $(this).attr('href');
        });
    });

    var socialArray = ['facebook', 'twitter', 'linkedin', 'google'];


        $('a#share-list-content-' + value).on('click', function() {


            //for "prettiness" sake let's make the first letter ucase    		
                return letter.toUpperCase();
            });

                action: value,
                label: domain
            };

        });

    });

    //Top Menu login 
    $('#login-subnav-submit').on('click', function() {
        var login_subnav_username = $('#login-subnav-username').val();

        if (login_subnav_username != "") {
            $('#login-subnav-form').submit();
        }
        return false;
    });

    // Modal Login
    $('#login-modal-submit').on('click', function() {
        var login_modal_username = $('#login-modal-username').val();
        if (login_modal_username != "") {
            $('#login-modal-form').submit();
        }
        return false;
    });

    // Checkout
    $('#checkout-button-cart').on('click', function() {
        });
        return false;
    });

    // Payment processed
    if ($('#review-order-summary').length > 0) {
    }

    // Track appraisals ordered
    if ($('#review-afternic-appr').length > 0) {
        var label = getUsername();
        $('#review-afternic-appr span.module-domain-nonlinking').each(function(k, v) {
            label = label + '_' + $(v).text();
        });
    }

    // Track AO ordered
    if ($('#review-afternic-agent').length > 0) {
        var label = getUsername();
        $('#review-afternic-agent span.module-domain-nonlinking').each(function(k, v) {
            label = label + '_' + $(v).text();
        });
    }

    // Portfolio add to cart
    $('#appraisals-checkout').on('track', function(event, formdata) {
    });

    // Portfolio edits
    $('#portfolio-form').on('track', function(event, items) {
        var events = [];
        var price_fields = ['buynow', 'floor', 'reserve', 'minimum'];

        for (var key in items) {
            for (var i in price_fields) {
                if (key.indexOf(price_fields[i]) > -1) {
                    events.push('Price Change');
                }
            }

            if (key.indexOf('category') > -1) {
                events.push('Category Change');
            } else if (key.indexOf('park') > -1) {
                events.push('Parking Change');
            } else if (key.indexOf('current_status') > -1) {
                events.push('Status Change');
            } else if (key.indexOf('promolevel') > -1 && items[key] == 'upgrade') {
                events.push('Premium Upgrade');
            }
        }
        var unique_events = events.filter(function(itm, i, a) {
            return i == a.indexOf(itm);
        });

        for (var index in unique_events) {
        }
    });

    // Edit listing 
    $('#domain-admin-content').on('track', function(event, items) {
        var events = [];
        var price_fields = ['buynow', 'floor', 'reserve', 'min_bid'];

        for (var key in items) {
            for (var i in price_fields) {
                if (key.indexOf(price_fields[i]) > -1) {
                    events.push('Price Change');
                }
            }

            if (key.indexOf('category') > -1) {
                events.push('Category Change');
            } else if (key.indexOf('park') > -1) {
                events.push('Parking Change');
            } else if (key.indexOf('current_status') > -1) {
                events.push('Status Change');
            } else if (key.indexOf('promolevel') > -1 && items[key] == 'upgrade') {
                events.push('Premium Upgrade');
            }
        }
        var unique_events = events.filter(function(itm, i, a) {
            return i == a.indexOf(itm);
        });

        for (var index in unique_events) {
        }
    });

    // Move registrar
    $('#registrarConfirmForm').on('track', function(event, formdata) {
    });

    // Make offer, rest is in offer_modal
    $('#domain-profile-make-offer').on('track', function(event, formdata) {
    });

    // Domain page buynow
    $('#domain-profile-buynow-button').click(function() {
        var link = $(this).attr('href');
        });
        return false;
    });

});