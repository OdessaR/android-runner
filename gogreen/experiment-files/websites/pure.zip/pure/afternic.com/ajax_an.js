function loadNewListings() {
        // Create a template out the returned data

            url: "/ajax/home",
            type: "GET",
            cache: true,
            headers: {
                'Cache-Control': 'max-age=300'
            },
            data: {
                AJAX: 1,
                service: "distinctNewListing"
            },
            timeout: 30000
        });

        req.success(function(data, status) {

            var newDomainList = {
                domains: []
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    name: grabSLD(tempObj.name),
                    price: tempObj.buy_now,
                    table_class: "",
                    tld: grabTLD(tempObj.name)
                };

                if (parseInt(tempObj.buy_now, 10) > 0) {
                } else {
                }

                if ((intIndex % 2) == 0)

                newDomainList.domains.push(domainObj);
            });

            $('#new-listings-loader').hide();


            $('#new-listings-div').append(newListingRows);

            $('#table-new-listings a').on('click', function() {
                var link = $(this).attr('href');
                if ($(this).hasClass('button-buy-generic')) {
                }

                });
                return false;
            });


            // Hide the more link if there is less than 7
            if (newDomainList.domains.length <= 0) {
                $('#new-listings-div').remove();
            } else if (newDomainList.domains.length < 7) {
                $('#newlisting-more').remove();
            }
        });

        req.error(function() {
        });


    }); //end new-listings
} //end loadNewListings

function loadTrending() {
        // Create a template out the returned data

            url: "/ajax/home",
            type: "GET",
            cache: true,
            headers: {
                'Cache-Control': 'max-age=3600'
            },
            data: {
                AJAX: 1,
                service: "trending"
            },
            timeout: 10000
        });

        req.success(function(data, status) {

            var domainList = {
                domains: []
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    name: grabSLD(tempObj.domain_name),
                    price: tempObj.buy_now,
                    table_class: "",
                    tld: grabTLD(tempObj.domain_name)
                };

                if (parseInt(tempObj.buy_now, 10) > 0) {
                } else {
                }

                if ((intIndex % 2) == 0)

                domainList.domains.push(domainObj);
            });

            $('#trending-loader').hide();
            $('#trending-div').append(listingRows);

            $('#table-trending a').on('click', function() {
                var link = $(this).attr('href');
                if ($(this).hasClass('button-buy-generic')) {
                }

                });
                return false;
            });

            // Hide the more link if there is less than 7
            if (domainList.domains.length <= 0) {
                $('#trending-div').remove();
            } else if (domainList.domains.length < 7) {
                $('#trending-more').remove();
            }
        });

        req.error(function() {
        });


    }); //end trending-domains
} //end loadTrending

function loadRecentlySold() {
        // Create a template out the returned data

            url: "/ajax/home",
            type: "GET",
            data: {
                AJAX: 1,
                service: "recentlySold"
            },
            timeout: 30000
        });

        req.success(function(data, status) {

            var domainList = {
                domains: []
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    name: grabSLD(tempObj.name),
                    price: tempObj.price,
                    table_class: "",
                    tld: grabTLD(tempObj.name),
                    saledate: tempObj.saledate
                };

                if ((intIndex % 2) == 0)

                domainList.domains.push(domainObj);
            });

            $('#recently-sold-loader').hide();
            $('#recently-sold-div').append(listingRows);

            // Hide the more link if there is less than 7 
            if (domainList.domains.length <= 0) {
                $('#recently-sold-div').remove();
            } else if (domainList.domains.length < 7) {
                $('#sold-more').remove();
            }
        });

        req.error(function() {
        });


    }); //end recently-sold
} //end loadRecentlySold

function loadPremiumDomains() {
        // Create a template out the returned data

            url: "/ajax/home",
            type: "GET",
            cache: true,
            headers: {
                'Cache-Control': 'max-age=3600'
            },
            data: {
                AJAX: 1,
                service: "premiumDomain"
            },
            timeout: 10000
        });

        req.success(function(data, status) {

            var domainList = {
                domains: []
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    name: grabSLD(tempObj.name),
                    price: tempObj.buy_now,
                    table_class: "",
                    tld: grabTLD(tempObj.name)
                };

                if (parseInt(tempObj.buy_now, 10) > 0) {
                } else {
                }

                if ((intIndex % 2) == 0)

                domainList.domains.push(domainObj);
            });

            $('#premium-domains-loader').hide();
            $('#premium-domains-div').append(listingRows);

            $('#table-premium-domains a').on('click', function() {
                var link = $(this).attr('href');
                if ($(this).hasClass('button-buy-generic')) {
                }

                });
                return false;
            });

            // Hide the more link if there is less than 7
            if (domainList.domains.length <= 0) {
                $('#premium-domains-div').remove();
            } else if (domainList.domains.length < 7) {
                $('#premium-more').remove();
            }
        });

        req.error(function() {
        });


    }); //end premium-domains
} //end loadPremiumDomains

function loadSiteStats() {
        // Create a template out the returned data

            url: "/ajax/home",
            cache: true,
            headers: {
                'Cache-Control': 'max-age=3600'
            },
            type: "GET",
            data: {
                AJAX: 1,
                service: "siteStat"
            },
            timeout: 30000
        });

        req.success(function(data, status) {
            if (data === undefined || data === null) {
                return false;
            }

            var responseObj = data.response;

            var statObj = {
                cnt_domain: addCommas(responseObj.cnt_domain)
            };


            $('#footer-sub-left').append(statRows);

        });

        req.error(function() {
        });


    }); //end site-stats
} //end loadSiteStats

function loadUserFeaturedListing(uid) {
        // Create a template out the returned data

            url: "/ajax/userprofile",
            type: "GET",
            data: {
                AJAX: 1,
                service: "getUserFeaturedDomain",
                userid: uid
            },
            timeout: 10000
        });

        req.success(function(data, status) {

            var domainList = {
                domains: []
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    name: grabSLD(tempObj.name),
                    price: tempObj.buy_now,
                    table_class: "",
                    tld: grabTLD(tempObj.name)
                };

                if (parseInt(tempObj.buy_now, 10) > 0) {
                } else {
                }

                if ((intIndex % 2) == 0)

                domainList.domains.push(domainObj);
            });


            $('#user-featured-domain-list').html(listingRows);

            if (domainList.domains.length == 0) {
                $('#user-featured-domain-list').hide();
            }

        });

        req.error(function() {
        });
    });
}

function loadUserListing(uid, uname) {
        // Create a template out the returned data

            url: "/ajax/userprofile",
            type: "GET",
            data: {
                AJAX: 1,
                service: "displayDomainListingsFrontEnd",
                userid: uid
            },
            timeout: 10000
        });

        req.success(function(data, status) {

            var domainList = {
                domains: [],
                username: uname
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    name: grabSLD(tempObj.name),
                    price: tempObj.buy_now,
                    table_class: "",
                    tld: grabTLD(tempObj.name)
                };

                if (parseInt(tempObj.buy_now, 10) > 0) {
                } else {
                }

                if ((intIndex % 2) == 0)

                domainList.domains.push(domainObj);
            });


            $('#user-domain-list').html(listingRows);

            if (domainList.domains.length == 0) {
                $('#user-domain-list').hide();

                $('#profile-search').hide();

            } else {
                $('#profile-search').show();
            }
        });

        req.error(function() {
        });
    });
}

function loadUserActivity(uid) {
        // Create a template out the returned data

            url: "/ajax/userprofile",
            type: "GET",
            data: {
                AJAX: 1,
                service: "getUserActivity",
                userid: uid
            },
            timeout: 10000
        });

        req.success(function(data, status) {

            var activityList = {
                activities: []
            };

            $(data.response).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    activity: tempObj.activity,
                    date: tempObj.activity_date,
                    table_class: ""
                };

                if ((intIndex % 2) == 0)

                activityList.activities.push(actObj);
            });


            $('#user-recent-activity').html(listingRows);

            if (activityList.activities.length == 0) {
                $('#user-recent-activity').hide();

            }

        });

        req.error(function() {
        });
    });
}

function getUserMessageCount(uid) {
    if (uid == null || uid == undefined) {
        return;
    }
        url: "/ajax/userprofile",
        type: "GET",
        data: {
            AJAX: 1,
            service: "unreadNotificationCount",
            userid: uid
        },
        timeout: 30000
    });

    req.success(function(data, status) {
        var cnt = data.response.cnt;
        if (cnt === undefined || cnt === null) {
            return;
        }

        $('#header-notification-cnt').html(cnt);
        if ($('#sidebar-admin').length > 0) {
            if (cnt > 0) {
                $('#notification-alert-hint').removeClass('hidden').html(cnt);
                $('#sidebar-admin-quicknavlist-notifications').addClass('active-items-inside').html("<span>notifications: </span>" + cnt);
            } else {
                $('#notification-alert-hint').addClass('hidden').html(cnt);
                $('#sidebar-admin-quicknavlist-notifications').removeClass('active-items-inside').html('<span>notifications: </span>');
            }
        }
    });

    req.error(function() {
    });
}

function updateShoppingCartCount() {
        if ($('#sidebar-admin').length > 0) {
            if (cnt > 0) {
                $('#notification-cart-count').removeClass('hidden').html(cnt);
                $('#sidebar-admin-quicknavlist-basket').addClass('active-items-inside').html("<span>basket: </span>" + cnt);
            } else {
                $('#notification-cart-hint').addClass('hidden').html(cnt);
                $('#sidebar-admin-quicknavlist-basket').removeClass('active-items-inside').html('<span>basket: </span>');
            }
        }
    });
}

function loadBidHistory(aucid) {
        // Create a template out the returned data

            url: "/ajax/domainprofile",
            type: "GET",
            data: {
                AJAX: 1,
                service: "getBidHistory",
                auction_id: aucid
            },
            timeout: 10000
        });

        req.success(function(data, status) {

            var bidList = {
                bids: []
            };

            $(data.response.history).each(function(intIndex, objValue) {

                var tempObj = objValue;

                    bid_amt: tempObj.bid_amt,
                    bidder: tempObj.username,
                    bid_time: tempObj.bid_time,
                    table_class: ""
                };

                if ((intIndex % 2) == 0)

                bidList.bids.push(bidObj);
            });


            $('#domain-bid-history-table').html(listingRows);

            if (bidList.bids.length == 0) {
                $('#domain-profile-bid-history').hide();
                return;
            }

            // Render the highest bid
            var highest = data.response.highest;
            if (highest == null || highest == undefined) {
                return;
            }

            $('#domain-profile-price').html("$" + highest.bid_amt);
            $('#domain-profile-auctiondetail').html("(" + highest.position + " bid &bull; from " + highest.username + ")");
        });

        req.error(function() {
        });
    });
}