(function($) {

    };

})(jQuery);