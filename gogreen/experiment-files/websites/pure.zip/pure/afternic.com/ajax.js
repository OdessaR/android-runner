/*
 * ajax.js
 * Copyright: Bryan Healey 2010, 2011, 2012 (bryan@bryanhealey.com)
 * License: GNU General Public License (v3)
 * Purpose: Handle all AJAX functionality
 */

var ajaxQueue = {
    list: [],
    fired: false,
    timer: false,
    noQueue: false,

    begin: function() {
    },

    ensureSingularity: function(container) {
        }

        return true;
    },

    submit: function(formId, container) {
                'container': container
            });
            else alert("You must wait");
        }
    },

    request: function(url, method, params, container, onSuccess, onError, onTimeout) {
        if (!onSuccess) var onSuccess = false;
                'url': url,
                'method': method,
                'params': params,
                'container': container,
                'onSuccess': onSuccess,
                'onError': onError,
                'onTimeout': onTimeout
            });
            else alert("You must wait");
        }
    },

    fireNext: function() {


            if (el.form) {
                a.submit(el.form, el.container);
            } else {
                a.onSuccess = el.onSuccess;
                a.onError = el.onError;
                a.onTimeout = el.onTimeout;

                a.request(el.url, el.method, el.params, el.container);
            }
        }

    }
};

ajax = {
    onSuccess: null,
    onFail: null,
    onTimeout: null,

    submit: function(formId, container, params, sFunc, fFunc, tFunc) {
        else {



            return a;
        }
    },

    request: function(url, method, params, container, sFunc, fFunc, tFunc) {



        return a;
    }
};

function ajaxSingular() {

        if ($('#' + formId)) var form = $('#' + formId);
        else return false;


    };

        if (!params) var params = {};
        params['AJAX'] = "true";

        var ret = false;


        if (loader) {
            if ($('#' + container)) {
                loaderImg.src = '/img/loading.gif';

                loaderDiv.setAttribute('width', '100%');
                loaderDiv.style.textAlign = 'center';
                loaderDiv.style.paddingTop = '0.75em';
                loaderDiv.appendChild(loaderImg);

                $('#' + container).update(loaderDiv);
            } else if ($('loader-container')) {
                $('#loader-container').style.display = "block";
            }
        }

            type: method,
            url: uri,
            data: params,

            success: function(responseText) {
                try {
                    if ($('#' + container)) $('#' + container).html(responseText);
                }

                if (success) success(responseText);
                ret = true;


                if ($('#loader-container') !== null) $('#loader-container').css('display', 'none');
            },

            error: function(responseText, err) {
                if (err == 'timeout') timo(responseText);
                else {
                    if (fail) fail(responseText);
                    ret = false;

                    if ($('#loader-container') !== null) $('#loader-container').css('display', 'none');
                }

            }
        });

        return a;
    };
};