(function($) {

        var tldArray = {};

        tldData.forEach(function(tld) {

            var cat = tld.category;
            if (cat === null) {
                cat = "More";
            }

            if (!Array.isArray(tldArray[cat])) {
                tldArray[cat] = [];
            }

            tldArray[cat].push(tld.tld);
        });

        return tldArray;
    };



        var hasSelected = false;



        $('#search-mainbar-tld-wrap').append("<select id='search-mainbar-tld' name='tld' class='replace-select' style='z-index: 10; opacity: 0;'><option value='all' >All</option></span>");

        for (var index in tldArray) {

            $('#search-mainbar-tld').append($("<option></option>")
                .attr("value", "spacer-" + index)
                .attr('disabled', 'disabled')
                .text(""));

            $('#search-mainbar-tld').append($("<option></option>")
                .attr("value", "title1-" + index)
                .attr('disabled', 'disabled')
                .text(index));

            var arrayList = tldArray[index];

            for (var intIdx in arrayList) {
                if (arrayList[intIdx] == selectedTLD) {
                    $('#search-mainbar-tld').append($("<option></option>")
                        .attr("value", arrayList[intIdx])
                        .attr("selected", "selected")
                        .text(arrayList[intIdx]));
                    hasSelected = true;
                } else {
                    $('#search-mainbar-tld').append($("<option></option>")
                        .attr("value", arrayList[intIdx])
                        .text(arrayList[intIdx]));
                }
            }
        }

        if (hasSelected) {
            $('#search-mainbar-tld-wrap').append(
                "<span id='replace-select-0' class='replace-select-selected'>." + selectedTLD + "</span>"
            );
        }

        $("#search-mainbar-tld").on('change', function() {

            $("#replace-select-0").html(changedTLD);
            $("#searchTldSelected").val(changedTLD);

        });
    };

})(jQuery);