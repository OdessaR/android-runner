! function(e, t, n, i) {
        var a, r, s = (new Date).getTime(),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1),
            f = e.isPlainObject(o) ? e.extend(!0, {}, e.site.settings, o) : e.extend({}, e.site.settings),
            m = f.namespace,
            g = f.error,
            p = "module-" + m,
            h = e(n),
            v = h,
            y = v.data(p);
        return a = {
            initialize: function() {
                a.instantiate()
            },
            instantiate: function() {
                a.verbose("Storing instance of site", a), y = a, v.data(p, a)
            },
            normalize: function() {
                a.fix.console(), a.fix.requestAnimationFrame()
            },
            fix: {
                console: function() {
                },
                consoleClear: function() {
                },
                requestAnimationFrame: function() {
                        setTimeout(e, 0)
                    })
                }
            },
            moduleExists: function(t) {
                return e.fn[t] !== i && e.fn[t].settings !== i
            },
            enabled: {
                modules: function(t) {
                    var n = [];
                        a.moduleExists(t) && n.push(t)
                    }), n
                }
            },
            disabled: {
                modules: function(t) {
                    var n = [];
                        a.moduleExists(t) || n.push(t)
                    }), n
                }
            },
            change: {
                setting: function(t, n, o, r) {
                        var s, l = a.moduleExists(o) ? e.fn[o].settings.namespace || !1 : !0;
                    })
                },
                settings: function(t, n, o) {
                        var r;
                        a.moduleExists(i) && (a.verbose("Changing default setting", t, i), e.extend(!0, e.fn[i].settings, t), o && m && (r = e(":data(module-" + m + ")"), r.length > 0 && (a.verbose("Modifying existing settings", r), r[i]("setting", t))))
                    })
                }
            },
            enable: {
                console: function() {
                    a.console(!0)
                },
                debug: function(e, t) {
                },
                verbose: function(e, t) {
                }
            },
            disable: {
                console: function() {
                    a.console(!1)
                },
                debug: function(e, t) {
                },
                verbose: function(e, t) {
                }
            },
            console: function(e) {
                if (e) {
                    if (y.cache.console === i) return void a.error(g.console);
                    clear: function() {},
                    error: function() {},
                    group: function() {},
                    groupCollapsed: function() {},
                    groupEnd: function() {},
                    info: function() {},
                    log: function() {},
                    markTimeline: function() {},
                    warn: function() {}
                }
            },
            destroy: function() {
                a.verbose("Destroying previous site for", v), v.removeData(p)
            },
            cache: {},
            setting: function(t, n) {
                if (e.isPlainObject(t)) e.extend(!0, f, t);
                else {
                    if (n === i) return f[t];
                    f[t] = n
                }
            },
            internal: function(t, n) {
                if (e.isPlainObject(t)) e.extend(!0, a, t);
                else {
                    if (n === i) return a[t];
                    a[t] = n
                }
            },
            debug: function() {
            },
            verbose: function() {
            },
            error: function() {
            },
            performance: {
                log: function(e) {
                    var t, n, i;
                    f.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                        Element: b,
                        Name: e[0],
                        Arguments: [].slice.call(e, 1) || "",
                        "Execution Time": n
                    })), clearTimeout(a.performance.timer), a.performance.timer = setTimeout(a.performance.display, 500)
                },
                display: function() {
                    var t = f.name + ":",
                        n = 0;
                    s = !1, clearTimeout(a.performance.timer), e.each(l, function(e, t) {
                        n += t["Execution Time"]
                }
            },
            invoke: function(t, n, o) {
                var s, l, c, u = y;
                    var r = n != s ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                    if (e.isPlainObject(u[r]) && n != s) u = u[r];
                    else {
                        if (u[r] !== i) return l = u[r], !1;
                        if (!e.isPlainObject(u[o]) || n == s) return u[o] !== i ? (l = u[o], !1) : (a.error(g.method, t), !1);
                        u = u[o]
                    }
                })), e.isFunction(l) ? c = l.apply(o, n) : l !== i && (c = l), e.isArray(r) ? r.push(c) : r !== i ? r = [r, c] : c !== i && (r = c), l
            }
        name: "Site",
        namespace: "site",
        error: {
            console: "Console cannot be restored, most likely it was overwritten outside of module",
            method: "The method you called is not defined."
        },
        debug: !1,
        verbose: !1,
        performance: !0,
        modules: ["accordion", "api", "checkbox", "dimmer", "dropdown", "embed", "form", "modal", "nag", "popup", "rating", "shape", "sidebar", "state", "sticky", "tab", "transition", "visit", "visibility"],
        siteNamespace: "site",
        namespaceStub: {
            cache: {},
            config: {},
            sections: {},
            section: {},
            utilities: {}
        }
    }, e.extend(e.expr[":"], {
        data: e.expr.createPseudo ? e.expr.createPseudo(function(t) {
            return function(n) {
                return !!e.data(n, t)
            }
        }) : function(t, n, i) {
            return !!e.data(t, i[3])
        }
    })
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = a.selector || "",
            s = (new Date).getTime(),
            l = [],
            c = arguments[0],
            u = arguments[1],
            d = "string" == typeof c,
            f = [].slice.call(arguments, 1);
        return a.each(function() {
            var m, g, p, h, v, b, y, x, C, w, k, S, T, A, R, E, P, F, O = e(this),
                q = [],
                j = !1;
            F = {
                initialize: function() {
                    F.get.settings(), d ? (P === i && F.instantiate(), F.invoke(c)) : (P !== i && P.invoke("destroy"), F.verbose("Initializing form validation", O, x), F.bindEvents(), F.set.defaults(), F.instantiate())
                },
                instantiate: function() {
                    F.verbose("Storing instance of module", F), P = F, O.data(R, F)
                },
                destroy: function() {
                    F.verbose("Destroying previous module", P), F.removeEvents(), O.removeData(R)
                },
                refresh: function() {
                    F.verbose("Refreshing selector cache"), m = O.find(k.field), g = O.find(k.group), p = O.find(k.message), h = O.find(k.prompt), v = O.find(k.submit), b = O.find(k.clear), y = O.find(k.reset)
                },
                submit: function() {
                    F.verbose("Submitting form", O), O.submit()
                },
                attachEvents: function(t, n) {
                        F[n](), e.preventDefault()
                    })
                },
                bindEvents: function() {
                    F.verbose("Attaching form events"), O.on("submit" + E, F.validate.form).on("blur" + E, k.field, F.event.field.blur).on("click" + E, k.submit, F.submit).on("click" + E, k.reset, F.reset).on("click" + E, k.clear, F.clear), x.keyboardShortcuts && O.on("keydown" + E, k.field, F.event.field.keydown), m.each(function() {
                        var t = e(this),
                            n = t.prop("type"),
                            i = F.get.changeEvent(n, t);
                        e(this).on(i + E, F.event.field.change)
                    })
                },
                clear: function() {
                    m.each(function() {
                        var t = e(this),
                            n = t.parent(),
                            i = t.closest(g),
                            o = i.find(k.prompt),
                            a = t.data(w.defaultValue) || "",
                            r = n.is(k.uiCheckbox),
                            s = n.is(k.uiDropdown),
                            l = i.hasClass(S.error);
                        l && (F.verbose("Resetting error on field", i), i.removeClass(S.error), o.remove()), s ? (F.verbose("Resetting dropdown value", n, a), n.dropdown("clear")) : r ? t.prop("checked", !1) : (F.verbose("Resetting field value", t, a), t.val(""))
                    })
                },
                reset: function() {
                    m.each(function() {
                        var t = e(this),
                            n = t.parent(),
                            o = t.closest(g),
                            a = o.find(k.prompt),
                            r = t.data(w.defaultValue),
                            s = n.is(k.uiCheckbox),
                            l = n.is(k.uiDropdown),
                            c = o.hasClass(S.error);
                        r !== i && (c && (F.verbose("Resetting error on field", o), o.removeClass(S.error), a.remove()), l ? (F.verbose("Resetting dropdown value", n, r), n.dropdown("restore defaults")) : s ? (F.verbose("Resetting checkbox value", n, r), t.prop("checked", r)) : (F.verbose("Resetting field value", t, r), t.val(r)))
                    })
                },
                is: {
                    bracketedRule: function(e) {
                        return e.type && e.type.match(x.regExp.bracket)
                    },
                    empty: function(e) {
                        return e && 0 !== e.length ? e.is('input[type="checkbox"]') ? !e.is(":checked") : F.is.blank(e) : !0
                    },
                    blank: function(t) {
                        return "" === e.trim(t.val())
                    },
                    valid: function() {
                        var t = !0;
                        return F.verbose("Checking if form is valid"), e.each(C, function(e, n) {
                            F.validate.field(n, e) || (t = !1)
                        }), t
                    }
                },
                removeEvents: function() {
                    O.off(E), m.off(E), v.off(E), m.off(E)
                },
                event: {
                    field: {
                        keydown: function(t) {
                            var n = e(this),
                                i = t.which,
                                o = n.is(k.input),
                                a = n.is(k.checkbox),
                                r = n.closest(k.uiDropdown).length > 0,
                                s = {
                                    enter: 13,
                                    escape: 27
                                };
                            i == s.escape && (F.verbose("Escape key pressed blurring field"), n.blur()), t.ctrlKey || i != s.enter || !o || r || a || (j || (n.one("keyup" + E, F.event.field.keyup), F.submit(), F.debug("Enter pressed on input submitting form")), j = !0)
                        },
                        keyup: function() {
                            j = !1
                        },
                        blur: function(t) {
                            var n = e(this),
                                i = n.closest(g),
                                o = F.get.validation(n);
                            i.hasClass(S.error) ? (F.debug("Revalidating field", n, o), o && F.validate.field(o)) : ("blur" == x.on || "change" == x.on) && o && F.validate.field(o)
                        },
                        change: function(t) {
                            var n = e(this),
                                i = n.closest(g),
                                o = F.get.validation(n);
                            ("change" == x.on || i.hasClass(S.error) && x.revalidate) && (clearTimeout(F.timer), F.timer = setTimeout(function() {
                                F.debug("Revalidating field", n, F.get.validation(n)), F.validate.field(o)
                            }, x.delay))
                        }
                    }
                },
                get: {
                    ancillaryValue: function(e) {
                        return e.type && (e.value || F.is.bracketedRule(e)) ? e.value !== i ? e.value : e.type.match(x.regExp.bracket)[1] + "" : !1
                    },
                    ruleName: function(e) {
                        return F.is.bracketedRule(e) ? e.type.replace(e.type.match(x.regExp.bracket)[0], "") : e.type
                    },
                    changeEvent: function(e, t) {
                        return "checkbox" == e || "radio" == e || "hidden" == e || t.is("select") ? "change" : F.get.inputEvent()
                    },
                    inputEvent: function() {
                        return n.createElement("input").oninput !== i ? "input" : n.createElement("input").onpropertychange !== i ? "propertychange" : "keyup"
                    },
                    prompt: function(e, t) {
                        var n, i, o, a = F.get.ruleName(e),
                            r = F.get.ancillaryValue(e),
                            s = e.prompt || x.prompt[a] || x.text.unspecifiedRule,
                            l = -1 !== s.search("{value}"),
                            c = -1 !== s.search("{name}");
                        return (c || l) && (i = F.get.field(t.identifier)), l && (s = s.replace("{value}", i.val())), c && (n = i.closest(k.group).find("label").eq(0), o = 1 == n.length ? n.text() : i.prop("placeholder") || x.text.unspecifiedField, s = s.replace("{name}", o)), s = s.replace("{identifier}", t.identifier), s = s.replace("{ruleValue}", r), e.prompt || F.verbose("Using default validation prompt for type", s, a), s
                    },
                    settings: function() {
                        if (e.isPlainObject(t)) {
                            var n, o = Object.keys(t),
                                a = o.length > 0 ? t[o[0]].identifier !== i && t[o[0]].rules !== i : !1;
                            a ? (x = e.extend(!0, {}, e.fn.form.settings, u), C = e.extend({}, e.fn.form.settings.defaults, t), F.error(x.error.oldSyntax, D), F.verbose("Extending settings from legacy parameters", C, x)) : (t.fields && (n = Object.keys(t.fields), ("string" == typeof t.fields[n[0]] || e.isArray(t.fields[n[0]])) && e.each(t.fields, function(n, i) {
                                    rules: []
                                }, e.each(i, function(e, i) {
                                    t.fields[n].rules.push({
                                        type: i
                                    })
                                })
                            })), x = e.extend(!0, {}, e.fn.form.settings, t), C = e.extend({}, e.fn.form.settings.defaults, x.fields), F.verbose("Extending settings", C, x))
                        } else x = e.fn.form.settings, C = e.fn.form.settings.defaults, F.verbose("Using default form validation", C, x);
                        A = x.namespace, w = x.metadata, k = x.selector, S = x.className, T = x.error, R = "module-" + A, E = "." + A, P = O.data(R), F.refresh()
                    },
                    field: function(t) {
                        return F.verbose("Finding field with identifier", t), m.filter("#" + t).length > 0 ? m.filter("#" + t) : m.filter('[name="' + t + '"]').length > 0 ? m.filter('[name="' + t + '"]') : m.filter('[name="' + t + '[]"]').length > 0 ? m.filter('[name="' + t + '[]"]') : m.filter("[data-" + w.validate + '="' + t + '"]').length > 0 ? m.filter("[data-" + w.validate + '="' + t + '"]') : e("<input/>")
                    },
                    fields: function(t) {
                        var n = e();
                        return e.each(t, function(e, t) {
                            n = n.add(F.get.field(t))
                        }), n
                    },
                    validation: function(t) {
                        var n, i;
                        return C ? (e.each(C, function(e, o) {
                            i = o.identifier || e, F.get.field(i)[0] == t[0] && (o.identifier = i, n = o)
                        }), n || !1) : !1
                    },
                    value: function(e) {
                        var t, n = [];
                        return n.push(e), t = F.get.values.call(D, n), t[e]
                    },
                    values: function(t) {
                        var n = e.isArray(t) ? F.get.fields(t) : m,
                            i = {};
                        return n.each(function(t, n) {
                            var o = e(n),
                                a = (o.prop("type"), o.prop("name")),
                                r = o.val(),
                                s = o.is(k.checkbox),
                                l = o.is(k.radio),
                                c = -1 !== a.indexOf("[]"),
                                u = s ? o.is(":checked") : !1;
                            a && (c ? (a = a.replace("[]", ""), i[a] || (i[a] = []), s ? u ? i[a].push(r || !0) : i[a].push(!1) : i[a].push(r)) : l ? u && (i[a] = r) : s ? u ? i[a] = r || !0 : i[a] = !1 : i[a] = r)
                        }), i
                    }
                },
                has: {
                    field: function(e) {
                        return F.verbose("Checking for existence of a field with identifier", e), "string" != typeof e && F.error(T.identifier, e), m.filter("#" + e).length > 0 ? !0 : m.filter('[name="' + e + '"]').length > 0 ? !0 : m.filter("[data-" + w.validate + '="' + e + '"]').length > 0 ? !0 : !1
                    }
                },
                add: {
                    prompt: function(t, n) {
                        var o = F.get.field(t),
                            a = o.closest(g),
                            r = a.children(k.prompt),
                            s = 0 !== r.length;
                    },
                    errors: function(e) {
                        F.debug("Adding form error messages", e), F.set.error(), p.html(x.templates.error(e))
                    }
                },
                remove: {
                    prompt: function(t) {
                        var n = F.get.field(t),
                            o = n.closest(g),
                            a = o.children(k.prompt);
                        o.removeClass(S.error), x.inline && a.is(":visible") && (F.verbose("Removing prompt for field", t), x.transition && e.fn.transition !== i && O.transition("is supported") ? a.transition(x.transition + " out", x.duration, function() {
                            a.remove()
                        }) : a.fadeOut(x.duration, function() {
                            a.remove()
                        }))
                    }
                },
                set: {
                    success: function() {
                        O.removeClass(S.error).addClass(S.success)
                    },
                    defaults: function() {
                        m.each(function() {
                            var t = e(this),
                                n = t.filter(k.checkbox).length > 0,
                                i = n ? t.is(":checked") : t.val();
                            t.data(w.defaultValue, i)
                        })
                    },
                    error: function() {
                        O.removeClass(S.success).addClass(S.error)
                    },
                    value: function(e, t) {
                        var n = {};
                        return n[e] = t, F.set.values.call(D, n)
                    },
                    values: function(t) {
                        e.isEmptyObject(t) || e.each(t, function(t, n) {
                            var i, o = F.get.field(t),
                                a = o.parent(),
                                r = e.isArray(n),
                                s = a.is(k.uiCheckbox),
                                l = a.is(k.uiDropdown),
                                c = o.is(k.radio) && s,
                                u = o.length > 0;
                            u && (r && s ? (F.verbose("Selecting multiple", n, o), a.checkbox("uncheck"), e.each(n, function(e, t) {
                                i = o.filter('[value="' + t + '"]'), a = i.parent(), i.length > 0 && a.checkbox("check")
                            })) : c ? (F.verbose("Selecting radio value", n, o), o.filter('[value="' + n + '"]').parent(k.uiCheckbox).checkbox("check")) : s ? (F.verbose("Setting checkbox value", n, a), n === !0 ? a.checkbox("check") : a.checkbox("uncheck")) : l ? (F.verbose("Setting dropdown value", n, a), a.dropdown("set selected", n)) : (F.verbose("Setting field value", n, o), o.val(n)))
                        })
                    }
                },
                validate: {
                    form: function(e, t) {
                        var n = F.get.values();
                        if (j) return !1;
                        if (q = [], F.is.valid()) {
                            if (F.debug("Form has no validation errors, submitting"), F.set.success(), t !== !0) return x.onSuccess.call(D, e, n)
                        } else if (F.debug("Form has errors"), F.set.error(), x.inline || F.add.errors(q), O.data("moduleApi") !== i && e.stopImmediatePropagation(), t !== !0) return x.onFailure.call(D, q, n)
                    },
                    field: function(t, n) {
                        var o = t.identifier || n,
                            a = F.get.field(o),
                            r = t.depends ? F.get.field(t.depends) : !1,
                            s = !0,
                            l = [];
                            F.has.field(o) && !F.validate.rule(t, n) && (F.debug("Field is invalid", o, n.type), l.push(F.get.prompt(n, t)), s = !1)
                        }), s ? (F.remove.prompt(o, l), x.onValid.call(a), !0) : (q = q.concat(l), F.add.prompt(o, l), x.onInvalid.call(a, l), !1)
                    },
                    rule: function(t, n) {
                        var o = F.get.field(t.identifier),
                            a = (n.type, o.val()),
                            r = F.get.ancillaryValue(n),
                            s = F.get.ruleName(n),
                            l = x.rules[s];
                        return e.isFunction(l) ? (a = a === i || "" === a || null === a ? "" : e.trim(a + ""), l.call(o, a, r)) : void F.error(T.noRule, s)
                    }
                },
                setting: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, x, t);
                    else {
                        if (n === i) return x[t];
                        x[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, F, t);
                    else {
                        if (n === i) return F[t];
                        F[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        x.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: D,
                            "Execution Time": n
                        })), clearTimeout(F.performance.timer), F.performance.timer = setTimeout(F.performance.display, 500)
                    },
                    display: function() {
                        var t = x.name + ":",
                            n = 0;
                        s = !1, clearTimeout(F.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = P;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s
                }
            }, F.initialize()
        name: "Form",
        namespace: "form",
        debug: !1,
        verbose: !1,
        performance: !0,
        fields: !1,
        keyboardShortcuts: !0,
        on: "submit",
        inline: !1,
        delay: 200,
        revalidate: !0,
        transition: "scale",
        duration: 200,
        onValid: function() {},
        onInvalid: function() {},
        onSuccess: function() {
            return !0
        },
        onFailure: function() {
            return !1
        },
        metadata: {
            defaultValue: "default",
            validate: "validate"
        },
        regExp: {
            bracket: /\[(.*)\]/i,
            decimal: /^\d*(\.)\d+/,
            email: /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/,
            escape: /[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,
            flags: /^\/(.*)\/(.*)?/,
            integer: /^\-?\d+$/,
            number: /^\-?\d*(\.\d+)?$/,
            url: /(https?:\/\/(?:www\.|(?!www))[^\s\.]+\.[^\s]{2,}|www\.[^\s]+\.[^\s]{2,})/i,
            phone: /^(?=.*[0-9])[- +()0-9]+$/
        },
        text: {
            unspecifiedRule: "Please enter a valid value",
            unspecifiedField: "This field"
        },
        prompt: {
            empty: "{name} must have a value",
            checked: "{name} must be checked",
            email: "{name} must be a valid e-mail",
            url: "{name} must be a valid url",
            regExp: "{name} is not formatted correctly",
            integer: "{name} must be an integer",
            decimal: "{name} must be a decimal number",
            number: "{name} must be set to a number",
            is: '{name} must be "{ruleValue}"',
            isExactly: '{name} must be exactly "{ruleValue}"',
            not: '{name} cannot be set to "{ruleValue}"',
            notExactly: '{name} cannot be set to exactly "{ruleValue}"',
            contain: '{name} cannot contain "{ruleValue}"',
            containExactly: '{name} cannot contain exactly "{ruleValue}"',
            doesntContain: '{name} must contain  "{ruleValue}"',
            doesntContainExactly: '{name} must contain exactly "{ruleValue}"',
            minLength: "{name} must be at least {ruleValue} characters",
            length: "{name} must be at least {ruleValue} characters",
            exactLength: "{name} must be exactly {ruleValue} characters",
            maxLength: "{name} cannot be longer than {ruleValue} characters",
            match: "{name} must match {ruleValue} field",
            different: "{name} must have a different value than {ruleValue} field",
            creditCard: "{name} must be a valid credit card number",
            minCount: "{name} must have at least {ruleValue} choices",
            exactCount: "{name} must have exactly {ruleValue} choices",
            maxCount: "{name} must have {ruleValue} or less choices"
        },
        selector: {
            checkbox: 'input[type="checkbox"], input[type="radio"]',
            clear: ".clear",
            field: "input, textarea, select",
            group: ".field",
            input: "input",
            message: ".error.message",
            prompt: ".prompt.label",
            radio: 'input[type="radio"]',
            reset: '.reset:not([type="reset"])',
            submit: '.submit:not([type="submit"])',
            uiCheckbox: ".ui.checkbox",
            uiDropdown: ".ui.dropdown"
        },
        className: {
            error: "error",
            label: "ui prompt label",
            pressed: "down",
            success: "success"
        },
        error: {
            identifier: "You must specify a string identifier for each field",
            method: "The method you called is not defined.",
            noRule: "There is no rule matching the one you specified",
            oldSyntax: "Starting in 2.0 forms now only take a single settings object. Validation settings converted to new syntax automatically."
        },
        templates: {
            error: function(t) {
                var n = '<ul class="list">';
                return e.each(t, function(e, t) {
                    n += "<li>" + t + "</li>"
                }), n += "</ul>", e(n)
            },
            prompt: function(t) {
                return e("<div/>").addClass("ui basic red pointing prompt label").html(t[0])
            }
        },
        rules: {
            empty: function(t) {
                return !(t === i || "" === t || e.isArray(t) && 0 === t.length)
            },
            checked: function() {
                return e(this).filter(":checked").length > 0
            },
            email: function(t) {
                return e.fn.form.settings.regExp.email.test(t)
            },
            url: function(t) {
                return e.fn.form.settings.regExp.url.test(t)
            },
            phone: function(t) {
                return e.fn.form.settings.regExp.phone.test(t)
            },
            regExp: function(t, n) {
                if (n instanceof RegExp) return t.match(n);
                var i, o = n.match(e.fn.form.settings.regExp.flags);
            },
            integer: function(t, n) {
                var o, a, r, s = e.fn.form.settings.regExp.integer;
                return n && -1 === ["", ".."].indexOf(n) && (-1 == n.indexOf("..") ? s.test(n) && (o = a = n - 0) : (r = n.split("..", 2), s.test(r[0]) && (o = r[0] - 0), s.test(r[1]) && (a = r[1] - 0))), s.test(t) && (o === i || t >= o) && (a === i || a >= t)
            },
            decimal: function(t) {
                return e.fn.form.settings.regExp.decimal.test(t)
            },
            number: function(t) {
                return e.fn.form.settings.regExp.number.test(t)
            },
            is: function(e, t) {
            },
            isExactly: function(e, t) {
                return e == t
            },
            not: function(e, t) {
            },
            notExactly: function(e, t) {
                return e != t
            },
            contains: function(t, n) {
            },
            containsExactly: function(t, n) {
            },
            doesntContain: function(t, n) {
            },
            doesntContainExactly: function(t, n) {
            },
            minLength: function(e, t) {
                return e !== i ? e.length >= t : !1
            },
            length: function(e, t) {
                return e !== i ? e.length >= t : !1
            },
            exactLength: function(e, t) {
                return e !== i ? e.length == t : !1
            },
            maxLength: function(e, t) {
                return e !== i ? e.length <= t : !1
            },
            match: function(t, n) {
                var o;
                e(this);
                return e('[data-validate="' + n + '"]').length > 0 ? o = e('[data-validate="' + n + '"]').val() : e("#" + n).length > 0 ? o = e("#" + n).val() : e('[name="' + n + '"]').length > 0 ? o = e('[name="' + n + '"]').val() : e('[name="' + n + '[]"]').length > 0 && (o = e('[name="' + n + '[]"]')), o !== i ? t.toString() == o.toString() : !1
            },
            different: function(t, n) {
                var o;
                e(this);
                return e('[data-validate="' + n + '"]').length > 0 ? o = e('[data-validate="' + n + '"]').val() : e("#" + n).length > 0 ? o = e("#" + n).val() : e('[name="' + n + '"]').length > 0 ? o = e('[name="' + n + '"]').val() : e('[name="' + n + '[]"]').length > 0 && (o = e('[name="' + n + '[]"]')), o !== i ? t.toString() !== o.toString() : !1
            },
            creditCard: function(t, n) {
                var i, o, a = {
                        visa: {
                            pattern: /^4/,
                            length: [16]
                        },
                        amex: {
                            pattern: /^3[47]/,
                            length: [15]
                        },
                        mastercard: {
                            pattern: /^(5[1-5]|677189)|^(222[1-9]|2[3-6]\d{2}|27[0-1]\d|2720)/,
                            length: [16]
                        },
                        discover: {
                            pattern: /^(6011|622(12[6-9]|1[3-9][0-9]|[2-8][0-9]{2}|9[0-1][0-9]|92[0-5]|64[4-9])|65)/,
                            length: [16]
                        },
                        unionPay: {
                            pattern: /^(62|88)/,
                            length: [16, 17, 18, 19]
                        },
                        jcb: {
                            pattern: /^35(2[89]|[3-8][0-9])/,
                            length: [16]
                        },
                        maestro: {
                            pattern: /^(5018|5020|5038|6304|6759|676[1-3])/,
                            length: [12, 13, 14, 15, 16, 17, 18, 19]
                        },
                        dinersClub: {
                            pattern: /^(30[0-5]|^36)/,
                            length: [14]
                        },
                        laser: {
                            pattern: /^(6304|670[69]|6771)/,
                            length: [16, 17, 18, 19]
                        },
                        visaElectron: {
                            pattern: /^(4026|417500|4508|4844|491(3|7))/,
                            length: [16]
                        }
                    },
                    r = {},
                    s = !1,
                    l = "string" == typeof n ? n.split(",") : !1;
                if ("string" == typeof t && 0 !== t.length) {
                    if (l && (e.each(l, function(n, i) {
                            o = a[i], o && (r = {
                                length: -1 !== e.inArray(t.length, o.length),
                                pattern: -1 !== t.search(o.pattern)
                            }, r.length && r.pattern && (s = !0))
                        }), !s)) return !1;
                    if (i = {
                            number: -1 !== e.inArray(t.length, a.unionPay.length),
                            pattern: -1 !== t.search(a.unionPay.pattern)
                        }, i.number && i.pattern) return !0;
                    for (var c = t.length, u = 0, d = [
                            [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
                            [0, 2, 4, 6, 8, 1, 3, 5, 7, 9]
                        ], f = 0; c--;) f += d[u][parseInt(t.charAt(c), 10)], u ^= 1;
                    return f % 10 === 0 && f > 0
                }
            },
            minCount: function(e, t) {
                return 0 == t ? !0 : 1 == t ? "" !== e : e.split(",").length >= t
            },
            exactCount: function(e, t) {
                return 0 == t ? "" === e : 1 == t ? "" !== e && -1 === e.search(",") : e.split(",").length == t
            },
            maxCount: function(e, t) {
                return 0 == t ? !1 : 1 == t ? -1 === e.search(",") : e.split(",").length <= t
            }
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = (new Date).getTime(),
            s = [],
            l = arguments[0],
            c = "string" == typeof l,
            u = [].slice.call(arguments, 1);
        t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
            setTimeout(e, 0)
        };
        return a.each(function() {
            var d, f, m = e.isPlainObject(n) ? e.extend(!0, {}, e.fn.accordion.settings, n) : e.extend({}, e.fn.accordion.settings),
                g = m.className,
                p = m.namespace,
                h = m.selector,
                v = m.error,
                b = "." + p,
                y = "module-" + p,
                x = a.selector || "",
                C = e(this),
                w = C.find(h.title),
                k = C.find(h.content),
                T = C.data(y);
            f = {
                initialize: function() {
                    f.debug("Initializing", C), f.bind.events(), m.observeChanges && f.observeChanges(), f.instantiate()
                },
                instantiate: function() {
                    T = f, C.data(y, f)
                },
                destroy: function() {
                    f.debug("Destroying previous instance", C), C.off(b).removeData(y)
                },
                refresh: function() {
                    w = C.find(h.title), k = C.find(h.content)
                },
                observeChanges: function() {
                        f.debug("DOM tree modified, updating selector cache"), f.refresh()
                    }), d.observe(S, {
                        childList: !0,
                        subtree: !0
                    }), f.debug("Setting up mutation observer", d))
                },
                bind: {
                    events: function() {
                        f.debug("Binding delegated events"), C.on(m.on + b, h.trigger, f.event.click)
                    }
                },
                event: {
                    click: function() {
                        f.toggle.call(this)
                    }
                },
                toggle: function(t) {
                    var n = t !== i ? "number" == typeof t ? w.eq(t) : e(t).closest(h.title) : e(this).closest(h.title),
                        o = n.next(k),
                        a = o.hasClass(g.animating),
                        r = o.hasClass(g.active),
                        s = r && !a,
                        l = !r && a;
                    f.debug("Toggling visibility of content", n), s || l ? m.collapsible ? f.close.call(n) : f.debug("Cannot close accordion content collapsing is disabled") : f.open.call(n)
                },
                open: function(t) {
                    var n = t !== i ? "number" == typeof t ? w.eq(t) : e(t).closest(h.title) : e(this).closest(h.title),
                        o = n.next(k),
                        a = o.hasClass(g.animating),
                        r = o.hasClass(g.active),
                        s = r || a;
                    return s ? void f.debug("Accordion already open, skipping", o) : (f.debug("Opening accordion content", n), m.onOpening.call(o), m.exclusive && f.closeOthers.call(n), n.addClass(g.active), o.stop(!0, !0).addClass(g.animating), m.animateChildren && (e.fn.transition !== i && C.transition("is supported") ? o.children().transition({
                        animation: "fade in",
                        queue: !1,
                        useFailSafe: !0,
                        debug: m.debug,
                        verbose: m.verbose,
                        duration: m.duration
                    }) : o.children().stop(!0, !0).animate({
                        opacity: 1
                    }, m.duration, f.resetOpacity)), void o.slideDown(m.duration, m.easing, function() {
                        o.removeClass(g.animating).addClass(g.active), f.reset.display.call(this), m.onOpen.call(this), m.onChange.call(this)
                    }))
                },
                close: function(t) {
                    var n = t !== i ? "number" == typeof t ? w.eq(t) : e(t).closest(h.title) : e(this).closest(h.title),
                        o = n.next(k),
                        a = o.hasClass(g.animating),
                        r = o.hasClass(g.active),
                        s = !r && a,
                        l = r && a;
                    !r && !s || l || (f.debug("Closing accordion content", o), m.onClosing.call(o), n.removeClass(g.active), o.stop(!0, !0).addClass(g.animating), m.animateChildren && (e.fn.transition !== i && C.transition("is supported") ? o.children().transition({
                        animation: "fade out",
                        queue: !1,
                        useFailSafe: !0,
                        debug: m.debug,
                        verbose: m.verbose,
                        duration: m.duration
                    }) : o.children().stop(!0, !0).animate({
                        opacity: 0
                    }, m.duration, f.resetOpacity)), o.slideUp(m.duration, m.easing, function() {
                        o.removeClass(g.animating).removeClass(g.active), f.reset.display.call(this), m.onClose.call(this), m.onChange.call(this)
                    }))
                },
                closeOthers: function(t) {
                    var n, o, a, r = t !== i ? w.eq(t) : e(this).closest(h.title),
                        s = r.parents(h.content).prev(h.title),
                        l = r.closest(h.accordion),
                        c = h.title + "." + g.active + ":visible",
                        u = h.content + "." + g.active + ":visible";
                    m.closeNested ? (n = l.find(c).not(s), a = n.next(k)) : (n = l.find(c).not(s), o = l.find(u).find(c).not(s), n = n.not(o), a = n.next(k)), n.length > 0 && (f.debug("Exclusive enabled, closing other content", n), n.removeClass(g.active), a.removeClass(g.animating).stop(!0, !0), m.animateChildren && (e.fn.transition !== i && C.transition("is supported") ? a.children().transition({
                        animation: "fade out",
                        useFailSafe: !0,
                        debug: m.debug,
                        verbose: m.verbose,
                        duration: m.duration
                    }) : a.children().stop(!0, !0).animate({
                        opacity: 0
                    }, m.duration, f.resetOpacity)), a.slideUp(m.duration, m.easing, function() {
                        e(this).removeClass(g.active), f.reset.display.call(this)
                    }))
                },
                reset: {
                    display: function() {
                        f.verbose("Removing inline display from element", this), e(this).css("display", ""), "" === e(this).attr("style") && e(this).attr("style", "").removeAttr("style")
                    },
                    opacity: function() {
                        f.verbose("Removing inline opacity from element", this), e(this).css("opacity", ""), "" === e(this).attr("style") && e(this).attr("style", "").removeAttr("style")
                    }
                },
                setting: function(t, n) {
                    if (f.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        e.isPlainObject(m[t]) ? e.extend(!0, m[t], n) : m[t] = n
                    }
                },
                internal: function(t, n) {
                    return f.debug("Changing internal", t, n), n === i ? f[t] : void(e.isPlainObject(t) ? e.extend(!0, f, t) : f[t] = n)
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        m.performance && (t = (new Date).getTime(), i = r || t, n = t - i, r = t, s.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: S,
                            "Execution Time": n
                        })), clearTimeout(f.performance.timer), f.performance.timer = setTimeout(f.performance.display, 500)
                    },
                    display: function() {
                        var t = m.name + ":",
                            n = 0;
                        r = !1, clearTimeout(f.performance.timer), e.each(s, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = T;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (f.error(v.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s
                }
            }, c ? (T === i && f.initialize(), f.invoke(l)) : (T !== i && T.invoke("destroy"),
                f.initialize())
        name: "Accordion",
        namespace: "accordion",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        on: "click",
        observeChanges: !0,
        exclusive: !0,
        collapsible: !0,
        closeNested: !1,
        animateChildren: !0,
        duration: 350,
        easing: "easeOutQuad",
        onOpening: function() {},
        onOpen: function() {},
        onClosing: function() {},
        onClose: function() {},
        onChange: function() {},
        error: {
            method: "The method you called is not defined"
        },
        className: {
            active: "active",
            animating: "animating"
        },
        selector: {
            accordion: ".accordion",
            title: ".title",
            trigger: ".title",
            content: ".content"
        }
    }, e.extend(e.easing, {
        easeOutQuad: function(e, t, n, i, o) {
        }
    })
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = r.selector || "",
            l = (new Date).getTime(),
            c = [],
            u = arguments[0],
            d = "string" == typeof u,
            f = [].slice.call(arguments, 1);
        return r.each(function() {
            var r, m, g = e.extend(!0, {}, e.fn.checkbox.settings, o),
                p = g.className,
                h = g.namespace,
                v = g.selector,
                b = g.error,
                y = "." + h,
                x = "module-" + h,
                C = e(this),
                w = e(this).children(v.label),
                k = e(this).children(v.input),
                S = k[0],
                T = !1,
                A = !1,
                R = C.data(x),
            m = {
                initialize: function() {
                    m.verbose("Initializing checkbox", g), m.create.label(), m.bind.events(), m.set.tabbable(), m.hide.input(), m.observeChanges(), m.instantiate(), m.setup()
                },
                instantiate: function() {
                    m.verbose("Storing instance of module", m), R = m, C.data(x, m)
                },
                destroy: function() {
                    m.verbose("Destroying module"), m.unbind.events(), m.show.input(), C.removeData(x)
                },
                fix: {
                    reference: function() {
                        C.is(v.input) && (m.debug("Behavior called on <input> adjusting invoked element"), C = C.closest(v.checkbox), m.refresh())
                    }
                },
                setup: function() {
                    m.set.initialLoad(), m.is.indeterminate() ? (m.debug("Initial value is indeterminate"), m.indeterminate()) : m.is.checked() ? (m.debug("Initial value is checked"), m.check()) : (m.debug("Initial value is unchecked"), m.uncheck()), m.remove.initialLoad()
                },
                refresh: function() {
                    w = C.children(v.label), k = C.children(v.input), S = k[0]
                },
                hide: {
                    input: function() {
                        m.verbose("Modifying <input> z-index to be unselectable"), k.addClass(p.hidden)
                    }
                },
                show: {
                    input: function() {
                        m.verbose("Modifying <input> z-index to be selectable"), k.removeClass(p.hidden)
                    }
                },
                observeChanges: function() {
                        m.debug("DOM tree modified, updating selector cache"), m.refresh()
                    }), r.observe(E, {
                        childList: !0,
                        subtree: !0
                    }), m.debug("Setting up mutation observer", r))
                },
                attachEvents: function(t, n) {
                    var i = e(t);
                },
                event: {
                    click: function(t) {
                        var n = e(t.target);
                        return n.is(v.input) ? void m.verbose("Using default check action on initialized checkbox") : n.is(v.link) ? void m.debug("Clicking link inside checkbox, skipping toggle") : (m.toggle(), k.focus(), void t.preventDefault())
                    },
                    keydown: function(e) {
                        var t = e.which,
                            n = {
                                enter: 13,
                                space: 32,
                                escape: 27
                            };
                        t == n.escape ? (m.verbose("Escape key pressed blurring field"), k.blur(), A = !0) : e.ctrlKey || t != n.space && t != n.enter ? A = !1 : (m.verbose("Enter/space key pressed, toggling checkbox"), m.toggle(), A = !0)
                    },
                    keyup: function(e) {
                        A && e.preventDefault()
                    }
                },
                check: function() {
                    m.should.allowCheck() && (m.debug("Checking checkbox", k), m.set.checked(), m.should.ignoreCallbacks() || (g.onChecked.call(S), g.onChange.call(S)))
                },
                uncheck: function() {
                    m.should.allowUncheck() && (m.debug("Unchecking checkbox"), m.set.unchecked(), m.should.ignoreCallbacks() || (g.onUnchecked.call(S), g.onChange.call(S)))
                },
                indeterminate: function() {
                    return m.should.allowIndeterminate() ? void m.debug("Checkbox is already indeterminate") : (m.debug("Making checkbox indeterminate"), m.set.indeterminate(), void(m.should.ignoreCallbacks() || (g.onIndeterminate.call(S), g.onChange.call(S))))
                },
                determinate: function() {
                    return m.should.allowDeterminate() ? void m.debug("Checkbox is already determinate") : (m.debug("Making checkbox determinate"), m.set.determinate(), void(m.should.ignoreCallbacks() || (g.onDeterminate.call(S), g.onChange.call(S))))
                },
                enable: function() {
                    return m.is.enabled() ? void m.debug("Checkbox is already enabled") : (m.debug("Enabling checkbox"), m.set.enabled(), g.onEnable.call(S), void g.onEnabled.call(S))
                },
                disable: function() {
                    return m.is.disabled() ? void m.debug("Checkbox is already disabled") : (m.debug("Disabling checkbox"), m.set.disabled(), g.onDisable.call(S), void g.onDisabled.call(S))
                },
                get: {
                    radios: function() {
                        var t = m.get.name();
                        return e('input[name="' + t + '"]').closest(v.checkbox)
                    },
                    otherRadios: function() {
                        return m.get.radios().not(C)
                    },
                    name: function() {
                        return k.attr("name")
                    }
                },
                is: {
                    initialLoad: function() {
                        return T
                    },
                    radio: function() {
                        return k.hasClass(p.radio) || "radio" == k.attr("type")
                    },
                    indeterminate: function() {
                        return k.prop("indeterminate") !== i && k.prop("indeterminate")
                    },
                    checked: function() {
                        return k.prop("checked") !== i && k.prop("checked")
                    },
                    disabled: function() {
                        return k.prop("disabled") !== i && k.prop("disabled")
                    },
                    enabled: function() {
                        return !m.is.disabled()
                    },
                    determinate: function() {
                        return !m.is.indeterminate()
                    },
                    unchecked: function() {
                        return !m.is.checked()
                    }
                },
                should: {
                    allowCheck: function() {
                        return m.is.determinate() && m.is.checked() && !m.should.forceCallbacks() ? (m.debug("Should not allow check, checkbox is already checked"), !1) : g.beforeChecked.apply(S) === !1 ? (m.debug("Should not allow check, beforeChecked cancelled"), !1) : !0
                    },
                    allowUncheck: function() {
                        return m.is.determinate() && m.is.unchecked() && !m.should.forceCallbacks() ? (m.debug("Should not allow uncheck, checkbox is already unchecked"), !1) : g.beforeUnchecked.apply(S) === !1 ? (m.debug("Should not allow uncheck, beforeUnchecked cancelled"), !1) : !0
                    },
                    allowIndeterminate: function() {
                        return m.is.indeterminate() && !m.should.forceCallbacks() ? (m.debug("Should not allow indeterminate, checkbox is already indeterminate"), !1) : g.beforeIndeterminate.apply(S) === !1 ? (m.debug("Should not allow indeterminate, beforeIndeterminate cancelled"), !1) : !0
                    },
                    allowDeterminate: function() {
                        return m.is.determinate() && !m.should.forceCallbacks() ? (m.debug("Should not allow determinate, checkbox is already determinate"), !1) : g.beforeDeterminate.apply(S) === !1 ? (m.debug("Should not allow determinate, beforeDeterminate cancelled"), !1) : !0
                    },
                    forceCallbacks: function() {
                        return m.is.initialLoad() && g.fireOnInit
                    },
                    ignoreCallbacks: function() {
                        return T && !g.fireOnInit
                    }
                },
                can: {
                    change: function() {
                        return !(C.hasClass(p.disabled) || C.hasClass(p.readOnly) || k.prop("disabled") || k.prop("readonly"))
                    },
                    uncheck: function() {
                        return "boolean" == typeof g.uncheckable ? g.uncheckable : !m.is.radio()
                    }
                },
                set: {
                    initialLoad: function() {
                        T = !0
                    },
                    checked: function() {
                        return m.verbose("Setting class to checked"), C.removeClass(p.indeterminate).addClass(p.checked), m.is.radio() && m.uncheckOthers(), !m.is.indeterminate() && m.is.checked() ? void m.debug("Input is already checked, skipping input property change") : (m.verbose("Setting state to checked", S), k.prop("indeterminate", !1).prop("checked", !0), void m.trigger.change())
                    },
                    unchecked: function() {
                        return m.verbose("Removing checked class"), C.removeClass(p.indeterminate).removeClass(p.checked), !m.is.indeterminate() && m.is.unchecked() ? void m.debug("Input is already unchecked") : (m.debug("Setting state to unchecked"), k.prop("indeterminate", !1).prop("checked", !1), void m.trigger.change())
                    },
                    indeterminate: function() {
                        return m.verbose("Setting class to indeterminate"), C.addClass(p.indeterminate), m.is.indeterminate() ? void m.debug("Input is already indeterminate, skipping input property change") : (m.debug("Setting state to indeterminate"), k.prop("indeterminate", !0), void m.trigger.change())
                    },
                    determinate: function() {
                        return m.verbose("Removing indeterminate class"), C.removeClass(p.indeterminate), m.is.determinate() ? void m.debug("Input is already determinate, skipping input property change") : (m.debug("Setting state to determinate"), void k.prop("indeterminate", !1))
                    },
                    disabled: function() {
                        return m.verbose("Setting class to disabled"), C.addClass(p.disabled), m.is.disabled() ? void m.debug("Input is already disabled, skipping input property change") : (m.debug("Setting state to disabled"), k.prop("disabled", "disabled"), void m.trigger.change())
                    },
                    enabled: function() {
                        return m.verbose("Removing disabled class"), C.removeClass(p.disabled), m.is.enabled() ? void m.debug("Input is already enabled, skipping input property change") : (m.debug("Setting state to enabled"), k.prop("disabled", !1), void m.trigger.change())
                    },
                    tabbable: function() {
                        m.verbose("Adding tabindex to checkbox"), k.attr("tabindex") === i && k.attr("tabindex", 0)
                    }
                },
                remove: {
                    initialLoad: function() {
                        T = !1
                    }
                },
                trigger: {
                    change: function() {
                        var e = n.createEvent("HTMLEvents"),
                            t = k[0];
                        t && (m.verbose("Triggering native change event"), e.initEvent("change", !0, !1), t.dispatchEvent(e))
                    }
                },
                create: {
                    label: function() {
                        k.prevAll(v.label).length > 0 ? (k.prev(v.label).detach().insertAfter(k), m.debug("Moving existing label", w)) : m.has.label() || (w = e("<label>").insertAfter(k), m.debug("Creating label", w))
                    }
                },
                has: {
                    label: function() {
                        return w.length > 0
                    }
                },
                bind: {
                    events: function() {
                        m.verbose("Attaching checkbox events"), C.on("click" + y, m.event.click).on("keydown" + y, v.input, m.event.keydown).on("keyup" + y, v.input, m.event.keyup)
                    }
                },
                unbind: {
                    events: function() {
                        m.debug("Removing events"), C.off(y)
                    }
                },
                uncheckOthers: function() {
                    var e = m.get.otherRadios();
                    m.debug("Unchecking other radios", e), e.removeClass(p.checked)
                },
                toggle: function() {
                    return m.can.change() ? void(m.is.indeterminate() || m.is.unchecked() ? (m.debug("Currently unchecked"), m.check()) : m.is.checked() && m.can.uncheck() && (m.debug("Currently checked"), m.uncheck())) : void(m.is.radio() || m.debug("Checkbox is read-only or disabled, ignoring toggle"))
                },
                setting: function(t, n) {
                    if (m.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, g, t);
                    else {
                        if (n === i) return g[t];
                        e.isPlainObject(g[t]) ? e.extend(!0, g[t], n) : g[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        m[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        g.performance && (t = (new Date).getTime(), i = l || t, n = t - i, l = t, c.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: E,
                            "Execution Time": n
                        })), clearTimeout(m.performance.timer), m.performance.timer = setTimeout(m.performance.display, 500)
                    },
                    display: function() {
                        var t = g.name + ":",
                            n = 0;
                        l = !1, clearTimeout(m.performance.timer), e.each(c, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = R;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (m.error(b.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, d ? (R === i && m.initialize(), m.invoke(u)) : (R !== i && R.invoke("destroy"), m.initialize())
        name: "Checkbox",
        namespace: "checkbox",
        silent: !1,
        debug: !1,
        verbose: !0,
        performance: !0,
        uncheckable: "auto",
        fireOnInit: !1,
        onChange: function() {},
        beforeChecked: function() {},
        beforeUnchecked: function() {},
        beforeDeterminate: function() {},
        beforeIndeterminate: function() {},
        onChecked: function() {},
        onUnchecked: function() {},
        onDeterminate: function() {},
        onIndeterminate: function() {},
        onEnable: function() {},
        onDisable: function() {},
        onEnabled: function() {},
        onDisabled: function() {},
        className: {
            checked: "checked",
            indeterminate: "indeterminate",
            disabled: "disabled",
            hidden: "hidden",
            radio: "radio",
            readOnly: "read-only"
        },
        error: {
            method: "The method you called is not defined"
        },
        selector: {
            checkbox: ".ui.checkbox",
            label: "label, .box",
            input: 'input[type="checkbox"], input[type="radio"]',
            link: "a[href]"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = (new Date).getTime(),
            s = [],
            l = arguments[0],
            c = "string" == typeof l,
            u = [].slice.call(arguments, 1);
        return a.each(function() {
            var d, f, m, g = e.isPlainObject(t) ? e.extend(!0, {}, e.fn.dimmer.settings, t) : e.extend({}, e.fn.dimmer.settings),
                p = g.selector,
                h = g.namespace,
                v = g.className,
                b = g.error,
                y = "." + h,
                x = "module-" + h,
                C = a.selector || "",
                w = "ontouchstart" in n.documentElement ? "touchstart" : "click",
                k = e(this),
                T = k.data(x);
            m = {
                preinitialize: function() {
                    m.is.dimmer() ? (f = k.parent(), d = k) : (f = k, d = m.has.dimmer() ? g.dimmerName ? f.find(p.dimmer).filter("." + g.dimmerName) : f.find(p.dimmer) : m.create(), m.set.variation())
                },
                initialize: function() {
                    m.debug("Initializing dimmer", g), m.bind.events(), m.set.dimmable(), m.instantiate()
                },
                instantiate: function() {
                    m.verbose("Storing instance of module", m), T = m, k.data(x, T)
                },
                destroy: function() {
                    m.verbose("Destroying previous module", d), m.unbind.events(), m.remove.variation(), f.off(y)
                },
                bind: {
                    events: function() {
                        "hover" == g.on ? f.on("mouseenter" + y, m.show).on("mouseleave" + y, m.hide) : "click" == g.on && f.on(w + y, m.toggle), m.is.page() && (m.debug("Setting as a page dimmer", f), m.set.pageDimmer()), m.is.closable() && (m.verbose("Adding dimmer close event", d), f.on(w + y, p.dimmer, m.event.click))
                    }
                },
                unbind: {
                    events: function() {
                        k.removeData(x), f.off(y)
                    }
                },
                event: {
                    click: function(t) {
                        m.verbose("Determining if event occured on dimmer", t), (0 === d.find(t.target).length || e(t.target).is(p.content)) && (m.hide(), t.stopImmediatePropagation())
                    }
                },
                addContent: function(t) {
                    var n = e(t);
                    m.debug("Add content to dimmer", n), n.parent()[0] !== d[0] && n.detach().appendTo(d)
                },
                create: function() {
                    var t = e(g.template.dimmer());
                    return g.dimmerName && (m.debug("Creating named dimmer", g.dimmerName), t.addClass(g.dimmerName)), t.appendTo(f), t
                },
                show: function(t) {
                },
                hide: function(t) {
                },
                toggle: function() {
                    m.verbose("Toggling dimmer visibility", d), m.is.dimmed() ? m.hide() : m.show()
                },
                animate: {
                    show: function(t) {
                            animation: g.transition + " in",
                            queue: !1,
                            duration: m.get.duration(),
                            useFailSafe: !0,
                            onStart: function() {
                                m.set.dimmed()
                            },
                            onComplete: function() {
                                m.set.active(), t()
                            }
                        })) : (m.verbose("Showing dimmer animation with javascript"), m.set.dimmed(), "auto" == g.opacity && (g.opacity = .8), d.stop().css({
                            opacity: 0,
                            width: "100%",
                            height: "100%"
                        }).fadeTo(m.get.duration(), g.opacity, function() {
                            d.removeAttr("style"), m.set.active(), t()
                        }))
                    },
                    hide: function(t) {
                            animation: g.transition + " out",
                            queue: !1,
                            duration: m.get.duration(),
                            useFailSafe: !0,
                            onStart: function() {
                                m.remove.dimmed()
                            },
                            onComplete: function() {
                                m.remove.active(), t()
                            }
                        })) : (m.verbose("Hiding dimmer with javascript"), m.remove.dimmed(), d.stop().fadeOut(m.get.duration(), function() {
                            m.remove.active(), d.removeAttr("style"), t()
                        }))
                    }
                },
                get: {
                    dimmer: function() {
                        return d
                    },
                    duration: function() {
                        return "object" == typeof g.duration ? m.is.active() ? g.duration.hide : g.duration.show : g.duration
                    }
                },
                has: {
                    dimmer: function() {
                        return g.dimmerName ? k.find(p.dimmer).filter("." + g.dimmerName).length > 0 : k.find(p.dimmer).length > 0
                    }
                },
                is: {
                    active: function() {
                        return d.hasClass(v.active)
                    },
                    animating: function() {
                        return d.is(":animated") || d.hasClass(v.animating)
                    },
                    closable: function() {
                        return "auto" == g.closable ? "hover" == g.on ? !1 : !0 : g.closable
                    },
                    dimmer: function() {
                        return k.hasClass(v.dimmer)
                    },
                    dimmable: function() {
                        return k.hasClass(v.dimmable)
                    },
                    dimmed: function() {
                        return f.hasClass(v.dimmed)
                    },
                    disabled: function() {
                        return f.hasClass(v.disabled)
                    },
                    enabled: function() {
                        return !m.is.disabled()
                    },
                    page: function() {
                        return f.is("body")
                    },
                    pageDimmer: function() {
                        return d.hasClass(v.pageDimmer)
                    }
                },
                can: {
                    show: function() {
                        return !d.hasClass(v.disabled)
                    }
                },
                set: {
                    opacity: function(e) {
                        var t = d.css("background-color"),
                            n = t.split(","),
                            i = n && 3 == n.length,
                            o = n && 4 == n.length;
                    },
                    active: function() {
                        d.addClass(v.active)
                    },
                    dimmable: function() {
                        f.addClass(v.dimmable)
                    },
                    dimmed: function() {
                        f.addClass(v.dimmed)
                    },
                    pageDimmer: function() {
                        d.addClass(v.pageDimmer)
                    },
                    disabled: function() {
                        d.addClass(v.disabled)
                    },
                    variation: function(e) {
                    }
                },
                remove: {
                    active: function() {
                        d.removeClass(v.active)
                    },
                    dimmed: function() {
                        f.removeClass(v.dimmed)
                    },
                    disabled: function() {
                        d.removeClass(v.disabled)
                    },
                    variation: function(e) {
                    }
                },
                setting: function(t, n) {
                    if (m.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, g, t);
                    else {
                        if (n === i) return g[t];
                        e.isPlainObject(g[t]) ? e.extend(!0, g[t], n) : g[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        m[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        g.performance && (t = (new Date).getTime(), i = r || t, n = t - i, r = t, s.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: S,
                            "Execution Time": n
                        })), clearTimeout(m.performance.timer), m.performance.timer = setTimeout(m.performance.display, 500)
                    },
                    display: function() {
                        var t = g.name + ":",
                            n = 0;
                        r = !1, clearTimeout(m.performance.timer), e.each(s, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = T;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (m.error(b.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s
                }
            }, m.preinitialize(), c ? (T === i && m.initialize(), m.invoke(l)) : (T !== i && T.invoke("destroy"), m.initialize())
        name: "Dimmer",
        namespace: "dimmer",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        dimmerName: !1,
        variation: !1,
        closable: "auto",
        useCSS: !0,
        transition: "fade",
        on: !1,
        opacity: "auto",
        duration: {
            show: 500,
            hide: 500
        },
        onChange: function() {},
        onShow: function() {},
        onHide: function() {},
        error: {
            method: "The method you called is not defined."
        },
        className: {
            active: "active",
            animating: "animating",
            dimmable: "dimmable",
            dimmed: "dimmed",
            dimmer: "dimmer",
            disabled: "disabled",
            hide: "hide",
            pageDimmer: "page",
            show: "show"
        },
        selector: {
            dimmer: "> .ui.dimmer",
            content: ".ui.dimmer > .content, .ui.dimmer > .content > .center"
        },
        template: {
            dimmer: function() {
                return e("<div />").attr("class", "ui dimmer")
            }
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = e(n),
            l = r.selector || "",
            c = "ontouchstart" in n.documentElement,
            u = (new Date).getTime(),
            d = [],
            f = arguments[0],
            m = "string" == typeof f,
            g = [].slice.call(arguments, 1);
        return r.each(function(p) {
            var h, v, b, y, x, C, w, k, S = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.dropdown.settings, o) : e.extend({}, e.fn.dropdown.settings),
                T = S.className,
                A = S.message,
                R = S.fields,
                E = S.keys,
                P = S.metadata,
                F = S.namespace,
                O = S.regExp,
                D = S.selector,
                q = S.error,
                j = S.templates,
                M = "." + F,
                z = "module-" + F,
                I = e(this),
                L = e(S.context),
                N = I.find(D.text),
                V = I.find(D.search),
                H = I.find(D.sizer),
                U = I.find(D.input),
                W = I.find(D.icon),
                B = I.prev().find(D.text).length > 0 ? I.prev().find(D.text) : I.prev(),
                Q = I.children(D.menu),
                X = Q.find(D.item),
                $ = !1,
                Y = !1,
                Z = !1,
                J = I.data(z);
            k = {
                initialize: function() {
                    k.debug("Initializing dropdown", S), k.is.alreadySetup() ? k.setup.reference() : (k.setup.layout(), k.refreshData(), k.save.defaults(), k.restore.selected(), k.create.id(), k.bind.events(), k.observeChanges(), k.instantiate())
                },
                instantiate: function() {
                    k.verbose("Storing instance of dropdown", k), J = k, I.data(z, k)
                },
                destroy: function() {
                    k.verbose("Destroying previous dropdown", I), k.remove.tabbable(), I.off(M).removeData(z), Q.off(M), s.off(y), k.disconnect.menuObserver(), k.disconnect.selectObserver()
                },
                observeChanges: function() {
                },
                disconnect: {
                    menuObserver: function() {
                        w && w.disconnect()
                    },
                    selectObserver: function() {
                        C && C.disconnect()
                    }
                },
                observe: {
                    select: function() {
                        k.has.input() && C.observe(U[0], {
                            childList: !0,
                            subtree: !0
                        })
                    },
                    menu: function() {
                        k.has.menu() && w.observe(Q[0], {
                            childList: !0,
                            subtree: !0
                        })
                    }
                },
                create: {
                    id: function() {
                        x = (Math.random().toString(16) + "000000000").substr(2, 8), y = "." + x, k.verbose("Creating unique id for element", x)
                    },
                    userChoice: function(t) {
                        var n, o, a;
                            k.get.item(r) === !1 && (a = S.templates.addition(k.add.variables(A.addResult, r)), o = e("<div />").html(a).attr("data-" + P.value, r).attr("data-" + P.text, r).addClass(T.addition).addClass(T.item), S.hideAdditions && o.addClass(T.hidden), n = n === i ? o : n.add(o), k.verbose("Creating user choices for value", r, o))
                        }), n) : !1
                    },
                    userLabels: function(t) {
                        var n = k.get.userValues();
                        n && (k.debug("Adding user labels", n), e.each(n, function(e, t) {
                            k.verbose("Adding custom user value"), k.add.label(t, t)
                        }))
                    },
                    menu: function() {
                        Q = e("<div />").addClass(T.menu).appendTo(I)
                    },
                    sizer: function() {
                        H = e("<span />").addClass(T.sizer).insertAfter(V)
                    }
                },
                search: function(e) {
                },
                select: {
                    firstUnfiltered: function() {
                        k.verbose("Selecting first non-filtered element"), k.remove.selectedItem(), X.not(D.unselectable).not(D.addition + D.hidden).eq(0).addClass(T.selected)
                    },
                    nextAvailable: function(e) {
                        var t = e.nextAll(D.item).not(D.unselectable).eq(0),
                            n = e.prevAll(D.item).not(D.unselectable).eq(0),
                            i = t.length > 0;
                        i ? (k.verbose("Moving selection to", t), t.addClass(T.selected)) : (k.verbose("Moving selection to", n), n.addClass(T.selected))
                    }
                },
                setup: {
                    api: function() {
                        var e = {
                            debug: S.debug,
                            urlData: {
                                value: k.get.value(),
                                query: k.get.query()
                            },
                            on: !1
                        };
                        k.verbose("First request, initializing API"), I.api(e)
                    },
                    layout: function() {
                        I.is("select") && (k.setup.select(), k.setup.returnedObject()), k.has.menu() || k.create.menu(), k.is.search() && !k.has.search() && (k.verbose("Adding search input"), V = e("<input />").addClass(T.search).prop("autocomplete", "off").insertBefore(N)), k.is.multiple() && k.is.searchSelection() && !k.has.sizer() && k.create.sizer(), S.allowTab && k.set.tabbable()
                    },
                    select: function() {
                        var t = k.get.selectValues();
                        k.debug("Dropdown initialized on a select", t), I.is("select") && (U = I), U.parent(D.dropdown).length > 0 ? (k.debug("UI dropdown already exists. Creating dropdown menu only"), I = U.closest(D.dropdown), k.has.menu() || k.create.menu(), Q = I.children(D.menu), k.setup.menu(t)) : (k.debug("Creating entire dropdown from select"), I = e("<div />").attr("class", U.attr("class")).addClass(T.selection).addClass(T.dropdown).html(j.dropdown(t)).insertBefore(U), U.hasClass(T.multiple) && U.prop("multiple") === !1 && (k.error(q.missingMultiple), U.prop("multiple", !0)), U.is("[multiple]") && k.set.multiple(), U.prop("disabled") && (k.debug("Disabling dropdown"), I.addClass(T.disabled)), U.removeAttr("class").detach().prependTo(I)), k.refresh()
                    },
                    menu: function(e) {
                        Q.html(j.menu(e, R)), X = Q.find(D.item)
                    },
                    reference: function() {
                        k.debug("Dropdown behavior was called on select, replacing with closest dropdown"), I = I.parent(D.dropdown), k.refresh(), k.setup.returnedObject(), m && (J = k, k.invoke(f))
                    },
                    returnedObject: function() {
                        var e = r.slice(0, p),
                            t = r.slice(p + 1);
                        r = e.add(I).add(t)
                    }
                },
                refresh: function() {
                    k.refreshSelectors(), k.refreshData()
                },
                refreshItems: function() {
                    X = Q.find(D.item)
                },
                refreshSelectors: function() {
                    k.verbose("Refreshing selector cache"), N = I.find(D.text), V = I.find(D.search), U = I.find(D.input), W = I.find(D.icon), B = I.prev().find(D.text).length > 0 ? I.prev().find(D.text) : I.prev(), Q = I.children(D.menu), X = Q.find(D.item)
                },
                refreshData: function() {
                    k.verbose("Refreshing cached metadata"), X.removeData(P.text).removeData(P.value)
                },
                clearData: function() {
                    k.verbose("Clearing metadata"), X.removeData(P.text).removeData(P.value), I.removeData(P.defaultText).removeData(P.defaultValue).removeData(P.placeholderText)
                },
                toggle: function() {
                    k.verbose("Toggling menu visibility"), k.is.active() ? k.hide() : k.show()
                },
                show: function(t) {
                        if (k.debug("Showing dropdown"), !k.has.message() || k.has.maxSelections() || k.has.allResultsFiltered() || k.remove.message(), k.is.allFiltered()) return !0;
                        S.onShow.call(K) !== !1 && k.animate.show(function() {
                            k.can.click() && k.bind.intent(), k.has.menuSearch() && k.focusSearch(), k.set.visible(), t.call(K)
                        })
                    }
                },
                hide: function(t) {
                        k.remove.visible(), t.call(K)
                    }))
                },
                hideOthers: function() {
                    k.verbose("Finding other dropdowns to hide"), r.not(I).has(D.menu + "." + T.visible).dropdown("hide")
                },
                hideMenu: function() {
                    k.verbose("Hiding menu  instantaneously"), k.remove.active(), k.remove.visible(), Q.transition("hide")
                },
                hideSubMenus: function() {
                    var e = Q.children(D.item).find(D.menu);
                    k.verbose("Hiding sub menus", e), e.transition("hide")
                },
                bind: {
                    events: function() {
                        c && k.bind.touchEvents(), k.bind.keyboardEvents(), k.bind.inputEvents(), k.bind.mouseEvents()
                    },
                    touchEvents: function() {
                        k.debug("Touch device detected binding additional touch events"), k.is.searchSelection() || k.is.single() && I.on("touchstart" + M, k.event.test.toggle), Q.on("touchstart" + M, D.item, k.event.item.mouseenter)
                    },
                    keyboardEvents: function() {
                        k.verbose("Binding keyboard events"), I.on("keydown" + M, k.event.keydown), k.has.search() && I.on(k.get.inputEvent() + M, D.search, k.event.input), k.is.multiple() && s.on("keydown" + y, k.event.document.keydown)
                    },
                    inputEvents: function() {
                        k.verbose("Binding input change events"), I.on("change" + M, D.input, k.event.change)
                    },
                    mouseEvents: function() {
                        k.verbose("Binding mouse events"), k.is.multiple() && I.on("click" + M, D.label, k.event.label.click).on("click" + M, D.remove, k.event.remove.click), k.is.searchSelection() ? (I.on("mousedown" + M, k.event.mousedown).on("mouseup" + M, k.event.mouseup).on("mousedown" + M, D.menu, k.event.menu.mousedown).on("mouseup" + M, D.menu, k.event.menu.mouseup).on("click" + M, D.icon, k.event.icon.click).on("focus" + M, D.search, k.event.search.focus).on("click" + M, D.search, k.event.search.focus).on("blur" + M, D.search, k.event.search.blur).on("click" + M, D.text, k.event.text.focus), k.is.multiple() && I.on("click" + M, k.event.click)) : ("click" == S.on ? I.on("click" + M, D.icon, k.event.icon.click).on("click" + M, k.event.test.toggle) : "hover" == S.on ? I.on("mouseenter" + M, k.delay.show).on("mouseleave" + M, k.delay.hide) : I.on(S.on + M, k.toggle), I.on("mousedown" + M, k.event.mousedown).on("mouseup" + M, k.event.mouseup).on("focus" + M, k.event.focus).on("blur" + M, k.event.blur)), Q.on("mouseenter" + M, D.item, k.event.item.mouseenter).on("mouseleave" + M, D.item, k.event.item.mouseleave).on("click" + M, D.item, k.event.item.click)
                    },
                    intent: function() {
                        k.verbose("Binding hide intent event to document"), c && s.on("touchstart" + y, k.event.test.touch).on("touchmove" + y, k.event.test.touch), s.on("click" + y, k.event.test.hide)
                    }
                },
                unbind: {
                    intent: function() {
                        k.verbose("Removing hide intent event from document"), c && s.off("touchstart" + y).off("touchmove" + y), s.off("click" + y)
                    }
                },
                filter: function(e) {
                    var t = e !== i ? e : k.get.query(),
                        n = function() {
                            k.is.multiple() && k.filterActive(), k.select.firstUnfiltered(), k.has.allResultsFiltered() ? S.onNoResults.call(K, t) ? S.allowAdditions ? S.hideAdditions && (k.verbose("User addition with no menu, setting empty style"), k.set.empty(), k.hideMenu()) : (k.verbose("All items filtered, showing message", t), k.add.message(A.noResults)) : (k.verbose("All items filtered, hiding dropdown", t), k.hideMenu()) : (k.remove.empty(), k.remove.message()), S.allowAdditions && k.add.userSuggestion(e), k.is.searchSelection() && k.can.show() && k.is.focusedOnSearch() && k.show()
                        };
                    S.useLabels && k.has.maxSelections() || (S.apiSettings ? k.can.useAPI() ? k.queryRemote(t, function() {
                        n()
                    }) : k.error(q.noAPI) : (k.filterItems(t), n()))
                },
                queryRemote: function(t, n) {
                    var i = {
                        errorDuration: !1,
                        cache: "local",
                        throttle: S.throttle,
                        urlData: {
                            query: t
                        },
                        onError: function() {
                            k.add.message(A.serverError), n()
                        },
                        onFailure: function() {
                            k.add.message(A.serverError), n()
                        },
                        onSuccess: function(e) {
                            k.remove.message(), k.setup.menu({
                                values: e[R.remoteValues]
                            }), n()
                        }
                    };
                    I.api("get request") || k.setup.api(), i = e.extend(!0, {}, i, S.apiSettings), I.api("setting", i).api("query")
                },
                filterItems: function(t) {
                    var n = t !== i ? t : k.get.query(),
                        o = null,
                        a = k.escape.regExp(n),
                        r = new RegExp("^" + a, "igm");
                    k.has.query() && (o = [], k.verbose("Searching for matching values", n), X.each(function() {
                        var t, i, a = e(this);
                        if ("both" == S.match || "text" == S.match) {
                            if (t = String(k.get.choiceText(a, !1)), -1 !== t.search(r)) return o.push(this), !0;
                            if ("exact" === S.fullTextSearch && k.exactSearch(n, t)) return o.push(this), !0;
                            if (S.fullTextSearch === !0 && k.fuzzySearch(n, t)) return o.push(this), !0
                        }
                        if ("both" == S.match || "value" == S.match) {
                            if (i = String(k.get.choiceValue(a, t)), -1 !== i.search(r)) return o.push(this), !0;
                            if (S.fullTextSearch && k.fuzzySearch(n, i)) return o.push(this), !0
                        }
                    })), k.debug("Showing only matched items", n), k.remove.filteredItem(), o && X.not(o).addClass(T.filtered)
                },
                fuzzySearch: function(e, t) {
                    var n = t.length,
                        i = e.length;
                    if (i === n) return e === t;
                    e: for (var o = 0, a = 0; i > o; o++) {
                        for (var r = e.charCodeAt(o); n > a;)
                            if (t.charCodeAt(a++) === r) continue e;
                        return !1
                    }
                    return !0
                },
                exactSearch: function(e, t) {
                },
                filterActive: function() {
                    S.useLabels && X.filter("." + T.active).addClass(T.filtered)
                },
                focusSearch: function(e) {
                    k.has.search() && !k.is.focusedOnSearch() && (e ? (I.off("focus" + M, D.search), V.focus(), I.on("focus" + M, D.search, k.event.search.focus)) : V.focus())
                },
                forceSelection: function() {
                    var e = X.not(T.filtered).filter("." + T.selected).eq(0),
                        t = X.not(T.filtered).filter("." + T.active).eq(0),
                        n = e.length > 0 ? e : t,
                        i = n.length > 0;
                    return i ? (k.debug("Forcing partial selection to selected item", n), void k.event.item.click.call(n, {}, !0)) : void(S.allowAdditions ? (k.set.selected(k.get.query()), k.remove.searchTerm()) : k.remove.searchTerm())
                },
                event: {
                    change: function() {
                        Z || (k.debug("Input changed, updating selection"), k.set.selected())
                    },
                    focus: function() {
                        S.showOnFocus && !$ && k.is.hidden() && !v && k.show()
                    },
                    blur: function(e) {
                    },
                    mousedown: function() {
                        k.is.searchSelection() ? b = !0 : $ = !0
                    },
                    mouseup: function() {
                        k.is.searchSelection() ? b = !1 : $ = !1
                    },
                    click: function(t) {
                        var n = e(t.target);
                        n.is(I) && (k.is.focusedOnSearch() ? k.show() : k.focusSearch())
                    },
                    search: {
                        focus: function() {
                            $ = !0, k.is.multiple() && k.remove.activeLabel(), S.showOnFocus && k.search();
                        },
                        blur: function(e) {
                        }
                    },
                    icon: {
                        click: function(e) {
                            k.toggle()
                        }
                    },
                    text: {
                        focus: function(e) {
                            $ = !0, k.focusSearch()
                        }
                    },
                    input: function(e) {
                        (k.is.multiple() || k.is.searchSelection()) && k.set.filtered(), clearTimeout(k.timer), k.timer = setTimeout(k.search, S.delay.search)
                    },
                    label: {
                        click: function(t) {
                            var n = e(this),
                                i = I.find(D.label),
                                o = i.filter("." + T.active),
                                a = n.nextAll("." + T.active),
                                r = n.prevAll("." + T.active),
                                s = a.length > 0 ? n.nextUntil(a).add(o).add(n) : n.prevUntil(r).add(o).add(n);
                            t.shiftKey ? (o.removeClass(T.active), s.addClass(T.active)) : t.ctrlKey ? n.toggleClass(T.active) : (o.removeClass(T.active), n.addClass(T.active)), S.onLabelSelect.apply(this, i.filter("." + T.active))
                        }
                    },
                    remove: {
                        click: function() {
                            var t = e(this).parent();
                            t.hasClass(T.active) ? k.remove.activeLabels() : k.remove.activeLabels(t)
                        }
                    },
                    test: {
                        toggle: function(e) {
                            var t = k.is.multiple() ? k.show : k.toggle;
                            k.is.bubbledLabelClick(e) || k.is.bubbledIconClick(e) || k.determine.eventOnElement(e, t) && e.preventDefault()
                        },
                        touch: function(e) {
                            k.determine.eventOnElement(e, function() {
                                "touchstart" == e.type ? k.timer = setTimeout(function() {
                                    k.hide()
                                }, S.delay.touch) : "touchmove" == e.type && clearTimeout(k.timer)
                            }), e.stopPropagation()
                        },
                        hide: function(e) {
                            k.determine.eventInModule(e, k.hide)
                        }
                    },
                    select: {
                        mutation: function(e) {
                            k.debug("<select> modified, recreating menu"), k.setup.select()
                        }
                    },
                    menu: {
                        mutation: function(t) {
                            var n = t[0],
                                i = e(n.addedNodes ? n.addedNodes[0] : !1),
                                o = e(n.removedNodes ? n.removedNodes[0] : !1),
                                a = i.add(o),
                                r = a.is(D.addition) || a.closest(D.addition).length > 0,
                                s = a.is(D.message) || a.closest(D.message).length > 0;
                            r || s ? (k.debug("Updating item selector cache"), k.refreshItems()) : (k.debug("Menu modified, updating selector cache"), k.refresh())
                        },
                        mousedown: function() {
                            Y = !0
                        },
                        mouseup: function() {
                            Y = !1
                        }
                    },
                    item: {
                        mouseenter: function(t) {
                            var n = e(t.target),
                                i = e(this),
                                o = i.children(D.menu),
                                a = i.siblings(D.item).children(D.menu),
                                r = o.length > 0,
                                s = o.find(n).length > 0;
                            !s && r && (clearTimeout(k.itemTimer), k.itemTimer = setTimeout(function() {
                                k.verbose("Showing sub-menu", o), e.each(a, function() {
                                    k.animate.hide(!1, e(this))
                                }), k.animate.show(!1, o)
                            }, S.delay.show), t.preventDefault())
                        },
                        mouseleave: function(t) {
                            var n = e(this).children(D.menu);
                            n.length > 0 && (clearTimeout(k.itemTimer), k.itemTimer = setTimeout(function() {
                                k.verbose("Hiding sub-menu", n), k.animate.hide(!1, n)
                            }, S.delay.hide))
                        },
                        click: function(t, n) {
                            var i = e(this),
                                o = e(t ? t.target : ""),
                                a = i.find(D.menu),
                                r = k.get.choiceText(i),
                                s = k.get.choiceValue(i, r),
                                l = a.length > 0,
                                c = a.find(o).length > 0;
                            c || l && !S.allowCategorySelection || (k.is.searchSelection() && (S.allowAdditions && k.remove.userAddition(), k.remove.searchTerm(), k.is.focusedOnSearch() || 1 == n || k.focusSearch(!0)), S.useLabels || (k.remove.filteredItem(), k.set.scrollPosition(i)), k.determine.selectAction.call(this, r, s))
                        }
                    },
                    document: {
                        keydown: function(e) {
                            var t = e.which,
                                n = k.is.inObject(t, E);
                            if (n) {
                                var i = I.find(D.label),
                                    o = i.filter("." + T.active),
                                    a = (o.data(P.value), i.index(o)),
                                    r = i.length,
                                    s = o.length > 0,
                                    l = o.length > 1,
                                    c = 0 === a,
                                    u = a + 1 == r,
                                    d = k.is.searchSelection(),
                                    f = k.is.focusedOnSearch(),
                                    m = k.is.focused(),
                                    g = f && 0 === k.get.caretPosition();
                                if (d && !s && !f) return;
                                t == E.leftArrow ? !m && !g || s ? s && (e.shiftKey ? k.verbose("Adding previous label to selection") : (k.verbose("Selecting previous label"), i.removeClass(T.active)), c && !l ? o.addClass(T.active) : o.prev(D.siblingLabel).addClass(T.active).end(), e.preventDefault()) : (k.verbose("Selecting previous label"), i.last().addClass(T.active)) : t == E.rightArrow ? (m && !s && i.first().addClass(T.active), s && (e.shiftKey ? k.verbose("Adding next label to selection") : (k.verbose("Selecting next label"), i.removeClass(T.active)), u ? d ? f ? i.removeClass(T.active) : k.focusSearch() : l ? o.next(D.siblingLabel).addClass(T.active) : o.addClass(T.active) : o.next(D.siblingLabel).addClass(T.active), e.preventDefault())) : t == E.deleteKey || t == E.backspace ? s ? (k.verbose("Removing active labels"), u && d && !f && k.focusSearch(), o.last().next(D.siblingLabel).addClass(T.active), k.remove.activeLabels(o), e.preventDefault()) : g && !s && t == E.backspace && (k.verbose("Removing last label on input backspace"), o = i.last().addClass(T.active), k.remove.activeLabels(o)) : o.removeClass(T.active)
                            }
                        }
                    },
                    keydown: function(e) {
                        var t = e.which,
                            n = k.is.inObject(t, E);
                        if (n) {
                            var i, o, a = X.not(D.unselectable).filter("." + T.selected).eq(0),
                                r = Q.children("." + T.active).eq(0),
                                s = a.length > 0 ? a : r,
                                l = s.length > 0 ? s.siblings(":not(." + T.filtered + ")").addBack() : Q.children(":not(." + T.filtered + ")"),
                                c = s.children(D.menu),
                                u = s.closest(D.menu),
                                d = u.hasClass(T.visible) || u.hasClass(T.animating) || u.parent(D.menu).length > 0,
                                f = c.length > 0,
                                m = s.length > 0,
                                g = s.not(D.unselectable).length > 0,
                                p = t == E.delimiter && S.allowAdditions && k.is.multiple(),
                                h = S.allowAdditions && S.hideAdditions && (t == E.enter || p) && g;
                            if (h && (k.verbose("Selecting item from keyboard shortcut", s), k.event.item.click.call(s, e), k.is.searchSelection() && k.remove.searchTerm()), k.is.visible()) {
                                if ((t == E.enter || p) && (t == E.enter && m && f && !S.allowCategorySelection ? (k.verbose("Pressed enter on unselectable category, opening sub menu"), t = E.rightArrow) : g && (k.verbose("Selecting item from keyboard shortcut", s), k.event.item.click.call(s, e), k.is.searchSelection() && k.remove.searchTerm()), e.preventDefault()), m && (t == E.leftArrow && (o = u[0] !== Q[0], o && (k.verbose("Left key pressed, closing sub-menu"), k.animate.hide(!1, u), s.removeClass(T.selected), u.closest(D.item).addClass(T.selected), e.preventDefault())), t == E.rightArrow && f && (k.verbose("Right key pressed, opening sub-menu"), k.animate.show(!1, c), s.removeClass(T.selected), c.find(D.item).eq(0).addClass(T.selected), e.preventDefault())), t == E.upArrow) {
                                    if (i = m && d ? s.prevAll(D.item + ":not(" + D.unselectable + ")").eq(0) : X.eq(0), l.index(i) < 0) return k.verbose("Up key pressed but reached top of current menu"), void e.preventDefault();
                                    k.verbose("Up key pressed, changing active item"), s.removeClass(T.selected), i.addClass(T.selected), k.set.scrollPosition(i), S.selectOnKeydown && k.is.single() && k.set.selectedItem(i), e.preventDefault()
                                }
                                if (t == E.downArrow) {
                                    if (i = m && d ? i = s.nextAll(D.item + ":not(" + D.unselectable + ")").eq(0) : X.eq(0), 0 === i.length) return k.verbose("Down key pressed but reached bottom of current menu"), void e.preventDefault();
                                    k.verbose("Down key pressed, changing active item"), X.removeClass(T.selected), i.addClass(T.selected), k.set.scrollPosition(i), S.selectOnKeydown && k.is.single() && k.set.selectedItem(i), e.preventDefault()
                                }
                                t == E.pageUp && (k.scrollPage("up"), e.preventDefault()), t == E.pageDown && (k.scrollPage("down"), e.preventDefault()), t == E.escape && (k.verbose("Escape key pressed, closing dropdown"), k.hide())
                            } else p && e.preventDefault(), t != E.downArrow || k.is.visible() || (k.verbose("Down key pressed, showing dropdown"), k.select.firstUnfiltered(), k.show(), e.preventDefault())
                        } else k.has.search() || k.set.selectedLetter(String.fromCharCode(t))
                    }
                },
                trigger: {
                    change: function() {
                        var e = n.createEvent("HTMLEvents"),
                            t = U[0];
                        t && (k.verbose("Triggering native change event"), e.initEvent("change", !0, !1), t.dispatchEvent(e))
                    }
                },
                determine: {
                    selectAction: function(t, n) {
                        k.verbose("Determining action", S.action), e.isFunction(k.action[S.action]) ? (k.verbose("Triggering preset action", S.action, t, n), k.action[S.action].call(K, t, n, this)) : e.isFunction(S.action) ? (k.verbose("Triggering user action", S.action, t, n), S.action.call(K, t, n, this)) : k.error(q.action, S.action)
                    },
                    eventInModule: function(t, i) {
                        var o = e(t.target),
                            a = o.closest(n.documentElement).length > 0,
                            r = o.closest(I).length > 0;
                    },
                    eventOnElement: function(t, i) {
                        var o = e(t.target),
                            a = o.closest(D.siblingLabel),
                            r = n.body.contains(t.target),
                            s = 0 === I.find(a).length,
                            l = 0 === o.closest(Q).length;
                    }
                },
                action: {
                    nothing: function() {},
                    activate: function(t, n, o) {
                            if (k.set.selected(n, e(o)), k.is.multiple() && !k.is.allFiltered()) return;
                            k.hideAndClear()
                        }
                    },
                    select: function(t, n, o) {
                            if (k.set.value(n, e(o)), k.is.multiple() && !k.is.allFiltered()) return;
                            k.hideAndClear()
                        }
                    },
                    combo: function(t, n, o) {
                    },
                    hide: function(e, t, n) {
                        k.set.value(t, e), k.hideAndClear()
                    }
                },
                get: {
                    id: function() {
                        return x
                    },
                    defaultText: function() {
                        return I.data(P.defaultText)
                    },
                    defaultValue: function() {
                        return I.data(P.defaultValue)
                    },
                    placeholderText: function() {
                        return I.data(P.placeholderText) || ""
                    },
                    text: function() {
                        return N.text()
                    },
                    query: function() {
                        return e.trim(V.val())
                    },
                    searchWidth: function(e) {
                    },
                    selectionCount: function() {
                        var t, n = k.get.values();
                        return t = k.is.multiple() ? e.isArray(n) ? n.length : 0 : "" !== k.get.value() ? 1 : 0
                    },
                    transition: function(e) {
                        return "auto" == S.transition ? k.is.upward(e) ? "slide up" : "slide down" : S.transition
                    },
                    userValues: function() {
                        var t = k.get.values();
                        return t ? (t = e.isArray(t) ? t : [t], e.grep(t, function(e) {
                            return k.get.item(e) === !1
                        })) : !1
                    },
                    uniqueArray: function(t) {
                        return e.grep(t, function(n, i) {
                            return e.inArray(n, t) === i
                        })
                    },
                    caretPosition: function() {
                        var e, t, i = V.get(0);
                        return "selectionStart" in i ? i.selectionStart : n.selection ? (i.focus(), e = n.selection.createRange(), t = e.text.length, e.moveStart("character", -i.value.length), e.text.length - t) : void 0
                    },
                    value: function() {
                        var t = U.length > 0 ? U.val() : I.data(P.value),
                            n = e.isArray(t) && 1 === t.length && "" === t[0];
                        return t === i || n ? "" : t
                    },
                    values: function() {
                        var e = k.get.value();
                        return "" === e ? "" : !k.has.selectInput() && k.is.multiple() ? "string" == typeof e ? e.split(S.delimiter) : "" : e
                    },
                    remoteValues: function() {
                        var t = k.get.values(),
                            n = !1;
                        return t && ("string" == typeof t && (t = [t]), e.each(t, function(e, t) {
                            var i = k.read.remoteData(t);
                            k.verbose("Restoring value from session data", i, t), i && (n || (n = {}), n[t] = i)
                        })), n
                    },
                    choiceText: function(t, n) {
                    },
                    choiceValue: function(t, n) {
                    },
                    inputEvent: function() {
                        var e = V[0];
                        return e ? e.oninput !== i ? "input" : e.onpropertychange !== i ? "propertychange" : "keyup" : !1
                    },
                    selectValues: function() {
                        var t = {};
                        return t.values = [], I.find("option").each(function() {
                            var n = e(this),
                                o = n.html(),
                                a = n.attr("disabled"),
                                r = n.attr("value") !== i ? n.attr("value") : o;
                            "auto" === S.placeholder && "" === r ? t.placeholder = o : t.values.push({
                                name: o,
                                value: r,
                                disabled: a
                            })
                        }), S.placeholder && "auto" !== S.placeholder && (k.debug("Setting placeholder value to", S.placeholder), t.placeholder = S.placeholder), S.sortSelect ? (t.values.sort(function(e, t) {
                            return e.name > t.name ? 1 : -1
                        }), k.debug("Retrieved and sorted values from select", t)) : k.debug("Retrieved values from select", t), t
                    },
                    activeItem: function() {
                        return X.filter("." + T.active)
                    },
                    selectedItem: function() {
                        var e = X.not(D.unselectable).filter("." + T.selected);
                        return e.length > 0 ? e : X.eq(0)
                    },
                    itemWithAdditions: function(e) {
                        var t = k.get.item(e),
                            n = k.create.userChoice(e),
                            i = n && n.length > 0;
                        return i && (t = t.length > 0 ? t.add(n) : n), t
                    },
                    item: function(t, n) {
                        var o, a, r = !1;
                            var o = e(this),
                                s = k.get.choiceText(o),
                                l = k.get.choiceValue(o, s);
                            if (null !== l && l !== i)
                                if (a)(-1 !== e.inArray(String(l), t) || -1 !== e.inArray(s, t)) && (r = r ? r.add(o) : o);
                                else if (n) {
                                if (k.verbose("Ambiguous dropdown value using strict type check", o, t), l === t || s === t) return r = o, !0
                            } else if (String(l) == String(t) || s == t) return k.verbose("Found select item by value", l, t), r = o, !0
                        }), r
                    }
                },
                check: {
                    maxSelections: function(e) {
                    }
                },
                restore: {
                    defaults: function() {
                        k.clear(), k.restore.defaultText(), k.restore.defaultValue()
                    },
                    defaultText: function() {
                        var e = k.get.defaultText(),
                            t = k.get.placeholderText;
                        e === t ? (k.debug("Restoring default placeholder text", e), k.set.placeholderText(e)) : (k.debug("Restoring default text", e), k.set.text(e))
                    },
                    placeholderText: function() {
                        k.set.placeholderText()
                    },
                    defaultValue: function() {
                        var e = k.get.defaultValue();
                        e !== i && (k.debug("Restoring default value", e), "" !== e ? (k.set.value(e), k.set.selected()) : (k.remove.activeItem(), k.remove.selectedItem()))
                    },
                    labels: function() {
                        S.allowAdditions && (S.useLabels || (k.error(q.labels), S.useLabels = !0), k.debug("Restoring selected values"), k.create.userLabels()), k.check.maxSelections()
                    },
                    selected: function() {
                        k.restore.values(), k.is.multiple() ? (k.debug("Restoring previously selected values and labels"), k.restore.labels()) : k.debug("Restoring previously selected values")
                    },
                    values: function() {
                        k.set.initialLoad(), S.apiSettings && S.saveRemoteData && k.get.remoteValues() ? k.restore.remoteValues() : k.set.selected(), k.remove.initialLoad()
                    },
                    remoteValues: function() {
                        var t = k.get.remoteValues();
                        k.debug("Recreating selected from session data", t), t && (k.is.single() ? e.each(t, function(e, t) {
                            k.set.text(t)
                        }) : e.each(t, function(e, t) {
                            k.add.label(e, t)
                        }))
                    }
                },
                read: {
                    remoteData: function(e) {
                        var n;
                    }
                },
                save: {
                    defaults: function() {
                        k.save.defaultText(), k.save.placeholderText(), k.save.defaultValue()
                    },
                    defaultValue: function() {
                        var e = k.get.value();
                        k.verbose("Saving default value as", e), I.data(P.defaultValue, e)
                    },
                    defaultText: function() {
                        var e = k.get.text();
                        k.verbose("Saving default text as", e), I.data(P.defaultText, e)
                    },
                    placeholderText: function() {
                        var e;
                        S.placeholder !== !1 && N.hasClass(T.placeholder) && (e = k.get.text(), k.verbose("Saving placeholder text as", e), I.data(P.placeholderText, e))
                    },
                    remoteData: function(e, n) {
                    }
                },
                clear: function() {
                    k.is.multiple() && S.useLabels ? k.remove.labels() : (k.remove.activeItem(), k.remove.selectedItem()), k.set.placeholderText(), k.clearValue()
                },
                clearValue: function() {
                    k.set.value("")
                },
                scrollPage: function(e, t) {
                    var n, i, o, a = t || k.get.selectedItem(),
                        r = a.closest(D.menu),
                        s = r.outerHeight(),
                        l = r.scrollTop(),
                        c = X.eq(0).outerHeight(),
                        u = Math.floor(s / c),
                        d = (r.prop("scrollHeight"), "up" == e ? l - c * u : l + c * u),
                        f = X.not(D.unselectable);
                    o = "up" == e ? f.index(a) - u : f.index(a) + u, n = "up" == e ? o >= 0 : o < f.length, i = n ? f.eq(o) : "up" == e ? f.first() : f.last(), i.length > 0 && (k.debug("Scrolling page", e, i), a.removeClass(T.selected), i.addClass(T.selected), S.selectOnKeydown && k.is.single() && k.set.selectedItem(i), r.scrollTop(d))
                },
                set: {
                    filtered: function() {
                        var e = k.is.multiple(),
                            t = k.is.searchSelection(),
                            n = e && t,
                            i = t ? k.get.query() : "",
                            o = "string" == typeof i && i.length > 0,
                            a = k.get.searchWidth(),
                            r = "" !== i;
                        e && o && (k.verbose("Adjusting input width", a, S.glyphWidth), V.css("width", a)), o || n && r ? (k.verbose("Hiding placeholder text"), N.addClass(T.filtered)) : (!e || n && !r) && (k.verbose("Showing placeholder text"), N.removeClass(T.filtered))
                    },
                    empty: function() {
                        I.addClass(T.empty)
                    },
                    loading: function() {
                        I.addClass(T.loading)
                    },
                    placeholderText: function(e) {
                    },
                    tabbable: function() {
                        k.has.search() ? (k.debug("Added tabindex to searchable dropdown"), V.val("").attr("tabindex", 0), Q.attr("tabindex", -1)) : (k.debug("Added tabindex to dropdown"), I.attr("tabindex") === i && (I.attr("tabindex", 0), Q.attr("tabindex", -1)))
                    },
                    initialLoad: function() {
                        k.verbose("Setting initial load"), h = !0
                    },
                    activeItem: function(e) {
                        S.allowAdditions && e.filter(D.addition).length > 0 ? e.addClass(T.filtered) : e.addClass(T.active)
                    },
                    partialSearch: function(e) {
                        var t = k.get.query().length;
                        V.val(e.substr(0, t))
                    },
                    scrollPosition: function(e, t) {
                        var n, o, a, r, s, l, c, u, d, f = 5;
                    },
                    text: function(e) {
                        "select" !== S.action && ("combo" == S.action ? (k.debug("Changing combo button text", e, B), S.preserveHTML ? B.html(e) : B.text(e)) : (e !== k.get.placeholderText() && N.removeClass(T.placeholder), k.debug("Changing text", e, N), N.removeClass(T.filtered), S.preserveHTML ? N.html(e) : N.text(e)))
                    },
                    selectedItem: function(e) {
                        var t = k.get.choiceValue(e),
                            n = k.get.choiceText(e, !1);
                        k.debug("Setting user selection to item", e), k.remove.activeItem(), k.set.partialSearch(n), k.set.activeItem(e), k.set.selected(t, e), k.set.text(n)
                    },
                    selectedLetter: function(t) {
                        var n, i = X.filter("." + T.selected),
                            o = i.length > 0 && k.has.firstLetter(i, t),
                            a = !1;
                        o && (n = i.nextAll(X).eq(0), k.has.firstLetter(n, t) && (a = n)), a || X.each(function() {
                            return k.has.firstLetter(e(this), t) ? (a = e(this), !1) : void 0
                        }), a && (k.verbose("Scrolling to next value with letter", t), k.set.scrollPosition(a), i.removeClass(T.selected), a.addClass(T.selected), S.selectOnKeydown && k.is.single() && k.set.selectedItem(a))
                    },
                    direction: function(e) {
                        "auto" == S.direction ? k.is.onScreen(e) ? k.remove.upward(e) : k.set.upward(e) : "upward" == S.direction && k.set.upward(e)
                    },
                    upward: function(e) {
                        var t = e || I;
                        t.addClass(T.upward)
                    },
                    value: function(e, t, n) {
                        var o = k.escape.value(e),
                            a = U.length > 0,
                            r = (!k.has.value(e), k.get.values()),
                            s = e !== i ? String(e) : e;
                        if (a) {
                            if (!S.allowReselection && s == r && (k.verbose("Skipping value update already same value", e, r), !k.is.initialLoad())) return;
                            k.is.single() && k.has.selectInput() && k.can.extendSelect() && (k.debug("Adding user option", e), k.add.optionValue(e)), k.debug("Updating input value", o, r), Z = !0, U.val(o), S.fireOnInit === !1 && k.is.initialLoad() ? k.debug("Input native change event ignored on initial load") : k.trigger.change(), Z = !1
                        } else k.verbose("Storing value in metadata", o, U), o !== r && I.data(P.value, s);
                        S.fireOnInit === !1 && k.is.initialLoad() ? k.verbose("No callback on initial load", S.onChange) : S.onChange.call(K, e, t, n)
                    },
                    active: function() {
                        I.addClass(T.active)
                    },
                    multiple: function() {
                        I.addClass(T.multiple)
                    },
                    visible: function() {
                        I.addClass(T.visible)
                    },
                    exactly: function(e, t) {
                        k.debug("Setting selected to exact values"), k.clear(), k.set.selected(e, t)
                    },
                    selected: function(t, n) {
                        var i = k.is.multiple();
                            var t = e(this),
                                o = k.get.choiceText(t),
                                a = k.get.choiceValue(t, o),
                                r = t.hasClass(T.filtered),
                                s = t.hasClass(T.active),
                                l = t.hasClass(T.addition),
                                c = i && 1 == n.length;
                            i ? !s || l ? (S.apiSettings && S.saveRemoteData && k.save.remoteData(o, a), S.useLabels ? (k.add.value(a, o, t), k.add.label(a, o, c), k.set.activeItem(t), k.filterActive(), k.select.nextAvailable(n)) : (k.add.value(a, o, t), k.set.text(k.add.variables(A.count)), k.set.activeItem(t))) : r || (k.debug("Selected active value, removing label"), k.remove.selected(a)) : (S.apiSettings && S.saveRemoteData && k.save.remoteData(o, a), k.set.text(o), k.set.value(a, o, t), t.addClass(T.active).addClass(T.selected))
                        }))
                    }
                },
                add: {
                    label: function(t, n, i) {
                        var o, a = k.is.searchSelection() ? V : N,
                            r = k.escape.value(t);
                        return o = e("<a />").addClass(T.label).attr("data-value", r).html(j.label(r, n)), o = S.onLabelCreate.call(o, r, n), k.has.label(t) ? void k.debug("Label already exists, skipping", r) : (S.label.variation && o.addClass(S.label.variation), void(i === !0 ? (k.debug("Animating in label", o), o.addClass(T.hidden).insertBefore(a).transition(S.label.transition, S.label.duration)) : (k.debug("Adding selection label", o), o.insertBefore(a))))
                    },
                    message: function(t) {
                        var n = Q.children(D.message),
                            i = S.templates.message(k.add.variables(t));
                        n.length > 0 ? n.html(i) : n = e("<div/>").html(i).addClass(T.message).appendTo(Q)
                    },
                    optionValue: function(t) {
                        var n = k.escape.value(t),
                            i = U.find('option[value="' + n + '"]'),
                            o = i.length > 0;
                        o || (k.disconnect.selectObserver(), k.is.single() && (k.verbose("Removing previous user addition"), U.find("option." + T.addition).remove()), e("<option/>").prop("value", n).addClass(T.addition).html(t).appendTo(U), k.verbose("Adding user addition as an <option>", t), k.observe.select())
                    },
                    userSuggestion: function(e) {
                        var t, n = Q.children(D.addition),
                            i = k.get.item(e),
                            o = i && i.not(D.addition).length,
                            a = n.length > 0;
                        if (!S.useLabels || !k.has.maxSelections()) {
                            if ("" === e || o) return void n.remove();
                            a ? (n.data(P.value, e).data(P.text, e).attr("data-" + P.value, e).attr("data-" + P.text, e).removeClass(T.filtered), S.hideAdditions || (t = S.templates.addition(k.add.variables(A.addResult, e)), n.html(t)), k.verbose("Replacing user suggestion with new value", n)) : (n = k.create.userChoice(e), n.prependTo(Q), k.verbose("Adding item choice to menu corresponding with user choice addition", n)), (!S.hideAdditions || k.is.allFiltered()) && n.addClass(T.selected).siblings().removeClass(T.selected), k.refreshItems()
                        }
                    },
                    variables: function(e, t) {
                        var n, i, o = -1 !== e.search("{count}"),
                            a = -1 !== e.search("{maxCount}"),
                            r = -1 !== e.search("{term}");
                    },
                    value: function(t, n, i) {
                        var o, a = k.get.values();
                        return "" === t ? void k.debug("Cannot select blank values from multiselect") : (e.isArray(a) ? (o = a.concat([t]), o = k.get.uniqueArray(o)) : o = [t], k.has.selectInput() ? k.can.extendSelect() && (k.debug("Adding value to select", t, o, U), k.add.optionValue(t)) : (o = o.join(S.delimiter), k.debug("Setting hidden input to delimited value", o, U)), S.fireOnInit === !1 && k.is.initialLoad() ? k.verbose("Skipping onadd callback on initial load", S.onAdd) : S.onAdd.call(K, t, n, i), k.set.value(o, t, n, i), void k.check.maxSelections())
                    }
                },
                remove: {
                    active: function() {
                        I.removeClass(T.active)
                    },
                    activeLabel: function() {
                        I.find(D.label).removeClass(T.active)
                    },
                    empty: function() {
                        I.removeClass(T.empty)
                    },
                    loading: function() {
                        I.removeClass(T.loading)
                    },
                    initialLoad: function() {
                        h = !1
                    },
                    upward: function(e) {
                        var t = e || I;
                        t.removeClass(T.upward)
                    },
                    visible: function() {
                        I.removeClass(T.visible)
                    },
                    activeItem: function() {
                        X.removeClass(T.active)
                    },
                    filteredItem: function() {
                        S.useLabels && k.has.maxSelections() || (S.useLabels && k.is.multiple() ? X.not("." + T.active).removeClass(T.filtered) : X.removeClass(T.filtered), k.remove.empty())
                    },
                    optionValue: function(e) {
                        var t = k.escape.value(e),
                            n = U.find('option[value="' + t + '"]'),
                            i = n.length > 0;
                        i && n.hasClass(T.addition) && (C && (C.disconnect(), k.verbose("Temporarily disconnecting mutation observer")), n.remove(), k.verbose("Removing user addition as an <option>", t), C && C.observe(U[0], {
                            childList: !0,
                            subtree: !0
                        }))
                    },
                    message: function() {
                        Q.children(D.message).remove()
                    },
                    searchWidth: function() {
                        V.css("width", "")
                    },
                    searchTerm: function() {
                        k.verbose("Cleared search term"), V.val(""), k.set.filtered()
                    },
                    userAddition: function() {
                        X.filter(D.addition).remove()
                    },
                    selected: function(t, n) {
                            var t = e(this),
                                n = k.get.choiceText(t),
                                i = k.get.choiceValue(t, n);
                            k.is.multiple() ? S.useLabels ? (k.remove.value(i, n, t), k.remove.label(i)) : (k.remove.value(i, n, t), 0 === k.get.selectionCount() ? k.set.placeholderText() : k.set.text(k.add.variables(A.count))) : k.remove.value(i, n, t), t.removeClass(T.filtered).removeClass(T.active), S.useLabels && t.removeClass(T.selected)
                        }) : !1
                    },
                    selectedItem: function() {
                        X.removeClass(T.selected)
                    },
                    value: function(e, t, n) {
                        var i, o = k.get.values();
                        k.has.selectInput() ? (k.verbose("Input is <select> removing selected option", e), i = k.remove.arrayValue(e, o), k.remove.optionValue(e)) : (k.verbose("Removing from delimited values", e), i = k.remove.arrayValue(e, o), i = i.join(S.delimiter)), S.fireOnInit === !1 && k.is.initialLoad() ? k.verbose("No callback on initial load", S.onRemove) : S.onRemove.call(K, e, t, n), k.set.value(i, t, n), k.check.maxSelections()
                    },
                    arrayValue: function(t, n) {
                            return t != e
                        }), k.verbose("Removed value from delimited string", t, n), n
                    },
                    label: function(e, t) {
                        var n = I.find(D.label),
                            i = n.filter('[data-value="' + e + '"]');
                        k.verbose("Removing label", i), i.remove()
                    },
                    activeLabels: function(e) {
                    },
                    labels: function(t) {
                            var t = e(this),
                                n = t.data(P.value),
                                o = n !== i ? String(n) : n,
                                a = k.is.userValue(o);
                            return S.onLabelRemove.call(t, n) === !1 ? void k.debug("Label remove callback cancelled removal") : (k.remove.message(), void(a ? (k.remove.value(o), k.remove.label(o)) : k.remove.selected(o)))
                        })
                    },
                    tabbable: function() {
                        k.has.search() ? (k.debug("Searchable dropdown initialized"), V.removeAttr("tabindex"), Q.removeAttr("tabindex")) : (k.debug("Simple selection dropdown initialized"), I.removeAttr("tabindex"), Q.removeAttr("tabindex"))
                    }
                },
                has: {
                    menuSearch: function() {
                        return k.has.search() && V.closest(Q).length > 0
                    },
                    search: function() {
                        return V.length > 0
                    },
                    sizer: function() {
                        return H.length > 0
                    },
                    selectInput: function() {
                        return U.is("select")
                    },
                    minCharacters: function(e) {
                    },
                    firstLetter: function(e, t) {
                        var n, i;
                    },
                    input: function() {
                        return U.length > 0
                    },
                    items: function() {
                        return X.length > 0
                    },
                    menu: function() {
                        return Q.length > 0
                    },
                    message: function() {
                        return 0 !== Q.children(D.message).length
                    },
                    label: function(e) {
                        var t = k.escape.value(e),
                            n = I.find(D.label);
                        return n.filter('[data-value="' + t + '"]').length > 0
                    },
                    maxSelections: function() {
                        return S.maxSelections && k.get.selectionCount() >= S.maxSelections
                    },
                    allResultsFiltered: function() {
                        var e = X.not(D.addition);
                        return e.filter(D.unselectable).length === e.length
                    },
                    userSuggestion: function() {
                        return Q.children(D.addition).length > 0
                    },
                    query: function() {
                        return "" !== k.get.query()
                    },
                    value: function(t) {
                        var n = k.get.values(),
                            i = e.isArray(n) ? n && -1 !== e.inArray(t, n) : n == t;
                        return i ? !0 : !1
                    }
                },
                is: {
                    active: function() {
                        return I.hasClass(T.active)
                    },
                    bubbledLabelClick: function(t) {
                        return e(t.target).is("select, input") && I.closest("label").length > 0
                    },
                    bubbledIconClick: function(t) {
                        return e(t.target).closest(W).length > 0
                    },
                    alreadySetup: function() {
                        return I.is("select") && I.parent(D.dropdown).length > 0 && 0 === I.prev().length
                    },
                    animating: function(e) {
                        return e ? e.transition && e.transition("is animating") : Q.transition && Q.transition("is animating")
                    },
                    disabled: function() {
                        return I.hasClass(T.disabled)
                    },
                    focused: function() {
                        return n.activeElement === I[0]
                    },
                    focusedOnSearch: function() {
                        return n.activeElement === V[0]
                    },
                    allFiltered: function() {
                        return (k.is.multiple() || k.has.search()) && !(0 == S.hideAdditions && k.has.userSuggestion()) && !k.has.message() && k.has.allResultsFiltered()
                    },
                    hidden: function(e) {
                        return !k.is.visible(e)
                    },
                    initialLoad: function() {
                        return h
                    },
                    onScreen: function(e) {
                        var t, n = e || Q,
                            i = !0,
                            o = {};
                        return n.addClass(T.loading), t = {
                            context: {
                                scrollTop: L.scrollTop(),
                                height: L.outerHeight()
                            },
                            menu: {
                                offset: n.offset(),
                                height: n.outerHeight()
                            }
                        }, o = {
                            above: t.context.scrollTop <= t.menu.offset.top - t.menu.height,
                            below: t.context.scrollTop + t.context.height >= t.menu.offset.top + t.menu.height
                        }, o.below ? (k.verbose("Dropdown can fit in context downward", o), i = !0) : o.below || o.above ? (k.verbose("Dropdown cannot fit below, opening upward", o), i = !1) : (k.verbose("Dropdown cannot fit in either direction, favoring downward", o), i = !0), n.removeClass(T.loading), i
                    },
                    inObject: function(t, n) {
                        var i = !1;
                        return e.each(n, function(e, n) {
                            return n == t ? (i = !0, !0) : void 0
                        }), i
                    },
                    multiple: function() {
                        return I.hasClass(T.multiple)
                    },
                    single: function() {
                        return !k.is.multiple()
                    },
                    selectMutation: function(t) {
                        var n = !1;
                        return e.each(t, function(t, i) {
                            return i.target && e(i.target).is("select") ? (n = !0, !0) : void 0
                        }), n
                    },
                    search: function() {
                        return I.hasClass(T.search)
                    },
                    searchSelection: function() {
                        return k.has.search() && 1 === V.parent(D.dropdown).length
                    },
                    selection: function() {
                        return I.hasClass(T.selection)
                    },
                    userValue: function(t) {
                        return -1 !== e.inArray(t, k.get.userValues())
                    },
                    upward: function(e) {
                        var t = e || I;
                        return t.hasClass(T.upward)
                    },
                    visible: function(e) {
                        return e ? e.hasClass(T.visible) : Q.hasClass(T.visible)
                    }
                },
                can: {
                    activate: function(e) {
                        return S.useLabels ? !0 : k.has.maxSelections() ? k.has.maxSelections() && e.hasClass(T.active) ? !0 : !1 : !0
                    },
                    click: function() {
                        return c || "click" == S.on
                    },
                    extendSelect: function() {
                        return S.allowAdditions || S.apiSettings
                    },
                    show: function() {
                        return !k.is.disabled() && (k.has.items() || k.has.message())
                    },
                    useAPI: function() {
                        return e.fn.api !== i
                    }
                },
                animate: {
                    show: function(t, n) {
                        var i, o = n || Q,
                            a = n ? function() {} : function() {
                                k.hideSubMenus(), k.hideOthers(), k.set.active()
                            };
                            animation: i + " in",
                            debug: S.debug,
                            verbose: S.verbose,
                            duration: S.duration,
                            queue: !0,
                            onStart: a,
                            onComplete: function() {
                                t.call(K)
                            }
                        }))
                    },
                    hide: function(t, n) {
                        var i = n || Q,
                            o = (n ? .9 * S.duration : S.duration, n ? function() {} : function() {
                                k.can.click() && k.unbind.intent(), k.remove.active()
                            }),
                            a = k.get.transition(n);
                            animation: a + " out",
                            duration: S.duration,
                            debug: S.debug,
                            verbose: S.verbose,
                            queue: !0,
                            onStart: o,
                            onComplete: function() {
                                "auto" == S.direction && k.remove.upward(n), t.call(K)
                            }
                        }))
                    }
                },
                hideAndClear: function() {
                    k.remove.searchTerm(), k.has.maxSelections() || (k.has.search() ? k.hide(function() {
                        k.remove.filteredItem()
                    }) : k.hide())
                },
                delay: {
                    show: function() {
                        k.verbose("Delaying show event to ensure user intent"), clearTimeout(k.timer), k.timer = setTimeout(k.show, S.delay.show)
                    },
                    hide: function() {
                        k.verbose("Delaying hide event to ensure user intent"), clearTimeout(k.timer), k.timer = setTimeout(k.hide, S.delay.hide)
                    }
                },
                escape: {
                    value: function(t) {
                        var n = e.isArray(t),
                            i = "string" == typeof t,
                            o = !i && !n,
                            a = i && -1 !== t.search(O.quote),
                            r = [];
                        return k.has.selectInput() && !o && a ? (k.debug("Encoding quote values for use in select", t), n ? (e.each(t, function(e, t) {
                            r.push(t.replace(O.quote, "&quot;"))
                        }), r) : t.replace(O.quote, "&quot;")) : t
                    },
                    regExp: function(e) {
                    }
                },
                setting: function(t, n) {
                    if (k.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, S, t);
                    else {
                        if (n === i) return S[t];
                        e.isPlainObject(S[t]) ? e.extend(!0, S[t], n) : S[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, k, t);
                    else {
                        if (n === i) return k[t];
                        k[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        S.performance && (t = (new Date).getTime(), i = u || t, n = t - i, u = t, d.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: K,
                            "Execution Time": n
                        })), clearTimeout(k.performance.timer), k.performance.timer = setTimeout(k.performance.display, 500)
                    },
                    display: function() {
                        var t = S.name + ":",
                            n = 0;
                        u = !1, clearTimeout(k.performance.timer), e.each(d, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = J;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o],
                                !1) : (k.error(q.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, m ? (J === i && k.initialize(), k.invoke(f)) : (J !== i && J.invoke("destroy"), k.initialize())
        }), a !== i ? a : r
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        on: "click",
        action: "activate",
        apiSettings: !1,
        selectOnKeydown: !0,
        minCharacters: 0,
        saveRemoteData: !0,
        throttle: 200,
        context: t,
        direction: "auto",
        keepOnScreen: !0,
        match: "both",
        fullTextSearch: !1,
        placeholder: "auto",
        preserveHTML: !0,
        sortSelect: !1,
        forceSelection: !0,
        allowAdditions: !1,
        hideAdditions: !0,
        maxSelections: !1,
        useLabels: !0,
        delimiter: ",",
        showOnFocus: !0,
        allowReselection: !1,
        allowTab: !0,
        allowCategorySelection: !1,
        fireOnInit: !1,
        transition: "auto",
        duration: 200,
        glyphWidth: 1.037,
        label: {
            transition: "scale",
            duration: 200,
            variation: !1
        },
        delay: {
            hide: 300,
            show: 200,
            search: 20,
            touch: 50
        },
        onChange: function(e, t, n) {},
        onAdd: function(e, t, n) {},
        onRemove: function(e, t, n) {},
        onLabelSelect: function(e) {},
        onLabelCreate: function(t, n) {
            return e(this)
        },
        onLabelRemove: function(e) {
            return !0
        },
        onNoResults: function(e) {
            return !0
        },
        onShow: function() {},
        onHide: function() {},
        name: "Dropdown",
        namespace: "dropdown",
        message: {
            addResult: "Add <b>{term}</b>",
            count: "{count} selected",
            maxSelections: "Max {maxCount} selections",
            noResults: "No results found.",
            serverError: "There was an error contacting the server"
        },
        error: {
            action: "You called a dropdown action that was not defined",
            alreadySetup: "Once a select has been initialized behaviors must be called on the created ui dropdown",
            labels: "Allowing user additions currently requires the use of labels.",
            missingMultiple: "<select> requires multiple property to be set to correctly preserve multiple values",
            method: "The method you called is not defined.",
            noAPI: "The API module is required to load resources remotely",
            noStorage: "Saving remote data requires session storage",
            noTransition: "This module requires ui transitions <https://github.com/Semantic-Org/UI-Transition>"
        },
        regExp: {
            escape: /[-[\]{}()*+?.,\\^$|#\s]/g,
            quote: /"/g
        },
        metadata: {
            defaultText: "defaultText",
            defaultValue: "defaultValue",
            placeholderText: "placeholder",
            text: "text",
            value: "value"
        },
        fields: {
            remoteValues: "results",
            values: "values",
            disabled: "disabled",
            name: "name",
            value: "value",
            text: "text"
        },
        keys: {
            backspace: 8,
            delimiter: 188,
            deleteKey: 46,
            enter: 13,
            escape: 27,
            pageUp: 33,
            pageDown: 34,
            leftArrow: 37,
            upArrow: 38,
            rightArrow: 39,
            downArrow: 40
        },
        selector: {
            addition: ".addition",
            dropdown: ".ui.dropdown",
            hidden: ".hidden",
            icon: "> .dropdown.icon",
            input: '> input[type="hidden"], > select',
            item: ".item",
            label: "> .label",
            remove: "> .label > .delete.icon",
            siblingLabel: ".label",
            menu: ".menu",
            message: ".message",
            menuIcon: ".dropdown.icon",
            search: "input.search, .menu > .search > input, .menu input.search",
            sizer: "> input.sizer",
            text: "> .text:not(.icon)",
            unselectable: ".disabled, .filtered"
        },
        className: {
            active: "active",
            addition: "addition",
            animating: "animating",
            disabled: "disabled",
            empty: "empty",
            dropdown: "ui dropdown",
            filtered: "filtered",
            hidden: "hidden transition",
            item: "item",
            label: "ui label",
            loading: "loading",
            menu: "menu",
            message: "message",
            multiple: "multiple",
            placeholder: "default",
            sizer: "sizer",
            search: "search",
            selected: "selected",
            selection: "selection",
            upward: "upward",
            visible: "visible"
        }
        dropdown: function(t) {
            var n = t.placeholder || !1,
                i = (t.values || {}, "");
            return i += '<i class="dropdown icon"></i>', i += t.placeholder ? '<div class="default text">' + n + "</div>" : '<div class="text"></div>', i += '<div class="menu">', e.each(t.values, function(e, t) {
                i += t.disabled ? '<div class="disabled item" data-value="' + t.value + '">' + t.name + "</div>" : '<div class="item" data-value="' + t.value + '">' + t.name + "</div>"
            }), i += "</div>"
        },
        menu: function(t, n) {
            var i = t[n.values] || {},
                o = "";
            return e.each(i, function(e, t) {
                var i = t[n.text] ? 'data-text="' + t[n.text] + '"' : "",
                    a = t[n.disabled] ? "disabled " : "";
                o += '<div class="' + a + 'item" data-value="' + t[n.value] + '"' + i + ">", o += t[n.name], o += "</div>"
            }), o
        },
        label: function(e, t) {
            return t + '<i class="delete icon"></i>'
        },
        message: function(e) {
            return e
        },
        addition: function(e) {
            return e
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = a.selector || "",
            s = (new Date).getTime(),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1);
        return a.each(function() {
            var f, m = e.isPlainObject(n) ? e.extend(!0, {}, e.fn.embed.settings, n) : e.extend({}, e.fn.embed.settings),
                g = m.selector,
                p = m.className,
                h = m.sources,
                v = m.error,
                b = m.metadata,
                y = m.namespace,
                x = m.templates,
                C = "." + y,
                w = "module-" + y,
                k = (e(t), e(this)),
                S = k.find(g.placeholder),
                T = k.find(g.icon),
                A = k.find(g.embed),
                E = k.data(w);
            f = {
                initialize: function() {
                    f.debug("Initializing embed"), f.determine.autoplay(), f.create(), f.bind.events(), f.instantiate()
                },
                instantiate: function() {
                    f.verbose("Storing instance of module", f), E = f, k.data(w, f)
                },
                destroy: function() {
                    f.verbose("Destroying previous instance of embed"), f.reset(), k.removeData(w).off(C)
                },
                refresh: function() {
                    f.verbose("Refreshing selector cache"), S = k.find(g.placeholder), T = k.find(g.icon), A = k.find(g.embed)
                },
                bind: {
                    events: function() {
                        f.has.placeholder() && (f.debug("Adding placeholder events"), k.on("click" + C, g.placeholder, f.createAndShow).on("click" + C, g.icon, f.createAndShow))
                    }
                },
                create: function() {
                    var e = f.get.placeholder();
                    e ? f.createPlaceholder() : f.createAndShow()
                },
                createPlaceholder: function(e) {
                    var t = f.get.icon(),
                        n = f.get.url();
                    f.generate.embed(n);
                },
                createEmbed: function(t) {
                },
                changeEmbed: function(e) {
                    A.html(f.generate.embed(e))
                },
                createAndShow: function() {
                    f.createEmbed(), f.show()
                },
                change: function(e, t, n) {
                    f.debug("Changing video to ", e, t, n), k.data(b.source, e).data(b.id, t), n ? k.data(b.url, n) : k.removeData(b.url), f.has.embed() ? f.changeEmbed() : f.create()
                },
                reset: function() {
                    f.debug("Clearing embed and showing placeholder"), f.remove.active(), f.remove.embed(), f.showPlaceholder(), m.onReset.call(R)
                },
                show: function() {
                    f.debug("Showing embed"), f.set.active(), m.onDisplay.call(R)
                },
                hide: function() {
                    f.debug("Hiding embed"), f.showPlaceholder()
                },
                showPlaceholder: function() {
                    f.debug("Showing placeholder image"), f.remove.active(), m.onPlaceholderDisplay.call(R)
                },
                get: {
                    id: function() {
                        return m.id || k.data(b.id)
                    },
                    placeholder: function() {
                        return m.placeholder || k.data(b.placeholder)
                    },
                    icon: function() {
                        return m.icon ? m.icon : k.data(b.icon) !== i ? k.data(b.icon) : f.determine.icon()
                    },
                    source: function(e) {
                        return m.source ? m.source : k.data(b.source) !== i ? k.data(b.source) : f.determine.source()
                    },
                    type: function() {
                        var e = f.get.source();
                        return h[e] !== i ? h[e].type : !1
                    },
                    url: function() {
                        return m.url ? m.url : k.data(b.url) !== i ? k.data(b.url) : f.determine.url()
                    }
                },
                determine: {
                    autoplay: function() {
                        f.should.autoplay() && (m.autoplay = !0)
                    },
                    source: function(t) {
                        var n = !1;
                            return -1 !== t.search(i.domain) ? (n = e, !1) : void 0
                        }), n
                    },
                    icon: function() {
                        var e = f.get.source();
                        return h[e] !== i ? h[e].icon : !1
                    },
                    url: function() {
                        var e, t = m.id || k.data(b.id),
                            n = m.source || k.data(b.source);
                        return e = h[n] !== i ? h[n].url.replace("{id}", t) : !1, e && k.data(b.url, e), e
                    }
                },
                set: {
                    active: function() {
                        k.addClass(p.active)
                    }
                },
                remove: {
                    active: function() {
                        k.removeClass(p.active)
                    },
                    embed: function() {
                        A.empty()
                    }
                },
                encode: {
                    parameters: function(e) {
                        var t, n = [];
                        for (t in e) n.push(encodeURIComponent(t) + "=" + encodeURIComponent(e[t]));
                        return n.join("&amp;")
                    }
                },
                generate: {
                    embed: function(e) {
                        f.debug("Generating embed html");
                        var t, n, i = f.get.source();
                    },
                    parameters: function(t, n) {
                        var o = h[t] && h[t].parameters !== i ? h[t].parameters(m) : {};
                    }
                },
                has: {
                    embed: function() {
                        return A.length > 0
                    },
                    placeholder: function() {
                        return m.placeholder || k.data(b.placeholder)
                    }
                },
                should: {
                    autoplay: function() {
                        return "auto" === m.autoplay ? m.placeholder || k.data(b.placeholder) !== i : m.autoplay
                    }
                },
                is: {
                    video: function() {
                        return "video" == f.get.type()
                    }
                },
                setting: function(t, n) {
                    if (f.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        e.isPlainObject(m[t]) ? e.extend(!0, m[t], n) : m[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, f, t);
                    else {
                        if (n === i) return f[t];
                        f[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        m.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: R,
                            "Execution Time": n
                        })), clearTimeout(f.performance.timer), f.performance.timer = setTimeout(f.performance.display, 500)
                    },
                    display: function() {
                        var t = m.name + ":",
                            n = 0;
                        s = !1, clearTimeout(f.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = E;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (f.error(v.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s
                }
            }, u ? (E === i && f.initialize(), f.invoke(c)) : (E !== i && E.invoke("destroy"), f.initialize())
        name: "Embed",
        namespace: "embed",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        icon: !1,
        source: !1,
        url: !1,
        id: !1,
        autoplay: "auto",
        color: "#444444",
        hd: !0,
        brandedUI: !1,
        parameters: !1,
        onDisplay: function() {},
        onPlaceholderDisplay: function() {},
        onReset: function() {},
        onCreate: function(e) {},
        onEmbed: function(e) {
            return e
        },
        metadata: {
            id: "id",
            icon: "icon",
            placeholder: "placeholder",
            source: "source",
            url: "url"
        },
        error: {
            noURL: "No URL specified",
            method: "The method you called is not defined"
        },
        className: {
            active: "active",
            embed: "embed"
        },
        selector: {
            embed: ".embed",
            placeholder: ".placeholder",
            icon: ".icon"
        },
        sources: {
            youtube: {
                name: "youtube",
                type: "video",
                icon: "video play",
                domain: "youtube.com",
                url: "//www.youtube.com/embed/{id}",
                parameters: function(e) {
                    return {
                        autohide: !e.brandedUI,
                        autoplay: e.autoplay,
                        color: e.color || i,
                        hq: e.hd,
                        jsapi: e.api,
                        modestbranding: !e.brandedUI
                    }
                }
            },
            vimeo: {
                name: "vimeo",
                type: "video",
                icon: "video play",
                domain: "vimeo.com",
                url: "//player.vimeo.com/video/{id}",
                parameters: function(e) {
                    return {
                        api: e.api,
                        autoplay: e.autoplay,
                        byline: e.brandedUI,
                        color: e.color || i,
                        portrait: e.brandedUI,
                        title: e.brandedUI
                    }
                }
            }
        },
        templates: {
            iframe: function(e, t) {
                var n = e;
                return t && (n += "?" + t), '<iframe src="' + n + '" width="100%" height="100%" frameborder="0" scrolling="no" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>'
            },
            placeholder: function(e, t) {
                var n = "";
                return t && (n += '<i class="' + t + ' icon"></i>'), e && (n += '<img class="placeholder" src="' + e + '">'), n
            }
        },
        api: !1,
        onPause: function() {},
        onPlay: function() {},
        onStop: function() {}
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = e(t),
            l = e(n),
            c = e("body"),
            u = r.selector || "",
            d = (new Date).getTime(),
            f = [],
            m = arguments[0],
            g = "string" == typeof m,
            p = [].slice.call(arguments, 1),
            h = t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
                setTimeout(e, 0)
            };
        return r.each(function() {
            var r, v, b, y, x, C, w, k, S, T = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.modal.settings, o) : e.extend({}, e.fn.modal.settings),
                A = T.selector,
                R = T.className,
                E = T.namespace,
                P = T.error,
                F = "." + E,
                O = "module-" + E,
                D = e(this),
                q = e(T.context),
                j = D.find(A.close),
                z = D.data(O);
            S = {
                initialize: function() {
                    S.verbose("Initializing dimmer", q), S.create.id(), S.create.dimmer(), S.refreshModals(), S.bind.events(), T.observeChanges && S.observeChanges(), S.instantiate()
                },
                instantiate: function() {
                    S.verbose("Storing instance of modal"), z = S, D.data(O, z)
                },
                create: {
                    dimmer: function() {
                        var t = {
                                debug: T.debug,
                                dimmerName: "modals",
                                duration: {
                                    show: T.duration,
                                    hide: T.duration
                                }
                            },
                            n = e.extend(!0, t, T.dimmerSettings);
                        return T.inverted && (n.variation = n.variation !== i ? n.variation + " inverted" : "inverted"), e.fn.dimmer === i ? void S.error(P.dimmer) : (S.debug("Creating dimmer with settings", n), y = q.dimmer(n), T.detachable ? (S.verbose("Modal is detachable, moving content into dimmer"), y.dimmer("add content", D)) : S.set.undetached(), T.blurring && y.addClass(R.blurring), void(x = y.dimmer("get dimmer")))
                    },
                    id: function() {
                        w = (Math.random().toString(16) + "000000000").substr(2, 8), C = "." + w, S.verbose("Creating unique id for element", w)
                    }
                },
                destroy: function() {
                    S.verbose("Destroying previous modal"), D.removeData(O).off(F), s.off(C), x.off(C), j.off(F), q.dimmer("destroy")
                },
                observeChanges: function() {
                        S.debug("DOM tree modified, refreshing"), S.refresh()
                    }), k.observe(M, {
                        childList: !0,
                        subtree: !0
                    }), S.debug("Setting up mutation observer", k))
                },
                refresh: function() {
                    S.remove.scrolling(), S.cacheSizes(), S.set.screenHeight(), S.set.type(), S.set.position()
                },
                refreshModals: function() {
                    v = D.siblings(A.modal), r = v.add(D)
                },
                attachEvents: function(t, n) {
                    var i = e(t);
                },
                bind: {
                    events: function() {
                        S.verbose("Attaching events"), D.on("click" + F, A.close, S.event.close).on("click" + F, A.approve, S.event.approve).on("click" + F, A.deny, S.event.deny), s.on("resize" + C, S.event.resize)
                    }
                },
                get: {
                    id: function() {
                        return (Math.random().toString(16) + "000000000").substr(2, 8)
                    }
                },
                event: {
                    approve: function() {
                        return T.onApprove.call(M, e(this)) === !1 ? void S.verbose("Approve callback returned false cancelling hide") : void S.hide()
                    },
                    deny: function() {
                        return T.onDeny.call(M, e(this)) === !1 ? void S.verbose("Deny callback returned false cancelling hide") : void S.hide()
                    },
                    close: function() {
                        S.hide()
                    },
                    click: function(t) {
                        var i = e(t.target),
                            o = i.closest(A.modal).length > 0,
                            a = e.contains(n.documentElement, t.target);
                        !o && a && (S.debug("Dimmer clicked, hiding all modals"), S.is.active() && (S.remove.clickaway(), T.allowMultiple ? S.hide() : S.hideAll()))
                    },
                    debounce: function(e, t) {
                        clearTimeout(S.timer), S.timer = setTimeout(e, t)
                    },
                    keyboard: function(e) {
                        var t = e.which,
                            n = 27;
                        t == n && (T.closable ? (S.debug("Escape key pressed hiding modal"), S.hide()) : S.debug("Escape key pressed, but closable is set to false"), e.preventDefault())
                    },
                    resize: function() {
                        y.dimmer("is active") && h(S.refresh)
                    }
                },
                toggle: function() {
                    S.is.active() || S.is.animating() ? S.hide() : S.show()
                },
                show: function(t) {
                },
                hide: function(t) {
                },
                showModal: function(t) {
                        debug: T.debug,
                        animation: T.transition + " in",
                        queue: T.queue,
                        duration: T.duration,
                        useFailSafe: !0,
                        onComplete: function() {
                            T.onVisible.apply(M), T.keyboardShortcuts && S.add.keyboardShortcuts(), S.save.focus(), S.set.active(), T.autofocus && S.set.autofocus(), t()
                        }
                    }))) : S.debug("Modal is already visible")
                },
                hideModal: function(t, n) {
                        debug: T.debug,
                        animation: T.transition + " out",
                        queue: T.queue,
                        duration: T.duration,
                        useFailSafe: !0,
                        onStart: function() {
                            S.others.active() || n || S.hideDimmer(), T.keyboardShortcuts && S.remove.keyboardShortcuts()
                        },
                        onComplete: function() {
                            T.onHidden.call(M), S.restore.focus(), t()
                        }
                    })))
                },
                showDimmer: function() {
                    y.dimmer("is animating") || !y.dimmer("is active") ? (S.debug("Showing dimmer"), y.dimmer("show")) : S.debug("Dimmer already visible")
                },
                hideDimmer: function() {
                    return y.dimmer("is animating") || y.dimmer("is active") ? void y.dimmer("hide", function() {
                        S.remove.clickaway(), S.remove.screenHeight()
                    }) : void S.debug("Dimmer is not visible cannot hide")
                },
                hideAll: function(t) {
                    var n = r.filter("." + R.active + ", ." + R.animating);
                },
                hideOthers: function(t) {
                    var n = v.filter("." + R.active + ", ." + R.animating);
                },
                others: {
                    active: function() {
                        return v.filter("." + R.active).length > 0
                    },
                    animating: function() {
                        return v.filter("." + R.animating).length > 0
                    }
                },
                add: {
                    keyboardShortcuts: function() {
                        S.verbose("Adding keyboard shortcuts"), l.on("keyup" + F, S.event.keyboard)
                    }
                },
                save: {
                    focus: function() {
                        b = e(n.activeElement).blur()
                    }
                },
                restore: {
                    focus: function() {
                        b && b.length > 0 && b.focus()
                    }
                },
                remove: {
                    active: function() {
                        D.removeClass(R.active)
                    },
                    clickaway: function() {
                        T.closable && x.off("click" + C)
                    },
                    bodyStyle: function() {
                        "" === c.attr("style") && (S.verbose("Removing style attribute"), c.removeAttr("style"))
                    },
                    screenHeight: function() {
                        S.debug("Removing page height"), c.css("height", "")
                    },
                    keyboardShortcuts: function() {
                        S.verbose("Removing keyboard shortcuts"), l.off("keyup" + F)
                    },
                    scrolling: function() {
                        y.removeClass(R.scrolling), D.removeClass(R.scrolling)
                    }
                },
                cacheSizes: function() {
                    var o = D.outerHeight();
                    (S.cache === i || 0 !== o) && (S.cache = {
                        pageHeight: e(n).outerHeight(),
                        height: o + T.offset,
                        contextHeight: "body" == T.context ? e(t).height() : y.height()
                    }), S.debug("Caching modal and container sizes", S.cache)
                },
                can: {
                    fit: function() {
                        return S.cache.height + 2 * T.padding < S.cache.contextHeight
                    }
                },
                is: {
                    active: function() {
                        return D.hasClass(R.active)
                    },
                    animating: function() {
                        return D.transition("is supported") ? D.transition("is animating") : D.is(":visible")
                    },
                    scrolling: function() {
                        return y.hasClass(R.scrolling)
                    },
                    modernBrowser: function() {
                        return !(t.ActiveXObject || "ActiveXObject" in t)
                    }
                },
                set: {
                    autofocus: function() {
                        var e = D.find("[tabindex], :input").filter(":visible"),
                            t = e.filter("[autofocus]"),
                            n = t.length > 0 ? t.first() : e.first();
                        n.length > 0 && n.focus()
                    },
                    clickaway: function() {
                        T.closable && x.on("click" + C, S.event.click)
                    },
                    screenHeight: function() {
                        S.can.fit() ? c.css("height", "") : (S.debug("Modal is taller than page content, resizing page height"), c.css("height", S.cache.height + 2 * T.padding))
                    },
                    active: function() {
                        D.addClass(R.active)
                    },
                    scrolling: function() {
                        y.addClass(R.scrolling), D.addClass(R.scrolling)
                    },
                    type: function() {
                        S.can.fit() ? (S.verbose("Modal fits on screen"), S.others.active() || S.others.animating() || S.remove.scrolling()) : (S.verbose("Modal cannot fit on screen setting to scrolling"), S.set.scrolling())
                    },
                    position: function() {
                        S.verbose("Centering modal on page", S.cache), S.can.fit() ? D.css({
                            top: "",
                            marginTop: -(S.cache.height / 2)
                        }) : D.css({
                            marginTop: "",
                            top: l.scrollTop()
                        })
                    },
                    undetached: function() {
                        y.addClass(R.undetached)
                    }
                },
                setting: function(t, n) {
                    if (S.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, T, t);
                    else {
                        if (n === i) return T[t];
                        e.isPlainObject(T[t]) ? e.extend(!0, T[t], n) : T[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, S, t);
                    else {
                        if (n === i) return S[t];
                        S[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        T.performance && (t = (new Date).getTime(), i = d || t, n = t - i, d = t, f.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: M,
                            "Execution Time": n
                        })), clearTimeout(S.performance.timer), S.performance.timer = setTimeout(S.performance.display, 500)
                    },
                    display: function() {
                        var t = T.name + ":",
                            n = 0;
                        d = !1, clearTimeout(S.performance.timer), e.each(f, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = z;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, g ? (z === i && S.initialize(), S.invoke(m)) : (z !== i && z.invoke("destroy"), S.initialize())
        name: "Modal",
        namespace: "modal",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        observeChanges: !1,
        allowMultiple: !1,
        detachable: !0,
        closable: !0,
        autofocus: !0,
        inverted: !1,
        blurring: !1,
        dimmerSettings: {
            closable: !1,
            useCSS: !0
        },
        keyboardShortcuts: !0,
        context: "body",
        queue: !1,
        duration: 500,
        offset: 0,
        transition: "scale",
        padding: 50,
        onShow: function() {},
        onVisible: function() {},
        onHide: function() {
            return !0
        },
        onHidden: function() {},
        onApprove: function() {
            return !0
        },
        onDeny: function() {
            return !0
        },
        selector: {
            close: "> .close",
            approve: ".actions .positive, .actions .approve, .actions .ok",
            deny: ".actions .negative, .actions .deny, .actions .cancel",
            modal: ".ui.modal"
        },
        error: {
            dimmer: "UI Dimmer, a required component is not included in this page",
            method: "The method you called is not defined.",
            notFound: "The element you specified could not be found"
        },
        className: {
            active: "active",
            animating: "animating",
            blurring: "blurring",
            scrolling: "scrolling",
            undetached: "undetached"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = a.selector || "",
            s = (new Date).getTime(),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1);
        return a.each(function() {
            var a, f = e.isPlainObject(n) ? e.extend(!0, {}, e.fn.nag.settings, n) : e.extend({}, e.fn.nag.settings),
                m = (f.className, f.selector),
                g = f.error,
                p = f.namespace,
                h = "." + p,
                v = p + "-module",
                b = e(this),
                y = (b.find(m.close), e(f.context ? f.context : "body")),
                C = b.data(v);
            t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
                setTimeout(e, 0)
            };
            a = {
                initialize: function() {
                    a.verbose("Initializing element"), b.on("click" + h, m.close, a.dismiss).data(v, a), f.detachable && b.parent()[0] !== y[0] && b.detach().prependTo(y), f.displayTime > 0 && setTimeout(a.hide, f.displayTime)
                },
                destroy: function() {
                    a.verbose("Destroying instance"), b.removeData(v).off(h)
                },
                show: function() {
                    a.should.show() && !b.is(":visible") && (a.debug("Showing nag", f.animation.show), "fade" == f.animation.show ? b.fadeIn(f.duration, f.easing) : b.slideDown(f.duration, f.easing))
                },
                hide: function() {
                    a.debug("Showing nag", f.animation.hide), "fade" == f.animation.show ? b.fadeIn(f.duration, f.easing) : b.slideUp(f.duration, f.easing)
                },
                onHide: function() {
                    a.debug("Removing nag", f.animation.hide), b.remove(), f.onHide && f.onHide()
                },
                dismiss: function(e) {
                    f.storageMethod && a.storage.set(f.key, f.value), a.hide(), e.stopImmediatePropagation(), e.preventDefault()
                },
                should: {
                    show: function() {
                    }
                },
                get: {
                    storageOptions: function() {
                        var e = {};
                        return f.expires && (e.expires = f.expires), f.domain && (e.domain = f.domain), f.path && (e.path = f.path), e
                    }
                },
                clear: function() {
                    a.storage.remove(f.key)
                },
                storage: {
                    set: function(n, o) {
                        var r = a.get.storageOptions();
                        if ("localstorage" == f.storageMethod && t.localStorage !== i) t.localStorage.setItem(n, o), a.debug("Value stored using local storage", n, o);
                        else if ("sessionstorage" == f.storageMethod && t.sessionStorage !== i) t.sessionStorage.setItem(n, o), a.debug("Value stored using session storage", n, o);
                        else if (e.cookie !== i) e.cookie(n, o, r), a.debug("Value stored using cookie", n, o, r);
                        else {
                        }
                    },
                    get: function(n, o) {
                        var r;
                    },
                    remove: function(n) {
                        var o = a.get.storageOptions();
                    }
                },
                setting: function(t, n) {
                    if (a.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, f, t);
                    else {
                        if (n === i) return f[t];
                        e.isPlainObject(f[t]) ? e.extend(!0, f[t], n) : f[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, a, t);
                    else {
                        if (n === i) return a[t];
                        a[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        f.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: x,
                            "Execution Time": n
                        })), clearTimeout(a.performance.timer), a.performance.timer = setTimeout(a.performance.display, 500)
                    },
                    display: function() {
                        var t = f.name + ":",
                            n = 0;
                        s = !1, clearTimeout(a.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, r) {
                    var s, l, c, u = C;
                        var r = n != s ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(u[r]) && n != s) u = u[r];
                        else {
                            if (u[r] !== i) return l = u[r], !1;
                            if (!e.isPlainObject(u[o]) || n == s) return u[o] !== i ? (l = u[o], !1) : (a.error(g.method, t), !1);
                            u = u[o]
                        }
                    })), e.isFunction(l) ? c = l.apply(r, n) : l !== i && (c = l), e.isArray(o) ? o.push(c) : o !== i ? o = [o, c] : c !== i && (o = c), l
                }
            }, u ? (C === i && a.initialize(), a.invoke(c)) : (C !== i && C.invoke("destroy"), a.initialize())
        name: "Nag",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        namespace: "Nag",
        persist: !0,
        displayTime: 0,
        animation: {
            show: "slide",
            hide: "slide"
        },
        context: !1,
        detachable: !1,
        expires: 30,
        domain: !1,
        path: "/",
        storageMethod: "cookie",
        key: "nag",
        value: "dismiss",
        error: {
            noCookieStorage: "$.cookie or Cookies is not included. A storage solution is required.",
            noStorage: "Neither $.cookie, Cookies or store is defined. A storage solution is required for storing state",
            method: "The method you called is not defined."
        },
        className: {
            bottom: "bottom",
            fixed: "fixed"
        },
        selector: {
            close: ".close.icon"
        },
        speed: 500,
        easing: "easeOutQuad",
        onHide: function() {}
    }, e.extend(e.easing, {
        easeOutQuad: function(e, t, n, i, o) {
        }
    })
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = e(n),
            l = e(t),
            c = e("body"),
            u = r.selector || "",
            d = !0,
            f = (new Date).getTime(),
            m = [],
            g = arguments[0],
            p = "string" == typeof g,
            h = [].slice.call(arguments, 1);
        return r.each(function() {
            var r, v, b, y, x, C, w = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.popup.settings, o) : e.extend({}, e.fn.popup.settings),
                k = w.selector,
                S = w.className,
                T = w.error,
                A = w.metadata,
                R = w.namespace,
                E = "." + w.namespace,
                P = "module-" + R,
                F = e(this),
                O = e(w.context),
                D = e(w.scrollContext),
                q = e(w.boundary),
                j = w.target ? e(w.target) : F,
                M = 0,
                z = !1,
                I = !1,
                N = F.data(P);
            C = {
                initialize: function() {
                    C.debug("Initializing", F), C.createID(), C.bind.events(), !C.exists() && w.preserve && C.create(), w.observeChanges && C.observeChanges(), C.instantiate()
                },
                instantiate: function() {
                    C.verbose("Storing instance", C), N = C, F.data(P, N)
                },
                observeChanges: function() {
                        childList: !0,
                        subtree: !0
                    }), C.debug("Setting up mutation observer", b))
                },
                refresh: function() {
                    w.popup ? r = e(w.popup).eq(0) : w.inline && (r = j.nextAll(k.popup).eq(0), w.popup = r), w.popup ? (r.addClass(S.loading), v = C.get.offsetParent(), r.removeClass(S.loading), w.movePopup && C.has.popup() && C.get.offsetParent(r)[0] !== v[0] && (C.debug("Moving popup to the same offset parent as activating element"), r.detach().appendTo(v))) : v = w.inline ? C.get.offsetParent(j) : C.has.popup() ? C.get.offsetParent(r) : c, v.is("html") && v[0] !== c[0] && (C.debug("Setting page as offset parent"), v = c), C.get.variation() && C.set.variation()
                },
                reposition: function() {
                    C.refresh(), C.set.position()
                },
                destroy: function() {
                    C.debug("Destroying previous module"), b && b.disconnect(), r && !w.preserve && C.removePopup(), clearTimeout(C.hideTimer), clearTimeout(C.showTimer), C.unbind.close(), C.unbind.events(), F.removeData(P)
                },
                event: {
                    start: function(t) {
                        var n = e.isPlainObject(w.delay) ? w.delay.show : w.delay;
                        clearTimeout(C.hideTimer), I || (C.showTimer = setTimeout(C.show, n))
                    },
                    end: function() {
                        var t = e.isPlainObject(w.delay) ? w.delay.hide : w.delay;
                        clearTimeout(C.showTimer), C.hideTimer = setTimeout(C.hide, t)
                    },
                    touchstart: function(e) {
                        I = !0, C.show()
                    },
                    resize: function() {
                        C.is.visible() && C.set.position()
                    },
                    documentChanged: function(t) {
                        [].forEach.call(t, function(t) {
                            t.removedNodes && [].forEach.call(t.removedNodes, function(t) {
                                (t == L || e(t).find(L).length > 0) && (C.debug("Element removed from DOM, tearing down events"), C.destroy())
                            })
                        })
                    },
                    hideGracefully: function(t) {
                        var i = e(t.target),
                            o = e.contains(n.documentElement, t.target),
                            a = i.closest(k.popup).length > 0;
                        t && !a && o ? (C.debug("Click occurred outside popup hiding popup"), C.hide()) : C.debug("Click was inside popup, keeping popup open")
                    }
                },
                create: function() {
                    var t = C.get.html(),
                        n = C.get.title(),
                        i = C.get.content();
                    t || i || n ? (C.debug("Creating pop-up html"), t || (t = w.templates.popup({
                        title: n,
                        content: i
                    })), r = e("<div/>").addClass(S.popup).data(A.activator, F).html(t), w.inline ? (C.verbose("Inserting popup element inline", r), r.insertAfter(F)) : (C.verbose("Appending popup element to body", r), r.appendTo(O)), C.refresh(), C.set.variation(), w.hoverable && C.bind.popup(), w.onCreate.call(r, L)) : 0 !== j.next(k.popup).length ? (C.verbose("Pre-existing popup found"), w.inline = !0, w.popup = j.next(k.popup).data(A.activator, F), C.refresh(), w.hoverable && C.bind.popup()) : w.popup ? (e(w.popup).data(A.activator, F), C.verbose("Used popup specified in settings"), C.refresh(), w.hoverable && C.bind.popup()) : C.debug("No content specified skipping display", L);
                },
                createID: function() {
                    x = (Math.random().toString(16) + "000000000").substr(2, 8), y = "." + x, C.verbose("Creating unique id for element", x)
                },
                toggle: function() {
                    C.debug("Toggling pop-up"), C.is.hidden() ? (C.debug("Popup is hidden, showing pop-up"), C.unbind.close(), C.show()) : (C.debug("Popup is visible, hiding pop-up"), C.hide())
                },
                show: function(e) {
                        if (C.exists() || C.create(), w.onShow.call(r, L) === !1) return void C.debug("onShow callback returned false, cancelling popup animation");
                        w.preserve || w.popup || C.refresh(), r && C.set.position() && (C.save.conditions(), w.exclusive && C.hideAll(), C.animate.show(e))
                    }
                },
                hide: function(e) {
                        if (w.onHide.call(r, L) === !1) return void C.debug("onHide callback returned false, cancelling popup animation");
                        C.remove.visible(), C.unbind.close(), C.restore.conditions(), C.animate.hide(e)
                    }
                },
                hideAll: function() {
                    e(k.popup).filter("." + S.visible).each(function() {
                        e(this).data(A.activator).popup("hide")
                    })
                },
                exists: function() {
                    return r ? w.inline || w.popup ? C.has.popup() : r.closest(O).length >= 1 ? !0 : !1 : !1
                },
                removePopup: function() {
                    C.has.popup() && !w.popup && (C.debug("Removing popup", r), r.remove(), r = i, w.onRemove.call(r, L))
                },
                save: {
                    conditions: function() {
                        C.cache = {
                            title: F.attr("title")
                        }, C.cache.title && F.removeAttr("title"), C.verbose("Saving original attributes", C.cache.title)
                    }
                },
                restore: {
                    conditions: function() {
                        return C.cache && C.cache.title && (F.attr("title", C.cache.title), C.verbose("Restoring original attributes", C.cache.title)), !0
                    }
                },
                supports: {
                    svg: function() {
                    }
                },
                animate: {
                    show: function(t) {
                            animation: w.transition + " in",
                            queue: !1,
                            debug: w.debug,
                            verbose: w.verbose,
                            duration: w.duration,
                            onComplete: function() {
                                C.bind.close(), t.call(r, L), w.onVisible.call(r, L)
                            }
                        })
                    },
                    hide: function(t) {
                            animation: w.transition + " out",
                            queue: !1,
                            duration: w.duration,
                            debug: w.debug,
                            verbose: w.verbose,
                            onComplete: function() {
                                C.reset(), t.call(r, L), w.onHidden.call(r, L)
                            }
                        })
                    }
                },
                change: {
                    content: function(e) {
                        r.html(e)
                    }
                },
                get: {
                    html: function() {
                        return F.removeData(A.html), F.data(A.html) || w.html
                    },
                    title: function() {
                        return F.removeData(A.title), F.data(A.title) || w.title
                    },
                    content: function() {
                        return F.removeData(A.content), F.data(A.content) || F.attr("title") || w.content
                    },
                    variation: function() {
                        return F.removeData(A.variation), F.data(A.variation) || w.variation
                    },
                    popup: function() {
                        return r
                    },
                    popupOffset: function() {
                        return r.offset()
                    },
                    calculations: function() {
                        var e, n = j[0],
                            i = q[0] == t,
                            o = w.inline || w.popup && w.movePopup ? j.position() : j.offset(),
                            a = i ? {
                                top: 0,
                                left: 0
                            } : q.offset(),
                            s = {},
                            c = i ? {
                                top: l.scrollTop(),
                                left: l.scrollLeft()
                            } : {
                                top: 0,
                                left: 0
                            };
                        return s = {
                            target: {
                                element: j[0],
                                width: j.outerWidth(),
                                height: j.outerHeight(),
                                top: o.top,
                                left: o.left,
                                margin: {}
                            },
                            popup: {
                                width: r.outerWidth(),
                                height: r.outerHeight()
                            },
                            parent: {
                                width: v.outerWidth(),
                                height: v.outerHeight()
                            },
                            screen: {
                                top: a.top,
                                left: a.left,
                                scroll: {
                                    top: c.top,
                                    left: c.left
                                },
                                width: q.width(),
                                height: q.height()
                            }
                        }, w.setFluidWidth && C.is.fluid() && (s.container = {
                            width: r.parent().outerWidth()
                        }, s.popup.width = s.container.width), s.target.margin.top = w.inline ? parseInt(t.getComputedStyle(n).getPropertyValue("margin-top"), 10) : 0, s.target.margin.left = w.inline ? C.is.rtl() ? parseInt(t.getComputedStyle(n).getPropertyValue("margin-right"), 10) : parseInt(t.getComputedStyle(n).getPropertyValue("margin-left"), 10) : 0, e = s.screen, s.boundary = {
                            top: e.top + e.scroll.top,
                            bottom: e.top + e.scroll.top + e.height,
                            left: e.left + e.scroll.left,
                            right: e.left + e.scroll.left + e.width
                        }, s
                    },
                    id: function() {
                        return x
                    },
                    startEvent: function() {
                        return "hover" == w.on ? "mouseenter" : "focus" == w.on ? "focus" : !1
                    },
                    scrollEvent: function() {
                        return "scroll"
                    },
                    endEvent: function() {
                        return "hover" == w.on ? "mouseleave" : "focus" == w.on ? "blur" : !1
                    },
                    distanceFromBoundary: function(e, t) {
                        var n, i, o = {};
                            top: e.top - i.top,
                            left: e.left - i.left,
                            right: i.right - (e.left + n.width),
                            bottom: i.bottom - (e.top + n.height)
                        }, C.verbose("Distance from boundaries determined", e, o)), o
                    },
                    offsetParent: function(t) {
                        var n = t !== i ? t[0] : F[0],
                            o = n.parentNode,
                            a = e(o);
                        if (o)
                            for (var r = "none" === a.css("transform"), s = "static" === a.css("position"), l = a.is("html"); o && !l && s && r;) o = o.parentNode, a = e(o), r = "none" === a.css("transform"), s = "static" === a.css("position"), l = a.is("html");
                        return a && a.length > 0 ? a : e()
                    },
                    positions: function() {
                        return {
                            "top left": !1,
                            "top center": !1,
                            "top right": !1,
                            "bottom left": !1,
                            "bottom center": !1,
                            "bottom right": !1,
                            "left center": !1,
                            "right center": !1
                        }
                    },
                    nextPosition: function(e) {
                        var t = e.split(" "),
                            n = t[0],
                            i = t[1],
                            o = {
                                top: "bottom",
                                bottom: "top",
                                left: "right",
                                right: "left"
                            },
                            a = {
                                left: "center",
                                center: "right",
                                right: "left"
                            },
                            r = {
                                "top left": "top center",
                                "top center": "top right",
                                "top right": "right center",
                                "right center": "bottom right",
                                "bottom right": "bottom center",
                                "bottom center": "bottom left",
                                "bottom left": "left center",
                                "left center": "top left"
                            },
                            s = "top" == n || "bottom" == n,
                            l = !1,
                            c = !1,
                            u = !1;
                        return z || (C.verbose("All available positions available"), z = C.get.positions()), C.debug("Recording last position tried", e), z[e] = !0, "opposite" === w.prefer && (u = [o[n], i], u = u.join(" "), l = z[u] === !0, C.debug("Trying opposite strategy", u)), "adjacent" === w.prefer && s && (u = [n, a[i]], u = u.join(" "), c = z[u] === !0, C.debug("Trying adjacent strategy", u)), (c || l) && (C.debug("Using backup position", u), u = r[e]), u
                    }
                },
                set: {
                    position: function(e, t) {
                        if (0 === j.length || 0 === r.length) return void C.error(T.notFound);
                        var n, o, a, s, l, c, u, d;
                            return "left" == e ? "right" : "left"
                            case "top left":
                                c = {
                                    top: "auto",
                                    bottom: l.height - a.top + o,
                                    left: a.left + n,
                                    right: "auto"
                                };
                                break;
                            case "top center":
                                c = {
                                    bottom: l.height - a.top + o,
                                    left: a.left + a.width / 2 - s.width / 2 + n,
                                    top: "auto",
                                    right: "auto"
                                };
                                break;
                            case "top right":
                                c = {
                                    bottom: l.height - a.top + o,
                                    right: l.width - a.left - a.width - n,
                                    top: "auto",
                                    left: "auto"
                                };
                                break;
                            case "left center":
                                c = {
                                    top: a.top + a.height / 2 - s.height / 2 + n,
                                    right: l.width - a.left + o,
                                    left: "auto",
                                    bottom: "auto"
                                };
                                break;
                            case "right center":
                                c = {
                                    top: a.top + a.height / 2 - s.height / 2 + n,
                                    left: a.left + a.width + o,
                                    bottom: "auto",
                                    right: "auto"
                                };
                                break;
                            case "bottom left":
                                c = {
                                    top: a.top + a.height + o,
                                    left: a.left + n,
                                    bottom: "auto",
                                    right: "auto"
                                };
                                break;
                            case "bottom center":
                                c = {
                                    top: a.top + a.height + o,
                                    left: a.left + a.width / 2 - s.width / 2 + n,
                                    bottom: "auto",
                                    right: "auto"
                                };
                                break;
                            case "bottom right":
                                c = {
                                    top: a.top + a.height + o,
                                    right: l.width - a.left - a.width - n,
                                    left: "auto",
                                    bottom: "auto"
                                }
                        }
                        if (c === i && C.error(T.invalidPosition, e), C.debug("Calculated popup positioning values", c), r.css(c).removeClass(S.position).addClass(e).addClass(S.loading), u = C.get.popupOffset(), d = C.get.distanceFromBoundary(u, t), C.is.offstage(d, e)) {
                            if (!w.lastResort) return C.debug("Popup could not find a position to display", r), C.error(T.cannotPlace, L), C.remove.attempts(), C.remove.loading(), C.reset(), w.onUnplaceable.call(r, L), !1;
                            C.debug("No position found, showing with last position")
                        }
                        return C.debug("Position is on stage", e), C.remove.attempts(), C.remove.loading(), w.setFluidWidth && C.is.fluid() && C.set.fluidWidth(t), !0
                    },
                    fluidWidth: function(e) {
                    },
                    variation: function(e) {
                    },
                    visible: function() {
                        F.addClass(S.visible)
                    }
                },
                remove: {
                    loading: function() {
                        r.removeClass(S.loading)
                    },
                    variation: function(e) {
                    },
                    visible: function() {
                        F.removeClass(S.visible)
                    },
                    attempts: function() {
                        C.verbose("Resetting all searched positions"), M = 0, z = !1
                    }
                },
                bind: {
                    events: function() {
                        C.debug("Binding popup events to module"), "click" == w.on && F.on("click" + E, C.toggle), "hover" == w.on && d && F.on("touchstart" + E, C.event.touchstart), C.get.startEvent() && F.on(C.get.startEvent() + E, C.event.start).on(C.get.endEvent() + E, C.event.end), w.target && C.debug("Target set to element", j), l.on("resize" + y, C.event.resize)
                    },
                    popup: function() {
                        C.verbose("Allowing hover events on popup to prevent closing"), r && C.has.popup() && r.on("mouseenter" + E, C.event.start).on("mouseleave" + E, C.event.end)
                    },
                    close: function() {
                        (w.hideOnScroll === !0 || "auto" == w.hideOnScroll && "click" != w.on) && D.one(C.get.scrollEvent() + y, C.event.hideGracefully), "hover" == w.on && I && (C.verbose("Binding popup close event to document"), s.on("touchstart" + y, function(e) {
                            C.verbose("Touched away from popup"), C.event.hideGracefully.call(L, e)
                        })), "click" == w.on && w.closable && (C.verbose("Binding popup close event to document"), s.on("click" + y, function(e) {
                            C.verbose("Clicked away from popup"), C.event.hideGracefully.call(L, e)
                        }))
                    }
                },
                unbind: {
                    events: function() {
                        l.off(y), F.off(E)
                    },
                    close: function() {
                        s.off(y), D.off(y)
                    }
                },
                has: {
                    popup: function() {
                        return r && r.length > 0
                    }
                },
                is: {
                    offstage: function(t, n) {
                        var i = [];
                        return e.each(t, function(e, t) {
                            t < -w.jitter && (C.debug("Position exceeds allowable distance from edge", e, t, n), i.push(e))
                        }), i.length > 0 ? !0 : !1
                    },
                    svg: function(e) {
                    },
                    active: function() {
                        return F.hasClass(S.active)
                    },
                    animating: function() {
                        return r !== i && r.hasClass(S.animating)
                    },
                    fluid: function() {
                        return r !== i && r.hasClass(S.fluid)
                    },
                    visible: function() {
                        return r !== i && r.hasClass(S.visible)
                    },
                    dropdown: function() {
                        return F.hasClass(S.dropdown)
                    },
                    hidden: function() {
                        return !C.is.visible()
                    },
                    rtl: function() {
                        return "rtl" == F.css("direction")
                    }
                },
                reset: function() {
                },
                setting: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, w, t);
                    else {
                        if (n === i) return w[t];
                        w[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, C, t);
                    else {
                        if (n === i) return C[t];
                        C[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        w.performance && (t = (new Date).getTime(), i = f || t, n = t - i, f = t, m.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: L,
                            "Execution Time": n
                        })), clearTimeout(C.performance.timer), C.performance.timer = setTimeout(C.performance.display, 500)
                    },
                    display: function() {
                        var t = w.name + ":",
                            n = 0;
                        f = !1, clearTimeout(C.performance.timer), e.each(m, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = N;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, p ? (N === i && C.initialize(), C.invoke(g)) : (N !== i && N.invoke("destroy"), C.initialize())
        name: "Popup",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        namespace: "popup",
        observeChanges: !0,
        onCreate: function() {},
        onRemove: function() {},
        onShow: function() {},
        onVisible: function() {},
        onHide: function() {},
        onUnplaceable: function() {},
        onHidden: function() {},
        on: "hover",
        boundary: t,
        addTouchEvents: !0,
        position: "top left",
        variation: "",
        movePopup: !0,
        target: !1,
        popup: !1,
        inline: !1,
        preserve: !1,
        hoverable: !1,
        content: !1,
        html: !1,
        title: !1,
        closable: !0,
        hideOnScroll: "auto",
        exclusive: !1,
        context: "body",
        scrollContext: t,
        prefer: "opposite",
        lastResort: !1,
        delay: {
            show: 50,
            hide: 70
        },
        setFluidWidth: !0,
        duration: 200,
        transition: "scale",
        distanceAway: 0,
        jitter: 2,
        offset: 0,
        maxSearchDepth: 15,
        error: {
            invalidPosition: "The position you specified is not a valid position",
            cannotPlace: "Popup does not fit within the boundaries of the viewport",
            method: "The method you called is not defined.",
            noTransition: "This module requires ui transitions <https://github.com/Semantic-Org/UI-Transition>",
            notFound: "The target or popup you specified does not exist on the page"
        },
        metadata: {
            activator: "activator",
            content: "content",
            html: "html",
            offset: "offset",
            position: "position",
            title: "title",
            variation: "variation"
        },
        className: {
            active: "active",
            animating: "animating",
            dropdown: "dropdown",
            fluid: "fluid",
            loading: "loading",
            popup: "ui popup",
            position: "top left center bottom right",
            visible: "visible"
        },
        selector: {
            popup: ".ui.popup"
        },
        templates: {
            escape: function(e) {
                var t = /[&<>"'`]/g,
                    n = /[&<>"'`]/,
                    i = {
                        "&": "&amp;",
                        "<": "&lt;",
                        ">": "&gt;",
                        '"': "&quot;",
                        "'": "&#x27;",
                        "`": "&#x60;"
                    },
                    o = function(e) {
                        return i[e]
                    };
                return n.test(e) ? e.replace(t, o) : e
            },
            popup: function(t) {
                var n = "",
                    o = e.fn.popup.settings.templates.escape;
            }
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = a.selector || "",
            s = (new Date).getTime(),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1);
        return a.each(function() {
            var a, f, m = e.isPlainObject(t) ? e.extend(!0, {}, e.fn.progress.settings, t) : e.extend({}, e.fn.progress.settings),
                g = m.className,
                p = m.metadata,
                h = m.namespace,
                v = m.selector,
                b = m.error,
                y = "." + h,
                x = "module-" + h,
                C = e(this),
                w = e(this).find(v.bar),
                k = e(this).find(v.progress),
                S = e(this).find(v.label),
                A = C.data(x),
                R = !1;
            f = {
                initialize: function() {
                    f.debug("Initializing progress bar", m), f.set.duration(), f.set.transitionEvent(), f.read.metadata(), f.read.settings(), f.instantiate()
                },
                instantiate: function() {
                    f.verbose("Storing instance of progress", f), A = f, C.data(x, f)
                },
                destroy: function() {
                    f.verbose("Destroying previous progress for", C), clearInterval(A.interval), f.remove.state(), C.removeData(x), A = i
                },
                reset: function() {
                    f.remove.nextValue(), f.update.progress(0)
                },
                complete: function() {
                    (f.percent === i || f.percent < 100) && (f.remove.progressPoll(), f.set.percent(100))
                },
                read: {
                    metadata: function() {
                        var e = {
                            percent: C.data(p.percent),
                            total: C.data(p.total),
                            value: C.data(p.value)
                        };
                        e.percent && (f.debug("Current percent value set from metadata", e.percent), f.set.percent(e.percent)), e.total && (f.debug("Total value set from metadata", e.total), f.set.total(e.total)), e.value && (f.debug("Current value set from metadata", e.value), f.set.value(e.value), f.set.progress(e.value))
                    },
                    settings: function() {
                        m.total !== !1 && (f.debug("Current total set in settings", m.total), f.set.total(m.total)), m.value !== !1 && (f.debug("Current value set in settings", m.value), f.set.value(m.value), f.set.progress(f.value)), m.percent !== !1 && (f.debug("Current percent set in settings", m.percent), f.set.percent(m.percent))
                    }
                },
                bind: {
                    transitionEnd: function(e) {
                        var t = f.get.transitionEnd();
                        w.one(t + y, function(t) {
                            clearTimeout(f.failSafeTimer), e.call(this, t)
                        }), f.failSafeTimer = setTimeout(function() {
                            w.triggerHandler(t)
                        }, m.duration + m.failSafeDelay), f.verbose("Adding fail safe timer", f.timer)
                    }
                },
                increment: function(e) {
                    var t, n, i;
                },
                decrement: function(e) {
                    var t, n, i = f.get.total();
                },
                has: {
                    progressPoll: function() {
                        return f.progressPoll
                    },
                    total: function() {
                        return f.get.total() !== !1
                    }
                },
                get: {
                    text: function(e) {
                        var t = f.value || 0,
                            n = f.total || 0,
                            i = R ? f.get.displayPercent() : f.percent || 0,
                            o = f.total > 0 ? n - t : 100 - i;
                    },
                    normalizedValue: function(e) {
                        if (0 > e) return f.debug("Value cannot decrement below 0"), 0;
                        if (f.has.total()) {
                            if (e > f.total) return f.debug("Value cannot increment above total", f.total), f.total
                        } else if (e > 100) return f.debug("Value cannot increment above 100 percent"), 100;
                        return e
                    },
                    updateInterval: function() {
                        return "auto" == m.updateInterval ? m.duration : m.updateInterval
                    },
                    randomValue: function() {
                        return f.debug("Generating random increment percentage"), Math.floor(Math.random() * m.random.max + m.random.min)
                    },
                    numericValue: function(e) {
                        return "string" == typeof e ? "" !== e.replace(/[^\d.]/g, "") ? +e.replace(/[^\d.]/g, "") : !1 : e
                    },
                    transitionEnd: function() {
                        var e, t = n.createElement("element"),
                            o = {
                                transition: "transitionend",
                                OTransition: "oTransitionEnd",
                                MozTransition: "transitionend",
                                WebkitTransition: "webkitTransitionEnd"
                            };
                        for (e in o)
                            if (t.style[e] !== i) return o[e]
                    },
                    displayPercent: function() {
                        var e = w.width(),
                            t = C.width(),
                            n = parseInt(w.css("min-width"), 10),
                            i = e > n ? e / t * 100 : f.percent;
                        return m.precision > 0 ? Math.round(i * (10 * m.precision)) / (10 * m.precision) : Math.round(i)
                    },
                    percent: function() {
                        return f.percent || 0
                    },
                    value: function() {
                        return f.nextValue || f.value || 0
                    },
                    total: function() {
                        return f.total || !1
                    }
                },
                create: {
                    progressPoll: function() {
                        f.progressPoll = setTimeout(function() {
                            f.update.toNextValue(), f.remove.progressPoll()
                        }, f.get.updateInterval())
                    }
                },
                is: {
                    complete: function() {
                        return f.is.success() || f.is.warning() || f.is.error()
                    },
                    success: function() {
                        return C.hasClass(g.success)
                    },
                    warning: function() {
                        return C.hasClass(g.warning)
                    },
                    error: function() {
                        return C.hasClass(g.error)
                    },
                    active: function() {
                        return C.hasClass(g.active)
                    },
                    visible: function() {
                        return C.is(":visible")
                    }
                },
                remove: {
                    progressPoll: function() {
                        f.verbose("Removing progress poll timer"), f.progressPoll && (clearTimeout(f.progressPoll), delete f.progressPoll)
                    },
                    nextValue: function() {
                        f.verbose("Removing progress value stored for next update"), delete f.nextValue
                    },
                    state: function() {
                        f.verbose("Removing stored state"), delete f.total, delete f.percent, delete f.value
                    },
                    active: function() {
                        f.verbose("Removing active state"), C.removeClass(g.active)
                    },
                    success: function() {
                        f.verbose("Removing success state"), C.removeClass(g.success)
                    },
                    warning: function() {
                        f.verbose("Removing warning state"), C.removeClass(g.warning)
                    },
                    error: function() {
                        f.verbose("Removing error state"), C.removeClass(g.error)
                    }
                },
                set: {
                    barWidth: function(e) {
                        e > 100 ? f.error(b.tooHigh, e) : 0 > e ? f.error(b.tooLow, e) : (w.css("width", e + "%"), C.attr("data-percent", parseInt(e, 10)))
                    },
                    duration: function(e) {
                            "transition-duration": e
                        })
                    },
                    percent: function(e) {
                    },
                    labelInterval: function() {
                        var t = function() {
                            f.verbose("Bar finished animating, removing continuous label updates"), clearInterval(f.interval), R = !1, f.set.labels()
                        };
                        clearInterval(f.interval), f.bind.transitionEnd(t), R = !0, f.interval = setInterval(function() {
                            var t = e.contains(n.documentElement, T);
                            t || (clearInterval(f.interval), R = !1), f.set.labels()
                        }, m.framerate)
                    },
                    labels: function() {
                        f.verbose("Setting both bar progress and outer label text"), f.set.barLabel(), f.set.state()
                    },
                    label: function(e) {
                    },
                    state: function(e) {
                    },
                    barLabel: function(e) {
                        e !== i ? k.text(f.get.text(e)) : "ratio" == m.label && f.total ? (f.verbose("Adding ratio to bar label"), k.text(f.get.text(m.text.ratio))) : "percent" == m.label && (f.verbose("Adding percentage to bar label"), k.text(f.get.text(m.text.percent)))
                    },
                    active: function(e) {
                            m.onActive.call(T, f.value, f.total)
                        })
                    },
                    success: function(e) {
                            m.onSuccess.call(T, f.total)
                        })
                    },
                    warning: function(e) {
                            m.onWarning.call(T, f.value, f.total)
                        })
                    },
                    error: function(e) {
                            m.onError.call(T, f.value, f.total)
                        })
                    },
                    transitionEvent: function() {
                        a = f.get.transitionEnd()
                    },
                    total: function(e) {
                        f.total = e
                    },
                    value: function(e) {
                        f.value = e
                    },
                    progress: function(e) {
                        f.has.progressPoll() ? (f.debug("Updated within interval, setting next update to use new value", e), f.set.nextValue(e)) : (f.debug("First update in progress update interval, immediately updating", e), f.update.progress(e), f.create.progressPoll())
                    },
                    nextValue: function(e) {
                        f.nextValue = e
                    }
                },
                update: {
                    toNextValue: function() {
                        var e = f.nextValue;
                        e && (f.debug("Update interval complete using last updated value", e), f.update.progress(e), f.remove.nextValue())
                    },
                    progress: function(e) {
                        var t;
                    }
                },
                setting: function(t, n) {
                    if (f.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        e.isPlainObject(m[t]) ? e.extend(!0, m[t], n) : m[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, f, t);
                    else {
                        if (n === i) return f[t];
                        f[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        m.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: T,
                            "Execution Time": n
                        })), clearTimeout(f.performance.timer), f.performance.timer = setTimeout(f.performance.display, 500)
                    },
                    display: function() {
                        var t = m.name + ":",
                            n = 0;
                        s = !1, clearTimeout(f.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = A;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (f.error(b.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s
                }
            }, u ? (A === i && f.initialize(), f.invoke(c)) : (A !== i && A.invoke("destroy"), f.initialize())
        name: "Progress",
        namespace: "progress",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        random: {
            min: 2,
            max: 5
        },
        duration: 300,
        updateInterval: "auto",
        autoSuccess: !0,
        showActivity: !0,
        limitValues: !0,
        label: "percent",
        precision: 0,
        framerate: 1e3 / 30,
        percent: !1,
        total: !1,
        value: !1,
        failSafeDelay: 100,
        onLabelUpdate: function(e, t, n, i) {
            return t
        },
        onChange: function(e, t, n) {},
        onSuccess: function(e) {},
        onActive: function(e, t) {},
        onError: function(e, t) {},
        onWarning: function(e, t) {},
        error: {
            method: "The method you called is not defined.",
            nonNumeric: "Progress value is non numeric",
            tooHigh: "Value specified is above 100%",
            tooLow: "Value specified is below 0%"
        },
        regExp: {
            variable: /\{\$*[A-z0-9]+\}/g
        },
        metadata: {
            percent: "percent",
            total: "total",
            value: "value"
        },
        selector: {
            bar: "> .bar",
            label: "> .label",
            progress: ".bar > .progress"
        },
        text: {
            active: !1,
            error: !1,
            success: !1,
            warning: !1,
            percent: "{percent}%",
            ratio: "{value} of {total}"
        },
        className: {
            active: "active",
            error: "error",
            success: "success",
            warning: "warning"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var n, o = e(this),
            a = o.selector || "",
            r = (new Date).getTime(),
            s = [],
            l = arguments[0],
            c = "string" == typeof l,
            u = [].slice.call(arguments, 1);
        return o.each(function() {
            var d, f, m = e.isPlainObject(t) ? e.extend(!0, {}, e.fn.rating.settings, t) : e.extend({}, e.fn.rating.settings),
                g = m.namespace,
                p = m.className,
                h = m.metadata,
                v = m.selector,
                b = (m.error, "." + g),
                y = "module-" + g,
                C = e(this).data(y),
                w = e(this),
                k = w.find(v.icon);
            f = {
                initialize: function() {
                    f.verbose("Initializing rating module", m), 0 === k.length && f.setup.layout(), m.interactive ? f.enable() : f.disable(), f.set.initialLoad(), f.set.rating(f.get.initialRating()), f.remove.initialLoad(), f.instantiate()
                },
                instantiate: function() {
                    f.verbose("Instantiating module", m), C = f, w.data(y, f)
                },
                destroy: function() {
                    f.verbose("Destroying previous instance", C), f.remove.events(), w.removeData(y)
                },
                refresh: function() {
                    k = w.find(v.icon)
                },
                setup: {
                    layout: function() {
                        var t = f.get.maxRating(),
                            n = e.fn.rating.settings.templates.icon(t);
                        f.debug("Generating icon html dynamically"), w.html(n), f.refresh()
                    }
                },
                event: {
                    mouseenter: function() {
                        var t = e(this);
                        t.nextAll().removeClass(p.selected), w.addClass(p.selected), t.addClass(p.selected).prevAll().addClass(p.selected)
                    },
                    mouseleave: function() {
                        w.removeClass(p.selected), k.removeClass(p.selected)
                    },
                    click: function() {
                        var t = e(this),
                            n = f.get.rating(),
                            i = k.index(t) + 1,
                            o = "auto" == m.clearable ? 1 === k.length : m.clearable;
                        o && n == i ? f.clearRating() : f.set.rating(i)
                    }
                },
                clearRating: function() {
                    f.debug("Clearing current rating"), f.set.rating(0)
                },
                bind: {
                    events: function() {
                        f.verbose("Binding events"), w.on("mouseenter" + b, v.icon, f.event.mouseenter).on("mouseleave" + b, v.icon, f.event.mouseleave).on("click" + b, v.icon, f.event.click)
                    }
                },
                remove: {
                    events: function() {
                        f.verbose("Removing events"), w.off(b)
                    },
                    initialLoad: function() {
                        d = !1
                    }
                },
                enable: function() {
                    f.debug("Setting rating to interactive mode"), f.bind.events(), w.removeClass(p.disabled)
                },
                disable: function() {
                    f.debug("Setting rating to read-only mode"), f.remove.events(), w.addClass(p.disabled)
                },
                is: {
                    initialLoad: function() {
                        return d
                    }
                },
                get: {
                    initialRating: function() {
                        return w.data(h.rating) !== i ? (w.removeData(h.rating), w.data(h.rating)) : m.initialRating
                    },
                    maxRating: function() {
                        return w.data(h.maxRating) !== i ? (w.removeData(h.maxRating), w.data(h.maxRating)) : m.maxRating
                    },
                    rating: function() {
                        var e = k.filter("." + p.active).length;
                        return f.verbose("Current rating retrieved", e), e
                    }
                },
                set: {
                    rating: function(e) {
                        var t = e - 1 >= 0 ? e - 1 : 0,
                            n = k.eq(t);
                        w.removeClass(p.selected), k.removeClass(p.selected).removeClass(p.active), e > 0 && (f.verbose("Setting current rating to", e), n.prevAll().addBack().addClass(p.active)), f.is.initialLoad() || m.onRate.call(x, e)
                    },
                    initialLoad: function() {
                        d = !0
                    }
                },
                setting: function(t, n) {
                    if (f.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        e.isPlainObject(m[t]) ? e.extend(!0, m[t], n) : m[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, f, t);
                    else {
                        if (n === i) return f[t];
                        f[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        m.performance && (t = (new Date).getTime(), i = r || t, n = t - i, r = t, s.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: x,
                            "Execution Time": n
                        })), clearTimeout(f.performance.timer), f.performance.timer = setTimeout(f.performance.display, 500)
                    },
                    display: function() {
                        var t = m.name + ":",
                            n = 0;
                        r = !1, clearTimeout(f.performance.timer), e.each(s, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, o, a) {
                    var r, s, l, c = C;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, o) : s !== i && (l = s), e.isArray(n) ? n.push(l) : n !== i ? n = [n, l] : l !== i && (n = l), s
                }
            }, c ? (C === i && f.initialize(), f.invoke(l)) : (C !== i && C.invoke("destroy"), f.initialize())
        name: "Rating",
        namespace: "rating",
        slent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        initialRating: 0,
        interactive: !0,
        maxRating: 4,
        clearable: "auto",
        fireOnInit: !1,
        onRate: function(e) {},
        error: {
            method: "The method you called is not defined",
            noMaximum: "No maximum rating specified. Cannot generate HTML automatically"
        },
        metadata: {
            rating: "rating",
            maxRating: "maxRating"
        },
        className: {
            active: "active",
            disabled: "disabled",
            selected: "selected",
            loading: "loading"
        },
        selector: {
            icon: ".icon"
        },
        templates: {
            icon: function(e) {
                for (var t = 1, n = ""; e >= t;) n += '<i class="icon"></i>',
                    t++;
                return n
            }
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = r.selector || "",
            l = (new Date).getTime(),
            c = [],
            u = arguments[0],
            d = "string" == typeof u,
            f = [].slice.call(arguments, 1);
        return e(this).each(function() {
            var m, g = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.search.settings, o) : e.extend({}, e.fn.search.settings),
                p = g.className,
                h = g.metadata,
                v = g.regExp,
                b = g.fields,
                y = g.selector,
                x = g.error,
                C = g.namespace,
                w = "." + C,
                k = C + "-module",
                S = e(this),
                T = S.find(y.prompt),
                A = S.find(y.searchButton),
                R = S.find(y.results),
                E = S.find(y.result),
                P = S.find(y.category),
                O = S.data(k),
                D = !1;
            m = {
                initialize: function() {
                    m.verbose("Initializing module"), m.determine.searchFields(), m.bind.events(), m.set.type(), m.create.results(), m.instantiate()
                },
                instantiate: function() {
                    m.verbose("Storing instance of module", m), O = m, S.data(k, m)
                },
                destroy: function() {
                    m.verbose("Destroying instance"), S.off(w).removeData(k)
                },
                refresh: function() {
                    m.debug("Refreshing selector cache"), T = S.find(y.prompt), A = S.find(y.searchButton), P = S.find(y.category), R = S.find(y.results), E = S.find(y.result)
                },
                refreshResults: function() {
                    R = S.find(y.results), E = S.find(y.result)
                },
                bind: {
                    events: function() {
                        m.verbose("Binding events to search"), g.automatic && (S.on(m.get.inputEvent() + w, y.prompt, m.event.input), T.attr("autocomplete", "off")), S.on("focus" + w, y.prompt, m.event.focus).on("blur" + w, y.prompt, m.event.blur).on("keydown" + w, y.prompt, m.handleKeyboard).on("click" + w, y.searchButton, m.query).on("mousedown" + w, y.results, m.event.result.mousedown).on("mouseup" + w, y.results, m.event.result.mouseup).on("click" + w, y.result, m.event.result.click)
                    }
                },
                determine: {
                    searchFields: function() {
                        o && o.searchFields !== i && (g.searchFields = o.searchFields)
                    }
                },
                event: {
                    input: function() {
                        clearTimeout(m.timer), m.timer = setTimeout(m.query, g.searchDelay)
                    },
                    focus: function() {
                        m.set.focus(), m.has.minimumCharacters() && (m.query(), m.can.show() && m.showResults())
                    },
                    blur: function(e) {
                            i = function() {
                                m.cancel.query(), m.remove.focus(), m.timer = setTimeout(m.hideResults, g.hideDelay)
                            };
                        t || (m.resultsClicked ? (m.debug("Determining if user action caused search to close"), S.one("click.close" + w, y.results, function(e) {
                            return m.is.inMessage(e) || D ? void T.focus() : (D = !1, void(m.is.animating() || m.is.hidden() || i()))
                        })) : (m.debug("Input blurred without user action, closing results"), i()))
                    },
                    result: {
                        mousedown: function() {
                            m.resultsClicked = !0
                        },
                        mouseup: function() {
                            m.resultsClicked = !1
                        },
                        click: function(n) {
                            m.debug("Search result selected");
                            var i = e(this),
                                o = i.find(y.title).eq(0),
                                a = i.is("a[href]") ? i : i.find("a[href]").eq(0),
                                r = a.attr("href") || !1,
                                s = a.attr("target") || !1,
                                l = (o.html(), o.length > 0 ? o.text() : !1),
                                c = m.get.results(),
                                u = i.data(h.result) || m.get.result(l, c);
                        }
                    }
                },
                handleKeyboard: function(e) {
                    var t, n = S.find(y.result),
                        i = S.find(y.category),
                        o = n.filter("." + p.active),
                        a = n.index(o),
                        r = n.length,
                        s = o.length > 0,
                        l = e.which,
                        c = {
                            backspace: 8,
                            enter: 13,
                            escape: 27,
                            upArrow: 38,
                            downArrow: 40
                        };
                    if (l == c.escape && (m.verbose("Escape key pressed, blurring search field"), m.trigger.blur()), m.is.visible())
                        if (l == c.enter) {
                            if (m.verbose("Enter key pressed, selecting active result"), n.filter("." + p.active).length > 0) return m.event.result.click.call(n.filter("." + p.active), e), e.preventDefault(), !1
                        } else l == c.upArrow && s ? (m.verbose("Up key pressed, changing active result"), t = 0 > a - 1 ? a : a - 1, i.removeClass(p.active), n.removeClass(p.active).eq(t).addClass(p.active).closest(i).addClass(p.active), e.preventDefault()) : l == c.downArrow && (m.verbose("Down key pressed, changing active result"), t = a + 1 >= r ? a : a + 1, i.removeClass(p.active), n.removeClass(p.active).eq(t).addClass(p.active).closest(i).addClass(p.active), e.preventDefault());
                    else l == c.enter && (m.verbose("Enter key pressed, executing query"), m.query(), m.set.buttonPressed(), T.one("keyup", m.remove.buttonFocus))
                },
                setup: {
                    api: function(t) {
                        var n = {
                            debug: g.debug,
                            on: !1,
                            cache: !0,
                            action: "search",
                            urlData: {
                                query: t
                            },
                            onSuccess: function(e) {
                                m.parse.response.call(F, e, t)
                            },
                            onAbort: function(e) {},
                            onFailure: function() {
                                m.displayMessage(x.serverError)
                            },
                            onError: m.error
                        };
                        e.extend(!0, n, g.apiSettings), m.verbose("Setting up API request", n), S.api(n)
                    }
                },
                can: {
                    useAPI: function() {
                        return e.fn.api !== i
                    },
                    show: function() {
                        return m.is.focused() && !m.is.visible() && !m.is.empty()
                    },
                    transition: function() {
                        return g.transition && e.fn.transition !== i && S.transition("is supported")
                    }
                },
                is: {
                    animating: function() {
                        return R.hasClass(p.animating)
                    },
                    hidden: function() {
                        return R.hasClass(p.hidden)
                    },
                    inMessage: function(t) {
                        if (t.target) {
                            var i = e(t.target),
                                o = e.contains(n.documentElement, t.target);
                            return o && i.closest(y.message).length > 0
                        }
                    },
                    empty: function() {
                        return "" === R.html()
                    },
                    visible: function() {
                        return R.filter(":visible").length > 0
                    },
                    focused: function() {
                        return T.filter(":focus").length > 0
                    }
                },
                trigger: {
                    blur: function() {
                        var e = n.createEvent("HTMLEvents"),
                            t = T[0];
                        t && (m.verbose("Triggering native blur event"), e.initEvent("blur", !1, !1), t.dispatchEvent(e))
                    }
                },
                get: {
                    inputEvent: function() {
                        var e = T[0],
                            t = e !== i && e.oninput !== i ? "input" : e !== i && e.onpropertychange !== i ? "propertychange" : "keyup";
                        return t
                    },
                    value: function() {
                        return T.val()
                    },
                    results: function() {
                        var e = S.data(h.results);
                        return e
                    },
                    result: function(t, n) {
                        var o = ["title", "id"],
                            a = !1;
                            return e.isArray(i.results) && (a = m.search.object(t, i.results, o)[0]) ? !1 : void 0
                        })) : (m.debug("Finding result in results object", t), a = m.search.object(t, n, o)[0]), a || !1
                    }
                },
                select: {
                    firstResult: function() {
                        m.verbose("Selecting first result"), E.first().addClass(p.active)
                    }
                },
                set: {
                    focus: function() {
                        S.addClass(p.focus)
                    },
                    loading: function() {
                        S.addClass(p.loading)
                    },
                    value: function(e) {
                        m.verbose("Setting search input value", e), T.val(e)
                    },
                    type: function(e) {
                    },
                    buttonPressed: function() {
                        A.addClass(p.pressed)
                    }
                },
                remove: {
                    loading: function() {
                        S.removeClass(p.loading)
                    },
                    focus: function() {
                        S.removeClass(p.focus)
                    },
                    buttonPressed: function() {
                        A.removeClass(p.pressed)
                    }
                },
                query: function() {
                    var t = m.get.value(),
                        n = m.read.cache(t);
                    m.has.minimumCharacters() ? (n ? (m.debug("Reading result from cache", t), m.save.results(n.results), m.addResults(n.html), m.inject.id(n.results)) : (m.debug("Querying for", t), e.isPlainObject(g.source) || e.isArray(g.source) ? m.search.local(t) : m.can.useAPI() ? m.search.remote(t) : m.error(x.source)), g.onSearchQuery.call(F, t)) : m.hideResults()
                },
                search: {
                    local: function(e) {
                        var t, n = m.search.object(e, g.content);
                        m.set.loading(), m.save.results(n), m.debug("Returned local search results", n), t = m.generateResults({
                            results: n
                        }), m.remove.loading(), m.addResults(t), m.inject.id(n), m.write.cache(e, {
                            html: t,
                            results: n
                        })
                    },
                    remote: function(e) {
                        S.api("is loading") && S.api("abort"), m.setup.api(e), S.api("query")
                    },
                    object: function(t, n, o) {
                        var a = [],
                            r = [],
                            s = t.toString().replace(v.escape, "\\$&"),
                            l = new RegExp(v.beginsWith + s, "i"),
                            c = function(t, n) {
                                var i = -1 == e.inArray(n, a),
                                    o = -1 == e.inArray(n, r);
                                i && o && t.push(n)
                            };
                            e.each(n, function(e, n) {
                                var i = "string" == typeof n[o];
                                i && (-1 !== n[o].search(l) ? c(a, n) : g.searchFullText && m.fuzzySearch(t, n[o]) && c(r, n))
                            })
                        }), e.merge(a, r))
                    }
                },
                fuzzySearch: function(e, t) {
                    var n = t.length,
                        i = e.length;
                    if ("string" != typeof e) return !1;
                    if (i === n) return e === t;
                    e: for (var o = 0, a = 0; i > o; o++) {
                        for (var r = e.charCodeAt(o); n > a;)
                            if (t.charCodeAt(a++) === r) continue e;
                        return !1
                    }
                    return !0
                },
                parse: {
                    response: function(e, t) {
                        var n = m.generateResults(e);
                        m.verbose("Parsing server response", e), e !== i && t !== i && e[b.results] !== i && (m.addResults(n), m.inject.id(e[b.results]), m.write.cache(t, {
                            html: n,
                            results: e[b.results]
                        }), m.save.results(e[b.results]))
                    }
                },
                cancel: {
                    query: function() {
                        m.can.useAPI() && S.api("abort")
                    }
                },
                has: {
                    minimumCharacters: function() {
                        var e = m.get.value(),
                            t = e.length;
                        return t >= g.minCharacters
                    }
                },
                clear: {
                    cache: function(e) {
                        var t = S.data(h.cache);
                        e ? e && t && t[e] && (m.debug("Removing value from cache", e), delete t[e], S.data(h.cache, t)) : (m.debug("Clearing cache", e), S.removeData(h.cache))
                    }
                },
                read: {
                    cache: function(e) {
                        var t = S.data(h.cache);
                        return g.cache ? (m.verbose("Checking cache for generated html for query", e), "object" == typeof t && t[e] !== i ? t[e] : !1) : !1
                    }
                },
                create: {
                    id: function(e, t) {
                        var n, o, a = e + 1;
                        return t !== i ? (n = String.fromCharCode(97 + t), o = n + a, m.verbose("Creating category result id", o)) : (o = a, m.verbose("Creating result id", o)), o
                    },
                    results: function() {
                        0 === R.length && (R = e("<div />").addClass(p.results).appendTo(S))
                    }
                },
                inject: {
                    result: function(e, t, n) {
                        m.verbose("Injecting result into results");
                        var o = n !== i ? R.children().eq(n).children(y.result).eq(t) : R.children(y.result).eq(t);
                        m.verbose("Injecting results metadata", o), o.data(h.result, e)
                    },
                    id: function(t) {
                        m.debug("Injecting unique ids into results");
                        var n = 0,
                            o = 0;
                        return "category" === g.type ? e.each(t, function(t, a) {
                            o = 0, e.each(a.results, function(e, t) {
                                var r = a.results[e];
                                r.id === i && (r.id = m.create.id(o, n)), m.inject.result(r, o, n), o++
                            }), n++
                        }) : e.each(t, function(e, n) {
                            var a = t[e];
                            a.id === i && (a.id = m.create.id(o)), m.inject.result(a, o), o++
                        }), t
                    }
                },
                save: {
                    results: function(e) {
                        m.verbose("Saving current search results to metadata", e), S.data(h.results, e)
                    }
                },
                write: {
                    cache: function(e, t) {
                        var n = S.data(h.cache) !== i ? S.data(h.cache) : {};
                        g.cache && (m.verbose("Writing generated html to cache", e, t), n[e] = t, S.data(h.cache, n))
                    }
                },
                addResults: function(t) {
                    return e.isFunction(g.onResultsAdd) && g.onResultsAdd.call(R, t) === !1 ? (m.debug("onResultsAdd callback cancelled default action"), !1) : void(t ? (R.html(t), m.refreshResults(), g.selectFirstResult && m.select.firstResult(), m.showResults()) : m.hideResults())
                },
                showResults: function() {
                    m.is.visible() || (m.can.transition() ? (m.debug("Showing results with css animations"), R.transition({
                        animation: g.transition + " in",
                        debug: g.debug,
                        verbose: g.verbose,
                        duration: g.duration,
                        queue: !0
                    })) : (m.debug("Showing results with javascript"), R.stop().fadeIn(g.duration, g.easing)), g.onResultsOpen.call(R))
                },
                hideResults: function() {
                    m.is.visible() && (m.can.transition() ? (m.debug("Hiding results with css animations"), R.transition({
                        animation: g.transition + " out",
                        debug: g.debug,
                        verbose: g.verbose,
                        duration: g.duration,
                        queue: !0
                    })) : (m.debug("Hiding results with javascript"), R.stop().fadeOut(g.duration, g.easing)), g.onResultsClose.call(R))
                },
                generateResults: function(t) {
                    m.debug("Generating html from response", t);
                    var n = g.templates[g.type],
                        i = e.isPlainObject(t[b.results]) && !e.isEmptyObject(t[b.results]),
                        o = e.isArray(t[b.results]) && t[b.results].length > 0,
                        a = "";
                },
                displayMessage: function(e, t) {
                },
                setting: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, g, t);
                    else {
                        if (n === i) return g[t];
                        g[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        m[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        g.performance && (t = (new Date).getTime(), i = l || t, n = t - i, l = t, c.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: F,
                            "Execution Time": n
                        })), clearTimeout(m.performance.timer), m.performance.timer = setTimeout(m.performance.display, 500)
                    },
                    display: function() {
                        var t = g.name + ":",
                            n = 0;
                        l = !1, clearTimeout(m.performance.timer), e.each(c, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = O;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, d ? (O === i && m.initialize(), m.invoke(u)) : (O !== i && O.invoke("destroy"), m.initialize())
        name: "Search",
        namespace: "search",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        type: "standard",
        minCharacters: 1,
        selectFirstResult: !1,
        apiSettings: !1,
        source: !1,
        searchFields: ["title", "description"],
        displayField: "",
        searchFullText: !0,
        automatic: !0,
        hideDelay: 0,
        searchDelay: 200,
        maxResults: 7,
        cache: !0,
        showNoResults: !0,
        transition: "scale",
        duration: 200,
        easing: "easeOutExpo",
        onSelect: !1,
        onResultsAdd: !1,
        onSearchQuery: function(e) {},
        onResults: function(e) {},
        onResultsOpen: function() {},
        onResultsClose: function() {},
        className: {
            animating: "animating",
            active: "active",
            empty: "empty",
            focus: "focus",
            hidden: "hidden",
            loading: "loading",
            results: "results",
            pressed: "down"
        },
        error: {
            source: "Cannot search. No source used, and Semantic API module was not included",
            noResults: "Your search returned no results",
            logging: "Error in debug logging, exiting.",
            noEndpoint: "No search endpoint was specified",
            noTemplate: "A valid template name was not specified.",
            serverError: "There was an issue querying the server.",
            maxResults: "Results must be an array to use maxResults setting",
            method: "The method you called is not defined."
        },
        metadata: {
            cache: "cache",
            results: "results",
            result: "result"
        },
        regExp: {
            escape: /[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g,
            beginsWith: "(?:s|^)"
        },
        fields: {
            categories: "results",
            categoryName: "name",
            categoryResults: "results",
            description: "description",
            image: "image",
            price: "price",
            results: "results",
            title: "title",
            url: "url",
            action: "action",
            actionText: "text",
            actionURL: "url"
        },
        selector: {
            prompt: ".prompt",
            searchButton: ".search.button",
            results: ".results",
            message: ".results > .message",
            category: ".category",
            result: ".result",
            title: ".title, .name"
        },
        templates: {
            escape: function(e) {
                var t = /[&<>"'`]/g,
                    n = /[&<>"'`]/,
                    i = {
                        "&": "&amp;",
                        "<": "&lt;",
                        ">": "&gt;",
                        '"': "&quot;",
                        "'": "&#x27;",
                        "`": "&#x60;"
                    },
                    o = function(e) {
                        return i[e]
                    };
                return n.test(e) ? e.replace(t, o) : e
            },
            message: function(e, t) {
                var n = "";
                return e !== i && t !== i && (n += '<div class="message ' + t + '">', n += "empty" == t ? '<div class="header">No Results</div class="header"><div class="description">' + e + '</div class="description">' : ' <div class="description">' + e + "</div>", n += "</div>"), n
            },
            category: function(t, n) {
                var o = "";
                e.fn.search.settings.templates.escape;
                return t[n.categoryResults] !== i ? (e.each(t[n.categoryResults], function(t, a) {
                    a[n.results] !== i && a.results.length > 0 && (o += '<div class="category">', a[n.categoryName] !== i && (o += '<div class="name">' + a[n.categoryName] + "</div>"), e.each(a.results, function(e, t) {
                        o += t[n.url] ? '<a class="result" href="' + t[n.url] + '">' : '<a class="result">', t[n.image] !== i && (o += '<div class="image"> <img src="' + t[n.image] + '"></div>'), o += '<div class="content">', t[n.price] !== i && (o += '<div class="price">' + t[n.price] + "</div>"), t[n.title] !== i && (o += '<div class="title">' + t[n.title] + "</div>"), t[n.description] !== i && (o += '<div class="description">' + t[n.description] + "</div>"), o += "</div>", o += "</a>"
                    }), o += "</div>")
                }), t[n.action] && (o += '<a href="' + t[n.action][n.actionURL] + '" class="action">' + t[n.action][n.actionText] + "</a>"), o) : !1
            },
            standard: function(t, n) {
                var o = "";
                return t[n.results] !== i ? (e.each(t[n.results], function(e, t) {
                    o += t[n.url] ? '<a class="result" href="' + t[n.url] + '">' : '<a class="result">', t[n.image] !== i && (o += '<div class="image"> <img src="' + t[n.image] + '"></div>'), o += '<div class="content">', t[n.price] !== i && (o += '<div class="price">' + t[n.price] + "</div>"), t[n.title] !== i && (o += '<div class="title">' + t[n.title] + "</div>"), t[n.description] !== i && (o += '<div class="description">' + t[n.description] + "</div>"), o += "</div>", o += "</a>"
                }), t[n.action] && (o += '<a href="' + t[n.action][n.actionURL] + '" class="action">' + t[n.action][n.actionText] + "</a>"), o) : !1
            }
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = (e("body"), (new Date).getTime()),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1),
            f = t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
                setTimeout(e, 0)
            };
        return r.each(function() {
            var t, m, g, p = r.selector || "",
                h = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.shape.settings, o) : e.extend({}, e.fn.shape.settings),
                v = h.namespace,
                b = h.selector,
                y = h.error,
                x = h.className,
                C = "." + v,
                w = "module-" + v,
                k = e(this),
                S = k.find(b.sides),
                T = k.find(b.side),
                A = !1,
                E = k.data(w);
            g = {
                initialize: function() {
                    g.verbose("Initializing module for", R), g.set.defaultSide(), g.instantiate()
                },
                instantiate: function() {
                    g.verbose("Storing instance of module", g), E = g, k.data(w, E)
                },
                destroy: function() {
                    g.verbose("Destroying previous module for", R), k.removeData(w).off(C)
                },
                refresh: function() {
                    g.verbose("Refreshing selector cache for", R), k = e(R), S = e(this).find(b.shape), T = e(this).find(b.side)
                },
                repaint: function() {
                    g.verbose("Forcing repaint event");
                    var e = S[0] || n.createElement("div");
                    e.offsetWidth
                },
                animate: function(e, n) {
                        g.verbose("Executing animation callback"), e !== i && e.stopPropagation(), g.reset(), g.set.active()
                    }, h.beforeChange.call(m[0]), g.get.transitionEvent() ? (g.verbose("Starting CSS animation"), k.addClass(x.animating), S.css(e).one(g.get.transitionEvent(), n), g.set.duration(h.duration), f(function() {
                        k.addClass(x.animating), t.addClass(x.hidden)
                    })) : n()
                },
                queue: function(e) {
                    g.debug("Queueing animation of", e), S.one(g.get.transitionEvent(), function() {
                        g.debug("Executing queued animation"), setTimeout(function() {
                            k.shape(e)
                        }, 0)
                    })
                },
                reset: function() {
                    g.verbose("Animating states reset"), k.removeClass(x.animating).attr("style", "").removeAttr("style"), S.attr("style", "").removeAttr("style"), T.attr("style", "").removeAttr("style").removeClass(x.hidden), m.removeClass(x.animating).attr("style", "").removeAttr("style")
                },
                is: {
                    complete: function() {
                        return T.filter("." + x.active)[0] == m[0]
                    },
                    animating: function() {
                        return k.hasClass(x.animating)
                    }
                },
                set: {
                    defaultSide: function() {
                        t = k.find("." + h.className.active), m = t.next(b.side).length > 0 ? t.next(b.side) : k.find(b.side).first(), A = !1, g.verbose("Active side set to", t), g.verbose("Next side set to", m)
                    },
                    duration: function(e) {
                            "-webkit-transition-duration": e,
                            "-moz-transition-duration": e,
                            "-ms-transition-duration": e,
                            "-o-transition-duration": e,
                            "transition-duration": e
                        })
                    },
                    currentStageSize: function() {
                        var e = k.find("." + h.className.active),
                            t = e.outerWidth(!0),
                            n = e.outerHeight(!0);
                        k.css({
                            width: t,
                            height: n
                        })
                    },
                    stageSize: function() {
                        var e = k.clone().addClass(x.loading),
                            t = e.find("." + h.className.active),
                            n = A ? e.find(b.side).eq(A) : t.next(b.side).length > 0 ? t.next(b.side) : e.find(b.side).first(),
                            i = "next" == h.width ? n.outerWidth(!0) : "initial" == h.width ? k.width() : h.width,
                            o = "next" == h.height ? n.outerHeight(!0) : "initial" == h.height ? k.height() : h.height;
                        t.removeClass(x.active), n.addClass(x.active), e.insertAfter(k), e.remove(), "auto" != h.width && (k.css("width", i + h.jitter), g.verbose("Specifying width during animation", i)), "auto" != h.height && (k.css("height", o + h.jitter), g.verbose("Specifying height during animation", o))
                    },
                    nextSide: function(e) {
                        A = e, m = T.filter(e), A = T.index(m), 0 === m.length && (g.set.defaultSide(), g.error(y.side)), g.verbose("Next side manually set to", m)
                    },
                    active: function() {
                        g.verbose("Setting new side to active", m), T.removeClass(x.active), m.addClass(x.active), h.onChange.call(m[0]), g.set.defaultSide()
                    }
                },
                flip: {
                    up: function() {
                        if (g.is.complete() && !g.is.animating() && !h.allowRepeats) return void g.debug("Side already visible", m);
                        if (g.is.animating()) g.queue("flip up");
                        else {
                            g.debug("Flipping up", m);
                            var e = g.get.transform.up();
                            g.set.stageSize(), g.stage.above(), g.animate(e)
                        }
                    },
                    down: function() {
                        if (g.is.complete() && !g.is.animating() && !h.allowRepeats) return void g.debug("Side already visible", m);
                        if (g.is.animating()) g.queue("flip down");
                        else {
                            g.debug("Flipping down", m);
                            var e = g.get.transform.down();
                            g.set.stageSize(), g.stage.below(), g.animate(e)
                        }
                    },
                    left: function() {
                        if (g.is.complete() && !g.is.animating() && !h.allowRepeats) return void g.debug("Side already visible", m);
                        if (g.is.animating()) g.queue("flip left");
                        else {
                            g.debug("Flipping left", m);
                            var e = g.get.transform.left();
                            g.set.stageSize(), g.stage.left(), g.animate(e)
                        }
                    },
                    right: function() {
                        if (g.is.complete() && !g.is.animating() && !h.allowRepeats) return void g.debug("Side already visible", m);
                        if (g.is.animating()) g.queue("flip right");
                        else {
                            g.debug("Flipping right", m);
                            var e = g.get.transform.right();
                            g.set.stageSize(), g.stage.right(), g.animate(e)
                        }
                    },
                    over: function() {
                        return !g.is.complete() || g.is.animating() || h.allowRepeats ? void(g.is.animating() ? g.queue("flip over") : (g.debug("Flipping over", m), g.set.stageSize(), g.stage.behind(), g.animate(g.get.transform.over()))) : void g.debug("Side already visible", m)
                    },
                    back: function() {
                        return !g.is.complete() || g.is.animating() || h.allowRepeats ? void(g.is.animating() ? g.queue("flip back") : (g.debug("Flipping back", m), g.set.stageSize(), g.stage.behind(), g.animate(g.get.transform.back()))) : void g.debug("Side already visible", m)
                    }
                },
                get: {
                    transform: {
                        up: function() {
                            var e = {
                                y: -((t.outerHeight(!0) - m.outerHeight(!0)) / 2),
                                z: -(t.outerHeight(!0) / 2)
                            };
                            return {
                                transform: "translateY(" + e.y + "px) translateZ(" + e.z + "px) rotateX(-90deg)"
                            }
                        },
                        down: function() {
                            var e = {
                                y: -((t.outerHeight(!0) - m.outerHeight(!0)) / 2),
                                z: -(t.outerHeight(!0) / 2)
                            };
                            return {
                                transform: "translateY(" + e.y + "px) translateZ(" + e.z + "px) rotateX(90deg)"
                            }
                        },
                        left: function() {
                            var e = {
                                x: -((t.outerWidth(!0) - m.outerWidth(!0)) / 2),
                                z: -(t.outerWidth(!0) / 2)
                            };
                            return {
                                transform: "translateX(" + e.x + "px) translateZ(" + e.z + "px) rotateY(90deg)"
                            }
                        },
                        right: function() {
                            var e = {
                                x: -((t.outerWidth(!0) - m.outerWidth(!0)) / 2),
                                z: -(t.outerWidth(!0) / 2)
                            };
                            return {
                                transform: "translateX(" + e.x + "px) translateZ(" + e.z + "px) rotateY(-90deg)"
                            }
                        },
                        over: function() {
                            var e = {
                                x: -((t.outerWidth(!0) - m.outerWidth(!0)) / 2)
                            };
                            return {
                                transform: "translateX(" + e.x + "px) rotateY(180deg)"
                            }
                        },
                        back: function() {
                            var e = {
                                x: -((t.outerWidth(!0) - m.outerWidth(!0)) / 2)
                            };
                            return {
                                transform: "translateX(" + e.x + "px) rotateY(-180deg)"
                            }
                        }
                    },
                    transitionEvent: function() {
                        var e, t = n.createElement("element"),
                            o = {
                                transition: "transitionend",
                                OTransition: "oTransitionEnd",
                                MozTransition: "transitionend",
                                WebkitTransition: "webkitTransitionEnd"
                            };
                        for (e in o)
                            if (t.style[e] !== i) return o[e]
                    },
                    nextSide: function() {
                        return t.next(b.side).length > 0 ? t.next(b.side) : k.find(b.side).first()
                    }
                },
                stage: {
                    above: function() {
                        var e = {
                            origin: (t.outerHeight(!0) - m.outerHeight(!0)) / 2,
                            depth: {
                                active: m.outerHeight(!0) / 2,
                                next: t.outerHeight(!0) / 2
                            }
                        };
                        g.verbose("Setting the initial animation position as above", m, e), S.css({
                            transform: "translateZ(-" + e.depth.active + "px)"
                        }), t.css({
                            transform: "rotateY(0deg) translateZ(" + e.depth.active + "px)"
                        }), m.addClass(x.animating).css({
                            top: e.origin + "px",
                            transform: "rotateX(90deg) translateZ(" + e.depth.next + "px)"
                        })
                    },
                    below: function() {
                        var e = {
                            origin: (t.outerHeight(!0) - m.outerHeight(!0)) / 2,
                            depth: {
                                active: m.outerHeight(!0) / 2,
                                next: t.outerHeight(!0) / 2
                            }
                        };
                        g.verbose("Setting the initial animation position as below", m, e), S.css({
                            transform: "translateZ(-" + e.depth.active + "px)"
                        }), t.css({
                            transform: "rotateY(0deg) translateZ(" + e.depth.active + "px)"
                        }), m.addClass(x.animating).css({
                            top: e.origin + "px",
                            transform: "rotateX(-90deg) translateZ(" + e.depth.next + "px)"
                        })
                    },
                    left: function() {
                        var e = {
                                active: t.outerWidth(!0),
                                next: m.outerWidth(!0)
                            },
                            n = {
                                origin: (e.active - e.next) / 2,
                                depth: {
                                    active: e.next / 2,
                                    next: e.active / 2
                                }
                            };
                        g.verbose("Setting the initial animation position as left", m, n), S.css({
                            transform: "translateZ(-" + n.depth.active + "px)"
                        }), t.css({
                            transform: "rotateY(0deg) translateZ(" + n.depth.active + "px)"
                        }), m.addClass(x.animating).css({
                            left: n.origin + "px",
                            transform: "rotateY(-90deg) translateZ(" + n.depth.next + "px)"
                        })
                    },
                    right: function() {
                        var e = {
                                active: t.outerWidth(!0),
                                next: m.outerWidth(!0)
                            },
                            n = {
                                origin: (e.active - e.next) / 2,
                                depth: {
                                    active: e.next / 2,
                                    next: e.active / 2
                                }
                            };
                        g.verbose("Setting the initial animation position as left", m, n), S.css({
                            transform: "translateZ(-" + n.depth.active + "px)"
                        }), t.css({
                            transform: "rotateY(0deg) translateZ(" + n.depth.active + "px)"
                        }), m.addClass(x.animating).css({
                            left: n.origin + "px",
                            transform: "rotateY(90deg) translateZ(" + n.depth.next + "px)"
                        })
                    },
                    behind: function() {
                        var e = {
                                active: t.outerWidth(!0),
                                next: m.outerWidth(!0)
                            },
                            n = {
                                origin: (e.active - e.next) / 2,
                                depth: {
                                    active: e.next / 2,
                                    next: e.active / 2
                                }
                            };
                        g.verbose("Setting the initial animation position as behind", m, n), t.css({
                            transform: "rotateY(0deg)"
                        }), m.addClass(x.animating).css({
                            left: n.origin + "px",
                            transform: "rotateY(-180deg)"
                        })
                    }
                },
                setting: function(t, n) {
                    if (g.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, h, t);
                    else {
                        if (n === i) return h[t];
                        e.isPlainObject(h[t]) ? e.extend(!0, h[t], n) : h[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, g, t);
                    else {
                        if (n === i) return g[t];
                        g[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        h.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: R,
                            "Execution Time": n
                        })), clearTimeout(g.performance.timer), g.performance.timer = setTimeout(g.performance.display, 500)
                    },
                    display: function() {
                        var t = h.name + ":",
                            n = 0;
                        s = !1, clearTimeout(g.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = E;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, u ? (E === i && g.initialize(), g.invoke(c)) : (E !== i && E.invoke("destroy"), g.initialize())
        name: "Shape",
        silent: !1,
        debug: !1,
        verbose: !1,
        jitter: 0,
        performance: !0,
        namespace: "shape",
        width: "initial",
        height: "initial",
        beforeChange: function() {},
        onChange: function() {},
        allowRepeats: !1,
        duration: !1,
        error: {
            side: "You tried to switch to a side that does not exist.",
            method: "The method you called is not defined"
        },
        className: {
            animating: "animating",
            hidden: "hidden",
            loading: "loading",
            active: "active"
        },
        selector: {
            sides: ".sides",
            side: ".side"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = e(t),
            l = e(n),
            c = e("html"),
            u = e("head"),
            d = r.selector || "",
            f = (new Date).getTime(),
            m = [],
            g = arguments[0],
            p = "string" == typeof g,
            h = [].slice.call(arguments, 1),
            v = t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
                setTimeout(e, 0)
            };
        return r.each(function() {
            var r, b, y, x, C, w, k = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.sidebar.settings, o) : e.extend({}, e.fn.sidebar.settings),
                S = k.selector,
                T = k.className,
                A = k.namespace,
                R = k.regExp,
                E = k.error,
                P = "." + A,
                F = "module-" + A,
                O = e(this),
                D = e(k.context),
                q = O.children(S.sidebar),
                j = D.children(S.fixed),
                M = D.children(S.pusher),
                I = O.data(F);
            w = {
                initialize: function() {
                    w.debug("Initializing sidebar", o), w.create.id(), C = w.get.transitionEvent(), w.is.ios() && w.set.ios(), k.delaySetup ? v(w.setup.layout) : w.setup.layout(), v(function() {
                        w.setup.cache()
                    }), w.instantiate()
                },
                instantiate: function() {
                    w.verbose("Storing instance of module", w), I = w, O.data(F, w)
                },
                create: {
                    id: function() {
                        y = (Math.random().toString(16) + "000000000").substr(2, 8), b = "." + y, w.verbose("Creating unique id for element", y)
                    }
                },
                destroy: function() {
                    w.verbose("Destroying previous module for", O), O.off(P).removeData(F), w.is.ios() && w.remove.ios(), D.off(b), s.off(b), l.off(b)
                },
                event: {
                    clickaway: function(e) {
                        var t = M.find(e.target).length > 0 || M.is(e.target),
                            n = D.is(e.target);
                        t && (w.verbose("User clicked on dimmed page"), w.hide()), n && (w.verbose("User clicked on dimmable context (scaled out page)"), w.hide())
                    },
                    touch: function(e) {},
                    containScroll: function(e) {
                        z.scrollTop <= 0 && (z.scrollTop = 1), z.scrollTop + z.offsetHeight >= z.scrollHeight && (z.scrollTop = z.scrollHeight - z.offsetHeight - 1)
                    },
                    scroll: function(t) {
                        0 === e(t.target).closest(S.sidebar).length && t.preventDefault()
                    }
                },
                bind: {
                    clickaway: function() {
                        w.verbose("Adding clickaway events to context", D), k.closable && D.on("click" + b, w.event.clickaway).on("touchend" + b, w.event.clickaway)
                    },
                    scrollLock: function() {
                        k.scrollLock && (w.debug("Disabling page scroll"), s.on("DOMMouseScroll" + b, w.event.scroll)), w.verbose("Adding events to contain sidebar scroll"), l.on("touchmove" + b, w.event.touch), O.on("scroll" + P, w.event.containScroll)
                    }
                },
                unbind: {
                    clickaway: function() {
                        w.verbose("Removing clickaway events from context", D), D.off(b)
                    },
                    scrollLock: function() {
                        w.verbose("Removing scroll lock from page"), l.off(b), s.off(b), O.off("scroll" + P)
                    }
                },
                add: {
                    inlineCSS: function() {
                        var t, n = w.cache.width || O.outerWidth(),
                            i = w.cache.height || O.outerHeight(),
                            o = w.is.rtl(),
                            a = w.get.direction(),
                            s = {
                                left: n,
                                right: -n,
                                top: i,
                                bottom: -i
                            };
                        o && (w.verbose("RTL detected, flipping widths"), s.left = -n, s.right = n), t = "<style>", "left" === a || "right" === a ? (w.debug("Adding CSS rules for animation distance", n), t += " .ui.visible." + a + ".sidebar ~ .fixed, .ui.visible." + a + ".sidebar ~ .pusher {   -webkit-transform: translate3d(" + s[a] + "px, 0, 0);           transform: translate3d(" + s[a] + "px, 0, 0); }") : ("top" === a || "bottom" == a) && (t += " .ui.visible." + a + ".sidebar ~ .fixed, .ui.visible." + a + ".sidebar ~ .pusher {   -webkit-transform: translate3d(0, " + s[a] + "px, 0);           transform: translate3d(0, " + s[a] + "px, 0); }"), w.is.ie() && ("left" === a || "right" === a ? (w.debug("Adding CSS rules for animation distance", n), t += " body.pushable > .ui.visible." + a + ".sidebar ~ .pusher:after {   -webkit-transform: translate3d(" + s[a] + "px, 0, 0);           transform: translate3d(" + s[a] + "px, 0, 0); }") : ("top" === a || "bottom" == a) && (t += " body.pushable > .ui.visible." + a + ".sidebar ~ .pusher:after {   -webkit-transform: translate3d(0, " + s[a] + "px, 0);           transform: translate3d(0, " + s[a] + "px, 0); }"), t += " body.pushable > .ui.visible.left.sidebar ~ .ui.visible.right.sidebar ~ .pusher:after, body.pushable > .ui.visible.right.sidebar ~ .ui.visible.left.sidebar ~ .pusher:after {   -webkit-transform: translate3d(0px, 0, 0);           transform: translate3d(0px, 0, 0); }"), t += "</style>", r = e(t).appendTo(u), w.debug("Adding sizing css to head", r)
                    }
                },
                refresh: function() {
                    w.verbose("Refreshing selector cache"), D = e(k.context), q = D.children(S.sidebar), M = D.children(S.pusher), j = D.children(S.fixed), w.clear.cache()
                },
                refreshSidebars: function() {
                    w.verbose("Refreshing other sidebars"),
                        q = D.children(S.sidebar)
                },
                repaint: function() {
                    w.verbose("Forcing repaint event"), z.style.display = "none";
                    z.offsetHeight;
                    z.scrollTop = z.scrollTop, z.style.display = ""
                },
                setup: {
                    cache: function() {
                        w.cache = {
                            width: O.outerWidth(),
                            height: O.outerHeight(),
                            rtl: "rtl" == O.css("direction")
                        }
                    },
                    layout: function() {
                        0 === D.children(S.pusher).length && (w.debug("Adding wrapper element for sidebar"), w.error(E.pusher), M = e('<div class="pusher" />'), D.children().not(S.omitted).not(q).wrapAll(M), w.refresh()), (0 === O.nextAll(S.pusher).length || O.nextAll(S.pusher)[0] !== M[0]) && (w.debug("Moved sidebar to correct parent element"), w.error(E.movedSidebar, z), O.detach().prependTo(D), w.refresh()), w.clear.cache(), w.set.pushable(), w.set.direction()
                    }
                },
                attachEvents: function(t, n) {
                    var i = e(t);
                },
                show: function(t) {
                        if (w.refreshSidebars(), k.overlay && (w.error(E.overlay), k.transition = "overlay"), w.refresh(), w.othersActive())
                            if (w.debug("Other sidebars currently visible"), k.exclusive) {
                                if ("overlay" != k.transition) return void w.hideOthers(w.show);
                                w.hideOthers()
                            } else k.transition = "overlay";
                        w.pushPage(function() {
                            t.call(z), k.onShow.call(z)
                        }), k.onChange.call(z), k.onVisible.call(z)
                    } else w.debug("Sidebar is already visible")
                },
                hide: function(t) {
                        t.call(z), k.onHidden.call(z)
                    }), k.onChange.call(z), k.onHide.call(z))
                },
                othersAnimating: function() {
                    return q.not(O).filter("." + T.animating).length > 0
                },
                othersVisible: function() {
                    return q.not(O).filter("." + T.visible).length > 0
                },
                othersActive: function() {
                    return w.othersVisible() || w.othersAnimating()
                },
                hideOthers: function(e) {
                    var t = q.not(O).filter("." + T.visible),
                        n = t.length,
                        i = 0;
                        i++, i == n && e()
                    })
                },
                toggle: function() {
                    w.verbose("Determining toggled direction"), w.is.hidden() ? w.show() : w.hide()
                },
                pushPage: function(t) {
                    var n, i, o, a = w.get.transition(),
                        r = "overlay" === a || w.othersActive() ? O : M;
                        w.bind.clickaway(), w.add.inlineCSS(), w.set.animating(), w.set.visible()
                    }, i = function() {
                        w.set.dimmed()
                    }, o = function(e) {
                        e.target == r[0] && (r.off(C + b, o), w.remove.animating(), w.bind.scrollLock(), t.call(z))
                    }, r.off(C + b), r.on(C + b, o), v(n), k.dimPage && !w.othersVisible() && v(i)
                },
                pullPage: function(t) {
                    var n, i, o = w.get.transition(),
                        a = "overlay" == o || w.othersActive() ? O : M;
                        w.set.transition(o), w.set.animating(), w.remove.visible(), k.dimPage && !w.othersVisible() && M.removeClass(T.dimmed)
                    }, i = function(e) {
                        e.target == a[0] && (a.off(C + b, i), w.remove.animating(), w.remove.transition(), w.remove.inlineCSS(), ("scale down" == o || k.returnScroll && w.is.mobile()) && w.scrollBack(), t.call(z))
                    }, a.off(C + b), a.on(C + b, i), v(n)
                },
                scrollToTop: function() {
                    w.verbose("Scrolling to top of page to avoid animation issues"), x = e(t).scrollTop(), O.scrollTop(0), t.scrollTo(0, 0)
                },
                scrollBack: function() {
                    w.verbose("Scrolling back to original page position"), t.scrollTo(0, x)
                },
                clear: {
                    cache: function() {
                        w.verbose("Clearing cached dimensions"), w.cache = {}
                    }
                },
                set: {
                    ios: function() {
                        c.addClass(T.ios)
                    },
                    pushed: function() {
                        D.addClass(T.pushed)
                    },
                    pushable: function() {
                        D.addClass(T.pushable)
                    },
                    dimmed: function() {
                        M.addClass(T.dimmed)
                    },
                    active: function() {
                        O.addClass(T.active)
                    },
                    animating: function() {
                        O.addClass(T.animating)
                    },
                    transition: function(e) {
                    },
                    direction: function(e) {
                    },
                    visible: function() {
                        O.addClass(T.visible)
                    },
                    overlay: function() {
                        O.addClass(T.overlay)
                    }
                },
                remove: {
                    inlineCSS: function() {
                        w.debug("Removing inline css styles", r), r && r.length > 0 && r.remove()
                    },
                    ios: function() {
                        c.removeClass(T.ios)
                    },
                    pushed: function() {
                        D.removeClass(T.pushed)
                    },
                    pushable: function() {
                        D.removeClass(T.pushable)
                    },
                    active: function() {
                        O.removeClass(T.active)
                    },
                    animating: function() {
                        O.removeClass(T.animating)
                    },
                    transition: function(e) {
                    },
                    direction: function(e) {
                    },
                    visible: function() {
                        O.removeClass(T.visible)
                    },
                    overlay: function() {
                        O.removeClass(T.overlay)
                    }
                },
                get: {
                    direction: function() {
                        return O.hasClass(T.top) ? T.top : O.hasClass(T.right) ? T.right : O.hasClass(T.bottom) ? T.bottom : T.left
                    },
                    transition: function() {
                        var e, t = w.get.direction();
                        return e = w.is.mobile() ? "auto" == k.mobileTransition ? k.defaultTransition.mobile[t] : k.mobileTransition : "auto" == k.transition ? k.defaultTransition.computer[t] : k.transition, w.verbose("Determined transition", e), e
                    },
                    transitionEvent: function() {
                        var e, t = n.createElement("element"),
                            o = {
                                transition: "transitionend",
                                OTransition: "oTransitionEnd",
                                MozTransition: "transitionend",
                                WebkitTransition: "webkitTransitionEnd"
                            };
                        for (e in o)
                            if (t.style[e] !== i) return o[e]
                    }
                },
                is: {
                    ie: function() {
                        var e = !t.ActiveXObject && "ActiveXObject" in t,
                            n = "ActiveXObject" in t;
                        return e || n
                    },
                    ios: function() {
                            t = e.match(R.ios),
                            n = e.match(R.mobileChrome);
                        return t && !n ? (w.verbose("Browser was found to be iOS", e), !0) : !1
                    },
                    mobile: function() {
                            t = e.match(R.mobile);
                        return t ? (w.verbose("Browser was found to be mobile", e), !0) : (w.verbose("Browser is not mobile, using regular transition", e), !1)
                    },
                    hidden: function() {
                        return !w.is.visible()
                    },
                    visible: function() {
                        return O.hasClass(T.visible)
                    },
                    open: function() {
                        return w.is.visible()
                    },
                    closed: function() {
                        return w.is.hidden()
                    },
                    vertical: function() {
                        return O.hasClass(T.top)
                    },
                    animating: function() {
                        return D.hasClass(T.animating)
                    },
                    rtl: function() {
                        return w.cache.rtl === i && (w.cache.rtl = "rtl" == O.css("direction")), w.cache.rtl
                    }
                },
                setting: function(t, n) {
                    if (w.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, k, t);
                    else {
                        if (n === i) return k[t];
                        e.isPlainObject(k[t]) ? e.extend(!0, k[t], n) : k[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, w, t);
                    else {
                        if (n === i) return w[t];
                        w[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        k.performance && (t = (new Date).getTime(), i = f || t, n = t - i, f = t, m.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: z,
                            "Execution Time": n
                        })), clearTimeout(w.performance.timer), w.performance.timer = setTimeout(w.performance.display, 500)
                    },
                    display: function() {
                        var t = k.name + ":",
                            n = 0;
                        f = !1, clearTimeout(w.performance.timer), e.each(m, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = I;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (w.error(E.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, p ? (I === i && w.initialize(), w.invoke(g)) : (I !== i && w.invoke("destroy"), w.initialize())
        name: "Sidebar",
        namespace: "sidebar",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        transition: "auto",
        mobileTransition: "auto",
        defaultTransition: {
            computer: {
                left: "uncover",
                right: "uncover",
                top: "overlay",
                bottom: "overlay"
            },
            mobile: {
                left: "uncover",
                right: "uncover",
                top: "overlay",
                bottom: "overlay"
            }
        },
        context: "body",
        exclusive: !1,
        closable: !0,
        dimPage: !0,
        scrollLock: !1,
        returnScroll: !1,
        delaySetup: !1,
        duration: 500,
        onChange: function() {},
        onShow: function() {},
        onHide: function() {},
        onHidden: function() {},
        onVisible: function() {},
        className: {
            active: "active",
            animating: "animating",
            dimmed: "dimmed",
            ios: "ios",
            pushable: "pushable",
            pushed: "pushed",
            right: "right",
            top: "top",
            left: "left",
            bottom: "bottom",
            visible: "visible"
        },
        selector: {
            fixed: ".fixed",
            omitted: "script, link, style, .ui.modal, .ui.dimmer, .ui.nag, .ui.fixed",
            pusher: ".pusher",
            sidebar: ".ui.sidebar"
        },
        regExp: {
            ios: /(iPad|iPhone|iPod)/g,
            mobileChrome: /(CriOS)/g,
            mobile: /Mobile|iP(hone|od|ad)|Android|BlackBerry|IEMobile|Kindle|NetFront|Silk-Accelerated|(hpw|web)OS|Fennec|Minimo|Opera M(obi|ini)|Blazer|Dolfin|Dolphin|Skyfire|Zune/g
        },
        error: {
            method: "The method you called is not defined.",
            pusher: "Had to add pusher element. For optimal performance make sure body content is inside a pusher element",
            movedSidebar: "Had to move sidebar. For optimal performance make sure sidebar and pusher are direct children of your body tag",
            overlay: "The overlay setting is no longer supported, use animation: overlay",
            notFound: "There were no elements that matched the specified selector"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = r.selector || "",
            l = (new Date).getTime(),
            c = [],
            u = arguments[0],
            d = "string" == typeof u,
            f = [].slice.call(arguments, 1);
        return r.each(function() {
            var r, m, g, p, h, v = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.sticky.settings, o) : e.extend({}, e.fn.sticky.settings),
                b = v.className,
                y = v.namespace,
                x = v.error,
                C = "." + y,
                w = "module-" + y,
                k = e(this),
                S = e(t),
                T = e(v.scrollContext),
                A = (k.selector || "", k.data(w)),
                R = t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
                    setTimeout(e, 0)
                },
            h = {
                initialize: function() {
                    h.determineContainer(), h.determineContext(), h.verbose("Initializing sticky", v, r), h.save.positions(), h.checkErrors(), h.bind.events(), v.observeChanges && h.observeChanges(), h.instantiate()
                },
                instantiate: function() {
                    h.verbose("Storing instance of module", h), A = h, k.data(w, h)
                },
                destroy: function() {
                    h.verbose("Destroying previous instance"), h.reset(), g && g.disconnect(), p && p.disconnect(), S.off("load" + C, h.event.load).off("resize" + C, h.event.resize), T.off("scrollchange" + C, h.event.scrollchange), k.removeData(w)
                },
                observeChanges: function() {
                        childList: !0,
                        subtree: !0
                    }), p.observe(E, {
                        childList: !0,
                        subtree: !0
                    }), p.observe(m[0], {
                        childList: !0,
                        subtree: !0
                    }), h.debug("Setting up mutation observer", p))
                },
                determineContainer: function() {
                    r = v.container ? e(v.container) : k.offsetParent()
                },
                determineContext: function() {
                    return m = v.context ? e(v.context) : r, 0 === m.length ? void h.error(x.invalidContext, v.context, k) : void 0
                },
                checkErrors: function() {
                    return h.is.hidden() && h.error(x.visible, k), h.cache.element.height > h.cache.context.height ? (h.reset(), void h.error(x.elementSize, k)) : void 0
                },
                bind: {
                    events: function() {
                        S.on("load" + C, h.event.load).on("resize" + C, h.event.resize), T.off("scroll" + C).on("scroll" + C, h.event.scroll).on("scrollchange" + C, h.event.scrollchange)
                    }
                },
                event: {
                    changed: function(e) {
                        clearTimeout(h.timer), h.timer = setTimeout(function() {
                            h.verbose("DOM tree modified, updating sticky menu", e), h.refresh()
                        }, 100)
                    },
                    documentChanged: function(t) {
                        [].forEach.call(t, function(t) {
                            t.removedNodes && [].forEach.call(t.removedNodes, function(t) {
                                (t == E || e(t).find(E).length > 0) && (h.debug("Element removed from DOM, tearing down events"), h.destroy())
                            })
                        })
                    },
                    load: function() {
                        h.verbose("Page contents finished loading"), R(h.refresh)
                    },
                    resize: function() {
                        h.verbose("Window resized"), R(h.refresh)
                    },
                    scroll: function() {
                        R(function() {
                            T.triggerHandler("scrollchange" + C, T.scrollTop())
                        })
                    },
                    scrollchange: function(e, t) {
                        h.stick(t), v.onScroll.call(E)
                    }
                },
                refresh: function(e) {
                    h.reset(), v.context || h.determineContext(), e && h.determineContainer(), h.save.positions(), h.stick(), v.onReposition.call(E)
                },
                supports: {
                    sticky: function() {
                        var t = e("<div/>");
                        t[0];
                        return t.addClass(b.supported), t.css("position").match("sticky")
                    }
                },
                save: {
                    lastScroll: function(e) {
                        h.lastScroll = e
                    },
                    elementScroll: function(e) {
                        h.elementScroll = e
                    },
                    positions: function() {
                        var e = {
                                height: T.height()
                            },
                            t = {
                                margin: {
                                    top: parseInt(k.css("margin-top"), 10),
                                    bottom: parseInt(k.css("margin-bottom"), 10)
                                },
                                offset: k.offset(),
                                width: k.outerWidth(),
                                height: k.outerHeight()
                            },
                            n = {
                                offset: m.offset(),
                                height: m.outerHeight()
                            };
                        ({
                            height: r.outerHeight()
                        });
                        h.is.standardScroll() || (h.debug("Non-standard scroll. Removing scroll offset from element offset"), e.top = T.scrollTop(), e.left = T.scrollLeft(), t.offset.top += e.top, n.offset.top += e.top, t.offset.left += e.left, n.offset.left += e.left), h.cache = {
                            fits: t.height < e.height,
                            scrollContext: {
                                height: e.height
                            },
                            element: {
                                margin: t.margin,
                                top: t.offset.top - t.margin.top,
                                left: t.offset.left,
                                width: t.width,
                                height: t.height,
                                bottom: t.offset.top + t.height
                            },
                            context: {
                                top: n.offset.top,
                                height: n.height,
                                bottom: n.offset.top + n.height
                            }
                        }, h.set.containerSize(), h.set.size(), h.stick(), h.debug("Caching element positions", h.cache)
                    }
                },
                get: {
                    direction: function(e) {
                        var t = "down";
                    },
                    scrollChange: function(e) {
                    },
                    currentElementScroll: function() {
                        return h.elementScroll ? h.elementScroll : h.is.top() ? Math.abs(parseInt(k.css("top"), 10)) || 0 : Math.abs(parseInt(k.css("bottom"), 10)) || 0
                    },
                    elementScroll: function(e) {
                        var t = h.cache.element,
                            n = h.cache.scrollContext,
                            i = h.get.scrollChange(e),
                            o = t.height - n.height + v.offset,
                            a = h.get.currentElementScroll(),
                            r = a + i;
                        return a = h.cache.fits || 0 > r ? 0 : r > o ? o : r
                    }
                },
                remove: {
                    lastScroll: function() {
                        delete h.lastScroll
                    },
                    elementScroll: function(e) {
                        delete h.elementScroll
                    },
                    offset: function() {
                        k.css("margin-top", "")
                    }
                },
                set: {
                    offset: function() {
                        h.verbose("Setting offset on element", v.offset), k.css("margin-top", v.offset)
                    },
                    containerSize: function() {
                        var e = r.get(0).tagName;
                        "HTML" === e || "body" == e ? h.determineContainer() : Math.abs(r.outerHeight() - h.cache.context.height) > v.jitter && (h.debug("Context has padding, specifying exact height for container", h.cache.context.height), r.css({
                            height: h.cache.context.height
                        }))
                    },
                    minimumSize: function() {
                        var e = h.cache.element;
                        r.css("min-height", e.height)
                    },
                    scroll: function(e) {
                        h.debug("Setting scroll on element", e), h.elementScroll != e && (h.is.top() && k.css("bottom", "").css("top", -e), h.is.bottom() && k.css("top", "").css("bottom", e))
                    },
                    size: function() {
                        0 !== h.cache.element.height && 0 !== h.cache.element.width && (E.style.setProperty("width", h.cache.element.width + "px", "important"), E.style.setProperty("height", h.cache.element.height + "px", "important"))
                    }
                },
                is: {
                    standardScroll: function() {
                        return T[0] == t
                    },
                    top: function() {
                        return k.hasClass(b.top)
                    },
                    bottom: function() {
                        return k.hasClass(b.bottom)
                    },
                    initialPosition: function() {
                        return !h.is.fixed() && !h.is.bound()
                    },
                    hidden: function() {
                        return !k.is(":visible")
                    },
                    bound: function() {
                        return k.hasClass(b.bound)
                    },
                    fixed: function() {
                        return k.hasClass(b.fixed)
                    }
                },
                stick: function(e) {
                    var t = e || T.scrollTop(),
                        n = h.cache,
                        i = n.fits,
                        o = n.element,
                        a = n.scrollContext,
                        r = n.context,
                        s = h.is.bottom() && v.pushing ? v.bottomOffset : v.offset,
                        e = {
                            top: t + s,
                            bottom: t + s + a.height
                        },
                        l = (h.get.direction(e.top), i ? 0 : h.get.elementScroll(e.top)),
                        c = !i,
                        u = 0 !== o.height;
                    u && (h.is.initialPosition() ? e.top >= r.bottom ? (h.debug("Initial element position is bottom of container"), h.bindBottom()) : e.top > o.top && (o.height + e.top - l >= r.bottom ? (h.debug("Initial element position is bottom of container"), h.bindBottom()) : (h.debug("Initial element position is fixed"), h.fixTop())) : h.is.fixed() ? h.is.top() ? e.top <= o.top ? (h.debug("Fixed element reached top of container"), h.setInitialPosition()) : o.height + e.top - l >= r.bottom ? (h.debug("Fixed element reached bottom of container"), h.bindBottom()) : c && (h.set.scroll(l), h.save.lastScroll(e.top), h.save.elementScroll(l)) : h.is.bottom() && (e.bottom - o.height <= o.top ? (h.debug("Bottom fixed rail has reached top of container"), h.setInitialPosition()) : e.bottom >= r.bottom ? (h.debug("Bottom fixed rail has reached bottom of container"), h.bindBottom()) : c && (h.set.scroll(l), h.save.lastScroll(e.top), h.save.elementScroll(l))) : h.is.bottom() && (e.top <= o.top ? (h.debug("Jumped from bottom fixed to top fixed, most likely used home/end button"), h.setInitialPosition()) : v.pushing ? h.is.bound() && e.bottom <= r.bottom && (h.debug("Fixing bottom attached element to bottom of browser."), h.fixBottom()) : h.is.bound() && e.top <= r.bottom - o.height && (h.debug("Fixing bottom attached element to top of browser."), h.fixTop())))
                },
                bindTop: function() {
                    h.debug("Binding element to top of parent container"), h.remove.offset(), k.css({
                        left: "",
                        top: "",
                        marginBottom: ""
                    }).removeClass(b.fixed).removeClass(b.bottom).addClass(b.bound).addClass(b.top), v.onTop.call(E), v.onUnstick.call(E)
                },
                bindBottom: function() {
                    h.debug("Binding element to bottom of parent container"), h.remove.offset(), k.css({
                        left: "",
                        top: ""
                    }).removeClass(b.fixed).removeClass(b.top).addClass(b.bound).addClass(b.bottom), v.onBottom.call(E), v.onUnstick.call(E)
                },
                setInitialPosition: function() {
                    h.debug("Returning to initial position"), h.unfix(), h.unbind()
                },
                fixTop: function() {
                    h.debug("Fixing element to top of page"), h.set.minimumSize(), h.set.offset(), k.css({
                        left: h.cache.element.left,
                        bottom: "",
                        marginBottom: ""
                    }).removeClass(b.bound).removeClass(b.bottom).addClass(b.fixed).addClass(b.top), v.onStick.call(E)
                },
                fixBottom: function() {
                    h.debug("Sticking element to bottom of page"), h.set.minimumSize(), h.set.offset(), k.css({
                        left: h.cache.element.left,
                        bottom: "",
                        marginBottom: ""
                    }).removeClass(b.bound).removeClass(b.top).addClass(b.fixed).addClass(b.bottom), v.onStick.call(E)
                },
                unbind: function() {
                    h.is.bound() && (h.debug("Removing container bound position on element"), h.remove.offset(), k.removeClass(b.bound).removeClass(b.top).removeClass(b.bottom))
                },
                unfix: function() {
                    h.is.fixed() && (h.debug("Removing fixed position on element"), h.remove.offset(), k.removeClass(b.fixed).removeClass(b.top).removeClass(b.bottom), v.onUnstick.call(E))
                },
                reset: function() {
                    h.debug("Resetting elements position"), h.unbind(), h.unfix(), h.resetCSS(), h.remove.offset(), h.remove.lastScroll()
                },
                resetCSS: function() {
                    k.css({
                        width: "",
                        height: ""
                    }), r.css({
                        height: ""
                    })
                },
                setting: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, v, t);
                    else {
                        if (n === i) return v[t];
                        v[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, h, t);
                    else {
                        if (n === i) return h[t];
                        h[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        v.performance && (t = (new Date).getTime(), i = l || t, n = t - i, l = t, c.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: E,
                            "Execution Time": n
                        })), clearTimeout(h.performance.timer), h.performance.timer = setTimeout(h.performance.display, 0)
                    },
                    display: function() {
                        var t = v.name + ":",
                            n = 0;
                        l = !1, clearTimeout(h.performance.timer), e.each(c, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = A;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, d ? (A === i && h.initialize(), h.invoke(u)) : (A !== i && A.invoke("destroy"), h.initialize())
        name: "Sticky",
        namespace: "sticky",
        silent: !1,
        debug: !1,
        verbose: !0,
        performance: !0,
        pushing: !1,
        context: !1,
        container: !1,
        scrollContext: t,
        offset: 0,
        bottomOffset: 0,
        jitter: 5,
        observeChanges: !1,
        onReposition: function() {},
        onScroll: function() {},
        onStick: function() {},
        onUnstick: function() {},
        onTop: function() {},
        onBottom: function() {},
        error: {
            container: "Sticky element must be inside a relative container",
            visible: "Element is hidden, you must call refresh after element becomes visible. Use silent setting to surpress this warning in production.",
            method: "The method you called is not defined.",
            invalidContext: "Context specified does not exist",
            elementSize: "Sticky element is larger than its container, cannot create sticky."
        },
        className: {
            bound: "bound",
            fixed: "fixed",
            supported: "native",
            top: "top",
            bottom: "bottom"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
            s = r.selector || "",
            l = (new Date).getTime(),
            c = [],
            u = arguments[0],
            d = "string" == typeof u,
            f = [].slice.call(arguments, 1),
            m = !1;
        return r.each(function() {
            var g, p, h, v, b, y, x = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.tab.settings, o) : e.extend({}, e.fn.tab.settings),
                C = x.className,
                w = x.metadata,
                k = x.selector,
                S = x.error,
                T = "." + x.namespace,
                A = "module-" + x.namespace,
                R = e(this),
                E = {},
                P = !0,
                F = 0,
                D = R.data(A);
            b = {
                initialize: function() {
                    b.debug("Initializing tab menu item", R), b.fix.callbacks(), b.determineTabs(), b.debug("Determining tabs", x.context, p), x.auto && b.set.auto(), b.bind.events(), x.history && !m && (b.initializeHistory(), m = !0), b.instantiate()
                },
                instantiate: function() {
                    b.verbose("Storing instance of module", b), D = b, R.data(A, b)
                },
                destroy: function() {
                    b.debug("Destroying tabs", R), R.removeData(A).off(T)
                },
                bind: {
                    events: function() {
                        e.isWindow(O) || (b.debug("Attaching tab activation events to element", R), R.on("click" + T, b.event.click))
                    }
                },
                determineTabs: function() {
                    var t;
                    "parent" === x.context ? (R.closest(k.ui).length > 0 ? (t = R.closest(k.ui), b.verbose("Using closest UI element as parent", t)) : t = R, g = t.parent(), b.verbose("Determined parent element for creating context", g)) : x.context ? (g = e(x.context), b.verbose("Using selector for tab context", x.context, g)) : g = e("body"), x.childrenOnly ? (p = g.children(k.tabs), b.debug("Searching tab context children for tabs", g, p)) : (p = g.find(k.tabs), b.debug("Searching tab context for tabs", g, p))
                },
                fix: {
                    callbacks: function() {
                    }
                },
                initializeHistory: function() {
                    if (b.debug("Initializing page state"), e.address === i) return b.error(S.state), !1;
                    if ("state" == x.historyType) {
                        if (b.debug("Using HTML5 to manage state"), x.path === !1) return b.error(S.path), !1;
                        e.address.history(!0).state(x.path)
                    }
                    e.address.bind("change", b.event.history.change)
                },
                event: {
                    click: function(t) {
                        var n = e(this).data(w.tab);
                        n !== i ? (x.history ? (b.verbose("Updating page state", t), e.address.value(n)) : (b.verbose("Changing tab", t), b.changeTab(n)), t.preventDefault()) : b.debug("No tab specified")
                    },
                    history: {
                        change: function(t) {
                            var n = t.pathNames.join("/") || b.get.initialPath(),
                                o = x.templates.determineTitle(n) || !1;
                            b.performance.display(), b.debug("History change event", n, t), y = t, n !== i && b.changeTab(n), o && e.address.title(o)
                        }
                    }
                },
                refresh: function() {
                    h && (b.debug("Refreshing tab", h), b.changeTab(h))
                },
                cache: {
                    read: function(e) {
                        return e !== i ? E[e] : !1
                    },
                    add: function(e, t) {
                    },
                    remove: function(e) {
                    }
                },
                set: {
                    auto: function() {
                        var t = "string" == typeof x.path ? x.path.replace(/\/$/, "") + "/{$tab}" : "/{$tab}";
                        b.verbose("Setting up automatic tab retrieval from server", t), e.isPlainObject(x.apiSettings) ? x.apiSettings.url = t : x.apiSettings = {
                            url: t
                        }
                    },
                    loading: function(e) {
                        var t = b.get.tabElement(e),
                            n = t.hasClass(C.loading);
                        n || (b.verbose("Setting loading state for", t), t.addClass(C.loading).siblings(p).removeClass(C.active + " " + C.loading), t.length > 0 && x.onRequest.call(t[0], e))
                    },
                    state: function(t) {
                        e.address.value(t)
                    }
                },
                changeTab: function(n) {
                    var i = t.history && t.history.pushState,
                        o = i && x.ignoreFirstLoad && P,
                        a = x.auto || e.isPlainObject(x.apiSettings),
                        r = a && !o ? b.utilities.pathToArray(n) : b.get.defaultPathArray(n);
                        var s, l, c, u, d = r.slice(0, t + 1),
                            f = b.utilities.arrayToPath(d),
                            m = b.is.tab(f),
                            p = t + 1 == r.length,
                            k = b.get.tabElement(f);
                        if (b.verbose("Looking for tab", i), m) {
                            if (b.verbose("Tab was found", i), h = f, v = b.utilities.filterArray(r, d), p ? u = !0 : (l = r.slice(0, t + 2), c = b.utilities.arrayToPath(l), u = !b.is.tab(c), u && b.verbose("Tab parameters found", l)), u && a) return o ? (b.debug("Ignoring remote content on first tab load", f), P = !1, b.cache.add(n, k.html()), b.activate.all(f), x.onFirstLoad.call(k[0], f, v, y), x.onLoad.call(k[0], f, v, y)) : (b.activate.navigation(f), b.fetch.content(f, n)), !1;
                            b.debug("Opened local tab", f), b.activate.all(f), b.cache.read(f) || (b.cache.add(f, !0), b.debug("First time tab loaded calling tab init"), x.onFirstLoad.call(k[0], f, v, y)), x.onLoad.call(k[0], f, v, y)
                        } else {
                            if (-1 != n.search("/") || "" === n) return b.error(S.missingTab, R, g, f), !1;
                            if (s = e("#" + n + ', a[name="' + n + '"]'), f = s.closest("[data-tab]").data(w.tab), k = b.get.tabElement(f), s && s.length > 0 && f) return b.debug("Anchor link used, opening parent tab", k, s), k.hasClass(C.active) || setTimeout(function() {
                                b.scrollTo(s)
                            }, 0), b.activate.all(f), b.cache.read(f) || (b.cache.add(f, !0), b.debug("First time tab loaded calling tab init"), x.onFirstLoad.call(k[0], f, v, y)), x.onLoad.call(k[0], f, v, y), !1
                        }
                    })
                },
                scrollTo: function(t) {
                    var i = t && t.length > 0 ? t.offset().top : !1;
                    i !== !1 && (b.debug("Forcing scroll to an in-page link in a hidden tab", i, t), e(n).scrollTop(i))
                },
                update: {
                    content: function(t, n, o) {
                        var a = b.get.tabElement(t),
                            r = a[0];
                    }
                },
                fetch: {
                    content: function(t, n) {
                        var o, a, r = b.get.tabElement(t),
                            s = {
                                dataType: "html",
                                encodeParameters: !1,
                                on: "now",
                                cache: x.alwaysRefresh,
                                headers: {
                                    "X-Remote": !0
                                },
                                onSuccess: function(e) {
                                    "response" == x.cacheType && b.cache.add(n, e), b.update.content(t, e), t == h ? (b.debug("Content loaded", t), b.activate.tab(t)) : b.debug("Content loaded in background", t), x.onFirstLoad.call(r[0], t, v, y), x.onLoad.call(r[0], t, v, y), "string" == typeof x.cacheType && "dom" == x.cacheType.toLowerCase() && r.children().length > 0 ? setTimeout(function() {
                                        var e = r.children().clone(!0);
                                        e = e.not("script"), b.cache.add(n, e)
                                    }, 0) : b.cache.add(n, r.html())
                                },
                                urlData: {
                                    tab: n
                                }
                            },
                            l = r.api("get request") || !1,
                            c = l && "pending" === l.state();
                    }
                },
                activate: {
                    all: function(e) {
                        b.activate.tab(e), b.activate.navigation(e)
                    },
                    tab: function(e) {
                        var t = b.get.tabElement(e),
                            n = "siblings" == x.deactivate ? t.siblings(p) : p.not(t),
                            i = t.hasClass(C.active);
                        b.verbose("Showing tab content for", t), i || (t.addClass(C.active), n.removeClass(C.active + " " + C.loading), t.length > 0 && x.onVisible.call(t[0], e))
                    },
                    navigation: function(e) {
                        var t = b.get.navElement(e),
                            n = "siblings" == x.deactivate ? t.siblings(r) : r.not(t),
                            i = t.hasClass(C.active);
                        b.verbose("Activating tab navigation for", t, e), i || (t.addClass(C.active), n.removeClass(C.active + " " + C.loading))
                    }
                },
                deactivate: {
                    all: function() {
                        b.deactivate.navigation(), b.deactivate.tabs()
                    },
                    navigation: function() {
                        r.removeClass(C.active)
                    },
                    tabs: function() {
                        p.removeClass(C.active + " " + C.loading)
                    }
                },
                is: {
                    tab: function(e) {
                        return e !== i ? b.get.tabElement(e).length > 0 : !1
                    }
                },
                get: {
                    initialPath: function() {
                        return r.eq(0).data(w.tab) || p.eq(0).data(w.tab)
                    },
                    path: function() {
                        return e.address.value()
                    },
                    defaultPathArray: function(e) {
                        return b.utilities.pathToArray(b.get.defaultPath(e))
                    },
                    defaultPath: function(e) {
                        var t = r.filter("[data-" + w.tab + '^="' + e + '/"]').eq(0),
                            n = t.data(w.tab) || !1;
                        if (n) {
                            if (b.debug("Found default tab", n), F < x.maxDepth) return F++, b.get.defaultPath(n);
                            b.error(S.recursion)
                        } else b.debug("No default tabs found for", e, p);
                        return F = 0, e
                    },
                    navElement: function(e) {
                    },
                    tabElement: function(e) {
                        var t, n, i, o;
                    },
                    tab: function() {
                        return h
                    }
                },
                utilities: {
                    filterArray: function(t, n) {
                        return e.grep(t, function(t) {
                            return -1 == e.inArray(t, n)
                        })
                    },
                    last: function(t) {
                        return e.isArray(t) ? t[t.length - 1] : !1
                    },
                    pathToArray: function(e) {
                    },
                    arrayToPath: function(t) {
                        return e.isArray(t) ? t.join("/") : !1
                    }
                },
                setting: function(t, n) {
                    if (b.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, x, t);
                    else {
                        if (n === i) return x[t];
                        e.isPlainObject(x[t]) ? e.extend(!0, x[t], n) : x[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, b, t);
                    else {
                        if (n === i) return b[t];
                        b[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        x.performance && (t = (new Date).getTime(), i = l || t, n = t - i, l = t, c.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: O,
                            "Execution Time": n
                        })), clearTimeout(b.performance.timer), b.performance.timer = setTimeout(b.performance.display, 500)
                    },
                    display: function() {
                        var t = x.name + ":",
                            n = 0;
                        l = !1, clearTimeout(b.performance.timer), e.each(c, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = D;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (b.error(S.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, d ? (D === i && b.initialize(), b.invoke(u)) : (D !== i && D.invoke("destroy"), b.initialize())
        e(t).tab.apply(this, arguments)
        name: "Tab",
        namespace: "tab",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        auto: !1,
        history: !1,
        historyType: "hash",
        path: !1,
        context: !1,
        childrenOnly: !1,
        maxDepth: 25,
        deactivate: "siblings",
        alwaysRefresh: !1,
        cache: !0,
        cacheType: "response",
        ignoreFirstLoad: !1,
        apiSettings: !1,
        evaluateScripts: "once",
        onFirstLoad: function(e, t, n) {},
        onLoad: function(e, t, n) {},
        onVisible: function(e, t, n) {},
        onRequest: function(e, t, n) {},
        templates: {
            determineTitle: function(e) {}
        },
        error: {
            api: "You attempted to load content without API module",
            method: "The method you called is not defined",
            missingTab: "Activated tab cannot be found. Tabs are case-sensitive.",
            noContent: "The tab you specified is missing a content url.",
            path: "History enabled, but no path was specified",
            recursion: "Max recursive depth reached",
            legacyInit: "onTabInit has been renamed to onFirstLoad in 2.0, please adjust your code.",
            legacyLoad: "onTabLoad has been renamed to onLoad in 2.0. Please adjust your code",
            state: "History requires Asual's Address library <https://github.com/asual/jquery-address>"
        },
        metadata: {
            tab: "tab",
            loaded: "loaded",
            promise: "promise"
        },
        className: {
            loading: "loading",
            active: "active"
        },
        selector: {
            tabs: ".ui.tab",
            ui: ".ui"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = a.selector || "",
            s = (new Date).getTime(),
            l = [],
            c = arguments,
            u = c[0],
            d = [].slice.call(arguments, 1),
            f = "string" == typeof u;
        t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
            setTimeout(e, 0)
        };
        return a.each(function(t) {
            var m, g, p, h, v, b, y, x, C, w = e(this),
            C = {
                initialize: function() {
                    m = C.get.settings.apply(k, c), h = m.className, p = m.error, v = m.metadata, x = "." + m.namespace, y = "module-" + m.namespace, g = w.data(y) || C, b = C.get.animationEndEvent(), f && (f = C.invoke(u)), f === !1 && (C.verbose("Converted arguments into settings object", m), m.interval ? C.delay(m.animate) : C.animate(), C.instantiate())
                },
                instantiate: function() {
                    C.verbose("Storing instance of module", C), g = C, w.data(y, g)
                },
                destroy: function() {
                    C.verbose("Destroying previous module for", k), w.removeData(y)
                },
                refresh: function() {
                    C.verbose("Refreshing display type on next animation"), delete C.displayType
                },
                forceRepaint: function() {
                    C.verbose("Forcing element repaint");
                    var e = w.parent(),
                        t = w.next();
                    0 === t.length ? w.detach().appendTo(e) : w.detach().insertBefore(t)
                },
                repaint: function() {
                    C.verbose("Repainting element");
                    k.offsetWidth
                },
                delay: function(e) {
                    var n, o, r = C.get.animationDirection();
                },
                animate: function(e) {
                    if (m = e || m, C.debug("Preparing animation", m.animation), C.is.animating()) {
                        if (m.queue) return !m.allowRepeats && C.has.direction() && C.is.occurring() && C.queuing !== !0 ? C.debug("Animation is currently occurring, preventing queueing same animation", m.animation) : C.queue(m.animation), !1;
                        if (!m.allowRepeats && C.is.occurring()) return C.debug("Animation is already occurring, will not execute repeated animation", m.animation), !1;
                        C.debug("New animation started, completing previous early", m.animation), g.complete()
                    }
                    C.set.animating(m.animation)
                },
                reset: function() {
                    C.debug("Resetting animation to beginning conditions"), C.remove.animationCallbacks(), C.restore.conditions(), C.remove.animating()
                },
                queue: function(e) {
                    C.debug("Queueing animation of", e), C.queuing = !0, w.one(b + ".queue" + x, function() {
                        C.queuing = !1, C.repaint(), C.animate.apply(this, m)
                    })
                },
                complete: function(e) {
                    C.debug("Animation complete", m.animation), C.remove.completeCallback(), C.remove.failSafe(), C.is.looping() || (C.is.outward() ? (C.verbose("Animation is outward, hiding element"), C.restore.conditions(), C.hide()) : C.is.inward() ? (C.verbose("Animation is outward, showing element"), C.restore.conditions(), C.show()) : (C.verbose("Static animation completed"), C.restore.conditions(), m.onComplete.call(k)))
                },
                force: {
                    visible: function() {
                        var e = w.attr("style"),
                            t = C.get.userStyle(),
                            n = C.get.displayType(),
                            o = t + "display: " + n + " !important;",
                            a = w.css("display"),
                            r = e === i || "" === e;
                        a !== n ? (C.verbose("Overriding default display to show element", n), w.attr("style", o)) : r && w.removeAttr("style")
                    },
                    hidden: function() {
                        var e = w.attr("style"),
                            t = w.css("display"),
                            n = e === i || "" === e;
                        "none" === t || C.is.hidden() ? n && w.removeAttr("style") : (C.verbose("Overriding default display to hide element"), w.css("display", "none"))
                    }
                },
                has: {
                    direction: function(t) {
                        var n = !1;
                            (t === h.inward || t === h.outward) && (n = !0)
                        })), n
                    },
                    inlineDisplay: function() {
                        var t = w.attr("style") || "";
                        return e.isArray(t.match(/display.*?;/, ""))
                    }
                },
                set: {
                    animating: function(e) {
                        var t;
                    },
                    duration: function(e, t) {
                            "animation-duration": t
                        }))
                    },
                    direction: function(e) {
                    },
                    looping: function() {
                        C.debug("Transition set to loop"), w.addClass(h.looping)
                    },
                    hidden: function() {
                        w.addClass(h.transition).addClass(h.hidden)
                    },
                    inward: function() {
                        C.debug("Setting direction to inward"), w.removeClass(h.outward).addClass(h.inward)
                    },
                    outward: function() {
                        C.debug("Setting direction to outward"), w.removeClass(h.inward).addClass(h.outward)
                    },
                    visible: function() {
                        w.addClass(h.transition).addClass(h.visible)
                    }
                },
                start: {
                    animation: function(e) {
                    }
                },
                save: {
                    animation: function(e) {
                        C.cache || (C.cache = {}), C.cache.animation = e
                    },
                    displayType: function(e) {
                        "none" !== e && w.data(v.displayType, e)
                    },
                    transitionExists: function(t, n) {
                    }
                },
                restore: {
                    conditions: function() {
                        var e = C.get.currentAnimation();
                        e && (w.removeClass(e), C.verbose("Removing animation class", C.cache)), C.remove.duration()
                    }
                },
                add: {
                    failSafe: function() {
                        var e = C.get.duration();
                        "non-animate" === b ? C.timer = setTimeout(function() {
                            w.triggerHandler(b)
                        }, 5) : C.timer = setTimeout(function() {
                            w.triggerHandler(b)
                        }, e + m.failSafeDelay), C.verbose("Adding fail safe timer", C.timer)
                    }
                },
                remove: {
                    animating: function() {
                        w.removeClass(h.animating)
                    },
                    animationCallbacks: function() {
                        C.remove.queueCallback(), C.remove.completeCallback()
                    },
                    queueCallback: function() {
                        w.off(".queue" + x)
                    },
                    completeCallback: function() {
                        w.off(".complete" + x)
                    },
                    display: function() {
                        w.css("display", "")
                    },
                    direction: function() {
                        w.removeClass(h.inward).removeClass(h.outward)
                    },
                    duration: function() {
                        w.css("animation-duration", "")
                    },
                    failSafe: function() {
                        C.verbose("Removing fail safe timer", C.timer), C.timer && clearTimeout(C.timer)
                    },
                    hidden: function() {
                        w.removeClass(h.hidden)
                    },
                    visible: function() {
                        w.removeClass(h.visible)
                    },
                    looping: function() {
                        C.debug("Transitions are no longer looping"), C.is.looping() && (C.reset(), w.removeClass(h.looping))
                    },
                    transition: function() {
                        w.removeClass(h.visible).removeClass(h.hidden)
                    }
                },
                get: {
                    settings: function(t, n, i) {
                        return "object" == typeof t ? e.extend(!0, {}, e.fn.transition.settings, t) : "function" == typeof i ? e.extend({}, e.fn.transition.settings, {
                            animation: t,
                            onComplete: i,
                            duration: n
                        }) : "string" == typeof n || "number" == typeof n ? e.extend({}, e.fn.transition.settings, {
                            animation: t,
                            duration: n
                        }) : "object" == typeof n ? e.extend({}, e.fn.transition.settings, n, {
                            animation: t
                        }) : "function" == typeof n ? e.extend({}, e.fn.transition.settings, {
                            animation: t,
                            onComplete: n
                        }) : e.extend({}, e.fn.transition.settings, {
                            animation: t
                        })
                    },
                    animationClass: function(e) {
                        var t = e || m.animation,
                            n = C.can.transition() && !C.has.direction() ? C.get.direction() + " " : "";
                        return h.animating + " " + h.transition + " " + n + t
                    },
                    currentAnimation: function() {
                        return C.cache && C.cache.animation !== i ? C.cache.animation : !1
                    },
                    currentDirection: function() {
                        return C.is.inward() ? h.inward : h.outward
                    },
                    direction: function() {
                        return C.is.hidden() || !C.is.visible() ? h.inward : h.outward
                    },
                    animationDirection: function(t) {
                        var n;
                            t === h.inward ? n = h.inward : t === h.outward && (n = h.outward)
                        })), n ? n : !1
                    },
                    duration: function(e) {
                    },
                    displayType: function(e) {
                    },
                    userStyle: function(e) {
                    },
                    transitionExists: function(t) {
                        return e.fn.transition.exists[t]
                    },
                    animationStartEvent: function() {
                        var e, t = n.createElement("div"),
                            o = {
                                animation: "animationstart",
                                OAnimation: "oAnimationStart",
                                MozAnimation: "mozAnimationStart",
                                WebkitAnimation: "webkitAnimationStart"
                            };
                        for (e in o)
                            if (t.style[e] !== i) return o[e];
                        return !1
                    },
                    animationEndEvent: function() {
                        var e, t = n.createElement("div"),
                            o = {
                                animation: "animationend",
                                OAnimation: "oAnimationEnd",
                                MozAnimation: "mozAnimationEnd",
                                WebkitAnimation: "webkitAnimationEnd"
                            };
                        for (e in o)
                            if (t.style[e] !== i) return o[e];
                        return "non-animate"
                    }
                },
                can: {
                    transition: function(t) {
                        var n, o, a, r, s, l, c = m.animation,
                            u = C.get.transitionExists(c),
                            d = C.get.displayType(!1);
                        if (u === i || t) {
                            if (C.verbose("Determining whether animation exists"), n = w.attr("class"), o = w.prop("tagName"), a = e("<" + o + " />").addClass(n).insertAfter(w), r = a.addClass(c).removeClass(h.inward).removeClass(h.outward).addClass(h.animating).addClass(h.transition).css("animationName"), s = a.addClass(h.inward).css("animationName"), d || (d = a.attr("class", n).removeAttr("style").removeClass(h.hidden).removeClass(h.visible).show().css("display"), C.verbose("Determining final display state", d), C.save.displayType(d)), a.remove(), r != s) C.debug("Direction exists for animation", c), l = !0;
                            else {
                                if ("none" == r || !r) return void C.debug("No animation defined in css", c);
                                C.debug("Static animation found", c, d), l = !1
                            }
                            C.save.transitionExists(c, l)
                        }
                        return u !== i ? u : l
                    },
                    animate: function() {
                        return C.can.transition() !== i
                    }
                },
                is: {
                    animating: function() {
                        return w.hasClass(h.animating)
                    },
                    inward: function() {
                        return w.hasClass(h.inward)
                    },
                    outward: function() {
                        return w.hasClass(h.outward)
                    },
                    looping: function() {
                        return w.hasClass(h.looping)
                    },
                    occurring: function(e) {
                    },
                    visible: function() {
                        return w.is(":visible")
                    },
                    hidden: function() {
                        return "hidden" === w.css("visibility")
                    },
                    supported: function() {
                        return b !== !1
                    }
                },
                hide: function() {
                    C.verbose("Hiding element"), C.is.animating() && C.reset(), k.blur(), C.remove.display(), C.remove.visible(), C.set.hidden(), C.force.hidden(), m.onHide.call(k), m.onComplete.call(k)
                },
                show: function(e) {
                    C.verbose("Showing element", e), C.remove.hidden(), C.set.visible(), C.force.visible(), m.onShow.call(k), m.onComplete.call(k)
                },
                toggle: function() {
                    C.is.visible() ? C.hide() : C.show()
                },
                stop: function() {
                    C.debug("Stopping current animation"), w.triggerHandler(b)
                },
                stopAll: function() {
                    C.debug("Stopping all animation"), C.remove.queueCallback(), w.triggerHandler(b)
                },
                clear: {
                    queue: function() {
                        C.debug("Clearing animation queue"), C.remove.queueCallback()
                    }
                },
                enable: function() {
                    C.verbose("Starting animation"), w.removeClass(h.disabled)
                },
                disable: function() {
                    C.debug("Stopping animation"), w.addClass(h.disabled)
                },
                setting: function(t, n) {
                    if (C.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, m, t);
                    else {
                        if (n === i) return m[t];
                        e.isPlainObject(m[t]) ? e.extend(!0, m[t], n) : m[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, C, t);
                    else {
                        if (n === i) return C[t];
                        C[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        m.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: k,
                            "Execution Time": n
                        })), clearTimeout(C.performance.timer), C.performance.timer = setTimeout(C.performance.display, 500)
                    },
                    display: function() {
                        var t = m.name + ":",
                            n = 0;
                        s = !1, clearTimeout(C.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = g;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : !1;
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s !== i ? s : !1
                }
            }, C.initialize()
        name: "Transition",
        silent: !1,
        debug: !1,
        verbose: !1,
        performance: !0,
        namespace: "transition",
        interval: 0,
        reverse: "auto",
        onStart: function() {},
        onComplete: function() {},
        onShow: function() {},
        onHide: function() {},
        useFailSafe: !0,
        failSafeDelay: 100,
        allowRepeats: !1,
        displayType: !1,
        animation: "fade",
        duration: !1,
        queue: !0,
        metadata: {
            displayType: "display"
        },
        className: {
            animating: "animating",
            disabled: "disabled",
            hidden: "hidden",
            inward: "in",
            loading: "loading",
            looping: "looping",
            outward: "out",
            transition: "transition",
            visible: "visible"
        },
        error: {
            noAnimation: "Element is no longer attached to DOM. Unable to animate.  Use silent setting to surpress this warning in production.",
            repeated: "That animation is already occurring, cancelling repeated animation",
            method: "The method you called is not defined",
            support: "This browser does not support CSS animations"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
            r = a.selector || "",
            s = (new Date).getTime(),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1);
        return a.each(function() {
            var a, f, m, g, p, h, v = e.isPlainObject(n) ? e.extend(!0, {}, e.fn.api.settings, n) : e.extend({}, e.fn.api.settings),
                b = v.namespace,
                y = v.metadata,
                x = v.selector,
                C = v.error,
                w = v.className,
                k = "." + b,
                S = "module-" + b,
                T = e(this),
                A = T.closest(x.form),
                R = v.stateContext ? e(v.stateContext) : T,
                P = R[0],
                F = T.data(S);
            h = {
                initialize: function() {
                    u || h.bind.events(), h.instantiate()
                },
                instantiate: function() {
                    h.verbose("Storing instance of module", h), F = h, T.data(S, F)
                },
                destroy: function() {
                    h.verbose("Destroying previous module for", E), T.removeData(S).off(k)
                },
                bind: {
                    events: function() {
                        var e = h.get.event();
                        e ? (h.verbose("Attaching API events to element", e), T.on(e + k, h.event.trigger)) : "now" == v.on && (h.debug("Querying API endpoint immediately"), h.query())
                    }
                },
                decode: {
                    json: function(e) {
                        if (e !== i && "string" == typeof e) try {
                        } catch (t) {}
                        return e
                    }
                },
                read: {
                    cachedResponse: function(e) {
                        var n;
                    }
                },
                write: {
                    cachedResponse: function(n, o) {
                    }
                },
                query: function() {
                    if (h.is.disabled()) return void h.debug("Element is disabled API request aborted");
                    if (h.is.loading()) {
                        if (!v.interruptRequests) return void h.debug("Cancelling request, previous request is still pending");
                        h.debug("Interrupting previous request"), h.abort()
                    }
                    return v.defaultData && e.extend(!0, v.urlData, h.get.defaultData()), v.serializeForm && (v.data = h.add.formData(v.data)), f = h.get.settings(), f === !1 ? (h.cancelled = !0, void h.error(C.beforeSend)) : (h.cancelled = !1, m = h.get.templatedURL(), m || h.is.mocked() ? (m = h.add.urlData(m), m || h.is.mocked() ? (f.url = v.base + m, a = e.extend(!0, {}, v, {
                        type: v.method || v.type,
                        data: g,
                        url: v.base + m,
                        beforeSend: v.beforeXHR,
                        success: function() {},
                        failure: function() {},
                        complete: function() {}
                    }), h.debug("Querying URL", a.url), h.verbose("Using AJAX settings", a), "local" === v.cache && h.read.cachedResponse(m) ? (h.debug("Response returned from local cache"), h.request = h.create.request(), void h.request.resolveWith(P, [h.read.cachedResponse(m)])) : void(v.throttle ? v.throttleFirstRequest || h.timer ? (h.debug("Throttling request", v.throttle), clearTimeout(h.timer), h.timer = setTimeout(function() {
                        h.timer && delete h.timer, h.debug("Sending throttled request", g, a.method), h.send.request()
                    }, v.throttle)) : (h.debug("Sending request", g, a.method), h.send.request(), h.timer = setTimeout(function() {}, v.throttle)) : (h.debug("Sending request", g, a.method), h.send.request()))) : void 0) : void h.error(C.missingURL))
                },
                should: {
                    removeError: function() {
                        return v.hideError === !0 || "auto" === v.hideError && !h.is.form()
                    }
                },
                is: {
                    disabled: function() {
                        return T.filter(x.disabled).length > 0
                    },
                    expectingJSON: function() {
                        return "json" === v.dataType || "jsonp" === v.dataType
                    },
                    form: function() {
                        return T.is("form") || R.is("form")
                    },
                    mocked: function() {
                        return v.mockResponse || v.mockResponseAsync || v.response || v.responseAsync
                    },
                    input: function() {
                        return T.is("input")
                    },
                    loading: function() {
                        return h.request ? "pending" == h.request.state() : !1
                    },
                    abortedRequest: function(e) {
                        return e && e.readyState !== i && 0 === e.readyState ? (h.verbose("XHR request determined to be aborted"), !0) : (h.verbose("XHR request was not aborted"), !1)
                    },
                    validResponse: function(t) {
                        return h.is.expectingJSON() && e.isFunction(v.successTest) ? (h.debug("Checking JSON returned success", v.successTest, t), v.successTest(t) ? (h.debug("Response passed success test", t), !0) : (h.debug("Response failed success test", t), !1)) : (h.verbose("Response is not JSON, skipping validation", v.successTest, t), !0)
                    }
                },
                was: {
                    cancelled: function() {
                        return h.cancelled || !1
                    },
                    succesful: function() {
                        return h.request && "resolved" == h.request.state()
                    },
                    failure: function() {
                        return h.request && "rejected" == h.request.state()
                    },
                    complete: function() {
                        return h.request && ("resolved" == h.request.state() || "rejected" == h.request.state())
                    }
                },
                add: {
                    urlData: function(t, n) {
                        var o, a;
                            var r = -1 !== a.indexOf("$") ? a.substr(2, a.length - 3) : a.substr(1, a.length - 2),
                                s = e.isPlainObject(n) && n[r] !== i ? n[r] : T.data(r) !== i ? T.data(r) : R.data(r) !== i ? R.data(r) : n[r];
                            return s === i ? (h.error(C.requiredParameter, r, t), t = !1, !1) : (h.verbose("Found required variable", r, s), s = v.encodeParameters ? h.get.urlEncodedValue(s) : s, t = t.replace(a, s), void 0)
                        })), a && (h.debug("Looking for optional URL variables", o), e.each(a, function(o, a) {
                            var r = -1 !== a.indexOf("$") ? a.substr(3, a.length - 4) : a.substr(2, a.length - 3),
                                s = e.isPlainObject(n) && n[r] !== i ? n[r] : T.data(r) !== i ? T.data(r) : R.data(r) !== i ? R.data(r) : n[r];
                            s !== i ? (h.verbose("Optional variable Found", r, s), t = t.replace(a, s)) : (h.verbose("Optional variable not found", r), t = -1 !== t.indexOf("/" + a) ? t.replace("/" + a, "") : t.replace(a, ""))
                        }))), t
                    },
                    formData: function(t) {
                        var n, o = e.fn.serializeObject !== i,
                            a = o ? A.serializeObject() : A.serialize();
                        return t = t || v.data, n = e.isPlainObject(t), n ? o ? (h.debug("Extending existing data with form data", t, a), t = e.extend(!0, {}, t, a)) : (h.error(C.missingSerialize), h.debug("Cant extend data. Replacing data with form data", t, a), t = a) : (h.debug("Adding form data", a), t = a), t
                    }
                },
                send: {
                    request: function() {
                        h.set.loading(), h.request = h.create.request(), h.is.mocked() ? h.mockedXHR = h.create.mockedXHR() : h.xhr = h.create.xhr(), v.onRequest.call(P, h.request, h.xhr)
                    }
                },
                event: {
                    trigger: function(e) {
                        h.query(), ("submit" == e.type || "click" == e.type) && e.preventDefault()
                    },
                    xhr: {
                        always: function() {},
                        done: function(t, n, i) {
                                a = (new Date).getTime() - p,
                                r = v.loadingDuration - a,
                                s = e.isFunction(v.onResponse) ? h.is.expectingJSON() ? v.onResponse.call(o, e.extend(!0, {}, t)) : v.onResponse.call(o, t) : !1;
                            r = r > 0 ? r : 0, s && (h.debug("Modified API response in onResponse callback", v.onResponse, s, t), t = s), r > 0 && h.debug("Response completed early delaying state change by", r), setTimeout(function() {
                                h.is.validResponse(t) ? h.request.resolveWith(o, [t, i]) : h.request.rejectWith(o, [i, "invalid"])
                            }, r)
                        },
                        fail: function(e, t, n) {
                                o = (new Date).getTime() - p,
                                a = v.loadingDuration - o;
                            a = a > 0 ? a : 0, a > 0 && h.debug("Response completed early delaying state change by", a), setTimeout(function() {
                                h.is.abortedRequest(e) ? h.request.rejectWith(i, [e, "aborted", n]) : h.request.rejectWith(i, [e, "error", t, n])
                            }, a)
                        }
                    },
                    request: {
                        done: function(e, t) {
                            h.debug("Successful API Response", e), "local" === v.cache && m && (h.write.cachedResponse(m, e), h.debug("Saving server response locally", h.cache)), v.onSuccess.call(P, e, T, t)
                        },
                        complete: function(e, t) {
                            var n, i;
                            h.was.succesful() ? (i = e, n = t) : (n = e, i = h.get.responseFromXHR(n)), h.remove.loading(), v.onComplete.call(P, i, T, n)
                        },
                        fail: function(e, t, n) {
                            var o = h.get.responseFromXHR(e),
                                r = h.get.errorFromRequest(o, t, n);
                            return "aborted" == t ? (h.debug("XHR Aborted (Most likely caused by page navigation or CORS Policy)", t, n), v.onAbort.call(P, t, T, e), !0) : ("invalid" == t ? h.debug("JSON did not pass success test. A server-side error has most likely occurred", o) : "error" == t && e !== i && (h.debug("XHR produced a server error", t, n), 200 != e.status && n !== i && "" !== n && h.error(C.statusMessage + n, a.url), v.onError.call(P, r, T, e)), v.errorDuration && "aborted" !== t && (h.debug("Adding error state"), h.set.error(), h.should.removeError() && setTimeout(h.remove.error, v.errorDuration)), h.debug("API Request failed", r, e), void v.onFailure.call(P, o, T, e))
                        }
                    }
                },
                create: {
                    request: function() {
                        return e.Deferred().always(h.event.request.complete).done(h.event.request.done).fail(h.event.request.fail)
                    },
                    mockedXHR: function() {
                        var t, n, i, o = !1,
                            a = !1,
                            r = !1,
                            s = v.mockResponse || v.response,
                            l = v.mockResponseAsync || v.responseAsync;
                        return i = e.Deferred().always(h.event.xhr.complete).done(h.event.xhr.done).fail(h.event.xhr.fail), s ? (e.isFunction(s) ? (h.debug("Using specified synchronous callback", s), n = s.call(P, f)) : (h.debug("Using settings specified response", s), n = s), i.resolveWith(P, [n, o, {
                            responseText: n
                        }])) : e.isFunction(l) && (t = function(e) {
                            h.debug("Async callback returned response", e), e ? i.resolveWith(P, [e, o, {
                                responseText: e
                            }]) : i.rejectWith(P, [{
                                responseText: e
                            }, a, r])
                        }, h.debug("Using specified async response callback", l), l.call(P, f, t)), i
                    },
                    xhr: function() {
                        var t;
                        return t = e.ajax(a).always(h.event.xhr.always).done(h.event.xhr.done).fail(h.event.xhr.fail), h.verbose("Created server request", t, a), t
                    }
                },
                set: {
                    error: function() {
                        h.verbose("Adding error state to element", R), R.addClass(w.error)
                    },
                    loading: function() {
                        h.verbose("Adding loading state to element", R), R.addClass(w.loading), p = (new Date).getTime()
                    }
                },
                remove: {
                    error: function() {
                        h.verbose("Removing error state from element", R), R.removeClass(w.error)
                    },
                    loading: function() {
                        h.verbose("Removing loading state from element", R), R.removeClass(w.loading)
                    }
                },
                get: {
                    responseFromXHR: function(t) {
                        return e.isPlainObject(t) ? h.is.expectingJSON() ? h.decode.json(t.responseText) : t.responseText : !1
                    },
                    errorFromRequest: function(t, n, o) {
                        return e.isPlainObject(t) && t.error !== i ? t.error : v.error[n] !== i ? v.error[n] : o
                    },
                    request: function() {
                        return h.request || !1
                    },
                    xhr: function() {
                        return h.xhr || !1
                    },
                    settings: function() {
                        var t;
                        return t = v.beforeSend.call(P, v), t && (t.success !== i && (h.debug("Legacy success callback detected", t), h.error(C.legacyParameters, t.success), t.onSuccess = t.success), t.failure !== i && (h.debug("Legacy failure callback detected", t), h.error(C.legacyParameters, t.failure), t.onFailure = t.failure), t.complete !== i && (h.debug("Legacy complete callback detected", t), h.error(C.legacyParameters, t.complete), t.onComplete = t.complete)), t === i && h.error(C.noReturnedValue), t === !1 ? t : t !== i ? e.extend(!0, {}, t) : e.extend(!0, {}, v)
                    },
                    urlEncodedValue: function(e) {
                        var n = t.decodeURIComponent(e),
                            i = t.encodeURIComponent(e),
                            o = n !== e;
                        return o ? (h.debug("URL value is already encoded, avoiding double encoding", e), e) : (h.verbose("Encoding value using encodeURIComponent", e, i), i)
                    },
                    defaultData: function() {
                        var t = {};
                        return e.isWindow(E) || (h.is.input() ? t.value = T.val() : h.is.form() || (t.text = T.text())), t
                    },
                    event: function() {
                        return e.isWindow(E) || "now" == v.on ? (h.debug("API called without element, no events attached"), !1) : "auto" == v.on ? T.is("input") ? E.oninput !== i ? "input" : E.onpropertychange !== i ? "propertychange" : "keyup" : T.is("form") ? "submit" : "click" : v.on
                    },
                    templatedURL: function(e) {
                        if (e) {
                            if (h.debug("Looking up url for action", e, v.api), v.api[e] === i && !h.is.mocked()) return void h.error(C.missingAction, v.action, v.api);
                            m = v.api[e]
                        } else h.is.form() && (m = T.attr("action") || R.attr("action") || !1, h.debug("No url or action specified, defaulting to form action", m));
                        return m
                    }
                },
                abort: function() {
                    var e = h.get.xhr();
                    e && "resolved" !== e.state() && (h.debug("Cancelling API request"), e.abort())
                },
                reset: function() {
                    h.remove.error(), h.remove.loading()
                },
                setting: function(t, n) {
                    if (h.debug("Changing setting", t, n), e.isPlainObject(t)) e.extend(!0, v, t);
                    else {
                        if (n === i) return v[t];
                        e.isPlainObject(v[t]) ? e.extend(!0, v[t], n) : v[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, h, t);
                    else {
                        if (n === i) return h[t];
                        h[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        v.performance && (t = (new Date).getTime(), i = s || t, n = t - i, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            "Execution Time": n
                        })), clearTimeout(h.performance.timer), h.performance.timer = setTimeout(h.performance.display, 500)
                    },
                    display: function() {
                        var t = v.name + ":",
                            n = 0;
                        s = !1, clearTimeout(h.performance.timer), e.each(l, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, a) {
                    var r, s, l, c = F;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (h.error(C.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(a, n) : s !== i && (l = s), e.isArray(o) ? o.push(l) : o !== i ? o = [o, l] : l !== i && (o = l), s
                }
            }, u ? (F === i && h.initialize(), h.invoke(c)) : (F !== i && F.invoke("destroy"), h.initialize())
        name: "API",
        namespace: "api",
        debug: !1,
        verbose: !1,
        performance: !0,
        api: {},
        cache: !0,
        interruptRequests: !0,
        on: "auto",
        stateContext: !1,
        loadingDuration: 0,
        hideError: "auto",
        errorDuration: 2e3,
        encodeParameters: !0,
        action: !1,
        url: !1,
        base: "",
        urlData: {},
        defaultData: !0,
        serializeForm: !1,
        throttle: 0,
        throttleFirstRequest: !0,
        method: "get",
        data: {},
        dataType: "json",
        mockResponse: !1,
        mockResponseAsync: !1,
        response: !1,
        responseAsync: !1,
        beforeSend: function(e) {
            return e
        },
        beforeXHR: function(e) {},
        onRequest: function(e, t) {},
        onResponse: !1,
        onSuccess: function(e, t) {},
        onComplete: function(e, t) {},
        onFailure: function(e, t) {},
        onError: function(e, t) {},
        onAbort: function(e, t) {},
        successTest: !1,
        error: {
            beforeSend: "The before send function has aborted the request",
            error: "There was an error with your request",
            exitConditions: "API Request Aborted. Exit conditions met",
            JSONParse: "JSON could not be parsed during error handling",
            legacyParameters: "You are using legacy API success callback names",
            method: "The method you called is not defined",
            missingAction: "API action used but no url was defined",
            missingSerialize: "jquery-serialize-object is required to add form data to an existing data object",
            missingURL: "No URL specified for api event",
            noReturnedValue: "The beforeSend callback must return a settings object, beforeSend ignored.",
            noStorage: "Caching responses locally requires session storage",
            parseError: "There was an error parsing your request",
            requiredParameter: "Missing a required URL parameter: ",
            statusMessage: "Server gave an error: ",
            timeout: "Your request timed out"
        },
        regExp: {
            required: /\{\$*[A-z0-9]+\}/g,
            optional: /\{\/\$*[A-z0-9]+\}/g
        },
        className: {
            loading: "loading",
            error: "error"
        },
        selector: {
            disabled: ".disabled",
            form: "form"
        },
        metadata: {
            action: "action",
            url: "url"
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var o, a = e(this),
            r = a.selector || "",
            s = ("ontouchstart" in n.documentElement, (new Date).getTime()),
            l = [],
            c = arguments[0],
            u = "string" == typeof c,
            d = [].slice.call(arguments, 1);
        return a.each(function() {
            var n, f = e.isPlainObject(t) ? e.extend(!0, {}, e.fn.state.settings, t) : e.extend({}, e.fn.state.settings),
                m = f.error,
                g = f.metadata,
                p = f.className,
                h = f.namespace,
                v = f.states,
                b = f.text,
                y = "." + h,
                x = h + "-module",
                C = e(this),
                k = C.data(x);
            n = {
                initialize: function() {
                    n.verbose("Initializing module"), f.automatic && n.add.defaults(), f.context && "" !== r ? e(f.context).on(r, "mouseenter" + y, n.change.text).on(r, "mouseleave" + y, n.reset.text).on(r, "click" + y, n.toggle.state) : C.on("mouseenter" + y, n.change.text).on("mouseleave" + y, n.reset.text).on("click" + y, n.toggle.state), n.instantiate()
                },
                instantiate: function() {
                    n.verbose("Storing instance of module", n), k = n, C.data(x, n)
                },
                destroy: function() {
                    n.verbose("Destroying previous module", k), C.off(y).removeData(x)
                },
                refresh: function() {
                    n.verbose("Refreshing selector cache"), C = e(w)
                },
                add: {
                    defaults: function() {
                        var o = t && e.isPlainObject(t.states) ? t.states : {};
                        e.each(f.defaults, function(t, a) {
                            n.is[t] !== i && n.is[t]() && (n.verbose("Adding default states", t, w), e.extend(f.states, a, o))
                        })
                    }
                },
                is: {
                    active: function() {
                        return C.hasClass(p.active)
                    },
                    loading: function() {
                        return C.hasClass(p.loading)
                    },
                    inactive: function() {
                        return !C.hasClass(p.active)
                    },
                    state: function(e) {
                        return p[e] === i ? !1 : C.hasClass(p[e])
                    },
                    enabled: function() {
                        return !C.is(f.filter.active)
                    },
                    disabled: function() {
                        return C.is(f.filter.active)
                    },
                    textEnabled: function() {
                        return !C.is(f.filter.text)
                    },
                    button: function() {
                        return C.is(".button:not(a, .submit)")
                    },
                    input: function() {
                        return C.is("input")
                    },
                    progress: function() {
                        return C.is(".ui.progress")
                    }
                },
                allow: function(e) {
                    n.debug("Now allowing state", e), v[e] = !0
                },
                disallow: function(e) {
                    n.debug("No longer allowing", e), v[e] = !1
                },
                allows: function(e) {
                    return v[e] || !1
                },
                enable: function() {
                    C.removeClass(p.disabled)
                },
                disable: function() {
                    C.addClass(p.disabled)
                },
                setState: function(e) {
                    n.allows(e) && C.addClass(p[e])
                },
                removeState: function(e) {
                    n.allows(e) && C.removeClass(p[e])
                },
                toggle: {
                    state: function() {
                        var t, o;
                        if (n.allows("active") && n.is.enabled()) {
                            if (n.refresh(), e.fn.api !== i)
                                if (t = C.api("get request"), o = C.api("was cancelled")) n.debug("API Request cancelled by beforesend"), f.activateTest = function() {
                                    return !1
                                }, f.deactivateTest = function() {
                                    return !1
                                };
                                else if (t) return void n.listenTo(t);
                            n.change.state()
                        }
                    }
                },
                listenTo: function(t) {
                    n.debug("API request detected, waiting for state signal", t), t && (b.loading && n.update.text(b.loading), e.when(t).then(function() {
                        "resolved" == t.state() ? (n.debug("API request succeeded"), f.activateTest = function() {
                            return !0
                        }, f.deactivateTest = function() {
                            return !0
                        }) : (n.debug("API request failed"), f.activateTest = function() {
                            return !1
                        }, f.deactivateTest = function() {
                            return !1
                        }), n.change.state()
                    }))
                },
                change: {
                    state: function() {
                        n.debug("Determining state change direction"), n.is.inactive() ? n.activate() : n.deactivate(), f.sync && n.sync(), f.onChange.call(w)
                    },
                    text: function() {
                        n.is.textEnabled() && (n.is.disabled() ? (n.verbose("Changing text to disabled text", b.hover), n.update.text(b.disabled)) : n.is.active() ? b.hover ? (n.verbose("Changing text to hover text", b.hover), n.update.text(b.hover)) : b.deactivate && (n.verbose("Changing text to deactivating text", b.deactivate), n.update.text(b.deactivate)) : b.hover ? (n.verbose("Changing text to hover text", b.hover), n.update.text(b.hover)) : b.activate && (n.verbose("Changing text to activating text", b.activate), n.update.text(b.activate)))
                    }
                },
                activate: function() {
                    f.activateTest.call(w) && (n.debug("Setting state to active"), C.addClass(p.active), n.update.text(b.active), f.onActivate.call(w));
                },
                deactivate: function() {
                    f.deactivateTest.call(w) && (n.debug("Setting state to inactive"), C.removeClass(p.active), n.update.text(b.inactive), f.onDeactivate.call(w))
                },
                sync: function() {
                    n.verbose("Syncing other buttons to current state"), n.is.active() ? a.not(C).state("activate") : a.not(C).state("deactivate")
                },
                get: {
                    text: function() {
                        return f.selector.text ? C.find(f.selector.text).text() : C.html()
                    },
                    textFor: function(e) {
                        return b[e] || !1
                    }
                },
                flash: {
                    text: function(e, t, i) {
                        var o = n.get.text();
                            n.update.text(o), i.call(w)
                        }, t)
                    }
                },
                reset: {
                    text: function() {
                        var e = b.active || C.data(g.storedText),
                            t = b.inactive || C.data(g.storedText);
                        n.is.textEnabled() && (n.is.active() && e ? (n.verbose("Resetting active text", e), n.update.text(e)) : t && (n.verbose("Resetting inactive text", e), n.update.text(t)))
                    }
                },
                update: {
                    text: function(e) {
                        var t = n.get.text();
                        e && e !== t ? (n.debug("Updating text", e), f.selector.text ? C.data(g.storedText, e).find(f.selector.text).text(e) : C.data(g.storedText, e).html(e)) : n.debug("Text is already set, ignoring update", e)
                    }
                },
                setting: function(t, o) {
                    if (n.debug("Changing setting", t, o), e.isPlainObject(t)) e.extend(!0, f, t);
                    else {
                        if (o === i) return f[t];
                        e.isPlainObject(f[t]) ? e.extend(!0, f[t], o) : f[t] = o
                    }
                },
                internal: function(t, o) {
                    if (e.isPlainObject(t)) e.extend(!0, n, t);
                    else {
                        if (o === i) return n[t];
                        n[t] = o
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, i, o;
                        f.performance && (t = (new Date).getTime(), o = s || t, i = t - o, s = t, l.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: w,
                            "Execution Time": i
                        })), clearTimeout(n.performance.timer), n.performance.timer = setTimeout(n.performance.display, 500)
                    },
                    display: function() {
                        var t = f.name + ":",
                            o = 0;
                        s = !1, clearTimeout(n.performance.timer), e.each(l, function(e, t) {
                            o += t["Execution Time"]
                    }
                },
                invoke: function(t, a, r) {
                    var s, l, c, u = k;
                        var r = o != s ? a + t[o + 1].charAt(0).toUpperCase() + t[o + 1].slice(1) : t;
                        if (e.isPlainObject(u[r]) && o != s) u = u[r];
                        else {
                            if (u[r] !== i) return l = u[r], !1;
                            if (!e.isPlainObject(u[a]) || o == s) return u[a] !== i ? (l = u[a], !1) : (n.error(m.method, t), !1);
                            u = u[a]
                        }
                    })), e.isFunction(l) ? c = l.apply(r, a) : l !== i && (c = l), e.isArray(o) ? o.push(c) : o !== i ? o = [o, c] : c !== i && (o = c), l
                }
            }, u ? (k === i && n.initialize(), n.invoke(c)) : (k !== i && k.invoke("destroy"), n.initialize())
        name: "State",
        debug: !1,
        verbose: !1,
        namespace: "state",
        performance: !0,
        onActivate: function() {},
        onDeactivate: function() {},
        onChange: function() {},
        activateTest: function() {
            return !0
        },
        deactivateTest: function() {
            return !0
        },
        automatic: !0,
        sync: !1,
        flashDuration: 1e3,
        filter: {
            text: ".loading, .disabled",
            active: ".disabled"
        },
        context: !1,
        error: {
            beforeSend: "The before send function has cancelled state change",
            method: "The method you called is not defined."
        },
        metadata: {
            promise: "promise",
            storedText: "stored-text"
        },
        className: {
            active: "active",
            disabled: "disabled",
            error: "error",
            loading: "loading",
            success: "success",
            warning: "warning"
        },
        selector: {
            text: !1
        },
        defaults: {
            input: {
                disabled: !0,
                loading: !0,
                active: !0
            },
            button: {
                disabled: !0,
                loading: !0,
                active: !0
            },
            progress: {
                active: !0,
                success: !0,
                warning: !0,
                error: !0
            }
        },
        states: {
            active: !0,
            disabled: !0,
            error: !0,
            loading: !0,
            success: !0,
            warning: !0
        },
        text: {
            disabled: !1,
            flash: !1,
            hover: !1,
            active: !1,
            inactive: !1,
            activate: !1,
            deactivate: !1
        }
    }
}(jQuery, window, document),
function(e, t, n, i) {
    "use strict";
        var a, r = e(this),
            s = r.selector || "",
            l = (new Date).getTime(),
            c = [],
            u = arguments[0],
            d = "string" == typeof u,
            f = [].slice.call(arguments, 1),
            m = r.length,
            g = 0;
        return r.each(function() {
            var r, p, h, v, b = e.isPlainObject(o) ? e.extend(!0, {}, e.fn.visibility.settings, o) : e.extend({}, e.fn.visibility.settings),
                y = b.className,
                x = b.namespace,
                C = b.error,
                w = b.metadata,
                k = "." + x,
                S = "module-" + x,
                T = e(t),
                A = e(this),
                R = e(b.context),
                E = (A.selector || "", A.data(S)),
                P = t.requestAnimationFrame || t.mozRequestAnimationFrame || t.webkitRequestAnimationFrame || t.msRequestAnimationFrame || function(e) {
                    setTimeout(e, 0)
                },
                O = !1;
            v = {
                initialize: function() {
                    v.debug("Initializing", b), v.setup.cache(), v.should.trackChanges() && ("image" == b.type && v.setup.image(), "fixed" == b.type && v.setup.fixed(), b.observeChanges && v.observeChanges(), v.bind.events()), v.save.position(), v.is.visible() || v.error(C.visible, A), b.initialCheck && v.checkVisibility(), v.instantiate()
                },
                instantiate: function() {
                    v.debug("Storing instance", v), A.data(S, v), E = v
                },
                destroy: function() {
                    v.verbose("Destroying previous module"), h && h.disconnect(), p && p.disconnect(), T.off("load" + k, v.event.load).off("resize" + k, v.event.resize), R.off("scroll" + k, v.event.scroll).off("scrollchange" + k, v.event.scrollchange), "fixed" == b.type && (v.resetFixed(), v.remove.placeholder()), A.off(k).removeData(S)
                },
                observeChanges: function() {
                        childList: !0,
                        subtree: !0
                    }), h.observe(F, {
                        childList: !0,
                        subtree: !0
                    }), v.debug("Setting up mutation observer", h))
                },
                bind: {
                    events: function() {
                        v.verbose("Binding visibility events to scroll and resize"), b.refreshOnLoad && T.on("load" + k, v.event.load), T.on("resize" + k, v.event.resize), R.off("scroll" + k).on("scroll" + k, v.event.scroll).on("scrollchange" + k, v.event.scrollchange)
                    }
                },
                event: {
                    changed: function(e) {
                        v.verbose("DOM tree modified, updating visibility calculations"), v.timer = setTimeout(function() {
                            v.verbose("DOM tree modified, updating sticky menu"), v.refresh()
                        }, 100)
                    },
                    contextChanged: function(t) {
                        [].forEach.call(t, function(t) {
                            t.removedNodes && [].forEach.call(t.removedNodes, function(t) {
                                (t == F || e(t).find(F).length > 0) && (v.debug("Element removed from DOM, tearing down events"), v.destroy())
                            })
                        })
                    },
                    resize: function() {
                        v.debug("Window resized"), b.refreshOnResize && P(v.refresh)
                    },
                    load: function() {
                        v.debug("Page finished loading"), P(v.refresh)
                    },
                    scroll: function() {
                        b.throttle ? (clearTimeout(v.timer), v.timer = setTimeout(function() {
                            R.triggerHandler("scrollchange" + k, [R.scrollTop()])
                        }, b.throttle)) : P(function() {
                            R.triggerHandler("scrollchange" + k, [R.scrollTop()])
                        })
                    },
                    scrollchange: function(e, t) {
                        v.checkVisibility(t)
                    }
                },
                precache: function(t, i) {
                    for (var o = t.length, a = 0, r = [], s = n.createElement("img"), l = function() {
                            a++, a >= t.length && e.isFunction(i) && i()
                        }; o--;) s = n.createElement("img"), s.onload = l, s.onerror = l, s.src = t[o], r.push(s)
                },
                enableCallbacks: function() {
                    v.debug("Allowing callbacks to occur"), O = !1
                },
                disableCallbacks: function() {
                    v.debug("Disabling all callbacks temporarily"), O = !0
                },
                should: {
                    trackChanges: function() {
                        return d ? (v.debug("One time query, no need to bind events"), !1) : (v.debug("Callbacks being attached"), !0)
                    }
                },
                setup: {
                    cache: function() {
                        v.cache = {
                            occurred: {},
                            screen: {},
                            element: {}
                        }
                    },
                    image: function() {
                        var e = A.data(w.src);
                        e && (v.verbose("Lazy loading image", e), b.once = !0, b.observeChanges = !1, b.onOnScreen = function() {
                            v.debug("Image on screen", F), v.precache(e, function() {
                                v.set.image(e, function() {
                                    g++, g == m && b.onAllLoaded.call(this), b.onLoad.call(this)
                                })
                            })
                        })
                    },
                    fixed: function() {
                        v.debug("Setting up fixed"), b.once = !1, b.observeChanges = !1, b.initialCheck = !0, b.refreshOnLoad = !0, o.transition || (b.transition = !1), v.create.placeholder(), v.debug("Added placeholder", r), b.onTopPassed = function() {
                            v.debug("Element passed, adding fixed position", A), v.show.placeholder(), v.set.fixed(), b.transition && e.fn.transition !== i && A.transition(b.transition, b.duration)
                        }, b.onTopPassedReverse = function() {
                            v.debug("Element returned to position, removing fixed", A), v.hide.placeholder(), v.remove.fixed()
                        }
                    }
                },
                create: {
                    placeholder: function() {
                        v.verbose("Creating fixed position placeholder"), r = A.clone(!1).css("display", "none").addClass(y.placeholder).insertAfter(A)
                    }
                },
                show: {
                    placeholder: function() {
                        v.verbose("Showing placeholder"), r.css("display", "block").css("visibility", "hidden")
                    }
                },
                hide: {
                    placeholder: function() {
                        v.verbose("Hiding placeholder"), r.css("display", "none").css("visibility", "")
                    }
                },
                set: {
                    fixed: function() {
                        v.verbose("Setting element to fixed position"), A.addClass(y.fixed).css({
                            position: "fixed",
                            top: b.offset + "px",
                            left: "auto",
                            zIndex: b.zIndex
                        }), b.onFixed.call(F)
                    },
                    image: function(t, n) {
                        A.attr("src", t), b.transition ? e.fn.transition !== i ? A.transition(b.transition, b.duration, n) : A.fadeIn(b.duration, n) : A.show()
                    }
                },
                is: {
                    onScreen: function() {
                        var e = v.get.elementCalculations();
                        return e.onScreen
                    },
                    offScreen: function() {
                        var e = v.get.elementCalculations();
                        return e.offScreen
                    },
                    visible: function() {
                        return v.cache && v.cache.element ? !(0 === v.cache.element.width && 0 === v.cache.element.offset.top) : !1
                    }
                },
                refresh: function() {
                    v.debug("Refreshing constants (width/height)"), "fixed" == b.type && v.resetFixed(), v.reset(), v.save.position(), b.checkOnRefresh && v.checkVisibility(), b.onRefresh.call(F)
                },
                resetFixed: function() {
                    v.remove.fixed(), v.remove.occurred()
                },
                reset: function() {
                    v.verbose("Resetting all cached values"), e.isPlainObject(v.cache) && (v.cache.screen = {}, v.cache.element = {})
                },
                checkVisibility: function(e) {
                    v.verbose("Checking visibility of element", v.cache.element), !O && v.is.visible() && (v.save.scroll(e), v.save.calculations(), v.passed(), v.passingReverse(), v.topVisibleReverse(), v.bottomVisibleReverse(), v.topPassedReverse(), v.bottomPassedReverse(), v.onScreen(), v.offScreen(), v.passing(), v.topVisible(), v.bottomVisible(), v.topPassed(), v.bottomPassed(), b.onUpdate && b.onUpdate.call(F, v.get.elementCalculations()))
                },
                passed: function(t, n) {
                    var o = v.get.elementCalculations();
                    if (t && n) b.onPassed[t] = n;
                    else {
                        if (t !== i) return v.get.pixelsPassed(t) > o.pixelsPassed;
                        o.passing && e.each(b.onPassed, function(e, t) {
                            o.bottomVisible || o.pixelsPassed > v.get.pixelsPassed(e) ? v.execute(t, e) : b.once || v.remove.occurred(t)
                        })
                    }
                },
                onScreen: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onOnScreen,
                        o = "onScreen";
                    return e && (v.debug("Adding callback for onScreen", e), b.onOnScreen = e), t.onScreen ? v.execute(n, o) : b.once || v.remove.occurred(o), e !== i ? t.onOnScreen : void 0
                },
                offScreen: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onOffScreen,
                        o = "offScreen";
                    return e && (v.debug("Adding callback for offScreen", e), b.onOffScreen = e), t.offScreen ? v.execute(n, o) : b.once || v.remove.occurred(o), e !== i ? t.onOffScreen : void 0
                },
                passing: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onPassing,
                        o = "passing";
                    return e && (v.debug("Adding callback for passing", e), b.onPassing = e), t.passing ? v.execute(n, o) : b.once || v.remove.occurred(o), e !== i ? t.passing : void 0
                },
                topVisible: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onTopVisible,
                        o = "topVisible";
                    return e && (v.debug("Adding callback for top visible", e), b.onTopVisible = e), t.topVisible ? v.execute(n, o) : b.once || v.remove.occurred(o), e === i ? t.topVisible : void 0
                },
                bottomVisible: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onBottomVisible,
                        o = "bottomVisible";
                    return e && (v.debug("Adding callback for bottom visible", e), b.onBottomVisible = e), t.bottomVisible ? v.execute(n, o) : b.once || v.remove.occurred(o), e === i ? t.bottomVisible : void 0
                },
                topPassed: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onTopPassed,
                        o = "topPassed";
                    return e && (v.debug("Adding callback for top passed", e), b.onTopPassed = e), t.topPassed ? v.execute(n, o) : b.once || v.remove.occurred(o), e === i ? t.topPassed : void 0
                },
                bottomPassed: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onBottomPassed,
                        o = "bottomPassed";
                    return e && (v.debug("Adding callback for bottom passed", e), b.onBottomPassed = e), t.bottomPassed ? v.execute(n, o) : b.once || v.remove.occurred(o), e === i ? t.bottomPassed : void 0
                },
                passingReverse: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onPassingReverse,
                        o = "passingReverse";
                    return e && (v.debug("Adding callback for passing reverse", e), b.onPassingReverse = e), t.passing ? b.once || v.remove.occurred(o) : v.get.occurred("passing") && v.execute(n, o), e !== i ? !t.passing : void 0
                },
                topVisibleReverse: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onTopVisibleReverse,
                        o = "topVisibleReverse";
                    return e && (v.debug("Adding callback for top visible reverse", e), b.onTopVisibleReverse = e), t.topVisible ? b.once || v.remove.occurred(o) : v.get.occurred("topVisible") && v.execute(n, o), e === i ? !t.topVisible : void 0
                },
                bottomVisibleReverse: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onBottomVisibleReverse,
                        o = "bottomVisibleReverse";
                    return e && (v.debug("Adding callback for bottom visible reverse", e), b.onBottomVisibleReverse = e), t.bottomVisible ? b.once || v.remove.occurred(o) : v.get.occurred("bottomVisible") && v.execute(n, o), e === i ? !t.bottomVisible : void 0
                },
                topPassedReverse: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onTopPassedReverse,
                        o = "topPassedReverse";
                    return e && (v.debug("Adding callback for top passed reverse", e), b.onTopPassedReverse = e), t.topPassed ? b.once || v.remove.occurred(o) : v.get.occurred("topPassed") && v.execute(n, o), e === i ? !t.onTopPassed : void 0
                },
                bottomPassedReverse: function(e) {
                    var t = v.get.elementCalculations(),
                        n = e || b.onBottomPassedReverse,
                        o = "bottomPassedReverse";
                    return e && (v.debug("Adding callback for bottom passed reverse", e), b.onBottomPassedReverse = e), t.bottomPassed ? b.once || v.remove.occurred(o) : v.get.occurred("bottomPassed") && v.execute(n, o), e === i ? !t.bottomPassed : void 0
                },
                execute: function(e, t) {
                    var n = v.get.elementCalculations(),
                        i = v.get.screenCalculations();
                },
                remove: {
                    fixed: function() {
                        v.debug("Removing fixed position"), A.removeClass(y.fixed).css({
                            position: "",
                            top: "",
                            left: "",
                            zIndex: ""
                        }), b.onUnfixed.call(F)
                    },
                    placeholder: function() {
                        v.debug("Removing placeholder content"), r && r.remove()
                    },
                    occurred: function(e) {
                        if (e) {
                            var t = v.cache.occurred;
                            t[e] !== i && t[e] === !0 && (v.debug("Callback can now be called again", e), v.cache.occurred[e] = !1)
                        } else v.cache.occurred = {}
                    }
                },
                save: {
                    calculations: function() {
                        v.verbose("Saving all calculations necessary to determine positioning"), v.save.direction(), v.save.screenCalculations(), v.save.elementCalculations()
                    },
                    occurred: function(e) {
                        e && (v.cache.occurred[e] === i || v.cache.occurred[e] !== !0) && (v.verbose("Saving callback occurred", e), v.cache.occurred[e] = !0)
                    },
                    scroll: function(e) {
                    },
                    direction: function() {
                        var e, t = v.get.scroll(),
                            n = v.get.lastScroll();
                        return e = t > n && n ? "down" : n > t && n ? "up" : "static", v.cache.direction = e, v.cache.direction
                    },
                    elementPosition: function() {
                        var e = v.cache.element,
                            t = v.get.screenSize();
                        return v.verbose("Saving element position"), e.fits = e.height < t.height, e.offset = A.offset(), e.width = A.outerWidth(), e.height = A.outerHeight(), v.cache.element = e, e
                    },
                    elementCalculations: function() {
                        var e = v.get.screenCalculations(),
                            t = v.get.elementPosition();
                        return b.includeMargin ? (t.margin = {}, t.margin.top = parseInt(A.css("margin-top"), 10), t.margin.bottom = parseInt(A.css("margin-bottom"), 10), t.top = t.offset.top - t.margin.top, t.bottom = t.offset.top + t.height + t.margin.bottom) : (t.top = t.offset.top, t.bottom = t.offset.top + t.height), t.topVisible = e.bottom >= t.top, t.topPassed = e.top >= t.top, t.bottomVisible = e.bottom >= t.bottom, t.bottomPassed = e.top >= t.bottom, t.pixelsPassed = 0, t.percentagePassed = 0, t.onScreen = t.topVisible && !t.bottomPassed, t.passing = t.topPassed && !t.bottomPassed, t.offScreen = !t.onScreen, t.passing && (t.pixelsPassed = e.top - t.top, t.percentagePassed = (e.top - t.top) / t.height), v.cache.element = t, v.verbose("Updated element calculations", t), t
                    },
                    screenCalculations: function() {
                        var e = v.get.scroll();
                        return v.save.direction(), v.cache.screen.top = e, v.cache.screen.bottom = e + v.cache.screen.height, v.cache.screen
                    },
                    screenSize: function() {
                        v.verbose("Saving window position"), v.cache.screen = {
                            height: R.height()
                        }
                    },
                    position: function() {
                        v.save.screenSize(), v.save.elementPosition()
                    }
                },
                get: {
                    pixelsPassed: function(e) {
                        var t = v.get.elementCalculations();
                        return e.search("%") > -1 ? t.height * (parseInt(e, 10) / 100) : parseInt(e, 10)
                    },
                    occurred: function(e) {
                        return v.cache.occurred !== i ? v.cache.occurred[e] || !1 : !1
                    },
                    direction: function() {
                        return v.cache.direction === i && v.save.direction(), v.cache.direction
                    },
                    elementPosition: function() {
                        return v.cache.element === i && v.save.elementPosition(), v.cache.element
                    },
                    elementCalculations: function() {
                        return v.cache.element === i && v.save.elementCalculations(), v.cache.element
                    },
                    screenCalculations: function() {
                        return v.cache.screen === i && v.save.screenCalculations(), v.cache.screen
                    },
                    screenSize: function() {
                        return v.cache.screen === i && v.save.screenSize(), v.cache.screen
                    },
                    scroll: function() {
                        return v.cache.scroll === i && v.save.scroll(), v.cache.scroll
                    },
                    lastScroll: function() {
                        return v.cache.screen === i ? (v.debug("First scroll event, no last scroll could be found"), !1) : v.cache.screen.top
                    }
                },
                setting: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, b, t);
                    else {
                        if (n === i) return b[t];
                        b[t] = n
                    }
                },
                internal: function(t, n) {
                    if (e.isPlainObject(t)) e.extend(!0, v, t);
                    else {
                        if (n === i) return v[t];
                        v[t] = n
                    }
                },
                debug: function() {
                },
                verbose: function() {
                },
                error: function() {
                },
                performance: {
                    log: function(e) {
                        var t, n, i;
                        b.performance && (t = (new Date).getTime(), i = l || t, n = t - i, l = t, c.push({
                            Name: e[0],
                            Arguments: [].slice.call(e, 1) || "",
                            Element: F,
                            "Execution Time": n
                        })), clearTimeout(v.performance.timer), v.performance.timer = setTimeout(v.performance.display, 500)
                    },
                    display: function() {
                        var t = b.name + ":",
                            n = 0;
                        l = !1, clearTimeout(v.performance.timer), e.each(c, function(e, t) {
                            n += t["Execution Time"]
                    }
                },
                invoke: function(t, n, o) {
                    var r, s, l, c = E;
                        var a = n != r ? o + t[n + 1].charAt(0).toUpperCase() + t[n + 1].slice(1) : t;
                        if (e.isPlainObject(c[a]) && n != r) c = c[a];
                        else {
                            if (c[a] !== i) return s = c[a], !1;
                            if (!e.isPlainObject(c[o]) || n == r) return c[o] !== i ? (s = c[o], !1) : (v.error(C.method, t), !1);
                            c = c[o]
                        }
                    })), e.isFunction(s) ? l = s.apply(o, n) : s !== i && (l = s), e.isArray(a) ? a.push(l) : a !== i ? a = [a, l] : l !== i && (a = l), s
                }
            }, d ? (E === i && v.initialize(), E.save.scroll(), E.save.calculations(), v.invoke(u)) : (E !== i && E.invoke("destroy"), v.initialize())
        name: "Visibility",
        namespace: "visibility",
        debug: !1,
        verbose: !1,
        performance: !0,
        observeChanges: !0,
        initialCheck: !0,
        refreshOnLoad: !0,
        refreshOnResize: !0,
        checkOnRefresh: !0,
        once: !0,
        continuous: !1,
        offset: 0,
        includeMargin: !1,
        context: t,
        throttle: !1,
        type: !1,
        zIndex: "10",
        transition: "fade in",
        duration: 1e3,
        onPassed: {},
        onOnScreen: !1,
        onOffScreen: !1,
        onPassing: !1,
        onTopVisible: !1,
        onBottomVisible: !1,
        onTopPassed: !1,
        onBottomPassed: !1,
        onPassingReverse: !1,
        onTopVisibleReverse: !1,
        onBottomVisibleReverse: !1,
        onTopPassedReverse: !1,
        onBottomPassedReverse: !1,
        onLoad: function() {},
        onAllLoaded: function() {},
        onFixed: function() {},
        onUnfixed: function() {},
        onUpdate: !1,
        onRefresh: function() {},
        metadata: {
            src: "src"
        },
        className: {
            fixed: "fixed",
            placeholder: "placeholder"
        },
        error: {
            method: "The method you called is not defined.",
            visible: "Element is hidden, you must call refresh after element becomes visible"
        }
    }
}(jQuery, window, document);