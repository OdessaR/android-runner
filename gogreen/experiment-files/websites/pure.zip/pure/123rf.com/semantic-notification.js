(function($) {
})(function($) {


    var sanitize = function(str) {
        var lt = /</g;
        var gt = />/g;


        return str;
    };

    var escape = function(str) {
        return str;
    }

    var gen_id = function(type) {
    };

    var Message = function(id, template, options) {

                $Item.id = jQuery(this).closest('.notification-wrapper').attr('id');
                $Item.close();
            });
        }
    }

    Message.defaults = {
        timeout: 3000,
        position: 'center',
        stack: true
    };

    Message.prototype.display = function() {
        var starting_time = new Date();
        var remaining_time = $Item.options.timeout;

        }

        $("#" + $Item.id).fadeIn();

        $Item.timer = setTimeout(function() {
            $Item.close();
        }, remaining_time);

        $("#" + $Item.id).on("mouseenter", function() {
            clearTimeout($Item.timer);
            remaining_time -= new Date() - starting_time;

            // console.log("Remain time on pause "+remaining_time);
        });
        $("#" + $Item.id).on("mouseleave", function() {
            starting_time = new Date();
            clearTimeout($Item.timer);
            $Item.timer = setTimeout(function() {
                $Item.close();
            }, remaining_time);

            // console.log("Remain time on resume "+remaining_time);
        });

    };

    Message.prototype.close = function() {

        $("#" + $Item.id).fadeOut();
        setTimeout(function() {
            $("#" + $Item.id).remove();
        }, 500);
    };

        var id = gen_id("success");

        var success_template =
            '<div class="notification-wrapper" id="' + id + '">' +
            '<table>' +
            '<tr>' +
            '<td class="notification-icon success">' +
            '<img src="/assets/images/icon-success.png" width="24">' +
            '</td>' +
            '<td>' +
            '<div class="notification-message">' +
            escape(sanitize(message)) +
            '</div>' +
            '</td>' +
            '<td class="notification-close">' +
            '<i class="link icon close"></i>' +
            '</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

        return (new Message(id, success_template, options)).display();
    }

        var id = gen_id("reminder");
        var reminder_template =
            '<div class="notification-wrapper" id="' + id + '">' +
            '<table>' +
            '<tr>' +
            '<td class="notification-icon reminder">' +
            '<img src="/assets/images/icon-reminder.png" width="24">' +
            '</td>' +
            '<td>' +
            '<div class="notification-message">' +
            escape(sanitize(message)) +
            '</div>' +
            '</td>' +
            '<td class="notification-close">' +
            '<i class="link icon close"></i>' +
            '</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

        return (new Message(id, reminder_template, options)).display();
    }

        var id = gen_id("error");
        var error_template =
            '<div class="notification-wrapper" id="' + id + '">' +
            '<table>' +
            '<tr>' +
            '<td class="notification-icon error">' +
            '<img src="/assets/images/icon-error.png" width="24">' +
            '</td>' +
            '<td>' +
            '<div class="notification-message">' +
            escape(sanitize(message)) +
            '</div>' +
            '</td>' +
            '<td class="notification-close">' +
            '<i class="link icon close"></i>' +
            '</td>' +
            '</tr>' +
            '</table>' +
            '</div>';

        return (new Message(id, error_template, options)).display();
    }

});

if (window.location.hash) {
    var gethash = window.location.hash;
    // console.log(gethash);
    if (gethash.indexOf("notify_success=") !== -1 || gethash.indexOf("notify_reminder=") !== -1 || gethash.indexOf("notify_error=") !== -1) {

        if (gethash.indexOf("notify_success=") !== -1) {
            var show_msg = decodeURI(gethash.split('notify_success=')[1]);
            SemanticNotify.notify_success(show_msg);
        } else if (gethash.indexOf("notify_reminder=") !== -1) {
            var show_msg = decodeURI(gethash.split('notify_reminder=')[1]);
            SemanticNotify.notify_reminder(show_msg);
        } else if (gethash.indexOf("notify_error=") !== -1) {
            var show_msg = decodeURI(gethash.split('notify_error=')[1]);
            SemanticNotify.notify_error(show_msg);
        }
        document.location.hash = "";

    }
}