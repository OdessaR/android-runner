	function popVideoFootage() {
	    var url = "/123rf-popup-video.php";
	        contentType: 'text/html',
	        onComplete: function(transport) {
	            $('testReg2').innerHTML = transport.responseText;
	            $('testReg2').setStyle({
	                width: '690px',
	                margin: '0 auto'
	            });
	            $('testReg').setStyle({
	                position: 'fixed',
	                opacity: '0.6',
	                zIndex: '5060',
	                margin: '0 auto',
	                top: '0',
	                left: '0',
	                textAlign: 'center',
	                paddingTop: '15%',
	                background: '#000',
	                color: '#fff',
	                display: 'block'
	            });
	            $('adRegForm').setStyle({
	                position: 'fixed',
	                opacity: '1',
	                filter: 'alpha(opacity: 100)',
	                KHTMLOpacity: '1',
	                MozOpacity: '1',
	                opacity: '1',
	                width: '650px',
	                height: '370px',
	                textAlign: 'center',
	                display: 'block',
	                top: '30%',
	                zIndex: '5065',
	                border: '5px solid #aaa',
	                color: 'gray',
	                background: '#fff',
	                padding: '5px 0 0 0',
	                display: 'block'
	            });


	        }
	    });
	}
	Event.observe(window, 'resize', function() {
	    $('testReg').setStyle({
	    });
	});

	function closeTestReg(url) {
	    $('testReg').setStyle({
	        display: 'none'
	    });
	    $('adRegForm').setStyle({
	        display: 'none'
	    });
	    $('testReg').innerHTML = "";
	    $('testReg2').innerHTML = "";
	}