! function() {
    var c = "",
        e = new Date(20020101),
        l = (new Date).getMilliseconds(),
        s = e.getTimezoneOffset(),
        p = 1,
        f = 2,
        d = "",
        m = "",
        o = "/visitor/v200/svrGP",
        a = "eloqua.com",
        I = "",
        q = "";

    function v(e) {
        return null == e || "" === e
    }

    function h(e) {
    }

    function i(e, t) {
        if (!v(I) && !v(c)) {
            var n = I + "?pps=50&siteid=" + c + "&DLKey=" + encodeURIComponent(e) + "&DLLookup=" + encodeURIComponent(t) + "&ms=" + l + q;
            v(d) || (n += "&elqGUID=" + d);
        }
    }

    function k() {
        if (!v(I) && !v(c)) {
            var e = I + "?pps=70&siteid=" + c + "&ms=" + l + q;
            v(d) || (e += "&elqGUID=" + d);
        }
    }

    function y(e, t, n) {
        var r = "";
        if (!v(I) && !v(c)) {
            if ("" != q) {
                var o = w("OPTIN");
                if (null != o) {
                    if ("0" == o) return;
                    "1" == o && (r += "&isOptedIn=1")
                }
            }
            t = h(t), v(n) || (n === f ? r += "&optin=country" : n === p ? r += "&optin=all" : n === u && (r += "&optin=disabled"));
            if (v(e)) {
            } else {
                var i = I + "?pps=3&siteid=" + c + "&ref=" + encodeURIComponent(e) + "&ref2=" + t + "&tzo=" + s + "&ms=" + l + r + q;
                v(d) || (i += "&elqGUID=" + d), i += V(m), a.src = i
            }
        }
    }

    function C(e, t) {
        y(e, t, u)
    }

    function U(e, t) {
        y(e, t, f)
    }

    function O(e, t) {
        y(e, t, p)
    }

    function g(e) {
        if (!v(I) && !v(c) && !v(e)) {
            if (40 == e && "" != q) {
                var t = w("OPTIN");
                if (null != t) {
                    if ("0" == t) return r("function elqGetOptOutStatus(){ return 0; }");
                    if ("1" == t) return r("function elqGetOptOutStatus(){ return 1; }")
                }
            }
            if (43 != e && 44 != e || "" == q) {
            }
        }
    }

    function r(e) {
    }

    function n(e, t, n) {
    }

    function b(e, t, n) {
        if (!v(I) && !v(c)) {
            var r = w("OPTIN");
            if (null != r) {
                if ("0" == r) return;
                "1" == r && y(t, n, e)
            } else N() ? (R("ELQSITEVISITED", "YES"), e == f ? E(e, t, n) : elqCreateOptInBanner()) : e == f && y(t, n, e)
        }
    }

    function E(e, t, n) {
        var r = I + "?pps=45&siteid=" + c + q;
        v(t) || (r += "&ref=" + encodeURIComponent(t)), r += "&ref2=" + n + "&tzo=" + s + "&ms=" + l, r += e == f ? "&optin=country" : "&optin=all", v(d) || (r += "&elqGUID=" + d);
    }

    function T(e, t) {
    }

    function D(e, t) {
    }

    function R(e, t) {
    }

    function S(e, t) {
        if ("" == e) return null;
        var n = e.indexOf("=");
        if (0 < n && e.substr(0, n).trim() == t) return e.substr(n + 1);
        return null
    }

    function w(e) {
        return null
    }

    function G(e, t) {
        var n = w(e);
        if (null != n)
            for (var r = n.split("&"), o = 0; o < r.length; o++)
                if (null != (n = S(r[o], t))) return n;
        return null
    }

    function N() {
        var e = w("ELQSITEVISITED");
        return null == e || "YES" != e
    }

    function V(e) {
        var t = "";
        return v(e) || (t += "&bkuuidSwapTime=" + encodeURIComponent(e)), t
    }
    var B = t._elqQ;

    function P(e, t, n) {
        if (!v(I) && !v(c) && !v(e)) {
            var r = I + "?pps=17&siteid=" + c + "&elq=" + encodeURIComponent(t || "") + "&ref=" + encodeURIComponent(e) + "&ref2=" + n + "&ms=" + l;
        }
    }
    t._elqQ = new function() {
            for (var e = 0; e < arguments.length; e++) try {
                if ("function" == typeof arguments[e]) arguments[e]();
                else switch (arguments[e][0]) {
                    case "elqSetRootDomain":
                        var t;
                        a = encodeURIComponent(arguments[e][1]), null == arguments[e][2] || (r = arguments[e][2], isNaN(r) || parseInt(Number(r)) != r || isNaN(parseInt(r, 10))) || (t = arguments[e][2], a = a + ":" + t), I = "https://s" + c + ".t." + a + o;
                        break;
                    case "elqSetSiteId":
                        c = encodeURIComponent(arguments[e][1]), I = "https://s" + c + ".t." + a + o;
                        break;
                    case "elqTrackPageView":
                        break;
                    case "elqVisitorGuid":
                        d = encodeURIComponent(arguments[e][1]);
                        break;
                    case "elqTrackPageViewOptinByCountry":
                        break;
                    case "elqTrackPageViewOptinAll":
                        break;
                    case "elqTrackPageViewDisplayOptInBannerByCountry":
                        break;
                    case "elqTrackPageViewDisplayOptInBannerForAll":
                        break;
                    case "elqDataLookup":
                        break;
                    case "elqGetCustomerGUID":
                        break;
                    case "elqOptStatus":
                        g(40);
                        break;
                    case "elqOptIn":
                        g(41);
                        break;
                    case "elqOptOut":
                        g(42);
                        break;
                    case "elqGlobalOptIn":
                        g(43);
                        break;
                    case "elqGlobalOptOut":
                        g(44);
                        break;
                    case "elqUseFirstPartyCookie":
                        q = "&firstPartyCookieDomain=" + encodeURIComponent(arguments[e][1]);
                        var n = G("ELOQUA", "GUID");
                        null != n && (d = encodeURIComponent(n)), m = w("BKUT")
                }
            } catch (e) {}
            var r
        }
    }, t._elqQ.push.apply(t._elqQ, B), t._elq = {
        trackEvent: function(e, t, n) {
            P(e, t, n)
        },
        trackOutboundLink: function(e, t, n) {
            P(e.href, t, n);
            var r, o = function(e) {
                    try {
                        return "string" == typeof e && decodeURI(e) !== e
                    } catch (e) {
                        return
                    }
                }(e.href) ? e.href : encodeURI(e.href),
                a = e.getAttribute("target");
            r = v(a) ? 'document.location = "' + o + '"' : 'window.open("' + o + '", "' + encodeURIComponent(a) + '")', setTimeout(r, 1e3)
        }
    }
}();