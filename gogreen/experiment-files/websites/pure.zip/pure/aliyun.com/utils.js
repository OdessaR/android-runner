define({
    isMobile: {
        Android: function() {
        },
        BlackBerry: function() {
        },
        iOS: function() {
        },
        Opera: function() {
        },
        Windows: function() {
        },
        any: function() {
        }
    }
});