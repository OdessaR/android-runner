if (!window.criteo_q || window.criteo_q instanceof Array) {
    var oldQueue = window.criteo_q || [];
    window.criteo_q = function() {
        var a = {
                bodyReady: !1,
                domReady: !1,
                queue: [],
                actions: [],
                disingScheduled: [],
                accounts: [],
                acid: null,
                axid: null,
                ccp: null
            },
            b = {
                tagVersion: "4.0.0",
                handlerResponseType: "single",
                responseType: "js",
                handlerParams: {
                    v: "4.0.0"
                },
                extraData: [],
                customerInfo: [],
                manualDising: !1,
                manualFlush: !1,
                disOnce: !1,
                partialDis: !1,
                eventMap: {
                    applaunched: "al",
                    viewitem: "vp",
                    viewhome: "vh",
                    viewlist: "vl",
                    viewbasket: "vb",
                    viewsearch: "vs",
                    tracktransaction: "vc",
                    calldising: "dis",
                    setdata: "exd",
                    setemail: "ce"
                },
                propMap: {
                    event: "e",
                    account: "a",
                    currency: "c",
                    product: "p",
                    item: "p",
                    "item.id": "i",
                    "item.price": "pr",
                    "item.quantity": "q",
                    "product.id": "i",
                    "product.price": "pr",
                    "product.quantity": "q",
                    data: "d",
                    keywords: "kw",
                    checkin_date: "din",
                    checkout_date: "dout",
                    deduplication: "dd",
                    attribution: "at",
                    "attribution.channel": "ac",
                    "attribution.value": "v",
                    user_segment: "si",
                    new_customer: "nc",
                    customer_id: "ci",
                    email: "m",
                    hash_method: "h",
                    transaction_value: "tv",
                    responseType: "rt"
                },
                setters: {
                    seturl: {
                        cfg: "handlerUrlPrefix",
                        evt: "url"
                    },
                    setaccount: {
                        cfg: "account",
                        evt: "account"
                    },
                    setcalltype: {
                        cfg: "handlerResponseType",
                        evt: "type"
                    },
                    setresponsetype: {
                        cfg: "responseType",
                        evt: "type"
                    },
                    oninitialized: {
                        cfg: "onInitialized",
                        evt: "callback"
                    },
                    ondomready: {
                        cfg: "onDOMReady",
                        evt: "callback"
                    },
                    beforeappend: {
                        cfg: "beforeAppend",
                        evt: "callback"
                    },
                    aftereval: {
                        cfg: "afterEval",
                        evt: "callback"
                    },
                    onflush: {
                        cfg: "onFlush",
                        evt: "callback"
                    }
                },
                flags: {
                    disonce: "disOnce",
                    manualdising: "manualDising",
                    manualflush: "manualFlush",
                    nopartialflush: "noPartialFlush",
                    disonpartialflush: "partialDis"
                }
            },
            c = function(a) {
                var b;
            };
        ! function(a) {
            var b = c("criteo_acid"),
                d = c("cto_axid"),
                e = c("cto_optout");
        }(a),
        function(a) {
            var b = c("criteo_cookie_perm");
            null !== b && (a.ccp = b)
        }(a);
        var d = function() {
                for (var b = 0; b < arguments.length; ++b) a.queue.push(arguments[b]);
                e()
            },
            e = function() {
                for (var c = [], d = a.queue, e = 0; e < d.length; ++e) {
                    var h = d[e];
                    if (h instanceof Array) d.splice.apply(d, [e + 1, 0].concat(h));
                    else if (h instanceof Function) d.splice(e + 1, 0, h());
                    else if (h && "[object Object]" === h.toString()) switch (f(h, e, d, c)) {
                        case 0:
                            c.push(h);
                            break;
                        case -1:
                            c = c.concat(d.slice(e)), e = d.length
                    }
                }
                b.afterEval instanceof Function && (c = b.afterEval(d, c, a, b)), a.queue = c || [], !b.manualFlush && (!b.noPartialFlush || 0 === a.queue.length) && g(0 !== a.queue.length)
            },
            f = function(c, d, e, k) {
                if (!a.domReady && c.requiresDOM && "no" !== c.requiresDOM) return "blocking" === c.requiresDOM ? -1 : 0;
                if (delete c.requiresDOM, !c.event) return j(c), 1;
                switch (c.account && n(c.account, a.accounts), c.event = c.event.toLowerCase(), c.event) {
                    case "setdata":
                        return c = j(c), b.extraData.push(c), h(a.actions, j(c)), 1;
                    case "setparameter":
                        for (var l in c) "event" !== l.toLowerCase() && c.hasOwnProperty(l) && (b.handlerParams[l] = c[l]);
                        return 1;
                    case "calldising":
                        c.hasOwnProperty("account") || (c.account = a.accounts), d = b.handlerResponseType, c.hasOwnProperty("type") && (d = c.type, delete c.type), n(c.account, a.disingScheduled), "sequential" === d && (c.dc = !0);
                        break;
                    case "setcustomerid":
                        return c.event = "setdata", c.customer_id = c.id, delete c.id, f(c);
                    case "setemail":
                    case "sethashedemail":
                    case "ceh":
                        return c.event = "setemail", c.hasOwnProperty("email") && c.email && !(c.email instanceof Array) && (c.email = [c.email]), d = j(c), b.customerInfo.push(d), i(a.actions, j(c)), 1;
                    case "setsitetype":
                        return d = "d", "mobile" !== c.type && "m" !== c.type || (d = "m"), "tablet" !== c.type && "t" !== c.type || (d = "t"), c.event = "setdata", delete c.type, c.site_type = d, f(c);
                    case "appendtag":
                            if (b.container || "script" !== c.element.tagName.toLowerCase() && !c.isImgUrl) {
                                if (!b.container) return 0;
                                b.container.appendChild(c.element)
                        return 1;
                    case "gettagstate":
                        return c.callback instanceof Function ? c.callback(a, b) : 1;
                    case "flush":
                    case "flushevents":
                        return g(d !== e.length - 1 || 0 !== k.length), 1
                }
                return (d = b.setters[c.event]) ? (b[d.cfg] = c[d.evt], 1) : (d = b.flags[c.event]) ? (b[d] = !0, 1) : (a.actions.push(j(c)), 1)
            },
            g = function(c) {
                if (b.onFlush instanceof Function && (a.actions = b.onFlush(a.actions, a, b)), 0 !== a.actions.length) {
                    for (var d = 0; d < b.extraData.length; ++d) h(a.actions, b.extraData[d]);
                    for (d = 0; d < b.customerInfo.length; ++d) i(a.actions, b.customerInfo[d]);
                    if (!b.manualDising && (!c || b.partialDis)) {
                        for (c = [], d = 0; d < a.accounts.length; ++d) o(a.disingScheduled, a.accounts[d]) || c.push(a.accounts[d]);
                        0 < c.length && f({
                            event: "callDising",
                            account: c
                        })
                    }
                    if (c = a.actions, d = [], 1 === a.accounts.length && (b.account = a.accounts[0]), b.account && d.push("a=" + m(b.account, [])), "js" !== b.responseType && d.push("rt=" + m(b.responseType, [])), b.handlerParams) {
                        var e = decodeURIComponent(m(b.handlerParams, []));
                        e && d.push(e)
                    }
                    for (e = 0; e < c.length; ++e) c[e].account && l(b.account, c[e].account) && delete c[e].account, d.push("p" + e + "=" + m(c[e], []));
                    null !== a.acid && d.push("acid=" + a.acid), null !== a.axid && d.push("axid=" + a.axid), a.canWriteCookie && d.push("adce=1"), null !== a.ccp && d.push("ccp=" + a.ccp), c = d.join("&"), c = {
                        event: "appendTag",
                        url: b.handlerUrlPrefix + "?" + c,
                        isImgUrl: "gif" === b.responseType
                    }, a.actions = [], f(c), b.disOnce || (a.disingScheduled = [])
                }
            },
            h = function(a, b) {
                for (var c = 0; c < a.length; ++c) {
                    var d = a[c];
                    if (d.event === b.event && l(b.account, d.account)) {
                        for (var e in b) b.hasOwnProperty(e) && "account" !== e && (d[e] = b[e]);
                        return
                    }
                }
                a.push(b)
            },
            i = function(a, b) {
                for (var c = 0; c < a.length; ++c) {
                    var d = a[c];
                    if (d.event === b.event && l(b.account, d.account) && ("hash_method" in b ? b.hash_method : "") === ("hash_method" in d ? d.hash_method : "")) {
                        if (b.hasOwnProperty("email")) {
                            for (var c = d, d = d.email, e = b.email, f = [], g = 0; g < e.length; ++g) o(d, e[g]) || f.push(e[g]);
                            d = d.concat(f), c.email = d
                        }
                        return
                    }
                }
                a.push(b)
            },
            j = function(a) {
                var b = a;
                if (a instanceof Function) return b = a(), b instanceof Function ? b : j(b);
                if (a instanceof Array)
                    for (var b = [], c = 0; c < a.length; ++c) b[c] = j(a[c]);
                else if (a && "[object Object]" === a.toString())
                    for (c in b = {}, a) a.hasOwnProperty(c) && (b[c] = j(a[c]));
                return b
            },
            k = function(a, c) {
                var d = c.join(".");
                return b.propMap[d] ? b.propMap[d] : a
            },
            l = function(a, b) {
                if (!(a instanceof Array)) return l([a], b);
                if (!(b instanceof Array)) return l(a, [b]);
                if (a.length !== b.length) return !1;
                for (var c = 0; c < a.length; ++c)
                    if (!o(b, a[c])) return !1;
                return !0
            },
            m = function(a, c) {
                var d = "";
                if (a instanceof Function) d = m(a(), c);
                else if (a instanceof Array) {
                    for (var e = [], f = 0; f < a.length; ++f) e[f] = m(a[f], c);
                    d += "[" + e.join(",") + "]"
                } else if (a && "[object Object]" === a.toString()) {
                    e = [];
                    for (f in a)
                        if (a.hasOwnProperty(f)) {
                            var g = c.concat([f]);
                            e.push(k(f, g) + "=" + m(a[f], g))
                        } d += e.join("&")
                } else d = 1 === c.length && "event" === c[0] ? d + (b.eventMap[a.toLowerCase()] ? b.eventMap[a.toLowerCase()] : a) : d + a;
                return encodeURIComponent(d)
            },
            n = function(a, b) {
                if (a instanceof Array)
                    for (var c = 0; c < a.length; ++c) n(a[c], b);
                else o(b, a) || b.push(a)
            },
            o = function(a, b) {
                for (var c = 0; c < a.length; ++c)
                    if (a[c] === b) return !0;
                return !1
            },
            p = function(a) {
                if (a) {
                    var b = a.createElement("script");
                    b.setAttribute("type", "text/javascript"), b.setAttribute("src", a.location.protocol + "//static.criteo.net/js/ld/ld-tag-debug.4.0.0.js"), a = a.getElementsByTagName("script")[0], a.parentNode.insertBefore(b, a)
                }
            };
        ! function(a) {
            ! function b() {
            }()
        }(function() {
            a.bodyReady = !(b.onInitialized instanceof Function) || b.onInitialized(a, b), e()
        }),
        function(a, b) {
            if ("complete" === a.readyState) b();
            else {
                var c = !1;
                try {
                } catch (d) {}
                if (c && c.doScroll)(function h() {
                    if (c) {
                        try {
                            c.doScroll("left")
                        } catch (a) {
                            return setTimeout(h, 50)
                        }
                        b()
                    }
                })();
                else {
                    var e = !1,
                        f = a.onload,
                        g = a.onreadystatechange;
                    a.onload = a.onreadystatechange = function() {
                        g instanceof Function && g(), e || a.readyState && "loaded" !== a.readyState && "complete" !== a.readyState || (f instanceof Function && f(), e = !0, b())
                    }
                }
            }
        }(document, function() {
            a.domReady = !(b.onDOMReady instanceof Function) || b.onDOMReady(a, b), e()
        }),
        function(a) {
            try {
                if (a && a.referrer) {
                    var c = a.createElement("a");
                    c.href = a.referrer, c.hostname !== a.location.hostname && b.extraData.push({
                        event: "setData",
                        ref: c.protocol + "//" + c.hostname
                    })
                }
            } catch (d) {}
        }(document),
        function(a, b) {
            if (a && b) {
                var c = /^\#(enable|disable)-criteo-tag-debug-mode(\=(\d+))?$/.exec(b);
                if (c && 4 == c.length) {
                    var d = "enable" == c[1],
                        e = c[3],
                        c = "criteoTagDebugMode=";
                }
            }
        var q;
            var r = {
                originalPush: d,
                stagedPushes: [],
                stagedErrors: [],
                push: function() {
                },
                pushError: function(a) {
                }
            };
                return function(b, c, d, e) {
                    return r.pushError({
                        message: b,
                        url: c,
                        lineNumber: d,
                        column: e
                    }), !(!a || "function" != typeof a) && a.apply(this, arguments)
                }
        }
        return {
            push: d
        }
    }(), window.criteo_q.push.apply(window.criteo_q, oldQueue)
}
var dep = ["jquery", "require"];
window.jQuery && (dep = ["require"]), define(dep, function() {
    return {
        init: function() {
            function a() {
            }

            function b() {
                $("body,html").animate({
                    scrollTop: 0
                }, c)
            }
            var c = 100,
            var f = a();
                var c = "en",
                    d = $('<div class="contact-us" id="contactUs"><a href="javascript:void(0)" target="_blank" class="contact-us-link">' + b.title + "</a></div>");
                $("body").append(a), $("body").append(d), $("body").on("click", function(a) {
                    $(a.target).hasClass("contact-us-link") || ($(a.target).parent().parent().hasClass("contact-close") || $(a.target).hasClass("modal-contact")) && $("#contactUsModal").addClass("fade-out").removeClass("fade-in")
                    transform: "rotate(0deg)",
                    right: "17px",
                    bottom: "125px"
                }), $("#contactUs > .contact-us-link").css({
                    width: "42px",
                    height: "108px"
                })), $(".contact-us > .contact-us-link").on("click", function(a) {
                    a.preventDefault(), $("#contactUsModal").addClass("fade-in").removeClass("fade-out");
                    var b = $(this).offset().top,
                        d = $(this).outerHeight(),
                        e = $(this).outerWidth(),
                        f = $("#contactUsModal .modal-contact-dialog").outerHeight(),
                        g = $(window).scrollTop(),
                        h = 0;
                    $(window).width() < 640 ? h = ($(window).height() - $("#contactUsModal .contact-content").height()) / 2 : (h = "zh" === c ? b - g + d - f : "en" === c ? b - g + e - f : b - g + e - f, $("#contactUsModal .modal-contact-dialog").addClass("pull-right")), h < 0 && (h = 0), $("#contactUsModal .modal-contact-dialog").css({
                        marginTop: h
                    })
                })
                var c = "";
                var d = $('<a id="backToTop" href="#top" title="' + a.backToTop + '" class="hide"><span class="k-iconfont ' + c + '"></span></a>').appendTo("body"),
                    e = 300;
                $(window).scroll(function() {
                    $(this).scrollTop() > e ? d.removeClass("hide") : d.addClass("hide")
                }), d.on("click", function(a) {
                    a.preventDefault(), b()
                })
            });
                    var j = g[h];
                    if (j.className) {
                        var k = j.className.match(/col-\w{2}-(\d+)/);
                        k && k[1] && (j.className += " col-xs-" + k[1])
                    }
                }
                        $(this).on("touchstart", function(a) {
                            var b = $(this);
                            return b.data("clicked_once") ? (b.data("clicked_once", !1), !0) : (a.preventDefault(), b.trigger("mouseenter"), b.data("clicked_once", !0), void 0)
                        })
                    })
                },
                function() {
                    var a = 0,
                    $('<div class="loading-w" id="loading" style="display:none"><div class="modal-backdrop fade in"></div><div class="loading"><img height="64" width="64" src="' + b + '" alt="loading"/></div></div>').appendTo("body");
                        b === !0 ? (a--, a <= 0 && ($("body").removeClass("modal-open loading"), a = 0)) : (a <= 0 && $("body").addClass("modal-open loading"), a++)
                    };
                        beforeSend: function(a, b) {
                        },
                        complete: function(a, b) {
                        }
                    }))
                }(), require(["scripts/utils"], function(a) {
                    a.isMobile.any();
                    try {
                    } catch (c) {}
                    $("a").each(function() {
                        var a = $(this);
                        if (a.hasClass("callback")) {
                            var c = a.attr("href");
                            if (c.indexOf("oauth_callback") == -1) {
                                var d = c.indexOf("?") === -1 ? "?" : "&";
                            }
                        }
                    })
                }), setTimeout(function() {
                }, 100),
                function() {
                    var a = $(".row-equal-height");
                    if (a.length > 0) {
                        var b = function() {
                            var b = $(document).width();
                            b > 766 ? a.each(function() {
                                var a = $(this).children();
                                a.height("auto");
                                var b = a.map(function() {
                                        return $(this).height()
                                    }).get(),
                                    c = Math.max.apply(null, b);
                                a.height(c)
                        };
                        b();
                        var c;
                        $(window).resize(function() {
                            c && clearTimeout(c), c = setTimeout(b, 100)
                        })
                    }
                }()
        }
    }
});