_satellite.pushAsyncScript(function(event, target, $variables) {
    //
        (function(f, e, a, t, h, r) {
            if (!f[h]) {
                    r.invoke ? r.invoke.apply(r, arguments) : r.queue.push(arguments)
                var g = e.createElement(a),
                    h = e.getElementsByTagName("head")[0] || e.getElementsByTagName("script")[0].parentNode;
                g.async = !0, g.src = t, h.appendChild(g)
            }
        })
        (window, document, "script", "https://cdn.feathr.co/js/boomerang.min.js", "feathr");

        feathr("fly", "5c5d965fa1f0aa5a1710add1");
        feathr("sprinkle", "page_view");
    }
});