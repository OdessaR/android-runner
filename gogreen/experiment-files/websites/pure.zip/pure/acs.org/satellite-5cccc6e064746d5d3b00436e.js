_satellite.pushAsyncScript(function(event, target, $variables) {
    var vids = [];
    var i = 0;
    var videoTitle;
    var videoDuration;
    jQuery('iframe[src*="player.vimeo.com"]').each(function() {
        // For each iframe create a player
        vids[i] = {};
        var player = vids[i].player;
        player.on('play', function(data) {
            var videoTitle;
            var videoDuration;
            try {
                player.getVideoTitle().then(function(title) {
                    player.getDuration().then(function(duration) {

                        if (data.seconds == 0) {
                            s.Media.open(videoTitle, videoDuration, 'vimeo');
                            s.Media.play(videoTitle, 0);
                        } else {
                            s.Media.play(videoTitle, Math.floor(data.seconds));
                        }
                    });
                });
            }
        });
        player.on('pause', function(data) {
            try {
                player.getVideoTitle().then(function(title) {
                    player.getDuration().then(function(duration) {
                        s.Media.stop(videoTitle, Math.floor(data.seconds));
                    });
                });
            }
        });
        player.on('ended', function(data) {
            //console.log('Played the video');
            try {
                });
            }
        });
        i++;
    });

});