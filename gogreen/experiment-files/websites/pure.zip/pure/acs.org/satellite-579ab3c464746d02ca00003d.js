_satellite.pushAsyncScript(function(event, target, $variables) {
    var result = true;
    var headers = {};
    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4) {
            var headerStr = xmlhttp.getAllResponseHeaders().toLowerCase()
            var headerPairs = headerStr.split('\u000d\u000a');
            for (var i = 0, len = headerPairs.length; i < len; i++) {
                var headerPair = headerPairs[i];
                var index = headerPair.indexOf('\u003a\u0020');
                if (index > 0) {
                    var key = headerPair.substring(0, index);
                    var val = headerPair.substring(index + 2);
                    headers[val] = val;
                    headers[key] = key;
                }

                    result = false;
                }
            }

            if (result) {
            } else {
            }
        }
    }
    xmlhttp.send();
});