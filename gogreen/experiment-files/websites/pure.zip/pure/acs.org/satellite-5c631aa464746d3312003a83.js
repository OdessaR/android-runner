// Create Eloqua Element
var _elqQ = _elqQ || [];
_elqQ.push(['elqSetSiteId', '341921710']);
// Page name handling
var _path = location.pathname;
var _searchArr = (location.search.length) ? location.search.substr(1).split('&') : [];
for (var i = 0; i < _searchArr.length; i++) {
    if ('WebCode=' == _searchArr[i].substr(0, 8)) {
        _path = ((_path.length) ? '/' : '') + _path + '/';
        _path += _searchArr[i];
        _searchArr.splice(i, 1);
    }
}
var _trackingURL = location.protocol + '//' + location.hostname + _path + ((_searchArr.length) ? '?' : '') + _searchArr.join('&') + location.hash;
//push page name
if (typeof _elqQ !== 'undefined') {
    _elqQ.push(['elqTrackPageView', _trackingURL]);
}

//Listener functions
(function() {
    function async_load() {
        s.type = 'text/javascript';
        s.async = true;
        s.src = '//img.en25.com/i/elqCfg.min.js';
        x.parentNode.insertBefore(s, x);
    }
})();
//notify for console
_satellite.notify('Eloqua ready')