_satellite.pushAsyncScript(function(event, target, $variables) {
    _sdi.utils = _sdi.utils || {};

    _sdi.utils.dataLayerHandle = function(initialPush, appEventData) {
        // Create reference to old method
        //var oldPush = initialPush.push;


        initialPush.forEach(function(initialPush, i) {
            if (initialPush.processed != true) {
            }
        })






                // name the event we are processing 
                // provison an objecto push


                //pick all the args in the initial objects

                // loop these args 

                    var schim = {}
                    if (element !== "event") { // we don't want the event name arg
                        //drilling down
                        // loop through level 2 args
                            Object.keys(a).forEach(function(b) {
                            })
                        })
                        appEventData.push(schim)
                    } else {
                    }


                })
                //process the event 
            });

            //fire the event

        } else {
        }

    }
});