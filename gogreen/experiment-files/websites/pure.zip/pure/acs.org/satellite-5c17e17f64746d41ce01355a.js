_satellite.pushAsyncScript(function(event, target, $variables) {
            // search event based rules
            // _satellite.rules
            var eventRulesLen = eventRules.length;
            var eventRulesList = [];
                    // console.log("has trigger");
                        // console.log("has trigger & arguments");
                        if (arg2String) {
                            arg2String = arg2String.toLowerCase();
                            var indexVar = arg2String.indexOf(variable);
                            if (indexVar > -1) {
                                //check to make sure "event8" doesn't catch "event83"
                                }
                            }
                        }
                    }
                }
            }
            // search page load rules
            // _satellite.pageLoadRules
            var pageLoadRulesLen = pageLoadRules.length;
            var pageLoadRulesList = [];
                    // console.log("has trigger");
                        // console.log("has trigger & arguments");
                        if (arg2String) {
                            arg2String = arg2String.toLowerCase();
                            var indexVar = arg2String.indexOf(variable);
                            if (indexVar > -1) {
                                //check to make sure "event8" doesn't catch "event83"
                                }
                            }
                        }
                    }
                }
            }
            // search direct call rules
            // _satellite.directCallRules
            var directCallRulesLen = directCallRules.length;
            var directCallRulesList = [];
                    // console.log("has trigger");
                        // console.log("has trigger & arguments");
                        if (arg2String) {
                            arg2String = arg2String.toLowerCase();
                            var indexVar = arg2String.indexOf(variable);
                            if (indexVar > -1) {
                                //check to make sure "event8" doesn't catch "event83"
                                }
                            }
                        }
                    }
                }
            }
            // function array2StringList(array){
            //   listString = JSON.stringify(array, null, "\t");
            //   listStringClean = listString.replace(/["']/g, "");
            //   listStringClean = listStringClean.replace(/,/g,"");
            //   return listStringClean;
            // }
            var allRules = {
                pageLoad: pageLoadRulesList,
                eventBased: eventRulesList,
                directCall: directCallRulesList
            }
            return allRules
        }

    } else {
    }
});