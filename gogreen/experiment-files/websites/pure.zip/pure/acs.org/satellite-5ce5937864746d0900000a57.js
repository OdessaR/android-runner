_satellite.pushAsyncScript(function(event, target, $variables) {
        ! function(f, b, e, v, n, t, s) {
            if (f.fbq) return;
                n.callMethod ?

                    n.callMethod.apply(n, arguments) : n.queue.push(arguments)
            };




            s.parentNode.insertBefore(t, s)
        }(window, document, 'script',

            'https://connect.facebook.net/en_US/fbevents.js');


        fbq('init', '420103382156928');

        fbq('track', 'PageView');
    }

});