_satellite.pushAsyncScript(function(event, target, $variables) {
        var myVid = "";
        //var palyeerIDforAnalytics = "ee-player_html5_api";
        //console.log("BC: looking for video JS API ");
            try {
                    // && typeof window.frames[x].frameElement.contentWindow.videojs.getPlayer("ee-player_html5_api") != "undefined"){
                    var videoContainer = videoWindow.document.getElementsByTagName("video")[0];
                    //console.log(videoContainer.id);
                    if (videoContainer.id &&
                        typeof videoWindow.videojs.getPlayer(videoContainer.id) == 'object') {
                        //var myVid = videoWindow.videojs(videoContainer.getAttribute("data-video-id"));
                        var myVid = videoWindow.videojs.getPlayer(videoContainer.id);
                        //console.log("BC: FOUND VIDEO ");
                    }
                }
        }
        if (myVid != "") {
            myVid.on('loadedmetadata', function() {
                var videoName = myVid.mediainfo.name;
                //console.log("BC: Video loaded " + videoName);
                var videoDuration = Math.floor(myVid.mediainfo.duration);


                myVid.on('play', function() {
                    //  console.log("BC Play video");
                });
                myVid.on('pause', function() {
                    //console.log("BC Pause video");
                });
                myVid.on('ended', function() {
                });
            });
        } else {
            setTimeout(checkVideojs, 500);
        }
    };

    checkVideojs();
});