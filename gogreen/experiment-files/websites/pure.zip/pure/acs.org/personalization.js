if (!window.CQ_Analytics) {
    window.CQ_Analytics = {}
}
CQ_Analytics.Operator = (function() {
    return function() {}
})();
CQ_Analytics.Operator.IS = "is";
CQ_Analytics.Operator.EQUALS = "equals";
CQ_Analytics.Operator.NOT_EQUAL = "notequal";
CQ_Analytics.Operator.GREATER = "greater";
CQ_Analytics.Operator.GREATER_OR_EQUAL = "greaterorequal";
CQ_Analytics.Operator.OLDER = "older";
CQ_Analytics.Operator.OLDER_OR_EQUAL = "olderorequal";
CQ_Analytics.Operator.LESS = "less";
CQ_Analytics.Operator.LESS_OR_EQUAL = "lessorequal";
CQ_Analytics.Operator.YOUNGER = "younger";
CQ_Analytics.Operator.YOUNGER_OR_EQUAL = "youngerorequal";
CQ_Analytics.Operator.CONTAINS = "contains";
CQ_Analytics.Operator.BEGINS_WITH = "beginswith";
CQ_Analytics.OperatorActions = function() {
    var mapping = {};
    var addOperator = function(name, text, operation) {
        mapping[name] = [text, operation]
    };
        if (s1) {
            if (s2) {
                return s1.toLowerCase().indexOf(s2.toLowerCase()) != -1
            }
            return true
        }
        return false
    });
        if (s1) {
            if (s2) {
                return s1.toLowerCase().indexOf(s2.toLowerCase()) == 0
            }
            return true
        }
        return false
    });
    var getByIndex = function(op, index) {
        if (mapping[op] && mapping[op][index]) {
            return mapping[op][index]
        }
        return ""
    };
    var escapeQuote = function(str) {
        if (str) {
        }
        return str
    };
    return {
        getText: function(operator) {
            return getByIndex(operator, 0)
        },
        setText: function(operator, newText) {
            if (mapping[operator] && mapping[operator][0]) {
                mapping[operator][0] = newText
            }
        },
        getOperation: function(operator) {
            return getByIndex(operator, 1)
        },
        operate: function(object, property, operator, value, valueFormat) {
            try {
                if (object && object[property]) {
                    var toEval = "";
                    op = op ? op : operator;
                    if (typeof op == "function") {
                        return op.call(this, objectValue, value, valueFormat)
                    } else {
                        if (valueFormat) {
                            toEval = valueFormat + "('" + objectValue + "') " + op + " " + valueFormat + "('" + value + "')"
                        } else {
                            var s1 = escapeQuote(objectValue);
                            var s2 = escapeQuote(value);
                            toEval = "'" + s1 + "' " + op + " '" + s2 + "'"
                        }
                        var b = eval(toEval);
                        return b
                    }
                }
            return false
        }
    }
}();
CQ_Analytics.Utils = new function() {
    return {
        registerDocumentEventHandler: function(c, b) {
            } else {
                    if (a) {
                        a(d)
                    }
                    b(d)
                }
            }
        },
        eventWrapper: function(a) {
            return function(d) {
                var c, b;
                } else {
                    c = (typeof(d.which) != "undefined") ? d.which : 0;
                    b = d
                }
                if (b) {
                    a(b, c)
                }
            }
        },
        loadElement: function(a, b) {
            $CQ("#" + b).load(a)
        },
        loadTeaserElement: function(a, d) {
            var e = $CQ("#" + d).css("height");
            var f = $CQ("#" + d).height();
            if (f > 0) {
                $CQ("#" + d).css("height", f)
            }
            var g = function(m) {
                if (m && m != "") {
                    var h = $CQ(m).css("display", "none");
                    $CQ("#" + d).append(h);
                    h.fadeIn(function() {
                        if (e && e != "0px") {
                            $CQ("#" + d).css("height", e)
                        }
                    })
                } else {
                    if (e && e != "0px") {
                        $CQ("#" + d).css("height", e)
                    }
                }
            };
            var j = function(h, m) {
                }
            };
            var b = function() {
                } else {
                        }, 100)
                    } else {
                        k()
                    }
                }
            };
            var k = function() {
                var m = a;
                }
                if (n) {
                    m += (m.indexOf("?") > 0 ? "&" : "?") + "wcmmode=" + n
                }
                    if (r) {
                        var q = p.body;
                        if (q) {
                            q = q.replace(new RegExp("\\n", "ig"), "");
                            q = q.replace(new RegExp("\\r", "ig"), "");
                            j(a, q);
                            b()
                        }
                    } else {
                        j(a, "")
                    }
                })
            };
            var c = $CQ("#" + d).children().length;
            if (c > 0) {
                var l = 0;
                $CQ("#" + d).children().fadeOut(function() {
                    var h = $CQ(this);
                        h.remove();
                        l++;
                        if (l >= c) {
                            b()
                        }
                    }, 50)
                })
            } else {
                b()
            }
        },
        clearElement: function(a) {
            if (a) {
                $CQ("#" + a).html("")
            }
        },
        indexOf: function(d, c) {
            for (var b = 0, a = d.length; b < a; b++) {
                if (d[b] == c) {
                    return b
                }
            }
            return -1
        },
        load: function(a, c, b) {
        },
        post: function(a, d, c, b) {
        },
        getPagePath: function() {
        },
        getPath: function(a) {
        },
        addParameter: function(b, a, c) {
        },
        removeParameters: function(a) {
        },
        removeAnchor: function(a) {
        },
        getSchemeAndAuthority: function(a) {
        },
        internalize: function(a, b) {
        },
        externalize: function(a, b) {
        },
        encodePathOfURI: function(a) {
        },
        encodePath: function(a) {
        },
        getContextPath: function() {
        },
        detectContextPath: function() {
        },
        urlEncode: function(h) {
            if (!h) {
                return ""
            }
            if (typeof h == "string") {
                return h
            }
            var c = [];
            for (var f in h) {
                var e = h[f],
                    b = encodeURIComponent(f);
                var g = typeof e;
                if (g == "undefined") {
                    c.push(b, "=&")
                } else {
                    if (g != "function" && g != "object") {
                        c.push(b, "=", encodeURIComponent(e), "&")
                    } else {
                        if (typeof e == "array") {
                            if (e.length) {
                                for (var d = 0, a = e.length; d < a; d++) {
                                    c.push(b, "=", encodeURIComponent(e[d] === undefined ? "" : e[d]), "&")
                                }
                            } else {
                                c.push(b, "=&")
                            }
                        }
                    }
                }
            }
            c.pop();
            return c.join("")
        },
        getUID: function() {
            var a = Math.floor(Math.random() * (Math.pow(2, 42) - 1));
        },
        getTimestamp: function() {
            var a = new Date();
            return a.getTime()
        },
        insert: function(d, c, b) {
            if (!d || isNaN(c) || !b) {
                return d
            }
            var a = "";
            var f = 0;
            var e = c;
            while (e < d.length) {
                a += d.substring(f, e) + b;
                f += c;
                e += c
            }
            if (f < d.length) {
                a += d.substring(f)
            }
            return a
        },
        addListener: function() {
                return function(d, b, c, a) {
                    d.addEventListener(b, c, (a))
                }
            } else {
                    return function(d, b, c, a) {
                        d.attachEvent("on" + b, c)
                    }
                } else {
                    return function() {}
                }
            }
        },
        removeListener: function() {
                return function(d, b, c, a) {
                    d.removeEventListener(b, c, (a))
                }
            } else {
                    return function(c, a, b) {
                        c.detachEvent("on" + a, b)
                    }
                } else {
                    return function() {}
                }
            }
        }
    }
};
CQ_Analytics.ClickstreamcloudRenderingUtils = new function() {
    return {
        createLink: function(f, d, b, a) {
            c.href = a;
            c.onclick = d;
            c.innerHTML = f;
            if (b) {
                for (var e in b) {
                    if (b.hasOwnProperty(e)) {
                        c[e] = b[e]
                    }
                }
            }
            return c
        },
        createStaticLink: function(d, a, c) {
            b.href = a;
            b.innerHTML = d;
            b.title = c;
            b.alt = c;
            return b
        },
        createNameValue: function(b, d, a, e) {
            c.className = a || "ccl-data";
            c.innerHTML = b + " = " + d;
            c.title = e;
            c.alt = e;
            return c
        },
        createText: function(d, a, c) {
            b.className = a || "ccl-data";
            if (d && d.indexOf && ((d.indexOf("/home") != -1 && d.indexOf("/image") != -1) || (d.indexOf("/") != -1 && d.indexOf(".png") != -1))) {
                b.innerHTML = '<img src="' + d + '.prof.thumbnail.png" border="0">'
            } else {
                if (d && d.indexOf && d.indexOf("www.gravatar.com") != -1) {
                    b.innerHTML = '<img src="' + d + '">'
                } else {
                    b.innerHTML = d
                }
            }
            b.title = c;
            b.alt = c;
            return b
        },
        createEditablePropertySpan: function(b, d) {
            var a = "var editSpan = this.nextSibling; this.style.display = 'none'; editSpan.style.display = 'block';";
            var e = "var editSpan = this.parentNode; var readSpan = this.parentNode.previousSibling;var newValue = this.value;editSpan.style.display = 'none'; readSpan.innerHTML = '" + b + " = '+value; readSpan.style.display = 'block';";
            c.innerHTML = '<span class="ccl-data" onclick="' + a + '">' + b + " = " + d + "</span>";
            c.innerHTML += '<span class="ccl-data" style="display: none;">' + b + ' = <input class="ccl-input" type="text" value="' + d + '" onblur="' + e + '"></span>';
            c.className = "ccl-data";
            return c
        }
    }
};
CQ_Analytics.ClientContextUtils = new function() {
    return {
        renderStoreProperty: function(f, c, b, d, e, a) {
                    var g = function() {
                        if (h) {
                            var j = function() {
                                var m = h.getProperty(b) || a;
                                var l = $CQ("#" + f);
                                if (l.attr("contenteditable") && l.attr("contenteditable") != "inherit") {
                                    return
                                }
                                if (typeof(m) == "string" && ((m.indexOf("/") == 0 && (m.toLowerCase().indexOf(".png") != -1 || m.toLowerCase().indexOf(".jpg") != -1 || m.toLowerCase().indexOf(".gif") != -1) || m.toLowerCase().indexOf("http") == 0))) {
                                    if (!m || m == "") {
                                        l.children().remove();
                                        } else {
                                            l.html("No " + b)
                                        }
                                    } else {
                                        var k = "";
                                        if (l.parents(".aem-cc-thumbnail").length == 0 || m.toLowerCase().indexOf("http") == 0 || m.indexOf("/libs/wcm/mobile") == 0) {
                                            k = m.replace(new RegExp("&amp;", "g"), "&")
                                        } else {
                                            k = "/etc/clientcontext/shared/thumbnail/content.png";
                                        }
                                        if (l.find("div").css("background-image") != "url(" + k + ")") {
                                            if (h.fireEvent("beforepropertyrender", h, f) !== false) {
                                                l.html("");
                                                l.children().remove();
                                                h.fireEvent("propertyrender", h, f)
                                            }
                                        }
                                    }
                                } else {
                                    } else {
                                        m = (!m || m == "") ? "No " + b : m = d + m + e
                                    }
                                    if (l.html() != m) {
                                        if (h.fireEvent("beforepropertyrender", h, f) !== false) {
                                            l.html(m);
                                            h.fireEvent("propertyrender", h, f)
                                        }
                                    }
                                }
                            };
                            if (h.fireEvent("beforeinitialpropertyrender", h, f) !== false) {
                                j();
                                if (h.addListener) {
                                    h.addListener("update", function() {
                                        j()
                                    })
                                }
                                h.fireEvent("initialpropertyrender", h, f)
                            }
                        }
                    };
                })
            }
        },
        renderStore: function(b, a) {
                    var c = function() {
                        if (d) {
                            d.divId = b;
                            var e = function() {
                                if (d.fireEvent("beforerender", d, d.divId) !== false) {
                                    d.renderer(d, d.divId);
                                    d.fireEvent("render", d, d.divId)
                                }
                            };
                            if (d.fireEvent("beforeinitialrender", d, b) !== false) {
                                e();
                                if (d.addListener) {
                                    d.addListener("update", function() {
                                        e()
                                    })
                                }
                                d.fireEvent("initialrender", d, b)
                            }
                        }
                    };
                })
            }
        },
        storesOptionsProvider: function() {
            var c = [];
            for (var b in a) {
                c.push({
                    value: b
                })
            }
            return c
        },
        storePropertiesOptionsProvider: function(c, e) {
            var b = [];
            if (a) {
                var g = a.getPropertyNames();
                for (var d = 0; d < g.length; d++) {
                    var f = g[d];
                        var h = {
                            value: f
                        };
                        if (e) {
                            h.text = f + " - " + a.getProperty(f)
                        }
                        b.push(h)
                    }
                }
            }
            return b
        },
        onStoreRegistered: function(b, c) {
            if (c) {
                if (a) {
                    c.call(a, a)
                } else {
                        if (d.getName() == b) {
                            c.call(d, d)
                        }
                    })
                }
            }
        },
        onStoreInitialized: function(c, e, b) {
            if (b === true) {
            }
            var d = function() {
                if (f.DELAYED_INIT_TIMEOUT) {
                    f.DELAYED_INIT_TIMEOUT = null
                }
                if (b > 0) {
                        f.DELAYED_INIT_TIMEOUT = null;
                        e.call(f, "initialize", f)
                    }, b)
                } else {
                    e.call(f, "initialize", f)
                }
            };
            if (a) {
                if (a.isInitialized()) {
                    d.call(a);
                    a.addListener("initialize", function(g, f) {
                        d.call(f)
                    })
                } else {
                    a.addListener("initialize", function(g, f) {
                        d.call(f)
                    })
                }
            } else {
                    if (f.getName() == c) {
                    }
                })
            }
        },
        init: function(d, c) {
        },
        initUI: function(c, a, b) {
        }
    }
};
CQ_Analytics.ClientContextUtils.DEFAULT_INIT_DELAY = 200;
CQ_Analytics.Variables = new function() {
    return {
        containsVariable: function(a) {
        },
        getVariables: function(b) {
            if (!b || typeof(b) != "string") {
                return []
            }
            var a = b.match(new RegExp("\\$\\{([\\w/]*)\\}", "ig"));
            return a ? a : []
        },
        replaceVariables: function(e) {
            if (!e) {
                return e
            }
            var f = "";
            var d = e;
            while (g.length > 0 && f.indexOf(g.join()) == -1) {
                for (var c = 0; c < g.length; c++) {
                }
                f += g.join();
            }
            return d
        },
        getPropertyPath: function(a) {
            if (!a || a.length < 2) {
                return null
            }
            return a.substring(2, a.length - 1)
        },
        getPropertyName: function(a) {
            if (c) {
                var b = c.split("/");
                if (b.length == 3) {
                    return b[2]
                }
            }
            return null
        },
        getStoreName: function(a) {
            if (c) {
                var b = c.split("/");
                if (b.length > 1) {
                    return b[1]
                }
            }
            return null
        },
        replace: function(a, b, c) {
            return a.replace(new RegExp("\\$\\{" + b + "\\}", "ig"), c)
        }
    }
};
CQ_Analytics.SessionPersistence = CQ.shared.ClientSidePersistence;
CQ_Analytics.Cookie = CQ.shared.ClientSidePersistence.CookieHelper;
CQ_Analytics.Observable = function() {
            var b = Array.prototype.slice.call(arguments, 0);
            for (var c = 0; c < e.length; c++) {
                var a = e[c];
                if (d == a.event) {
                        return false
                    }
                }
            }
        }
        return true
    }
};
CQ_Analytics.Observable.prototype.addListener = function(c, a, b) {
    if (c && a) {
            event: c.toLowerCase(),
            fireFn: a,
            scope: b
        })
    }
};
CQ_Analytics.Observable.prototype.removeListener = function(c, a) {
    if (c && a) {
            }
        }
    }
};
CQ_Analytics.Observable.prototype.setSuppressEvents = function(a) {
};
CQ_Analytics.Observable.prototype.listeners = null;
CQ_Analytics.Observable.prototype.suppressEvents = false;
if (!CQ_Analytics.StoreRegistry) {
    CQ_Analytics.StoreRegistry = new function() {
        var a = {};
        return {
            register: function(b) {
                if (b.STORENAME) {
                    a[b.STORENAME] = b
                }
            },
            getStores: function() {
                return a
            },
            getStore: function(b) {
                return a[b]
            }
        }
    }()
}
CQ_Analytics.SessionStore = function() {};
CQ_Analytics.SessionStore.prototype = new CQ_Analytics.Observable();
CQ_Analytics.SessionStore.prototype.setProperty = function(a, b) {
    }
};
CQ_Analytics.SessionStore.prototype.setProperties = function(b) {
    }
    var d = [];
    for (var a in b) {
        if (b.hasOwnProperty(a)) {
            d.push(a);
            var c = b[a];
        }
    }
    if (d.length > 0) {
    }
};
CQ_Analytics.SessionStore.prototype.initialized = false;
CQ_Analytics.SessionStore.prototype.init = function() {
};
CQ_Analytics.SessionStore.prototype.getLabel = function(a) {
    return a
};
CQ_Analytics.SessionStore.prototype.getLink = function(a) {
    return a
};
CQ_Analytics.SessionStore.prototype.removeProperty = function(a) {
    }
    }
};
CQ_Analytics.SessionStore.prototype.getPropertyNames = function(a) {
    }
    var b = new Array();
            b.push(c)
        }
    }
    return b
};
CQ_Analytics.SessionStore.prototype.getSessionStore = function() {
};
CQ_Analytics.SessionStore.prototype.clear = function() {
};
CQ_Analytics.SessionStore.prototype.getData = function(b) {
    }
    if (b) {
        var a = {};
            }
        }
        return a
    } else {
    }
};
CQ_Analytics.SessionStore.prototype.reset = function() {
    }
};
CQ_Analytics.SessionStore.prototype.getProperty = function(b, a) {
    }
    if (!a) {
        return c
    }
    return d
};
CQ_Analytics.SessionStore.prototype.getName = function() {
};
CQ_Analytics.SessionStore.prototype.addInitProperty = function(a, b) {
    }
};
CQ_Analytics.SessionStore.prototype.getInitProperty = function(a) {
};
CQ_Analytics.SessionStore.prototype.loadInitProperties = function(c, a) {
    if (c) {
        for (var b in c) {
            }
        }
    }
};
CQ_Analytics.SessionStore.prototype.isInitialized = function() {
};
CQ_Analytics.PersistedSessionStore = function() {};
CQ_Analytics.PersistedSessionStore.prototype = new CQ_Analytics.SessionStore();
CQ_Analytics.PersistedSessionStore.prototype.STOREKEY = "key";
CQ_Analytics.PersistedSessionStore.prototype.setNonPersisted = function(a) {
    }
};
CQ_Analytics.PersistedSessionStore.EXCLUDED_PROPERTIES_REGEX = "^generated*";
CQ_Analytics.PersistedSessionStore.prototype.isPersisted = function(a) {
    }
};
CQ_Analytics.PersistedSessionStore.prototype.getStoreKey = function() {
};
CQ_Analytics.PersistedSessionStore.prototype.persist = function() {
            container: "ClientContext"
        });
    }
};
CQ_Analytics.PersistedSessionStore.prototype.setProperty = function(a, b) {
    }
    }
};
CQ_Analytics.PersistedSessionStore.prototype.setProperties = function(b) {
    }
    var d = [];
    var e = false;
    for (var a in b) {
        if (b.hasOwnProperty(a)) {
            d.push(a);
            var c = b[a];
                e = true
            }
        }
    }
    if (e) {
    }
    if (d.length > 0) {
    }
};
CQ_Analytics.PersistedSessionStore.prototype.toString = function() {
    var b = null;
        var a = function(e) {
            if (!e || typeof(e) != "string") {
                return e
            }
            var d = e;
            d = d.replace(new RegExp(",", "g"), "&#44;");
            d = d.replace(new RegExp("=", "g"), "&#61;");
            d = d.replace(new RegExp("\\|", "g"), "&#124;");
            return d
        };
                b = (b === null ? "" : b + ",");
            }
        }
    }
    return b
};
CQ_Analytics.PersistedSessionStore.prototype.parse = function(e) {
    var d = function(h) {
        if (!h || typeof(h) != "string") {
            return h
        }
        var g = h;
        g = g.replace(new RegExp("&#44;", "g"), ",");
        g = g.replace(new RegExp("&#61;", "g"), "=");
        g = g.replace(new RegExp("&#124;", "g"), "|");
        return g
    };
    var c = {};
    var f = e.split(",");
    for (var a in f) {
        if (f.hasOwnProperty(a)) {
            var b = f[a].split("=");
            if (b.length == 2) {
                c[b[0]] = d(b[1])
            }
        }
    }
    return c
};
CQ_Analytics.PersistedSessionStore.prototype.reset = function(a) {
        if (!a) {
        }
    }
};
CQ_Analytics.PersistedSessionStore.prototype.removeProperty = function(a) {
    }
        }
    }
};
CQ_Analytics.PersistedSessionStore.prototype.clear = function() {
        container: "ClientContext"
    });
};
if (!CQ_Analytics.ClientContextMgr) {
    CQ_Analytics.ClientContextMgr = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype = new CQ_Analytics.PersistedSessionStore();
    CQ_Analytics.ClientContextMgr.prototype.STOREKEY = "CLIENTCONTEXT";
    CQ_Analytics.ClientContextMgr.prototype.STORENAME = "clientcontext";
    CQ_Analytics.ClientContextMgr.prototype.INITIALIZATION_EVENT_TIMER = 1000;
    CQ_Analytics.ClientContextMgr.prototype.CONFIG_PATH = CQ_Analytics.Utils.externalize("/etc/clientcontext/legacy/config.json", true);
    CQ_Analytics.ClientContextMgr.prototype.init = function() {
        }
            container: "ClientContext"
        });
        if (b) {
        } else {
        }
    };
    CQ_Analytics.ClientContextMgr.prototype.getSessionId = function() {
        }
    };
    CQ_Analytics.ClientContextMgr.prototype.setSessionId = function(a) {
        if (a) {
        }
    };
    CQ_Analytics.ClientContextMgr.prototype.getVisitorId = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.setVisitorId = function(a) {
    };
    CQ_Analytics.ClientContextMgr.prototype.getId = function() {
        if (!a) {
        }
        return a
    };
    CQ_Analytics.ClientContextMgr.prototype.isAnonymous = function() {
        return (!a)
    };
    CQ_Analytics.ClientContextMgr.prototype.isMode = function(a) {
    };
    CQ_Analytics.ClientContextMgr.prototype.get = function(a) {
        }
        if (a) {
        }
    };
    CQ_Analytics.ClientContextMgr.prototype.register = function(c) {
        }
        if (b.stats !== false && b.stats != "false") {
        }
        }
            a.fireEvent("storesinitialize");
            a.areStoresInitialized = true
        c.addListener("update", function() {
            a.update(c)
        });
            c.clear()
        });
    };
    CQ_Analytics.ClientContextMgr.prototype.update = function(b) {
        }
        if (a.stats !== false && a.stats != "false") {
        }
    };
    CQ_Analytics.ClientContextMgr.prototype.startPosting = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.stopPosting = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.post = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.getCCMToJCR = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.getName = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.clear = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.getRegisteredStore = function(a) {
    };
    CQ_Analytics.ClientContextMgr.prototype.loadConfig = function(c, autoConfig) {
        var setConfig = function(ccm, config) {
            ccm.fireEvent("configloaded");
            ccm.fireEvent("storesloaded");
        };
        if (c) {
            setConfig(this, c)
        } else {
            if (!autoConfig) {
                var params = {};
                params.cq_ck = new Date().valueOf();
                    var config = {};
                    try {
                        config = eval("config = " + response.responseText)
                    setConfig(this, config)
                }, this)
            } else {
                setConfig(this, {})
            }
        }
    };
    CQ_Analytics.ClientContextMgr.prototype.getConfig = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.getStoreConfig = function(a) {
        }
        return {}
    };
    CQ_Analytics.ClientContextMgr.prototype.getEditConfig = function(a) {
        }
        return {}
    };
    CQ_Analytics.ClientContextMgr.prototype.getUIConfig = function(a) {
        }
        return {}
    };
    CQ_Analytics.ClientContextMgr.prototype.getInitialData = function(a) {
        }
        return {}
    };
    CQ_Analytics.ClientContextMgr.prototype.getStores = function() {
    };
    CQ_Analytics.ClientContextMgr.prototype.onReady = function(b, a) {
        if (b) {
                b.call(a)
            } else {
            }
        }
    };
    CQ_Analytics.ClientContextMgr = CQ_Analytics.CCM = new CQ_Analytics.ClientContextMgr();
    CQ_Analytics.ClickstreamcloudMgr = CQ_Analytics.CCM;
    CQ_Analytics.ContextCloudMgr = CQ_Analytics.CCM;
    CQ_Analytics.ClientContextMgr.PATH = null;
    CQ_Analytics.ClientContextMgr.getClientContextURL = function(a) {
    };
    window.setTimeout(function() {
    }, 1);
    CQ_Analytics.Utils.addListener(window, "unload", function() {
        try {
            }
    })
}
if (CQ_Analytics.ClientContextMgr && !CQ_Analytics.ClientContextMgr.ServerStorage) {
    CQ_Analytics.ClientContextMgr.ServerStorage = function() {
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_MODE_PAGELOAD = 1;
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_MODE_TIMER = 2;
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_MODE_DATAUPDATE = 4;
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_TIMER = 600;
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_PROCESS_TIMER = 60;
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_MODE = 6;
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.POST_PATH = "/var/statistics/";
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.init = function() {
            var b = function() {
                    try {
                        var d = parseInt(a.data.lastPost);
                        var f = false;
                        if (isNaN(d)) {
                            f = true
                        } else {
                            var e = new Date().getTime();
                                f = true
                            }
                        }
                        a.post()
                    }
            };
            b.call(this)
        }
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.isMode = function(a) {
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.handleStoreRegistration = function(a) {
        }
            a.addListener("persist", function() {
            })
        }
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.startPosting = function() {
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.stopPosting = function() {
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.post = function(d, f) {
            try {
                g["./jcr:primaryType"] = "nt:unstructured";
                    c += "anonymous/" + a + "/" + e
                } else {
                }
        }
    };
    CQ_Analytics.ClientContextMgr.ServerStorage.prototype.getCCMToJCR = function(g) {
        var e = {};
        for (var j in c) {
            if (!g || j == g) {
                var a = c[j],
                    b = encodeURIComponent(j);
                var f = typeof a;
                if (f == "object") {
                    for (var d in a) {
                        var h = a[d];
                        d = d.replace(":", "/");
                        e["./" + j + "/./" + d] = h
                    }
                } else {
                    e["./" + j] = a
                }
            }
        }
        return e
    };
    CQ_Analytics.ClientContextMgr.ServerStorage = new CQ_Analytics.ClientContextMgr.ServerStorage();
    CQ_Analytics.ClickstreamcloudMgr.POST_MODE_PAGELOAD = CQ_Analytics.ClientContextMgr.ServerStorage.POST_MODE_PAGELOAD;
    CQ_Analytics.ClickstreamcloudMgr.POST_MODE_TIMER = CQ_Analytics.ClientContextMgr.ServerStorage.POST_MODE_TIMER;
    CQ_Analytics.ClickstreamcloudMgr.POST_MODE_DATAUPDATE = CQ_Analytics.ClientContextMgr.ServerStorage.POST_MODE_DATAUPDATE;
    CQ_Analytics.ClickstreamcloudMgr.POST_TIMER = CQ_Analytics.ClientContextMgr.ServerStorage.POST_PROCESS_TIMER;
    CQ_Analytics.ClickstreamcloudMgr.POST_PROCESS_TIMER = CQ_Analytics.ClientContextMgr.ServerStorage.POST_PROCESS_TIMER;
    CQ_Analytics.ClickstreamcloudMgr.POST_MODE = CQ_Analytics.ClientContextMgr.ServerStorage.POST_MODE;
    CQ_Analytics.ClickstreamcloudMgr.POST_PATH = CQ_Analytics.ClientContextMgr.ServerStorage.POST_PATH
}
CQ_Analytics.Percentile = {};
CQ_Analytics.Percentile.matchesPercentiles = function(b) {
    if (!d) {
        d = Math.round(Math.random() * 100);
    }
    for (var c = 0; c < b.length; c++) {
        var a = b[c];
        if ((a.start <= d) && (d < a.end)) {
            return true
        }
    }
    return false
};
if (!CQ_Analytics.SegmentMgr) {
    CQ_Analytics.SegmentMgr = function() {
            a.fireEvent("update")
        };
    };
    CQ_Analytics.SegmentMgr.prototype = new CQ_Analytics.SessionStore();
    CQ_Analytics.SegmentMgr.prototype.STORENAME = "segments";
    CQ_Analytics.SegmentMgr.prototype.register = function(a, c, b) {
        }
    };
    CQ_Analytics.SegmentMgr.prototype.resolveArray = function(e, g, b) {
        if (!(e instanceof Array)) {
        }
        var a = (b == "AND");
        for (var d = 0; d < e.length; d++) {
            var f = e[d];
            if (b == "AND") {
                if (c !== true) {
                    return c
                }
            } else {
                if (c === true) {
                    return true
                }
            }
        }
        return a
    };
    CQ_Analytics.SegmentMgr.prototype.resolve = function(segmentPath, clientcontext) {
        if (!segmentPath) {
            return false
        }
        if (segmentPath instanceof Array) {
        }
            return false
        }
            return true
        }
            return true
        }
        var parent = segmentPath.substring(0, segmentPath.lastIndexOf("/"));
            if (pres !== true) {
                return pres
            }
        }
        var rules = "function(clientcontext, contextcloud, clickstreamcloud) { return true ";
        rules += ";}";
        var res = true;
        try {
            var f = null;
            } else {
                eval("f = " + rules + "");
            }
            var e = (f == null || f(clientcontext, clientcontext, clientcontext));
            res = res && (e === true)
        }
        return res
    };
    CQ_Analytics.SegmentMgr.prototype.getResolved = function(c) {
        var a = new Array();
                a.push(b)
            }
        }
        return a
    };
    CQ_Analytics.SegmentMgr.prototype.getMaxBoost = function(e, g) {
        if (!(e instanceof Array)) {
        }
        var c = 0;
        for (var d = 0; d < e.length; d++) {
            var f = e[d];
                if (a > c) {
                    c = a
                }
            }
        }
        return c
    };
    CQ_Analytics.SegmentMgr.prototype.getBoost = function(a) {
        if (!(a instanceof Array)) {
        }
    };
    CQ_Analytics.SegmentMgr.prototype.reload = function(path) {
        var url = path;
        if (!url) {
        }
        if (url) {
            }
            try {
                    if (response && response.responseText) {
                        eval(response.responseText)
                    }
                }, this);
        }
    };
    CQ_Analytics.SegmentMgr.prototype.getSessionStore = function() {
    };
    CQ_Analytics.SegmentMgr.prototype.getProperty = function(a) {
        return a
    };
    CQ_Analytics.SegmentMgr.prototype.getLink = function(a) {
        return a + ".html"
    };
    CQ_Analytics.SegmentMgr.prototype.getLabel = function(c) {
        if (c) {
            var b = c;
            var a = b.lastIndexOf("/");
            if (a != -1) {
                b = b.substring(a + 1, b.length)
            }
            if (d === true) {
                return b
            } else {
                if (d !== true) {
                    return '<span class="invalid" title="' + d + '" alt="' + d + '">' + b + "</span>"
                }
            }
        }
        return c
    };
    CQ_Analytics.SegmentMgr.prototype.getPropertyNames = function() {
    };
    CQ_Analytics.SegmentMgr = new CQ_Analytics.SegmentMgr();
    CQ_Analytics.SegmentMgr.loadSegments = function(a) {
    };
    CQ_Analytics.SegmentMgr.renderer = function(a, c) {
            var e = a.getPropertyNames();
            var f = [];
            f.push("<div>");
            for (var d = 0; d < e.length; d++) {
                var b = e[d];
            }
            f.push("</div>");
            $CQ("#" + c).children().remove();
            $CQ("#" + c).append(f.join(""))
        }
    };
    CQ_Analytics.ClientContextMgr.addListener("storeupdate", CQ_Analytics.SegmentMgr.fireUpdate);
    CQ_Analytics.Utils.addListener(window, "unload", function() {
        try {
            }
    })
}
if (!CQ_Analytics.StrategyMgr) {
    CQ_Analytics.StrategyMgr = function() {
    };
    CQ_Analytics.StrategyMgr.prototype = {};
    CQ_Analytics.StrategyMgr.prototype.isRegistered = function(a) {
    };
    CQ_Analytics.StrategyMgr.prototype.register = function(b, a) {
        if (typeof a == "function") {
        }
    };
    CQ_Analytics.StrategyMgr.prototype.choose = function(b, a) {
        if (a.length == 1) {
            return a[0]
        }
        }
        return null
    };
    CQ_Analytics.StrategyMgr = new CQ_Analytics.StrategyMgr()
}
CQ_Analytics.StrategyMgr.register("clickstream-score", function(h) {
    if (h.length == 1) {
        return h[0]
    }
    var a = [];
        m = m || {};
        var l = -1;
        for (var e = 0; e < h.length; e++) {
            var g = 0;
            var k = h[e].tags;
            if (k) {
                for (var d = 0; d < k.length; d++) {
                    var f = k[d].tagID;
                    g += parseInt(m[f]) || 0
                }
            }
            if (g == l) {
                a.push(h[e])
            } else {
                if (g > l) {
                    a = [];
                    a.push(h[e]);
                    l = g
                }
            }
        }
    } else {
        a = h
    }
    if (a.length == 1) {
        return a[0]
    }
    var b = null;
    }
    if (!b) {
    }
    if (!b) {
    }
    if (parseFloat(b) > 1) {
        b = 1 / b
    }
    if (parseFloat(b) == 1) {
        b = 0
    }
    var c = Math.floor(b * a.length);
    return a[c]
});
CQ_Analytics.StrategyMgr.register("first", function(a) {
    return a[0]
});
CQ_Analytics.StrategyMgr.register("random", function(c) {
    var a = null;
    }
    if (!a) {
    }
    if (!a) {
    }
    if (parseFloat(a) > 1) {
        a = 1 / a
    }
    if (parseFloat(a) == 1) {
        a = 0
    }
    var b = Math.floor(a * c.length);
    return c[b]
});
if (!CQ_Analytics.PageDataMgr) {
    CQ_Analytics.PageDataMgr = function() {};
    CQ_Analytics.PageDataMgr.prototype = new CQ_Analytics.SessionStore();
    CQ_Analytics.PageDataMgr.prototype.STORENAME = "pagedata";
    CQ_Analytics.PageDataMgr.prototype.FORCE_EXPERIENCE_COOKIE = "aem-forceexperience";
    CQ_Analytics.PageDataMgr.prototype.init = function() {
        }
    };
    CQ_Analytics.PageDataMgr.prototype.getLabel = function(a) {
        return a
    };
    CQ_Analytics.PageDataMgr.prototype.getLink = function(a) {
        return ""
    };
    CQ_Analytics.PageDataMgr.prototype.setExperience = function(a) {
    };
    CQ_Analytics.PageDataMgr.prototype.getExperience = function() {
    };
    CQ_Analytics.PageDataMgr.prototype.clearExperience = function() {
    };
    CQ_Analytics.PageDataMgr = new CQ_Analytics.PageDataMgr();
    CQ_Analytics.CCM.addListener("configloaded", function() {
    }, CQ_Analytics.PageDataMgr)
}
CQ_Analytics.BrowserInfo = function() {
    var d = function(b) {
        return b.test(g)
    };
    var f = function() {
        if (d(/opera/)) {
            return {
                browserFamily: "Opera",
                browserVersion: ""
            }
        }
        if (d(/chrome/)) {
            return {
                browserFamily: "Chrome",
                browserVersion: ""
            }
        }
        if (d(/safari/)) {
            if (d(/applewebkit\/4/)) {
                return {
                    browserFamily: "Safari",
                    browserVersion: "2"
                }
            }
            if (d(/version\/3/)) {
                return {
                    browserFamily: "Safari",
                    browserVersion: "3"
                }
            }
            if (d(/version\/4/)) {
                return {
                    browserFamily: "Safari",
                    browserVersion: "4"
                }
            }
            if (d(/version\/5/)) {
                return {
                    browserFamily: "Safari",
                    browserVersion: "5"
                }
            }
            if (d(/version\/6/)) {
                return {
                    browserFamily: "Safari",
                    browserVersion: "6"
                }
            }
            return {
                browserFamily: "Safari",
                browserVersion: "7 or higher"
            }
        }
        if (d(/webkit/)) {
            return {
                browserFamily: "WebKit",
                browserVersion: ""
            }
        }
        if (d(/msie/)) {
            if (d(/msie 6/)) {
                return {
                    browserFamily: "IE",
                    browserVersion: "6"
                }
            }
            if (d(/msie 7/)) {
                return {
                    browserFamily: "IE",
                    browserVersion: "7"
                }
            }
            if (d(/msie 8/)) {
                return {
                    browserFamily: "IE",
                    browserVersion: "8"
                }
            }
            if (d(/msie 9/)) {
                return {
                    browserFamily: "IE",
                    browserVersion: "9"
                }
            }
            if (d(/msie 10/)) {
                return {
                    browserFamily: "IE",
                    browserVersion: "10"
                }
            }
            return {
                browserFamily: "IE",
                browserVersion: "11 or higher"
            }
        }
        if (d(/gecko/)) {
            if (d(/rv:1\.8/)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "2"
                }
            }
            if (d(/rv:1\.9/)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "3"
                }
            }
            if (d(/rv:2.0/)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "4"
                }
            }
            if (d(/rv:5./)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "5"
                }
            }
            if (d(/rv:6./)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "6"
                }
            }
            if (d(/rv:7./)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "7"
                }
            }
            if (d(/rv:8./)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "8"
                }
            }
            if (d(/rv:9./)) {
                return {
                    browserFamily: "Firefox",
                    browserVersion: "9"
                }
            }
            return {
                browserFamily: "Firefox",
                browserVersion: "10 or higher"
            }
        }
        var b = d(/adobeair/);
        if (b) {
            return {
                browserFamily: "Adobe AIR",
                browserVersion: ""
            }
        }
        return {
            browserFamily: "Unresolved",
            browserVersion: "Unresolved"
        }
    };
    var e = function() {
        if (d(/windows 98|win98/)) {
            return "Windows 98"
        }
        if (d(/windows nt 5.0|windows 2000/)) {
            return "Windows 2000"
        }
        if (d(/windows nt 5.1|windows xp/)) {
            return "Windows XP"
        }
        if (d(/windows nt 5.2/)) {
            return "Windows Server 2003"
        }
        if (d(/windows nt 6.0/)) {
            return "Windows Vista"
        }
        if (d(/windows nt 6.1/)) {
            return "Windows 7"
        }
        if (d(/windows nt 4.0|winnt4.0|winnt/)) {
            return "Windows NT 4.0"
        }
        if (d(/windows me/)) {
            return "Windows ME"
        }
        if (d(/mac os x/)) {
            if (d(/ipad/) || d(/iphone/)) {
                return "iOS"
            }
            return "Mac OS X"
        }
        if (d(/macintosh|mac os/)) {
            return "Mac OS"
        }
        if (d(/android/)) {
            return "Android"
        }
        if (d(/linux/)) {
            return "Linux"
        }
        return "Unresolved"
    };
    var c = function() {
        if (d(/ipad/)) {
            return "iPad"
        }
        if (d(/iphone/)) {
            return "iPhone"
        }
        if (d(/mobi/)) {
            return "Mobile"
        }
        return "Desktop"
    };
    var a = f.call();
};
CQ_Analytics.BrowserInfo.prototype = {
    getBrowserName: function() {
    },
    getBrowserFamily: function() {
    },
    getBrowserVersion: function() {
    },
    getOSName: function() {
    },
    getScreenResolution: function() {
    },
    getDeviceType: function() {
    },
    getUserAgent: function() {
    },
    isMobile: function(a) {
        if (!a) {
        }
        return a != "desktop"
    },
    isIE: function(a) {
    },
    isIE6: function() {
    },
    isIE7: function() {
    },
    isIE8: function() {
    },
    isIE9: function() {
    }
};
CQ_Analytics.BrowserInfoInstance = new CQ_Analytics.BrowserInfo();
if (!CQ_Analytics.MousePositionMgr) {
    CQ_Analytics.MousePositionMgr = function() {
            x: 0,
            y: 0
        };
            var b = c.pageX;
            if (!b && 0 !== b) {
                b = c.clientX || 0
            }
            return b
        };
            var c = b.pageY;
            if (!c && 0 !== c) {
                c = b.clientY || 0
            }
            return c
        };
        $CQ(document).bind("mousemove", function(h, g, f, l) {
            if (j) {
                if (!a.timer) {
                    var d = a.getPageX(j);
                    var k = a.getPageY(j);
                    a.timer = setTimeout(function() {
                        a.setPosition(d, k);
                        a.timer = null
                    }, 500)
                }
            }
        });
    };
    CQ_Analytics.MousePositionMgr.prototype = new CQ_Analytics.SessionStore();
    CQ_Analytics.MousePositionMgr.prototype.STORENAME = "mouseposition";
    CQ_Analytics.MousePositionMgr.prototype.setPosition = function(a, b) {
    };
    CQ_Analytics.MousePositionMgr.prototype.getProperty = function(a) {
    };
    CQ_Analytics.MousePositionMgr.prototype.getLabel = function(a) {
        return a
    };
    CQ_Analytics.MousePositionMgr.prototype.getLink = function(a) {
        return ""
    };
    CQ_Analytics.MousePositionMgr.prototype.getPropertyNames = function() {
        var a = new Array();
            a.push(b)
        }
        return a
    };
    CQ_Analytics.MousePositionMgr.prototype.getSessionStore = function() {
    };
    CQ_Analytics.MousePositionMgr.prototype.getData = function(a) {
    };
    CQ_Analytics.MousePositionMgr.prototype.clear = function() {
    };
    CQ_Analytics.MousePositionMgr = new CQ_Analytics.MousePositionMgr();
    CQ_Analytics.CCM.addListener("configloaded", function() {
    }, CQ_Analytics.MousePositionMgr)
}
if (!CQ_Analytics.EventDataMgr) {
    CQ_Analytics.EventDataMgr = function() {};
    CQ_Analytics.EventDataMgr.prototype = new CQ_Analytics.SessionStore();
    CQ_Analytics.EventDataMgr.prototype.STORENAME = "eventdata";
    CQ_Analytics.EventDataMgr.prototype.init = function() {
        }
    };
    CQ_Analytics.EventDataMgr.prototype.getLabel = function(a) {
        return a
    };
    CQ_Analytics.EventDataMgr.prototype.getLink = function(a) {
        return ""
    };
    CQ_Analytics.EventDataMgr = new CQ_Analytics.EventDataMgr();
    CQ_Analytics.CCM.addListener("configloaded", function() {
    }, CQ_Analytics.EventDataMgr)
}
if (!window.CQ_Context) {
    window.CQ_Context = function() {};
    window.CQ_Context.prototype = new CQ_Analytics.Observable();
    window.CQ_Context.prototype.getProfile = function() {
        return (function() {
            return {
                getUserId: function() {
                },
                getDisplayName: function() {
                    if (a) {
                        return a
                    }
                    if (a) {
                        return a
                    }
                },
                getFirstname: function() {
                },
                getLastname: function() {
                },
                getEmail: function() {
                },
                getProperty: function(a) {
                    }
                    return ""
                },
                getProperties: function() {
                    }
                    return {}
                },
                getAvatar: function() {
                },
                onUpdate: function(a, b) {
                    }
                }
            }
        })()
    };
    window.CQ_Context = new window.CQ_Context()
}
CQ_Analytics.Engine = function() {

    function h() {
    }

    function c(m) {
        if (l) {
            k.resolve(l)
        } else {
                k.resolve(n)
            })
        }
        return k.promise()
    }

    function f(l, k) {
            $CQ(window).unload(function() {
                try {
                    if (m) {
                        var o = k;
                        for (var p = 0; p < m.length; p++) {
                        }
                    }
            })
        }
    }

    function d(q, p, m) {
        var o = "",
            r;

        function k(w, v, x, u) {
            return '<a href="' + v + '" class="aem-teaser-segment-link"><img src="' + x + '" class="aem-teaser-decision-thumbnail ' + (u ? "aem-teaser-decision-match" : "aem-teaser-decision-nomatch") + '"></a>' + w + "<br>"
        }
        for (var n = 0; n < q.length; n++) {
            var l = q[n];
            if (l.hasOwnProperty("boost")) {
                if (l.noSegment) {
                } else {
                }
                var s = k(r, t, l.teaser.thumbnail, true);
                if (p === l.teaser.path) {
                    o += "<b>" + s + "</b>"
                } else {
                    o += s
                }
            } else {
                if (l.unknownSegment) {
                } else {
                }
                o += k(r, t, l.teaser.thumbnail, false)
            }
        }
        o += "<br>";
        if (m) {
        } else {
        }
        o += "<br>";
        return o
    }

    function j(m, l, k, n) {
        m.done(function(o) {
            if (o.teaserToolTip) {
                o.teaserToolTip.hide();
                o.teaserToolTip.remove()
            }
                html: d(l, k, n),
                width: 450,
                autoHide: false,
                closable: true,
                height: 300,
                floating: true,
                autoHeight: false,
                bodyStyle: "overflow-y: scroll;"
            });
                        tag: "div",
                        cls: "x-tool x-tool-help aem-teaser-tooltip-tool"
                    }, true);
                        o.teaserToolTip.setPosition(q[0] - 460, q[1] - 100);
                        o.teaserToolTip.show()
                    })
                }
            });
                }
            })
        })
    }

    function g(k) {
        k.done(function(l) {
            if (l.teaserToolTip) {
                l.teaserToolTip.hide();
                l.teaserToolTip.remove();
            }
        })
    }

    function b(t, s) {
        var o = [];
        var q = 0;
        for (var m = 0; m < t.length; m++) {
            var l = t[m],
                p = l.segments;
            var k;
            if (s) {
                k = {
                    teaser: l
                };
                s.push(k)
            }
            var n = !p || p.length === 0;
            if (n && k) {
                k.noSegment = true
            }
                n = true;
                if (p && p.length > 0) {
                        n = false;
                        if (k) {
                            k.unknownSegment = true
                        }
                    }
                }
            }
            if (n) {
                if (k) {
                    k.boost = r
                }
                if (r === q) {
                    o.push(l)
                } else {
                    if (r > q) {
                        o = [];
                        o.push(l);
                        q = r
                    }
                }
            }
        }
        return o
    }
    var a = {};

    function e(k, l) {
        a[k] = l
    }
    return {
        stopTeaserLoader: function(l) {
            var k = l.path || l;
            if (!k) {
                return
            }
            var m = a[k];
            if (m) {
                delete a[k]
            }
        },
        resolveTeaser: function(n, m, k) {
            var l = b(n, k);
            if (l.length === 0) {
                return null
            }
        },
        loadTeaser: function(k) {
            var n, m;
            if (h()) {
                n = c(m)
            }
            if (o && o.isCampaignSelected()) {
                return
            }
            var l = function() {
                if (r) {
                    var s = "/_jcr_content/par.html";
                    if (h()) {
                        s += "?wcmmode=disabled"
                    }
                    return
                }
                var q = null;
                var p = function() {
                    var u = null;
                    if (h()) {
                        u = []
                    }
                    if (v) {
                        if (!q || q.path !== v.path) {
                            q = v;
                            var t = v.url;
                            if (h()) {
                                t += "?wcmmode=disabled"
                            }
                                f(v, k.trackingURL)
                            }
                            if (n) {
                                j(n, u, q.path, k.strategy)
                            }
                        }
                    } else {
                        if (n) {
                            g(n)
                        }
                        q = null
                    }
                };
                p.call();
                    if (m) {
                        e(m, p)
                    }
                }
            };
                l.call(this)
            } else {
            }
        }
    }
}();
window.CQ_trackTeasersStats = true;

function initializeTeaserLoader(b, f, g, e, a, d) {
        var c = function() {
            var n = "/_jcr_content/par.html";
            if (e) {
                n += "?wcmmode=disabled"
            }
            if (l) {
                return
            }
            var m = function(q) {
                var s = "";
                var w = new Array();
                    var u = 0;
                    for (var r = 0; r < b.length; r++) {
                            var v = [b[r]["title"], o, b[r].thumbnail, t];
                            if (q == b[r].path) {
                            } else {
                            }
                            if (o == u) {
                                w.push(b[r])
                            } else {
                                if (o > u) {
                                    w = new Array();
                                    w.push(b[r]);
                                    u = o
                                }
                            }
                        } else {
                            var v = [b[r]["title"], b[r].thumbnail, t];
                        }
                    }
                }
                return s
            };
            var k = null;
            var h = null;
            var j = function() {
                var v = new Array();
                    var t = 0;
                    for (var r = 0; r < b.length; r++) {
                            if (o == t) {
                                v.push(b[r])
                            } else {
                                if (o > t) {
                                    v = new Array();
                                    v.push(b[r]);
                                    t = o
                                }
                            }
                        }
                    }
                }
                if (v.length > 0) {
                    var u = v[0];
                        if (s != null) {
                            u = s
                        }
                    }
                    if (!k || k.path != u.path) {
                        k = u;
                        var p = u.path + n;
                                $CQ(window).unload(function() {
                                    try {
                                        if (w) {
                                            var y = a;
                                            for (var z = 0; z < w.length; z++) {
                                            }
                                        }
                                })
                            }
                        }
                        if (e) {
                            if (d) {
                                if (q) {
                                    if (q && q.teaserToolTip) {
                                        q.teaserToolTip.hide();
                                        q.teaserToolTip.remove();
                                        q.teaserToolTip = null
                                    } else {
                                                    tag: "div",
                                                    cls: "x-tool x-tool-help aem-teaser-tooltip-tool"
                                                }, true);
                                                    if (!q.teaserToolTip) {
                                                            html: m(k.path),
                                                            width: 450,
                                                            autoHide: false,
                                                            closable: true,
                                                            height: 300,
                                                            floating: true,
                                                            autoHeight: false,
                                                            bodyStyle: "overflow-y: scroll;"
                                                        })
                                                    }
                                                    q.teaserToolTip.setPosition(x[0] - 460, x[1] - 100);
                                                    q.teaserToolTip.show()
                                                })
                                            }
                                        });
                                            }
                                        })
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if (e) {
                        if (q && q.teaserToolTip) {
                            q.teaserToolTip.hide();
                            q.teaserToolTip.remove();
                            q.teaserToolTip = null
                        }
                    }
                    k = null
                }
            };
            j.call();
            }
        };
            c.call(this)
        } else {
        }
    }
}
window.CQ_trackLandingPagesStats = true;

function initializeLandingPageLoader(f, d, e, c, a) {
        var g = ".html";
        var b = function() {
            var j = null;
            var h = function() {
                var l = new Array();
                    var s = 0;
                    for (var p = 0; p < f.length; p++) {
                            if (v == s) {
                                l.push(f[p])
                            } else {
                                if (v > s) {
                                    l = new Array();
                                    l.push(f[p]);
                                    s = v
                                }
                            }
                        }
                    }
                }
                if (l.length > 0) {
                    var o = l[0];
                        if (t != null) {
                            o = t
                        }
                    }
                    if (!j || j.path != o.path) {
                        var x = j;
                        j = o;
                        var y = n.responseText;
                        var q = function(K, A) {
                            var H = "";
                            if (K && K.indexOf('id="' + A + '"') != -1) {
                                var G = K.indexOf('id="' + A + '"');
                                var B = K.substring(0, G).lastIndexOf("<div");
                                var F = K.substring(B);
                                var J = F.split(new RegExp("<div", "ig"));
                                var D = 0;
                                for (var E = 0; E < J.length; E++) {
                                    D++;
                                    var I = J[E].split(new RegExp("</div", "ig"));
                                    for (var C = 1; C < I.length; C++) {
                                        D--;
                                        if (D == 1) {
                                            var z = J[E].lastIndexOf("</div") + 6;
                                            z = F.indexOf(J[E]) + z;
                                            F = F.substring(0, z);
                                            F = F.substring(F.indexOf(">") + 1, F.lastIndexOf("</div"));
                                            return F
                                        }
                                    }
                                }
                            }
                            return ""
                        };
                        y = q(y, e);
                        var u = $CQ("#" + e)[0];
                        var r = function(B, z) {
                            if (c) {
                                for (var D in C) {
                                    var A = C[D];
                                    if (!B || A.path.indexOf(B) != -1) {
                                        A.hide();
                                        A.remove()
                                    }
                                }
                            }
                        };
                        m.innerHTML = y;
                        if (x) {
                            $CQ("object", u).parent().fadeOut("slow");
                            $CQ("img", u).fadeOut("slow");
                            $CQ(u).slideUp("slow", function() {
                                r(x.path, false);
                                $CQ(u).children().remove();
                                var z = u.insertBefore(m, u.firstChild);
                                $CQ(u).slideDown("slow", function() {
                                    if (c) {
                                    }
                                })
                            })
                        } else {
                            var k = u.insertBefore(m, u.firstChild);
                            $CQ(u).slideDown("slow", function() {
                                if (c) {
                                }
                            })
                        }
                        try {
                                    $CQ(window).unload(function() {
                                        try {
                                            if (C) {
                                                var A = a;
                                                for (var B = 0; B < C.length; B++) {
                                                }
                                            }
                                    })
                                }
                            }
                    }
                } else {
                    j = null
                }
            };
            h.call();
            }
        };
                b.call(this)
            } else {
            }
        }
    }
}
CQ_Analytics.PersistedJSONStore = function() {};
CQ_Analytics.PersistedJSONStore.prototype = new CQ_Analytics.PersistedSessionStore();
CQ_Analytics.PersistedJSONStore.prototype.STOREKEY = "";
CQ_Analytics.PersistedJSONStore.prototype.STORENAME = "";
CQ_Analytics.PersistedJSONStore.prototype.init = function() {
        container: "ClientContext"
    });
    if (!b || b == "") {
        }
    } else {
    }
};
CQ_Analytics.PersistedJSONStore.prototype.clear = function() {
        container: "ClientContext"
    });
};
CQ_Analytics.PersistedJSONStore.prototype.initJSON = function(b, c) {
    if (!c) {
    }
    var a = function(g, d, f) {
        for (var e in f) {
            if (typeof f[e] == "object") {
                a(g, d ? d + "/" + e : e, f[e])
            } else {
            }
        }
    };
};
CQ_Analytics.PersistedJSONStore.prototype.getJSON = function() {
    var c = {};
    for (var g in e) {
        var d = g.split("/");
        var f = c;
        for (var b = 0; b < d.length; b++) {
            var a = d[b];
            if (b == d.length - 1) {
                f[a] = e[g]
            } else {
                f[a] = f[a] || {};
                f = f[a]
            }
        }
    }
    return c
};
CQ_Analytics.PersistedJSONStore.getInstance = function(a, c) {
    b.STOREKEY = a.toUpperCase();
    b.STORENAME = a;
    b.initJSON(c);
    return b
};
CQ_Analytics.PersistedJSONStore.registerNewInstance = function(a, b) {
    c.init();
    return c
};
CQ_Analytics.JSONStore = function() {};
CQ_Analytics.JSONStore.prototype = new CQ_Analytics.SessionStore();
CQ_Analytics.JSONStore.prototype.STOREKEY = "";
CQ_Analytics.JSONStore.prototype.STORENAME = "";
CQ_Analytics.JSONStore.prototype.init = function() {
    }
};
CQ_Analytics.JSONStore.prototype.clear = function() {
};
CQ_Analytics.JSONStore.prototype.initJSON = function(b, c) {
    if (!c) {
    }
    var a = function(g, d, f) {
        for (var e in f) {
            if (typeof f[e] == "object") {
                a(g, d ? d + "/" + e : e, f[e])
            } else {
            }
        }
    };
};
CQ_Analytics.JSONStore.prototype.getJSON = function() {
    var c = {};
    for (var g in e) {
        var d = g.split("/");
        var f = c;
        for (var b = 0; b < d.length; b++) {
            var a = d[b];
            if (b == d.length - 1) {
                f[a] = e[g]
            } else {
                f[a] = f[a] || {};
                f = f[a]
            }
        }
    }
    return c
};
CQ_Analytics.JSONStore.getInstance = function(a, c) {
    b.STOREKEY = a.toUpperCase();
    b.STORENAME = a;
    b.initJSON(c);
    return b
};
CQ_Analytics.JSONStore.registerNewInstance = function(a, b) {
    c.init();
    return c
};
CQ_Analytics.PersistedJSONPStore = function() {};
CQ_Analytics.PersistedJSONPStore.prototype = new CQ_Analytics.PersistedJSONStore();
CQ_Analytics.PersistedJSONPStore.prototype.setServiceURL = function(a) {
};
CQ_Analytics.PersistedJSONPStore.prototype.getServiceURL = function() {
};
CQ_Analytics.PersistedJSONPStore.prototype.load = function(d, a, e) {
            if (f) {
                f.initJSON(g);
                if (a) {
                    f.initJSON(a, true)
                }
            }
            if (e) {
                e.call(f)
            }
        }
    }
    if (d) {
    }
    b = b.replace("${callback}", "CQ_Analytics.PersistedJSONPStore.JSONPCallbacks." + c);
};
CQ_Analytics.PersistedJSONPStore.JSONPCallbacks = {};
CQ_Analytics.PersistedJSONPStore.getInstance = function(e, f, b, a, d) {
    if (e && f) {
        try {
            g.STOREKEY = e.toUpperCase();
            g.STORENAME = e;
            if (f) {
                g.setServiceURL(f)
            }
            if (!a) {
                g.load(f, b, d)
            }
            return g
        }
    }
    return null
};
CQ_Analytics.PersistedJSONPStore.registerNewInstance = function(d, e, b, f) {
    if (!e) {
        return null
    }
    if (!d) {
        if (a) {
            if (a.indexOf(".") != -1) {
                a = a.substring(0, a.lastIndexOf("."));
            } else {
            }
        } else {
        }
    }
        if (f) {
            f.call(this)
        }
    });
    if (c != null) {
        return c
    }
    return null
};
CQ_Analytics.JSONPStore = function() {};
CQ_Analytics.JSONPStore.prototype = new CQ_Analytics.JSONStore();
CQ_Analytics.JSONPStore.prototype.setServiceURL = function(a) {
};
CQ_Analytics.JSONPStore.prototype.getServiceURL = function() {
};
CQ_Analytics.JSONPStore.prototype.load = function(d, a, e) {
            if (f) {
                f.initJSON(g);
                if (a) {
                    f.initJSON(a, true)
                }
            }
            if (e) {
                e.call(f)
            }
        }
    }
    if (d) {
    }
    b = b.replace("${callback}", "CQ_Analytics.JSONPStore.JSONPCallbacks." + c);
};
CQ_Analytics.JSONPStore.JSONPCallbacks = {};
CQ_Analytics.JSONPStore.getInstance = function(e, f, b, a, d) {
    if (e) {
        try {
            g.STOREKEY = e.toUpperCase();
            g.STORENAME = e;
            if (f) {
                g.setServiceURL(f);
                if (!a) {
                    g.load(f, b, d)
                }
            }
            return g
        }
    }
    return null
};
CQ_Analytics.JSONPStore.registerNewInstance = function(d, e, b, f) {
    if (!d && e) {
        if (a) {
            if (a.indexOf(".") != -1) {
                a = a.substring(0, a.lastIndexOf("."));
            } else {
            }
        } else {
        }
    }
        if (f) {
            f.call(this)
        }
    });
    if (c != null) {
        return c
    }
    return null
};
CQ_Analytics.storeData = function(e, w) {
    var n = function(p, l) {
            if (j[p] === l) {
                return j
            }
        }
        return null
    };
    var s = function(j) {
        if (typeof j === "string") {
            return j.replace(/[,;=\|]/g, "")
        }
        return j
    };
    for (var v in w) {
        if (v !== "product") {
            var o = v.indexOf(".");
            var r = (o > 0) ? v.substr(0, o - 1) : undefined;
            var x = (o > 0) ? v.substr(o) : v;
            }
            e.setProperty(x, w[v])
        } else {
            var m = ["category", "sku", "quantity", "price", "events", "evars"];
            var c = e.getProperty("products").split(",");
            c = (c[0] == "") ? new Array() : c;
            var w = (w[v] instanceof Array) ? w[v] : [w[v]];
            for (var h = 0; h < w.length; h++) {
                var q = w[h];
                var b = new Array(6);
                for (var u in q) {
                    var o = m.indexOf(u);
                    if (o > -1) {
                        if (o < 4) {
                            b[o] = s(q[u])
                        } else {
                            var f = [];
                            for (var t in q[u]) {
                                var d = e.getName() + "." + v + "." + u + "." + t;
                                var g = n("cqVar", d);
                                if (g) {
                                    f.push(g.scVar + "=" + s(q[u][t]));
                                    var a = e.getProperty("events").split("\u2026");
                                    if (a.indexOf(g.cqVar) < 0) {
                                        a.push(g.cqVar.replace(/.+\./, ""));
                                        e.setProperty("events", a.join("\u2026"))
                                    }
                                }
                            }
                            b[o] = f.join("|")
                        }
                    }
                }
                c.push(b.join(";"))
            }
            e.setProperty("products", c.join(","))
        }
    }
};
CQ_Analytics.record = function(b) {
    if (b.collect) {
        return [b.event, b.values]
    } else {
        if (b.event) {
            try {
                    return f.rank - e.rank
                });
                        return
                    }
                }
            a.reset();
            if (typeof b.event == "string") {
                a.setProperty("events", b.event)
            } else {
                a.setProperty("events", b.event.join("\u2026"))
            }
            if (b.values) {
            }
            try {
                    return f.rank - e.rank
                });
                        return
                    }
                }
        }
    }
};
CQ_Analytics.recordBeforeCallbacks = [];
CQ_Analytics.recordAfterCallbacks = [];
CQ_Analytics.registerBeforeCallback = function(b, a) {
        rank: a,
        func: b
    })
};
CQ_Analytics.registerAfterCallback = function(b, a) {
        rank: a,
        func: b
    })
};
if (!CQ_Analytics.ProfileDataMgr) {
    CQ_Analytics.ProfileDataMgr = function() {
        }, this)
    };
    CQ_Analytics.ProfileDataMgr.prototype = new CQ_Analytics.PersistedSessionStore();
    CQ_Analytics.ProfileDataMgr.prototype.STOREKEY = "PROFILEDATA";
    CQ_Analytics.ProfileDataMgr.prototype.STORENAME = "profile";
    CQ_Analytics.ProfileDataMgr.prototype.LOADER_PATH = CQ_Analytics.Utils.externalize("/libs/cq/personalization/components/profileloader/content/load.js", true);
    CQ_Analytics.ProfileDataMgr.prototype.PROFILE_LOADER = CQ_Analytics.Utils.externalize("/libs/cq/personalization/components/profileloader/content/load.json", true);
    CQ_Analytics.ProfileDataMgr.prototype.init = function() {
            container: "ClientContext"
        });
            if (!f) {
                return
            }
                    container: "",
                });
                var e = c.get(f.key);
                if (f.key === "PROFILEDATA" && (!e || e == "") && f.action != "set") {
                }
                c.set(f.key, f.value)
            }
        });
        if (!a || a == "") {
            }
        } else {
        }
    };
    CQ_Analytics.ProfileDataMgr.prototype.checkAuthorizableId = function() {
        }
        } else {
        }
    };
    CQ_Analytics.ProfileDataMgr.prototype.getLabel = function(a) {
        return a
    };
    CQ_Analytics.ProfileDataMgr.prototype.getLink = function(a) {
        return ""
    };
    CQ_Analytics.ProfileDataMgr.prototype.clear = function() {
        }
    };
    CQ_Analytics.ProfileDataMgr.prototype.getLoaderURL = function() {
    };
    CQ_Analytics.ProfileDataMgr.prototype.loadProfile = function(authorizableId) {
        try {
            if (object) {
                for (var p in object) {
                }
                }
                return true
            }
            }
        }
        return false
    };
    CQ_Analytics.ProfileDataMgr = new CQ_Analytics.ProfileDataMgr();
    CQ_Analytics.CCM.addListener("configloaded", function() {
            if (j == "birthday" || !j) {
                var g = "";
                if (k) {
                    try {
                        var c = function(o, n) {
                            var m = new Date(n.getTime());
                            m.setUTCHours(o.getUTCHours(), o.getUTCMinutes(), o.getUTCSeconds(), o.getUTCMilliseconds());
                            var p = m.getTime() - o.getTime();
                            return p / (1000 * 60 * 60 * 24)
                        };
                        var d = function(m) {
                            var n = new Date(m.getFullYear(), 0, 0);
                            return c(m, n) * -1
                        };
                        var h = new Date(Date.parse(k));
                        if (!isNaN(h.getTime())) {
                            var f = new Date();
                            if (d(h) == d(f) && h.getMonth() == f.getMonth()) {
                            } else {
                                var b = f.getFullYear() - h.getFullYear();
                                if (d(h) > d(f)) {
                                    g = b
                                } else {
                                    g = Math.max(0, b - 1)
                                }
                            }
                        } else {
                            g = ""
                        }
                        g = ""
                    }
                }
                if (l != g) {
                }
            }
        });
    }, CQ_Analytics.ProfileDataMgr)
}
if (!CQ_Analytics.ClientContext) {
    CQ_Analytics.ClientContext = new function() {
        return {
            get: function(f, c) {
                if (f) {
                    if (f.indexOf("/") != 0) {
                    }
                    var d = f.split("/")[1];
                    var b = f.substring(f.indexOf("/" + d) + d.length + 2, f.length);
                    if (a) {
                        if (b) {
                            var e = a.getProperty(b);
                            if (e && c) {
                            }
                            return e
                        }
                        return a
                    }
                }
                return null
            },
            set: function(e, d) {
                if (e) {
                    if (e.indexOf("/") != 0) {
                    }
                    var c = e.split("/")[1];
                    var b = e.substring(e.indexOf("/" + c) + c.length + 2, e.length);
                    if (a) {
                        if (b) {
                            a.setProperty(b, d)
                        }
                    }
                }
            },
            clear: function() {
                if (a) {
                    for (var b in a) {
                        if (a[b].clear) {
                            a[b].clear()
                        }
                    }
                }
            },
            reset: function() {
                if (a) {
                    for (var b in a) {
                        if (a[b].reset) {
                            a[b].reset()
                        }
                    }
                }
            },
            persist: function(a) {
            }
        }
    }();
    window.ClientContext = CQ_Analytics.ClientContext;
    window.ContextCloud = CQ_Analytics.ClientContext
};