_satellite.pushAsyncScript(function(event, target, $variables) {
    setTimeout(function() {


        try {

            if (ClickTaleGetPID() && ClickTaleGetUID() && ClickTaleGetSID()) {
                var clickTaleLink = 'https://dmz01.app.clicktale.com/Player.aspx?PID=' + ClickTaleGetPID() + '&UID=' + ClickTaleGetUID() + '&SID=' + ClickTaleGetSID();


                    // ForeSee Staging Embed Script v2.01
                    // DO NOT MODIFY BELOW THIS LINE *****************************************
                    ;
                    (function(g) {
                            am = d.createElement('script'),
                            h = d.head || d.getElementsByTagName("head")[0],
                            fsr = 'fsReady',
                            aex = {
                                "src": "//gateway.foresee.com/sites/acsorg/staging/gateway.min.js",
                                "type": "text/javascript",
                                "async": "true",
                                "data-vendor": "fs",
                                "data-role": "gateway"
                            };
                        for (var attr in aex) {
                            am.setAttribute(attr, aex[attr]);
                        }
                        h.appendChild(am);
                            var aT = '__' + fsr + '_stk__';
                            g[aT].push(arguments);
                        });
                    })(window);
                    // DO NOT MODIFY ABOVE THIS LINE *****************************************

                    // Un-comment out the function below when you are ready to input your variable
                    fsReady(function() {
                    });
                    ClickTaleEvent('Foresee Feedback Accepted');


                } else {
                    // ForeSee Production Embed Script v2.01
                    // DO NOT MODIFY BELOW THIS LINE *****************************************
                    ;
                    (function(g) {
                            am = d.createElement('script'),
                            h = d.head || d.getElementsByTagName("head")[0],
                            fsr = 'fsReady',
                            aex = {
                                "src": "//gateway.foresee.com/sites/acsorg/production/gateway.min.js",
                                "type": "text/javascript",
                                "async": "true",
                                "data-vendor": "fs",
                                "data-role": "gateway"
                            };
                        for (var attr in aex) {
                            am.setAttribute(attr, aex[attr]);
                        }
                        h.appendChild(am);
                            var aT = '__' + fsr + '_stk__';
                            g[aT].push(arguments);
                        });
                    })(window);
                    // DO NOT MODIFY ABOVE THIS LINE *****************************************

                    // Un-comment out the function below when you are ready to input your variable
                    fsReady(function() {
                    });
                    ClickTaleEvent('Foresee Feedback Accepted');
                }

            } else {
            }


        }
    }, 1500);

});