_satellite.pushAsyncScript(function(event, target, $variables) {
        ! function(d, t, u) {

            function injectTag() {
                var ns = d.createElementNS;
                var a = ns ? ns.call(d, "http://www.w3.org/1999/xhtml", t) : d.createElement(t),
                    s = d.getElementsByTagName(t)[0];
                a.async = true;
                a.crossOrigin = "anonymous";
                a.type = "text/javascript";
                a.src = u;
                s.parentNode.insertBefore(a, s);
            }
            if (d.readyState != 'loading') {
                injectTag();
            } else {
                d.addEventListener('DOMContentLoaded', function() {
                    setTimeout(injectTag, 0)
                });
            }
        }(document, 'script', 'https://cdnssl.clicktale.net/www07/ptc/95b73f7d-f125-4d32-bd42-31a7ba37119a.js');
    }

});