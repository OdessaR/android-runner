_satellite.pushAsyncScript(function(event, target, $variables) {
    // new youtube **
            el.addEventListener(type, fn, !1);
        } : function(el, type, fn) {
            el.attachEvent("on" + type, fn);
        };
            var d = {};
            //skip looping video
            if (r.origin.match(/youtube\.com/) && typeof JSON != 'undefined' && r.origin.indexOf("loop=1") == -1) {
                d = JSON.parse(r.data);
                    v;
                // video info
                if (d.event == 'infoDelivery') {
                    var v = {},
                        id;
                    if (d.info.videoData) {
                        id = d.info.videoData.video_id;
                        v = videos[id] || {};
                        v.info = d.info;
                        v.id = d.id;
                        videos[id] = v;
                    }
                        if (vid.id == d.id) {
                            v = vid;
                        }
                    }
                    //video start
                    if (v.info) {
                        if (Math.abs(d.info.currentTime - v.info.currentTime) > 1.5) {
                            if (sc.track === true) {
                                sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                                if (v.state != 'paused') {
                                    sc.s().Media.play(v.info.videoData.title, d.info.currentTime);
                                }
                            }
                        }
                        v.info.currentTime = d.info.currentTime;
                    }
                    // video pause
                    if (d.info.playerState == 2) {
                        sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                        v.state = 'paused';
                    }
                    if (d.info.playerState == 1) {
                        // video start
                        if (!v.started) {
                            v.started = true;
                            if (sc.track === true) {
                                sc.s().Media.open(v.info.videoData.title, v.info.duration, 'youtube');
                                sc.s().Media.play(v.info.videoData.title, v.info.currentTime);
                            }
                        }
                        // video resume
                        else {
                            if (sc.track === true) {
                                sc.s().Media.play(v.info.videoData.title, v.info.currentTime);
                            }
                        }
                        v.state = 'playing';
                    }
                    // video buffer
                    if (d.info.playerState == 3 && v.started) {
                        if (sc.track === true) {
                            sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                        }
                        v.state = 'paused';
                    }
                    // video complete
                    if (d.info.playerState === 0) {
                        if (sc.track === true) {
                            sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                            sc.s().Media.close(v.info.videoData.title);
                        }
                        v.state = 'completed';
                    }
                } else if (d.event == 'onStateChange') {
                        if (vid.id == d.id) {
                            v = vid;
                        }
                    }
                    // video play
                    if (d.info == 1) {
                        // video start
                        if (!v.started) {
                            v.started = true;
                            if (sc.track === true) {
                                sc.s().Media.open(v.info.videoData.title, v.info.duration, 'youtube');
                                if (v.state != 'paused') {
                                    sc.s().Media.play(v.info.videoData.title, d.info.currentTime);
                                }
                            }
                        }
                        // video resume
                        else {
                            if (sc.track === true) {
                                sc.s().Media.play(v.info.videoData.title, v.info.currentTime);
                            }
                        }
                        v.state = 'playing';
                    }
                    // video pause
                    if (d.info == 2) {
                        if (sc.track === true) {
                            sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                        }
                        v.state = 'paused';
                    }
                    // video buffer
                    if (d.info == 3 && v.started) {
                        if (sc.track === true) {
                            sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                        }
                        v.state = 'paused';
                    }
                    // video complete
                    if (d.info === 0) {
                        if (sc.track === true) {
                            sc.s().Media.stop(v.info.videoData.title, v.info.currentTime);
                            sc.s().Media.close(v.info.videoData.title);
                        }
                        v.state = 'completed';
                    }
                }
            }
        });
            b.type = "text/javascript";
            if (a && typeof a == 'function') {
                if (b.readyState) {
                    b.onreadystatechange = function() {
                        if (b.readyState === "loaded" || b.readyState === "complete") {
                            b.onreadystatechange = null;
                            a();
                        }
                    };
                } else {
                    b.onload = function() {
                        a();
                    };
                }
            }
            b.src = c;
        };
        // youtube
            stages: {},
            players: {},
            sc: {
                track: true, // set to true if you want to use SiteCatalyst video measurement
                s: function() {
                }
            },
            init: function() {
                    api = false,
                    ids = [],
                for (var i = 0; i < scripts.length; i++) {
                    var script = scripts[i],
                        src = script.src || '';
                    if (src.match(/youtube\.com\/iframe_api/)) {
                        api = true;
                    }
                }
                if (api === false) {
                    });
                } else {
                }
            },
            ready: function(stage) {
                }
            },
            checkIframes: function() {
                    timeout = 1000,
                    videoNumber = 0;
                //jQuery('iframe[src*="youtube"][data-sdiyt!="true"]').each(function(idx, ifr) {
                jQuery('iframe[src*="youtube"]').each(function(idx, ifr) {
                    //don't tack looping video
                    if (ifr.src.indexOf("loop=1") != -1) {
                        var vid = null;
                    } else {
                        var vid = ifr.src.match(/h?t?t?p?s?\:?\/\/www\.youtube(-nocookie)?\.com\/embed\/([\w-]{11})(?:\?.*)?/),
                            id;
                    }
                        if (!ifr.id) {
                            videoNumber++;
                        }
                        var rewrite = false;
                        //only add optional "origin" param on HTTPS
                            //ifr.src += (ifr.src.indexOf('?')>-1 ? '&' : '?') + 'origin=https://'+document.location.host;
                            // rewrite = true;
                        }
                        if (!ifr.src.match(/enablejsapi=1/)) {
                            rewrite = true;
                        }
                            var frm = jQuery(this).clone();
                            frm.src = ifr.src;
                            frm.id = ifr.id;
                            jQuery(this).replaceWith(frm);
                        } else {
                                            "undefined")) {
                                            events: {
                                                onReady: function() {},
                                                onStateChange: function() {},
                                                videoId: ifr.id
                                            }
                                        });
                                        ifr.setAttribute('data-sdiyt', 'true');
                                    } else {
                                        ifr.setAttribute('data-sdiyt', 'true');
                                    }
                                } else {
                                    timeout = 100;
                                }
                            } else {
                                timeout = 100;
                            }
                        }
                    }
                });
                setTimeout(function() {
                }, timeout);
            },
            videos: {}
        };
            });
        }
    }
    /************** END YT ***************/

});