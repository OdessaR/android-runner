window.wpcom = window.wpcom || {};
window._tkq = window._tkq || [];
window._stq = window._stq || [];

function st_go(a) {
};

function ex_go(a) {
};

function re_go(a) {
};

function linktracker_init(b, p) {
};
if (!Array.prototype.forEach) {
    Array.prototype.forEach = function(fn, scope) {
        }
    };
}
window.wpcom.stats = (function() {
    var _clickTracker = (function() {
        var _blog, _post;
        var _addEvent = function(el, t, cb) {
            if ('function' === typeof el.addEventListener) {
                el.addEventListener(t, cb);
            } else if ('object' === typeof el.attachEvent) {
                el.attachEvent('on' + t, cb);
            }
        };
        var _getClickTarget = function(e) {
            if ('object' === typeof e && e.target) {
                return e.target;
            } else {
            }
        };
        var _clickTrack = function(e) {
            var d = 0;
            if (7 === _getIEVer()) d = 100;
            _processLink(_getClickTarget(e), d);
        };
        var _contextTrack = function(e) {
            _processLink(_getClickTarget(e), 0);
        };
        var _ignoreAnchor = function(a) {
            var p = a;
            while ('BODY' !== p.nodeName) {
                if ('wpcombar' === p.id) return true;
                if ('wpadminbar' === p.id) return true;
                if ('wpadvert' === p.className) return true;
                if (p.className.indexOf('wpcom-masterbar') > -1) return true;
                if ('undefined' === typeof p.nodeName) return true;
                if ('object' !== typeof p.parentNode) return true;
                p = p.parentNode;
            };
            return false;
        };
        var _isSameHost = function(a) {
            if (l.host === a.host) return true;
            if ('' === a.host) return true;
            if (l.protocol === a.protocol && l.host === a.hostname) {
                if ('http:' === l.protocol && l.host + ':80' === a.host) return true;
                if ('https:' === l.protocol && l.host + ':443' === a.host) return true;
            };
            return false;
        };
        var _processLink = function(a, d) {
            try {
                if ('object' !== typeof a) return;
                while ('A' !== a.nodeName) {
                    if ('undefined' === typeof a.nodeName) return;
                    if ('object' !== typeof a.parentNode) return;
                };
                if (_isSameHost(a)) return;
                if ('javascript:' === a.protocol) return;
                if (_ignoreAnchor(a)) return;
                    u: a.href,
                    r: ('undefined' !== typeof a.rel) ? a.rel : '0',
                    b: ('undefined' !== typeof _blog) ? _blog : '0',
                    p: ('undefined' !== typeof _post) ? _post : '0'
                }]);
                if (d) {
                    var now = new Date();
                    var end = now.getTime() + d;
                    while (true) {
                        now = new Date();
                        if (now.getTime() > end) {
                            break
                        }
                    }
                }
        };
        var API = {
            init: function(b, p) {
                _blog = b;
                _post = p;
                    _addEvent(document, 'click', _clickTrack);
                    _addEvent(document, 'contextmenu', _contextTrack);
                }
            }
        };
        return API;
    })();
    var _getIEVer = function() {
        var v = 0;
            if (null !== m) {
                v = parseInt(m[1]);
            }
        };
        return v;
    };
    var _serialize = function(o) {
        var p, q = [];
        for (p in o) {
            if (o.hasOwnProperty(p)) {
                q.push(encodeURIComponent(p) + '=' + encodeURIComponent(o[p]));
            }
        };
        return q.join('&');
    };
    var _loadGif = function(t, q, id) {
        i.alt = ":)";
            i.id = id;
        }
    };
    var STQ = function(q) {
        if (q && q.length) {
            for (var i = 0; i < q.length; i++) {
            }
        }
    };
    STQ.prototype.push = function(args) {
        if (args) {
            if ("object" === typeof args && args.length) {
                var cmd = args.splice(0, 1);
                if (API[cmd]) API[cmd].apply(null, args);
            } else if ("function" === typeof args) {
                args();
            }
        }
    };
    var initQueue = function() {
        }
    };
    var API = {
        view: function(o) {
            _loadGif('g.gif', _serialize(o), 'wpstats');
        },
        extra: function(o) {
            _loadGif('g.gif', _serialize(o), false);
        },
        raw: function(o) {
            _loadGif('g.gif', _serialize(o), false);
        },
        click: function(o) {
            _loadGif('c.gif', _serialize(o), false);
        },
        clickTrackerInit: function(b, p) {
            _clickTracker.init(b, p);
        }
    };
    var isDocumentHidden = function() {
    };
    var onDocumentVisibilityChange = function() {
            initQueue();
        }
    };
    var initQueueAfterDocumentIsVisible = function() {
    };

    function getFirstContentfulPaint() {
            for (var i = 0; i < paints.length; i++) {
                if (paints[i]['name'] === 'first-contentful-paint') {
                    return Math.round(paints[i]['startTime']);
                }
            }
        }
        return 0;
    }

    function trackInitialVisibilityState() {
        var visibilityState = 'unknown';
        }
        API.extra({
            'x_stats-initial-visibility': visibilityState
        });
    }
        });
    } else {
        trackInitialVisibilityState();
        if (isDocumentHidden()) {
            initQueueAfterDocumentIsVisible();
        } else {
            initQueue();
        }
    };
    return API;
})();
window.wpcom.tracks = (function() {
    var userId, userIdType, userLogin, previousAnonIds = [],
        retryTimeoutId = null,
        localCache = {},
        context = {},
        queriesPending = {},
        pixel = '//pixel.wp.com/t.gif',
        cookieDomain = null,
        cookiePrefix = 'tk_',
        testCookie = 'tc',
        userAnonCookie = 'ai',
        userPrevAnonCookie = 'aip',
        queriesCookie = 'qs',
        queriesTTL = 1800,
        clientUserIdType = 'wpcom:user_id';
    var TKQ = function(q) {
        if (q && q.length) {
            for (var i = 0; i < q.length; i++) {
            }
        }
    };
    TKQ.prototype.push = function(args) {
        if (args) {
            if ("object" == typeof args && args.length) {
                var cmd = args.splice(0, 1);
                if (API[cmd]) API[cmd].apply(null, args);
            } else if ("function" == typeof args) {
                args();
            }
        }
    };
    var initQueue = function() {
            retryQueries();
        }
    };
    var clone = function(obj, target) {
        if (obj == null || 'object' !== typeof obj)
            return obj;
        if (target == null || 'object' !== typeof target)
        for (var key in obj) {
            if (obj.hasOwnProperty(key)) {
            }
        }
        return target;
    };
    var bot = function() {
    };
    var serialize = function(obj) {
        var str = [];
        for (var p in obj) {
            if (obj.hasOwnProperty(p)) {
                str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
            }
        }
        return str.join("&");
    };
    var send = function(query) {
        loadIdentity();
        retryQueries();
        if (userLogin) {
        }
        var date = new Date();
        }
        }
        clone(context, query);
        var performSend = function() {
            getPixel(serialize(query));
        }
            requestIdleCallback(performSend, {
                timeout: 500
            })
        } else {
            setTimeout(performSend, 0);
        }
    };
    var getPixel = function(query) {
        if (!bot()) {
            if (query in queriesPending) {
                return;
            }
            queriesPending[query] = true;
            saveQuery(query);
            img.query = query;
            img.onload = function() {
                delete queriesPending[query];
                if (img) {
                    removeQuery(img.query);
                }
            };
            img.src = pixel + '?' + query + '&_rt=' + (new Date).getTime() + '&_=_';
            img.alt = ":)";
        }
    };
    var saveQuery = function(query) {
        var i, queries = getQueries();
        for (i = 0; i < queries.length; ++i) {
            if (query == queries[i]) {
                return;
            }
        }
        queries.push(query);
        saveQueries(queries);
    };
    var saveQueries = function(queries) {
        while (queries.join(" ").length > 2048) {
        }
        set(queriesCookie, queries.join(" "), queriesTTL);
    };
    var removeQuery = function(query) {
        var i, toSave = [],
            queries = getQueries();
        for (i = 0; i < queries.length; ++i) {
            if (query != queries[i]) {
                toSave.push(queries[i]);
            }
        }
        if (toSave.length !== queries.length) {
            saveQueries(toSave);
        }
    };
    var getQueries = function() {
        var queries = get(queriesCookie);
        return queries ? queries.split(' ') : [];
    };
    var retryQueries = function() {
        if (retryTimeoutId !== null) {
            return;
        }
            getQueries().forEach(getPixel);
            retryTimeoutId = null;
        }, 100);
    };
    var generateRandomToken = function(randomBytesLength) {
        var randomBytes = [];
            randomBytes = new Uint8Array(randomBytesLength);
        } else {
            for (var i = 0; i < randomBytesLength; ++i) {
                randomBytes[i] = Math.floor(Math.random() * 256);
            }
        }
        return btoa(String.fromCharCode.apply(String, randomBytes));
    }
    var newAnonId = function() {
        return generateRandomToken(18);
    }
    var get = function(key) {
        return getCookie(key) || localCache[key];
    };
    var set = function(key, value, ttl) {
        localCache[key] = value;
        setCookie(key, value, ttl);
    };
    var getCookie = function(key) {
        var name_eq = encodeURIComponent(cookiePrefix + key) + '=',
            name_eq_len = name_eq.length,
            cookies_len = cookies.length;
        if (cookies_len === 1) {
            cookies_len = cookies.length;
        }
        for (cookies_len--; cookies_len >= 0; cookies_len--) {
            if (cookies[cookies_len].substring(0, name_eq_len) === name_eq) {
                return decodeURIComponent(cookies[cookies_len].substring(name_eq_len));
            }
        };
        return null;
    };
    var checkCookieDomain = function(domain) {
        var randomToken = encodeURIComponent(generateRandomToken(12));
        return getCookie(testCookie) == randomToken;
    };
    var getCookieDomain = function() {
        if (cookieDomain == null) {
            cookieDomain = '';
                tokens = host.split('.'),
                tryDomain;
            } else {
                for (var i = 1; i <= tokens.length; ++i) {
                    tryDomain = '.' + tokens.slice(-i).join('.');
                    if (checkCookieDomain(tryDomain)) {
                        cookieDomain = tryDomain;
                        break;
                    }
                }
            }
            if (cookieDomain != '') {
                cookieDomain = "; domain=" + cookieDomain;
            }
        }
        return cookieDomain;
    };
    var setCookie = function(key, value, seconds) {
        var name = encodeURIComponent(cookiePrefix + key),
            date = new Date(),
            domain = getCookieDomain();
        if ('undefined' === typeof seconds) {
        }
        if (domain.match(/((^|\.)wp\.com$|^\.?w\.org$)/)) {
            return;
        }
        date.setTime(date.getTime() + seconds * 1E3);
            getCookieDomain() + "; path=/; expires=" + date.toUTCString();
    };
    var recordEvent = function(eventName, eventProps) {
        if ('_setProperties' === eventName) {
            return;
        }
        send(eventProps);
    };
    var identifyUser = function(newUserId, newUserLogin) {
        if (newUserLogin) {
            userLogin = newUserLogin;
        }
        if ('0' == newUserId || '' == newUserId || null == newUserId || userId == newUserId) {
            return;
        }
        var anonIds = getAnonIds();
        userId = newUserId;
        userIdType = clientUserIdType;
        for (var i = 0; i < anonIds.length; i++) {
            send({
                _en: '_aliasUser',
                anonId: anonIds[i]
            });
        }
        set(userAnonCookie, '', -1);
        set(userPrevAnonCookie, '', -1);
    };
    var getAnonIds = function() {
        var anonIds = [];
        if ('anon' === userIdType) {
            anonIds.push(userId);
        }
        var cookieAnonID = get(userAnonCookie);
        if (cookieAnonID && cookieAnonID !== userId) {
            anonIds.push(cookieAnonID);
        }
        var prevAnonIds = get(userPrevAnonCookie);
        if (prevAnonIds) {
            anonIds.concat(prevAnonIds.split(','));
        }
        return anonIds;
    }
    var identifyAnonUser = function(anonId) {
        loadIdentity();
        if (userId == anonId) {
            return;
        }
        if ('anon' !== userIdType) {
            send({
                _en: '_aliasUser',
                anonId: anonId
            });
            return;
        }
        if ('anon' == userIdType && userId) {
            var prevAnonIds = get(userPrevAnonCookie);
            if (prevAnonIds) {
                prevAnonIds = prevAnonIds.split(',');
            } else {
                prevAnonIds = [];
            }
            var alreadyListed = false;
            for (var i = 0; i < prevAnonIds.length; i++) {
                if (userId == prevAnonIds[i]) {
                    alreadyListed = true;
                }
            }
            if (!alreadyListed) {
                prevAnonIds.push(userId);
                set(userPrevAnonCookie, prevAnonIds.join(','));
            }
        }
        set(userAnonCookie, anonId);
        userId = anonId;
    };
    var clearIdentity = function() {
        userId = null;
        userLogin = null;
        set(userAnonCookie, '', -1);
        set(userPrevAnonCookie, '', -1);
        loadIdentity();
    };
    var setProperties = function(properties) {
        send(properties);
    };
    var loadIdentity = function() {
        if (userId) {
            return;
        }
        userIdType = 'anon';
        userId = get(userAnonCookie);
        if (!userId) {
            userId = newAnonId();
            set(userAnonCookie, userId);
        }
    };
    var storeContext = function(c) {
        if ('object' !== typeof c) {
            return;
        }
        context = c;
    };
    var API = {
        storeContext: storeContext,
        identifyUser: identifyUser,
        identifyAnonUser: identifyAnonUser,
        recordEvent: recordEvent,
        setProperties: setProperties,
        clearIdentity: clearIdentity
    };
    initQueue();
    return API;
})();