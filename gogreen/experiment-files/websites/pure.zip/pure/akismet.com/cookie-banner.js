(function() {
    "use strict";
    var docCookies = {
        getItem: function(sKey) {
            if (!sKey) {
                return null
            }
        },
        setItem: function(sKey, sValue, vEnd, sPath, sDomain, bSecure) {
            if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
                return false
            }
            var sExpires = "";
            if (vEnd) {
                switch (vEnd.constructor) {
                    case Number:
                        sExpires = vEnd === Infinity ? "; expires=Fri, 31 Dec 9999 23:59:59 GMT" : "; max-age=" + vEnd;
                        break;
                    case String:
                        sExpires = "; expires=" + vEnd;
                        break;
                    case Date:
                        sExpires = "; expires=" + vEnd.toUTCString();
                        break
                }
            }
            return true
        },
        removeItem: function(sKey, sPath, sDomain) {
                return false
            }
            return true
        },
        hasItem: function(sKey) {
            if (!sKey || /^(?:expires|max\-age|path|domain|secure)$/i.test(sKey)) {
                return false
            }
        },
        keys: function() {
            for (var nLen = aKeys.length, nIdx = 0; nIdx < nLen; nIdx++) {
                aKeys[nIdx] = decodeURIComponent(aKeys[nIdx])
            }
            return aKeys
        }
    };
    var DEFAULT_CSS = ".a8c-cookie-banner { \t\tdisplay: block; \t\tz-index: 50001; \t\tposition: fixed; \t\tbottom: 0; \t\tleft: 0; \t\tright: 0; \t\tmargin: 0; \t\tpadding: 16px 10px 16px 10px; \t\tbackground-color: #f0f0f0ff; \t\tborder-top: 1px solid rgba(0, 0, 0, 0.05); \t\ttransform: translateY(+100%); \t\ttransition: transform 600ms ease-out; \t} \t.a8c-cookie-banner p { \t\tdisplay: inline-block; \t\tcolor: black; \t\tmargin: 0 120px 0 0 ; \t\tpadding: 0; \t\tfont-family: sans-serif; \t\tfont-size: 12px; \t\tfont-weight: normal; \t\tline-height: 1.25; \t} \t.a8c-cookie-banner a { \t\tcolor: #0087BE; \t\tfont-family: sans-serif; \t\tfont-size: 12px; \t\tfont-weight: normal; \t\tline-height: 1.25; \t} \t.a8c-cookie-banner a.a8c-cookie-banner-ok-button { \t\tbox-sizing: border-box; \t\tdisplay: inline-block; \t\tposition: absolute; \t\tright: 10px; \t\ttop: 50%; \t\twidth: 110px; \t\ttransform: translateY(-50%); \t\tborder-radius: 4px; \t\tborder: 1px solid #e0e0e0; \t\tpadding: 10px; \t\tbackground-color: white; \t\ttext-align: center; \t\tfont-family: sans-serif; \t\ttext-decoration: none; \t} \t@media only screen and (max-width : 600px) { \t\t.a8c-cookie-banner { \t\t\tpadding: 10px 10px 10px 10px; \t\t} \t\t.a8c-cookie-banner p { \t\t\tmargin: 0 0 10px 0; \t\t\ttext-align: justify; \t\t} \t\t.a8c-cookie-banner a.a8c-cookie-banner-ok-button { \t\t\tdisplay: block; \t\t\tposition: static; \t\t\ttop: auto; \t\t\tright: auto; \t\t\ttransform: none; \t\t\tmin-width: 89px; \t\t\twidth: 50%; \t\t\tmargin: 0 auto; \t\t} \t}";
        cb.init ? cb.init(config) : cb.config = config
    };
    cb.init = function(config) {
        if (!config) {
            return
        }
        cb.config = config;
        $("head").append('<style type="text/css">' + DEFAULT_CSS + "</style>");
        var $div = $("<div/>");
        $div.addClass("a8c-cookie-banner custom-cookie-banner");
        var $p = $("<p/>");
        $p.html(config.text);
        var $a = $("<a/>", {
            href: "#"
        });
        $a.text(config.buttonText);
        $a.addClass("a8c-cookie-banner-ok-button");
        $div.append($p);
        $div.append($a);
            $(".a8c-cookie-banner").css("transform", "none")
        });
        $("a.a8c-cookie-banner-ok-button").on("click", function(event) {
            event.preventDefault();
            $(".a8c-cookie-banner").hide();
            var SIX_MONTHS_MAX = 6 * 30 * 24 * 60 * 60;
            docCookies.setItem(config.cookieName, "yes", SIX_MONTHS_MAX, "/");
            }])
        });
            "x_cookie-banner-view": "total," + sanitized_host
        }])
    }
})();
window.a8cCookieBanner();