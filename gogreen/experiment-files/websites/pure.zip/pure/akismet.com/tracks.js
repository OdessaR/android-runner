/**
 * Some wrapper functions for Tracks event tracking to reduce code duplication
 * and to allow us to add global event properties to every event.
 *
 * With these functions, we can also log events to the console during debugging
 * to make it easier to see which events are being triggered.
 */

function akismet_tracks_event(event_name, event_properties) {
    if (!event_properties) {
    }


    }

}

function akismet_tracks_identify(user_id) {
    }

}