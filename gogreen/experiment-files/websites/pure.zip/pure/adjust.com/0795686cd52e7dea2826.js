(window.webpackJsonp = window.webpackJsonp || []).push([
    [55], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var o = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1292: function(t, e, n) {
            "use strict";
            n.r(e);
            n(13), n(36), n(40), n(54), n(44), n(41);
            var o = n(10),
                r = n(107),
                c = {
                    nuxtI18n: {
                        locales: ["en", "ja", "zh", "fr", "id", "ko"]
                    },
                    mixins: [n(1060).a],
                    fetch: function(t) {
                            var n, o, r, c, l;
                                    case 0:
                                        n = t.store, o = t.route, r = !0, n.state.navBarContent[n.state.i18n.locale] && n.state.navBarContent[n.state.i18n.locale].links && (c = n.state.navBarContent[n.state.i18n.locale].links.find((function(t) {
                                            return "products-dropdown" == t.linkId
                                        })).dropdownContent.links, l = c.map((function(t) {
                                            return t.linkDestination.cached_url.split("/").pop()
                                        })), r = l.includes(o.params.slug) || "features" === o.params.slug), n.commit("SET_NAV_DATA", {
                                            mainNav: {
                                                ctaScrollOnPage: {
                                                    enabled: !0,
                                                    ctaText: "Request a Demo",
                                                    sectionId: "#demo-request"
                                                }
                                            },
                                            secondaryNav: {
                                                enabled: r,
                                                theme: "trans",
                                                component: "SecondaryNavProduct"
                                            }
                                        }), n.commit("SET_CONVERSION_PARAMS", {
                                            conversionValue: 30,
                                            conversionLabel: "2WDxCOmFj7oBEJLl7MwD"
                                        });
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                            schemaMarkup: {
                                "@context": "http://schema.org",
                                "@type": "WebPage",
                            }
                        })
                    },
                    asyncData: function(t) {
                            var n, o;
                                    case 0:
                                        return n = r.a.createAsyncDataStoryContext(t, {
                                            folderPath: "product/",
                                            slug: t.params.slug
                                    case 3:
                                        return o = e.sent, e.abrupt("return", o ? o.data : t.error({
                                            statusCode: 404
                                        }));
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                l = n(1),
                component = Object(l.a)(c, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        directives: [{
                            name: "editable",
                            rawName: "v-editable",
                            value: t.story.content,
                            expression: "story.content"
                        }]
                    }, [t.story.content.isFeaturedProduct ? n("a-section", {
                        style: {
                            "background-color": t.story.content.productColor.color,
                            "min-height": "420px"
                        },
                        attrs: {
                            "section-background-image": t.story.content.heroBackgroundImage,
                            "bg-position": "rightCenter",
                            theme: "light",
                            "t-padding": "large",
                            "b-padding": "xxLarge"
                        }
                    }, [n("a-row", {
                        staticClass: "margin -t-margin-2",
                        attrs: {
                            "vertical-alignment": "middle",
                            "horizontal-alignment": "left"
                        }
                    }, [n("a-column", {
                        attrs: {
                            "child-spacing": "medium",
                            width: "half"
                        }
                    }, [n("a-heading-block", {
                        attrs: {
                            "block-heading": t.story.content.pageTitle,
                            "block-byline": t.story.content.pageByline,
                            theme: "light",
                            "block-heading-size": "size2",
                            "block-heading-h-tag": "h1",
                            "block-byline-size": "size5",
                            "block-byline-h-tag": "h2"
                        }
                    })], 1)], 1)], 1) : t._e(), t._v(" "), t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    }))], 2)
                }), [], !1, null, null, null);
        }
    }
]);