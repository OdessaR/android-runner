(window.webpackJsonp = window.webpackJsonp || []).push([
    [32], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var r = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1299: function(t, e, n) {
            "use strict";
            n.r(e);
            n(41);
            var r = n(10),
                o = n(107),
                c = {
                    nuxtI18n: {
                        locales: ["en", "fr", "id"]
                    },
                    mixins: [n(1060).a],
                    fetch: function(t) {
                            var n;
                                    case 0:
                                        (n = t.store).commit("SET_NAV_DATA", {
                                            mainNav: {
                                                ctaScrollOnPage: {
                                                    enabled: !0,
                                                    ctaText: "Request a Demo",
                                                    sectionId: "#demo-request"
                                                }
                                            }
                                        }), n.commit("SET_CONVERSION_PARAMS", {
                                            conversionValue: 30,
                                            conversionLabel: "2WDxCOmFj7oBEJLl7MwD"
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                        })
                    },
                    asyncData: function(t) {
                            var n, r, c;
                                    case 0:
                                        return n = o.a.createAsyncDataStoryContext(t, {
                                            slug: "",
                                            folderPath: "customers/"
                                    case 3:
                                        return r = e.sent, c = {
                                            story: r.data.story
                                        }, e.abrupt("return", r ? c : t.error({
                                            statusCode: 404
                                        }));
                                    case 6:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                l = n(1),
                component = Object(l.a)(c, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        staticStyle: {
                            "overflow-x": "hidden"
                        }
                    }, t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    })), 1)
                }), [], !1, null, null, null);
        }
    }
]);