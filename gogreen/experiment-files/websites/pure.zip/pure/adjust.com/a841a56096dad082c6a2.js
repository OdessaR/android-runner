(window.webpackJsonp = window.webpackJsonp || []).push([
    [42], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var r = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1307: function(t, e, n) {
            "use strict";
            n.r(e);
            n(41);
            var r = n(10),
                o = n(107),
                c = {
                    nuxtI18n: {
                        locales: ["en", "ja", "zh"]
                    },
                    mixins: [n(1060).a],
                    fetch: function(t) {
                                    case 0:
                                        t.store.commit("SET_NAV_DATA", {});
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                        })
                    },
                    asyncData: function(t) {
                            var n, r;
                                    case 0:
                                        return n = o.a.createAsyncDataStoryContext(t, {
                                            folderPath: "partners/",
                                            slug: ""
                                    case 3:
                                        return r = e.sent, e.abrupt("return", r ? r.data : t.error({
                                            statusCode: 404
                                        }));
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                l = n(1),
                component = Object(l.a)(c, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    })), 1)
                }), [], !1, null, null, null);
        }
    }
]);