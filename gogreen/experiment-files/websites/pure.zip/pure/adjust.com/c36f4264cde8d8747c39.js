(window.webpackJsonp = window.webpackJsonp || []).push([
    [40], {
        1060: function(t, e, o) {
            "use strict";
            o(13), o(36), o(40);
                mounted: function() {
                    }));
                    o.lastIndexOf("/") !== o.length - 1 && (o += "/");
                    var n = {
                        event: "virtualPageview",
                        pagePath: o,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1093: function(t, e, o) {
            var content = o(1169);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("6f1fabf7", content, !1, {
                sourceMap: !1
            })
        },
        1167: function(t, e) {
        },
        1168: function(t, e, o) {
            "use strict";
            var n = o(1093);
            o.n(n).a
        },
        1169: function(t, e, o) {
            var n = o(5),
                r = o(500),
                c = o(1170),
                d = o(1171),
                l = o(1172);
            var h = r(c),
                m = r(d),
                y = r(l);
        },
        1170: function(t, e, o) {
        },
        1171: function(t, e, o) {
        },
        1172: function(t, e, o) {
        },
        1303: function(t, e, o) {
            "use strict";
            o.r(e);
            o(41);
            var n = o(10),
                r = o(107),
                c = {
                    nuxtI18n: {
                        locales: ["en", "ja", "zh", "fr", "id", "ko"]
                    },
                    mixins: [o(1060).a],
                    fetch: function(t) {
                            var o;
                                    case 0:
                                        (o = t.store).commit("SET_NAV_DATA", {
                                            mainNav: {
                                                ctaScrollOnPage: {
                                                    enabled: !0,
                                                    ctaText: "Request a Demo",
                                                    sectionId: "#demo-request"
                                                }
                                            }
                                        }), o.commit("SET_CONVERSION_PARAMS", {
                                            conversionValue: 30,
                                            conversionLabel: "2WDxCOmFj7oBEJLl7MwD"
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    data: function() {
                        return {
                        }
                    },
                    head: function() {
                            schemaMarkup: {
                                "@context": "http://schema.org",
                                "@type": "Corporation",
                                name: "Adjust",
                                legalName: "Adjust GmbH",
                                url: "https://www.adjust.com/",
                                address: {
                                    "@type": "PostalAddress",
                                    addressLocality: "Berlin",
                                    postalCode: "10405",
                                    streetAddress: "Saarbrücker Str. 37A",
                                    addressCountry: {
                                        "@type": "Country",
                                        name: "DE"
                                    }
                                },
                                logo: {
                                    "@type": "ImageObject",
                                    url: "https://a.storyblok.com/f/47007/1541x482/f8d86b3d72/logokit-02.png"
                                },
                                sameAs: ["https://www.facebook.com/adjustcom", "https://www.linkedin.com/company/adjustcom/", "https://twitter.com/adjustcom", "https://www.instagram.com/adjustcom/", "https://www.youtube.com/channel/UCLxY21pzKyjTuODjUytJIsA"]
                            }
                        })
                    },
                    asyncData: function(t) {
                            var o, n;
                                    case 0:
                                        return o = r.a.createAsyncDataStoryContext(t, {
                                            folderPath: "/",
                                            slug: ""
                                    case 3:
                                        return n = e.sent, e.abrupt("return", n ? n.data : t.error({
                                            statusCode: 404
                                        }));
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                d = (o(1168), o(1)),
                component = Object(d.a)(c, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        directives: [{
                            name: "editable",
                            rawName: "v-editable",
                            value: t.story.content,
                            expression: "story.content"
                        }]
                    }, [n("a-section", {
                        attrs: {
                            "section-background-image": o(1167),
                            "bg-color": "darkBlue"
                        }
                    }, [n("a-row", [n("a-column", {
                        staticClass: "margin -t-margin-5",
                        attrs: {
                            width: "full"
                        }
                    }, [n("a-heading-block", {
                        attrs: {
                            "block-heading": t.story.content.pageTitle,
                            "block-byline": t.story.content.pageByline,
                            theme: "light",
                            "block-heading-size": "size2",
                            "block-heading-h-tag": "h1",
                            "block-byline-size": "size5",
                            "block-byline-h-tag": "h2",
                            alignment: "center"
                        }
                    }), t._v(" "), n("a-horizontal-strip", {
                        attrs: {
                            wrap: "",
                            "horizontal-alignment": "center"
                        }
                    }, [n("a-link", {
                        attrs: {
                            "data-label": t.story.content.topSectionPrimaryCtaText + " button - top section",
                            "link-text": t.story.content.topSectionPrimaryCtaText,
                            "link-destination": t.story.content.topSectionPrimaryCtaLink,
                            "tracking-class": "tracking_handler_homepage_cta",
                            "emit-message": "demoUncollapse",
                            "link-style": "button",
                            theme: "brand"
                        }
                    }), t._v(" "), n("a-link", {
                        attrs: {
                            "data-label": t.story.content.topSectionSecondaryCtaText + " button - top section",
                            "link-text": t.story.content.topSectionSecondaryCtaText,
                            "link-destination": t.story.content.topSectionSecondaryCtaLink,
                            "tracking-class": "tracking_handler_homepage_cta",
                            theme: "light",
                            "link-style": "ghost"
                        }
                    })], 1)], 1), t._v(" "), n("a-column", {
                        attrs: {
                            width: "full",
                            alignment: "center"
                        }
                    }, [n("div", {
                        staticClass: "home-hero-video",
                        staticStyle: {
                            "margin-bottom": "-140px"
                        }
                    }, [n("div", {
                        staticClass: "home-hero-video__wrapper"
                    }, [n("div", {
                        staticClass: "home-hero-video__thumbnail-wrapper"
                    }, [n("a-video-modal-link", {
                        staticClass: "home-hero-video__modal-box",
                        attrs: {
                            "thumbnail-video": t.story.content.topSectionVideoPreview,
                            "thumbnail-tooltip": t.story.content.topSectionVideoTooltip,
                            "thumbnail-image": t.story.content.topSectionVideoImage,
                            "external-video-url": t.story.content.topSectionVideoUrl,
                            "thumbnail-size": "full",
                            "thumbnail-trans-width": "760",
                            "data-label": "Home Adjust Video"
                        }
                    })], 1)])])])], 1)], 1), t._v(" "), t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    }))], 2)
                }), [], !1, null, "20b34a9c", null);
        }
    }
]);