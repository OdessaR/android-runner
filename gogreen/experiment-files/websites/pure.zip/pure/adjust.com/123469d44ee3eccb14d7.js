(window.webpackJsonp = window.webpackJsonp || []).push([
    [56], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var o = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1291: function(t, e, n) {
            "use strict";
            n.r(e);
            n(41);
            var o = n(10),
                r = n(107),
                c = {
                    nuxtI18n: {
                        locales: ["en", "ja", "zh", "fr", "id", "ko"]
                    },
                    mixins: [n(1060).a],
                    fetch: function(t) {
                            var n;
                                    case 0:
                                        (n = t.store).commit("SET_NAV_DATA", {
                                            mainNav: {
                                                component: "MainNavReduced",
                                                showRequestDemoButton: !0,
                                                ctaScrollOnPage: {
                                                    enabled: !0,
                                                    ctaText: "Request a Demo",
                                                    sectionId: "#cta-scroll-anchor"
                                                }
                                            },
                                            calloutBanner: {
                                                enabled: !1
                                            }
                                        }), n.commit("SET_CONVERSION_PARAMS", {
                                            conversionValue: 30,
                                            conversionLabel: "2WDxCOmFj7oBEJLl7MwD"
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                        })
                    },
                    data: function() {
                        return {
                            story: {
                                content: {}
                            }
                        }
                    },
                    asyncData: function(t) {
                            var n, o;
                                    case 0:
                                        return n = r.a.createAsyncDataStoryContext(t, {
                                            folderPath: "request-a-demo/",
                                            slug: t.params.slug
                                    case 3:
                                        return o = e.sent, e.abrupt("return", o ? o.data : t.error({
                                            statusCode: 404
                                        }));
                                    case 5:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                l = n(1),
                component = Object(l.a)(c, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        directives: [{
                            name: "editable",
                            rawName: "v-editable",
                            value: t.story.content,
                            expression: "story.content"
                        }]
                    }, t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    })), 1)
                }), [], !1, null, null, null);
        }
    }
]);