CookieControl.Dialog = function(e, o, t, i, n, s, l, a, r, d, c, C, y, h, g, p, u, m, k, b, B, f, D) {
        top: "",
        bottom: "",
        slidedown: "",
        pushdown: "",
        slideup: "",
        overlay: "",
        popup: "",
        custom: ""
        white: "",
        dark: "",
        customcolor: ""
        top: "",
        bottom: "",
        slidedown: "",
        pushdown: "",
        slideup: "",
        overlay: "",
        popup: "",
        custom: ""
        top_white: "",
        top_dark: "",
        top_customcolor: "",
        bottom_white: "",
        bottom_dark: "",
        bottom_customcolor: "",
        slidedown_white: "",
        slidedown_dark: "",
        slidedown_customcolor: "",
        pushdown_white: "",
        pushdown_dark: "",
        pushdown_customcolor: "",
        slideup_white: "",
        slideup_dark: "",
        slideup_customcolor: "",
        overlay_white: "",
        overlay_dark: "",
        overlay_customcolor: "",
        popup_white: "",
        popup_dark: "",
        popup_customcolor: "",
        custom_white: "",
        custom_dark: "",
        custom_customcolor: ""
        background: "",
        text: "",
        acceptbutton: "",
        selectionbutton: "",
        declinebutton: "",
        buttontext: "",
        tab: "",
        border: "",
        logo: ""
        showdetails: "",
        hidedetails: "",
        cbCheckedNofocus: "",
        cbCheckedFocus: "",
        cbCheckedDisabled: "",
        cbNotCheckedFocus: "",
        cbNotCheckedNoFocus: ""
        HTML: "",
        CSS: "",
        Script: "",
        FunctionShowName: "",
        FunctionHideName: ""
        preferences: !0,
        statistics: !0,
        marketing: !0
        displayConsentBanner: !1
        purposes: [],
        specialpurposes: [],
        features: [],
        specialfeatures: [],
        stacks: [],
        vendors: [],
        version: "",
        lastupdated: ""
        tabHeader: "",
        deselectAll: "",
        feature: "",
        generalIntro: "",
        policyURL: "",
        purpose: "",
        purposeIntro: "",
        purposeLegitimateInterest: "",
        selectAll: "",
        thirdPartyVendors: "",
        vendorIntro: "",
        legitimateInterestHeader: "",
        legitimateInterestIntro: "",
        legitimateInterestPurposeIntro: "",
        legitimateInterestObjection: "",
        legitimateInterestVendorObjection: "",
        specialPurpose: "",
        specialFeature: "",
        purposeIntroShort: "",
        purposeIntroLong: "",
        purposeIntroPartly: "",
        globalConsent: "",
        withdrawConsent: "",
        preferencesIntro: "",
        consent: "",
        expand: "",
        collapse: "",
        saveAndExit: "",
        partners: "",
        partnersIntro: "",
        vendorsCan: "",
        settings: "",
        googleIntro: "",
        googleHeader: ""
}, CookieControl.Dialog.prototype.getCookieTableHTML = function(e, o, t, i) {
    for (var s = 0; s < o.length; s++) {
            var a = l.insertCell(j);
                var r = o[s][1].split("<br/>").length;
                1 < r && (a.innerHTML += "&nbsp;[x" + r + "]")
                if (7 < o[s].length && (d = o[s][7].split("<br/>")), 1 < d.length) {
                    for (var c = "", C = [], y = 0; y < d.length; y++) {
                    }
                    a.innerHTML = c
            }
        }
    }
    if (0 == o.length) {
    }
}, CookieControl.Dialog.prototype.getDomainLabel = function(e) {
    var o = e;
                break
            } return o
}, CookieControl.Dialog.prototype.init = function() {
        var t = {
                timeZone: "UTC",
                dateStyle: "short"
            },
            i = "",
        try {
        } catch (e) {
            i = n.toLocaleDateString("en-GB", t)
        }
        o = o.replace(/\{0\}/g, i)
    }
        var s = e.innerHTML;
        var a = [];
        var r = [];
        var d = [];
        var c = [];
                C = [];
                }
            }
            }
        }
                }
            g = [];
            }
        }
        }
        if (0 < r.length) {
                l += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", l += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'><label class='CybotCookiebotDialogBodyLevelButtonIABLabel'>" + u.name + "</label></div>", l += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>" + u.descriptionLegal.replace("* ", '<ul class="CybotCookiebotDialogBodyLevelButtonIABBullet"><li>').replace(/\* /g, "</li><li>") + "</li></ul></div>", l += "</div>"
            }
        }
        s = s.replace(/\[#IABV2_BODY_PURPOSES#\]/g, l);
        var m = "";
        if (0 < d.length) {
                m += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", m += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'><label class='CybotCookiebotDialogBodyLevelButtonIABLabel'>" + k.name + "</label></div>", m += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>" + k.descriptionLegal.replace("* ", '<ul class="CybotCookiebotDialogBodyLevelButtonIABBullet"><li>').replace(/\* /g, "</li><li>") + "</li></ul></div>", m += "</div>"
            }
        }
        if (0 < c.length) {
                m += "<div class='CybotCookiebotDialogBodyLevelButtonIABContainer'>", m += "<div class='CybotCookiebotDialogBodyLevelButtonWrapper'><input type='checkbox' id='CybotCookiebotDialogBodyLevelButtonIABFeature" + b.id + "' data-iabspecialfeatureid='" + b.id + "' class='CybotCookiebotDialogBodyLevelButton CybotCookiebotDialogBodyIABButtonFeatures' checked='checked' tabindex='0'><label class='CybotCookiebotDialogBodyLevelButtonIABLabel' for='CybotCookiebotDialogBodyLevelButtonIABFeature" + b.id + "'>" + b.name + "</label></div>", m += "<div class='CybotCookiebotDialogBodyLevelButtonIABDescription'>" + b.descriptionLegal.replace("* ", '<ul class="CybotCookiebotDialogBodyLevelButtonIABBullet"><li>').replace(/\* /g, "</li><li>") + "</li></ul></div>", m += "</div>"
            }
        }

        function B(e) {
            void 0 !== e && null != e && (e.style.display = "none")
        }

        function f(e, o) {
            var t = [];
            if (e.length < 0 || o.length < 0) return [];
            for (var i = 0; i < e.length; i++) 0 <= o.indexOf(e[i]) && t.push(e[i]);
            return t
        }
        setTimeout(function() {
            var e;
        }, 1), s = s.replace(/\[#IABV2_BODY_FEATURES#\]/g, m);
                        L = !0;
                        break
            }
                D += "</ul>"
            }
            if (0 < v.length) {
                D += "</ul>"
            }
            if (0 < T.length) {
                D += "</ul>"
            }
            if (0 < A.length) {
                D += "</ul>"
            }
            if (0 < E.length) {
                D += "</ul>"
            }
            D += "</div></div>"
        }
        if (0 < g.length) {
            for (var S, y = 0; y < g.length; y++) {
                var O = [1, 2];
                D += "</ul>", D += "</div></div>"
            }
        }
        s = s.replace(/\[#IABV2_BODY_PARTNERS#\]/g, D), e.innerHTML = s
    }
    var M = ["ar", "he", "fa", "az", "ur", "pa", "ps", "ug", "yi"],
        x = "left";
            break
            } else {
            }
}, CookieControl.Dialog.prototype.detachOnscrollEvent = function() {
    try {
}, CookieControl.Dialog.prototype.setOnscrollEvent = function() {
}, CookieControl.Dialog.prototype.onscrollfunction = function(e) {
            var o = 0;
    }
}, CookieControl.Dialog.prototype.show = function() {
    void 0 !== e ? o.displaydialog() : setTimeout(function() {
        o.show()
    }, 10)
}, CookieControl.Dialog.prototype.displaydialog = function() {
    var o = function(e) {
        c.isScrolling = !0
    };
                case "leveloptin":
                    break;
                case "optin":
                case "inlineoptin":
                    break;
                case "optout":
                case "optinout":
                case "leveloptin":
                    break;
                case "optin":
                case "inlineoptin":
                    break;
                case "optout":
                case "optinout":
                    break;
                case "optionaloptin":
            }
            c.resize()
        });
            e && (e.parentNode.title = c.htmlDecode(c.mandatoryText) + " " + c.htmlDecode(c.cookieIntroTypeNecessary.replace(/<[^>]*>?/gm, "")));
            e && (e.parentNode.title = c.htmlDecode(c.cookieIntroTypePreference.replace(/<[^>]*>?/gm, "")));
            e && (e.parentNode.title = c.htmlDecode(c.cookieIntroTypeStatistics.replace(/<[^>]*>?/gm, "")));
            e && (e.parentNode.title = c.htmlDecode(c.cookieIntroTypeAdvertising.replace(/<[^>]*>?/gm, "")))
        function() {
                var l, a, r, d;
                "leveloptin" == c.responseMode ? (t && (t.addEventListener("click", function(e) {
                    c.submitConsent(!1)
                }, !1), t.focus()), n && (n.addEventListener("click", function(e) {
                    c.submitConsent(!1)
                }, !1), i.focus()), s && (s.addEventListener("click", function(e) {
                    return c.submitDecline(e), !1
                    alert(c.mandatoryText + " " + c.htmlDecode(c.cookieIntroTypeNecessary))
                }, !1), e && (e.addEventListener("click", function(e) {
                    var o = !0,
                    return t && t.checked && (o = !1), o ? c.submitConsent(!1) : c.submitDecline(e), !1
                }, !1), e && (e.addEventListener("click", function(e) {
                    return c.submitConsent(!1), !1
                }, !1), e.focus()), o && o.addEventListener("click", function(e) {
                    return c.submitDecline(e), !1
                }, !1))
            }
        case "top":
            break;
        case "bottom":
            break;
        case "slidedown":
            break;
        case "pushdown":
            break;
        case "slideup":
            break;
        case "popup":
        case "overlay":
            break;
        case "custom":
    }
    setTimeout(function() {
        c.setButtonsSize(), c.setZoomLevel()
    }, 50)
}, CookieControl.Dialog.prototype.runCustomScript = function(o, t) {
    try {
        var e = new Function("return " + o)();
        "function" == typeof e && e()
    }
}, CookieControl.Dialog.prototype.createCustomScript = function(o) {
        else {
            t.type = "text/javascript", t.id = "CookiebotCustomScript";
            try {
            }
        }
}, CookieControl.Dialog.prototype.TryParseInt = function(e, o) {
}, CookieControl.Dialog.prototype.resetZoomLevel = function() {
}, CookieControl.Dialog.prototype.setZoomLevel = function() {
    var e, o, t = 1,
        var s = i.scrollHeight,
            l = i.scrollWidth;
        if ((a < s || n < l) && (e = n / (l + 0), o = a / (s + 0), t = Math.round(100 * Math.min(o, e)) / 100, .1 < e)) {
                case "top":
                case "slidedown":
                case "pushdown":
                    break;
                case "bottom":
                case "slideup":
                    i.style.transform = "scale(" + t + ")", i.style.webkitTransform = "scale(" + t + ")", i.style.msTransform = "scale(" + t + ")", i.style.MozTransform = "scale(" + t + ")", i.style.OTransform = "scale(" + t + ")", i.style.transformOrigin = "0px bottom", i.style.webkitTransformOrigin = "0px bottom", i.style.msTransformOrigin = "0px bottom", i.style.MozTransformOrigin = "0px bottom", i.style.OTransformOrigin = "0px bottom", i.style.width = Math.floor(n * (1 / t)) + "px";
                    break;
                case "overlay":
                case "popup":
            }
        }
    }
}, CookieControl.Dialog.prototype.setButtonsSize = function() {
            t = 0;
            case "optin":
            case "optionaloptin":
            case "inlineoptin":
                e && (e.style.paddingLeft = "12px", e.style.paddingRight = "12px");
                break;
            case "optout":
                o && (o.style.paddingLeft = "12px", o.style.paddingRight = "12px");
                break;
            case "optinout":
                e && o && (i = e.offsetWidth - 10, n = o.offsetWidth - 10, t = Math.max(i, n), 0 < (t = Math.max(80, t)) && (e.style.width = t + "px", o.style.width = t + "px"));
                break;
            case "leveloptin":
                    o = 0;
                if (e) {
                    var s = i.offsetWidth,
                        l = n.offsetWidth,
                        a = e.offsetWidth,
                        r = 8,
                        e = r + 4,
                        d = !1;
                    } catch (e) {} else {
                        try {
                        } catch (e) {}
                    }
                }
                    C = c && a,
                    C = c && a && s,
                if (y) {
                    var h = c.offsetWidth - 10,
                        g = a.offsetWidth - 10;
                    t = Math.max(h, g), 0 < (t = Math.max(80, t)) && (c.style.width = t + "px", a.style.width = t + "px");
                    try {
                    } catch (e) {}
                } else if (C) {
                    0 < (t = Math.max(80, h, g, C)) && (c.style.width = t + "px", a.style.width = t + "px", s.style.width = t + "px");
                    try {
                    } catch (e) {}

                    function u(e, o) {
                        for (var t = 0; t < e.length; t++) e[t].style.display = o, e[t].parentElement.appendChild(e[t])
                    }
                }
        }
    }
}, CookieControl.Dialog.prototype.hide = function(e) {
}, CookieControl.Dialog.prototype.resize = function() {
        case "top":
        case "slidedown":
            break;
        case "pushdown":
            break;
        case "bottom":
        case "slideup":
            break;
        case "popup":
        case "overlay":
    }
    setTimeout(function() {
        e.setButtonsSize(), e.setZoomLevel()
    }, 50)
}, CookieControl.Dialog.prototype.slideDown = function() {
        o.slideDown()
}, CookieControl.Dialog.prototype.pushDown = function() {
        o.pushDown()
}, CookieControl.Dialog.prototype.slideUp = function() {
        o.slideUp()
}, CookieControl.Dialog.prototype.fadeIn = function() {
        e.fadeIn()
}, CookieControl.Dialog.prototype.fadeOut = function() {
        e.fadeOut()
}, CookieControl.Dialog.prototype.showAtTop = function() {
}, CookieControl.Dialog.prototype.showAtBottom = function() {
    setTimeout(function() {
        o.DOM.style.opacity = 1, o.DOM.style.filter = "alpha(opacity=100)";
        var e = parseInt(o.DOM.scrollHeight);
        o.DOM.style.top = o.viewport.winHeight() - e + "px", o.resize()
    }, 100)
}, CookieControl.Dialog.prototype.submitConsent = function(e, o, t) {
}, CookieControl.Dialog.prototype.submitDecline = function(e) {
    var o;
}, CookieControl.Dialog.prototype.addStyle = function(e, o) {
}, CookieControl.Dialog.prototype.appendStyle = function(e) {
}, CookieControl.Dialog.prototype.showDetails = function() {
}, CookieControl.Dialog.prototype.hideDetails = function() {
}, CookieControl.Dialog.prototype.toggleDetails = function(e) {
    if (i) {
            case "top":
            case "slidedown":
            case "pushdown":
                break;
            case "bottom":
            case "slideup":
                    a = parseInt(l.scrollHeight);
                break;
            case "popup":
            case "overlay":
        }
    }
}, CookieControl.Dialog.prototype.showDetailPane = function(e) {
    for (var o = ["CybotCookiebotDialogDetailBodyContentTextAbout", "CybotCookiebotDialogDetailBodyContentTextIABv2", "CybotCookiebotDialogDetailBodyContentTextOverview"], t = 0; t < o.length; t++) {
        i && (i.style.display = "none")
    }
    for (var n = ["CybotCookiebotDialogDetailBodyContentTabsAbout", "CybotCookiebotDialogDetailBodyContentTabsIABv2", "CybotCookiebotDialogDetailBodyContentTabsOverview"], t = 0; t < n.length; t++) {
        s && (s.className = "CybotCookiebotDialogDetailBodyContentTab CybotCookiebotDialogDetailBodyContentTabsItem")
    }
    switch (e.toLowerCase()) {
        case "overview":
            break;
        case "iabv2":
            break;
        default:
    }
    l && (l.className = "CybotCookiebotDialogDetailBodyContentTab CybotCookiebotDialogDetailBodyContentTabsItemSelected"), a && (a.style.display = "block")
}, CookieControl.Dialog.prototype.htmlDecode = function(e) {
    return o.innerHTML = e, 0 === o.childNodes.length ? "" : o.childNodes[0].nodeValue
}, CookieControl.Dialog.prototype.showCookieContainerDetailPane = function(e) {
    for (var o = ["CybotCookiebotDialogDetailBodyContentCookieTabsNecessary", "CybotCookiebotDialogDetailBodyContentCookieTabsPreference", "CybotCookiebotDialogDetailBodyContentCookieTabsStatistics", "CybotCookiebotDialogDetailBodyContentCookieTabsAdvertising", "CybotCookiebotDialogDetailBodyContentCookieTabsUnclassified"], t = 0; t < o.length; t++) {
    }
    for (var i, n, s = ["CybotCookiebotDialogDetailBodyContentCookieContainerNecessary", "CybotCookiebotDialogDetailBodyContentCookieContainerPreference", "CybotCookiebotDialogDetailBodyContentCookieContainerStatistics", "CybotCookiebotDialogDetailBodyContentCookieContainerAdvertising", "CybotCookiebotDialogDetailBodyContentCookieContainerUnclassified"], t = 0; t < s.length; t++) {
    }
    switch (e.toLowerCase()) {
        case "preference":
            break;
        case "statistics":
            break;
        case "advertising":
            break;
        case "unclassified":
            break;
        default:
    }
    i.className = "CybotCookiebotDialogDetailBodyContentCookieContainerTypesSelected", n.scrollIntoView(!0), n.style.display = "block"
}, CookieControl.Dialog.prototype.showCookieContainerIABv2DetailPane = function(e) {
    for (var o = ["CybotCookiebotDialogDetailBodyContentIABv2TabPurposes", "CybotCookiebotDialogDetailBodyContentIABv2TabFeatures", "CybotCookiebotDialogDetailBodyContentIABv2TabPartners"], t = 0; t < o.length; t++) {
        i && (i.style.display = "none")
    }
    for (var n, s, l = ["CybotCookiebotDialogDetailBodyContentIABv2Purposes", "CybotCookiebotDialogDetailBodyContentIABv2Features", "CybotCookiebotDialogDetailBodyContentIABv2Partners"], t = 0; t < l.length; t++) {
        a && (a.className = "CybotCookiebotDialogDetailBodyContentCookieContainerTypes")
    }
    switch (e.toLowerCase()) {
        case "features":
            break;
        case "partners":
            break;
        default:
    }
    n && (n.className = "CybotCookiebotDialogDetailBodyContentIABv2TabSelected"), s && (s.scrollIntoView(!0), s.style.display = "block")
}, CookieControl.Dialog.prototype.setStateUnchecked = function() {
    setTimeout(function() {
    }, 100)
}, CookieControl.Dialog.prototype.getIAB2PurposeById = function(e) {
    return ""
}, CookieControl.Dialog.prototype.getIAB2SpecialPurposeById = function(e) {
    return ""
}, CookieControl.Dialog.prototype.getIAB2FeatureById = function(e) {
    return ""
}, CookieControl.Dialog.prototype.getIAB2SpecialFeatureById = function(e) {
    return ""
}, CookieControl.Dialog.prototype.IABSelectPurposes = function() {
    for (o = 0; o < e.length; o++) e[o].checked = !0
}, CookieControl.Dialog.prototype.IABDeselectPurposes = function(e) {
    for (t = 0; t < o.length; t++) e || (o[t].checked = !1)
}, CookieControl.Dialog.prototype.IABSelectFeatures = function() {
}, CookieControl.Dialog.prototype.IABDeselectFeatures = function() {
}, CookieControl.Dialog.prototype.IABSelectVendors = function() {
    for (o = 0; o < e.length; o++) e[o].checked = !0
}, CookieControl.Dialog.prototype.IABDeselectVendors = function(e) {
    for (t = 0; t < o.length; t++) e || (o[t].checked = !1)
}, CookieControl.Dialog.prototype.IABSelectAll = function() {
}, CookieControl.Dialog.prototype.ShowIABVendors = function() {
}, CookieControl.Dialog.prototype.IABDeselectAll = function(e) {
}, CookieControl.Dialog.prototype.IABToggleContainer = function(e) {
}, CookieControl.Viewport = function() {
            t = o.documentElement,
            i = o.getElementsByTagName("body")[0];
        return Math.max(Math.max(o.body.scrollHeight, o.documentElement.scrollHeight), Math.max(o.body.offsetHeight, o.documentElement.offsetHeight), Math.max(o.body.clientHeight, o.documentElement.clientHeight), e.innerHeight || t.clientHeight || i.clientHeight)
            t = o.documentElement,
            i = o.getElementsByTagName("body")[0];
        return Math.max(Math.max(o.body.scrollWidth, o.documentElement.scrollWidth), Math.max(o.body.offsetWidth, o.documentElement.offsetWidth), Math.max(o.body.clientWidth, o.documentElement.clientWidth), e.innerWidth || t.clientWidth || i.clientWidth)
            t = o.documentElement,
            o = o.getElementsByTagName("body")[0];
        return e.innerHeight || t.clientHeight || o.clientHeight
            t = o.documentElement,
            o = o.getElementsByTagName("body")[0];
        return e.innerWidth || t.clientWidth || o.clientWidth
        if (e.offsetParent)
        var e, o;
        return [o[0] - e[0], o[1] - e[1]]
            e()
            e()
            e()
            e()
        }))
    }
}, CookieControl.Viewport.prototype.isIE = function() {
    return -1 != e.indexOf("msie") && parseInt(e.split("msie")[1])
}, CookieControl.Dialog.prototype.clearDOM = function() {
    if (0 < e.length)
        for (var o = 0; o < e.length; o++) e[o].parentNode.removeChild(e[o]);
    t && t.parentNode.removeChild(t);
    t && t.parentNode.removeChild(t)
}, CookieControl.CSS = function(e) {
}, CookieControl.CSS.prototype.hasClass = function(e) {
}, CookieControl.CSS.prototype.addClass = function(e) {
}, CookieControl.CSS.prototype.removeClass = function(e) {
}, CookieControl.CSS.prototype.replaceClass = function(e, o) {
}, CookieControl.CSS.prototype.toggleClass = function(e, o) {
};
CookieConsent.responseMode = 'inlineoptin'
CookieControl.Dialog.prototype.loadTemplates = function() {}
CookieConsent.host = 'https://consent.cookiebot.com/';
var CookiebotDialog, CookieConsentDialog;
CookiebotDialog = CookieConsentDialog = new CookieControl.Dialog(CookieConsent, 'custom_customcolor', 'This website uses cookies', 'We use cookies to make it easier to interact with our website and to improve it. We want to better understand how our website is used and to personalize advertising. You can find out more about our use of cookies in our&nbsp;<a href="https://www.adjust.com/terms/privacy-policy/?utm_source=coba" target="_blank">Privacy Policy</a> and change your preferences below.', 'Allow all cookies', 'Use necessary cookies only', 'inlineoptin', false, false, 'strict', 'en', 'Cookies are small text files that can be used by websites to make a user\'s experience more efficient.<br style="" /><br style="" />The law states that we can store cookies on your device if they are strictly necessary for the operation of this site. For all other types of cookies we need your permission.<br style="" /><br style="" />This site uses different types of cookies. Some cookies are placed by third party services that appear on our pages.', 'Necessary cookies help make a website usable by enabling basic functions like page navigation and access to secure areas of the website. The website cannot function properly without these cookies.', 'Preference cookies enable a website to remember information that changes the way the website behaves or looks, like your preferred language or the region that you are in.', 'Statistic cookies help website owners to understand how visitors interact with websites by collecting and reporting information anonymously.', 'Marketing cookies are used to track visitors across websites. The intention is to display ads that are relevant and engaging for the individual user and thereby more valuable for publishers and third party advertisers.', 'Unclassified cookies are cookies that we are in the process of classifying, together with the providers of individual cookies.', 'Allow all cookies', 'Allow all cookies', 'Allow selection', '', 'Settings', 'Settings');
CookieConsentDialog.noCookiesTypeText = 'We do not use cookies of this type.';
CookieConsentDialog.aboutCookiesText = 'About cookies';
CookieConsentDialog.cookiesOverviewText = 'Cookie declaration';
CookieConsentDialog.cookieHeaderTypeNecessary = 'Necessary ({0})';
CookieConsentDialog.cookieHeaderTypePreference = 'Preferences ({0})';
CookieConsentDialog.cookieHeaderTypeStatistics = 'Statistics ({0})';
CookieConsentDialog.cookieHeaderTypeAdvertising = 'Marketing ({0})';
CookieConsentDialog.cookieHeaderTypeUnclassified = 'Unclassified ({0})';
CookieConsentDialog.cookieTableHeaderName = 'Name';
CookieConsentDialog.cookieTableHeaderProvider = 'Provider';
CookieConsentDialog.cookieTableHeaderPurpose = 'Purpose';
CookieConsentDialog.cookieTableHeaderType = 'Type';
CookieConsentDialog.cookieTableHeaderExpiry = 'Expiry';
CookieConsentDialog.bulkconsentDomainsString = '';
CookieConsentDialog.impliedConsentOnScroll = true;
CookieConsentDialog.impliedConsentOnRefresh = true;
CookieConsentDialog.showLogo = true;
CookieConsentDialog.mandatoryText = 'Mandatory - can not be deselected.';
CookieConsentDialog.logo = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAC4AAAAuCAYAAABXuSs3AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAY9SURBVGhD1VlbaJxFFE4aarUP2lhoX6pUCdQLqKkP9YYotOiTQTGIUisKVUHBPvimL4r4pFXBoiAVsQVFUBSxMTZJq6FN2pgmm81lc2nS3M39usludpPj980/s/337/7//nsR2Q+G3Z3LOd+cmTnnzGyRFCjySnwDZSIak1A4Iq1Lq6rwO+vYlk/kTDwAch8PTsszbYNyZ0Ov3Pxnl5TUtUtRTVAVfmcd29iHfTkmV2RFPLy+IcdHZ+WRpsuyqQYkfw9IUVUrPlH4maqYNvTlGI6lDMrKBhkTp7I957otsrZSUtsuZed75ImWK/Jy56gc6RlXhd9Zxzb2cY6jLMrMFL6Jh8JROdA8YCms1ophuf2o+3JkRjqXIxL1sB7b2Id9OYZj7bIomzr8whfxnyYXpfRs51VFp4NysH1YmhZWdI/MwbGUQVmGPHVQlx+kJf45LFT0R5tVILy8sVfOzC7r1txBWZSpjKL1UGc6eBI/RtK0BgXi89WuUVlZX9et+QNlUrZdF3V7wZX4z1OLCQtQ0AcDk7rlvwN1JMijkIMbUhLvW4nKTWc6LAFYwmxIHx2alnvO9ci9F/rkPniUOp/bS5HX24YcyCUVUhJ/7JL2HiivYAkzxVJ8XXbUd1l+m5M/1SIH4BL9gjqNfnJJhWuIfzM+Zw2qbpO7cWhWswgQx8dmLRl0eSSOCFoM79Gy6C9iUid1kwPlkJMTScTDsNRuLK8acLpN6ufCuiUz7L3YpxSW/tUllcEhJYu/GYz8grrVOHAhJ3KzI4n412Pa2iiVwWFdmxm4l83ZeA5+egEKb2QMQN0N2LPDkZjumR7kYPiQmx1JxPf93a9O9SYs7SWfy+pERRssTGUgWqsP5OshvWerAvLO5QlV5wfkQC7kRG52JIi3IxwX16ITFDyK8JsNupHCbtb5yP1Iogw6Ua/yFExmZ31IFh3L7gVyoTxyI0eDBPGjSDeVVVBSOf+ZWFx+g1/9/p95aZwPp1TOpMpkgN86DlQFUloj/wsfkdFABUE9jhwNEsSf5hJjKWkZJkN2VE0vyS7k1Co4sMBD7ILlDneOJA4wPcF2HEYquAUZ34rDG52d03sfh+0ueIz4hj9vRS5qtcCNHA0Uceq4A4k+c+bbECyiNqGTa3F1EUhENM6eXsd8x8mvCAzKYe5jXffhlSk9Ohn7sH3M5H/xiIp2kAs5kRs5Gnso4hPRuGwjOSzzfofD/3FyQRMMysM4IK+FxqSc7o6HRhO3yOATddvgQZZd9vB32GbWxAPyuEtgSQVyIjdyJFdCEee9sKQOIR6NhzpGVIOB3UWehGKD5sUVOdI9Jts5YT2xIizpFpS3UD+FlXIiAnPdTuupOBGUCz7TYnIiN3IkV0IR56VWWRCNb0KpHXa//KJjUsQYLsLv9U/IDjMBJScgt+IMnEwR8T6yOYHn4ef9gJzIjbLJlUhLnN6DLoxW2ooZD6ymTnpGEVje4D6n5c0ZwJZ4Ft5kKLKme8E7YSVKOUm0b4G8fpckyg5X4l5bhbC7uYMdV60Ux0H5dHgmcWAIrtBedTFAf04CY3aC6Amb9S15ltXf7h3Xte5w3Speh5MYXF2TrSrNBRFYqnpmSdXTFRbDuk3Y73ZE4Am4fa6jG+PB1dY/hK0xH1uHp4pZbainC51FjPCC6+H0cocG7zNPptWhbDf8NLfQS7TEr81Jq2AH75UPXIQLtFmft/oWLLdafk4Klv8EubsbPN0h4RWACN7SeSkwFnwIrlGtEsiUg9y1U7UQg+J3kZ8o4rQ8yvVYvafg+1V6gN9lDT2ylsJYhGcAItKFfKIZSc9m5tiGBA80+n/l412kBnu/TL3HaOujFJMQC4zxw8SC7pmMtCHfb5L1GQ6j2jK0/KlW3HRCrgHHiWl4lBeYn5MIyduIP4gVtB9yg7RJFuE3reUllj76BIJTQxZvK8cweQYq5Tb5qR+Hzi8kX1x8pbVEPi4SftGICe/hbYtbBytYif075/Auvi8S+bq6+QVT5SdbBlSS5txsGV3diHxclnNFxpdlg1yfJ3JFVs8TRD4ehLJFTg9CREE+wRko528E4bMgHj0NCvKZ2aAgH/YNCvKvFDsK7s8rOwry70InCuoPWjfQdgXzl/j/A5F/AWld11foPGubAAAAAElFTkSuQmCC';
CookieConsentDialog.logoAltText = 'logo';
CookieConsentDialog.customImages.showdetails = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAGCAMAAAAmGUT3AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkI3NDEyNDEwNzk0MjExRTQ5RUE5RkRFMUQ3MEU1NTZDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkI3NDEyNDExNzk0MjExRTQ5RUE5RkRFMUQ3MEU1NTZDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6Qjc0MTI0MEU3OTQyMTFFNDlFQTlGREUxRDcwRTU1NkMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6Qjc0MTI0MEY3OTQyMTFFNDlFQTlGREUxRDcwRTU1NkMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz70ohqeAAAABlBMVEVgYGAAAAAPhzbbAAAAAnRSTlP/AOW3MEoAAAAjSURBVHjaYmBkYAQBBkYGIAAxQBQcQ/ggCiLFCGFBCIAAAwADkwAg7Yr51AAAAABJRU5ErkJggg==';
CookieConsentDialog.customImages.hidedetails = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAkAAAAGCAYAAAARx7TFAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjU0QzAwODExNzk0MjExRTQ4QzBERTBGMTkxMUY2M0M0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjU0QzAwODEyNzk0MjExRTQ4QzBERTBGMTkxMUY2M0M0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NTRDMDA4MEY3OTQyMTFFNDhDMERFMEYxOTExRjYzQzQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NTRDMDA4MTA3OTQyMTFFNDhDMERFMEYxOTExRjYzQzQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz576KdnAAAATklEQVR42kyO2xEAMQgCJZ3afxFcyGRz+uMD3EHdXbYrJSltrz4Dt4UBNfsWPG614oRwO2Q/Eg+IwvnDj8kjk+48MzmZeNYI/4jRPwEGAFy/MS7NcXxJAAAAAElFTkSuQmCC';
CookieConsentDialog.customImages.cbCheckedNofocus = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjNGMUE0MkE1QkJDMjExRTM5QUIxQzQwRjkwREYzMUIyIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjNGMUE0MkE2QkJDMjExRTM5QUIxQzQwRjkwREYzMUIyIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6M0YxQTQyQTNCQkMyMTFFMzlBQjFDNDBGOTBERjMxQjIiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6M0YxQTQyQTRCQkMyMTFFMzlBQjFDNDBGOTBERjMxQjIiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz4IZcVrAAAA5UlEQVR42mL8//8/AyMjIwMxQHwRgwOQAuEJjMRqBGoSAFL3gRhEf2BiIB7Mh2oCgQ+MFy5c+E9Ix/o3SxlmPOtGFnJkAZEGBgaMeJyoAKTOI9k24WUcwwEmNEUGBJx4AaipEMRgQtIEUnAeSCcgiRVAQxEGEmEMsB/dLxk4Atn70RRcgDoRDGLEMxh63WfAvQSz8QIUIztvPRL/QixQIzIAawS6+wMopNA0K8CCHogD0T0O9yMOzSDQCJR7gFMjmuYFUKEDQLEJ2KKJBV0AqjkRGKILsdiOqhFv6kHSCkrXMAAQYACIkU0SIPgtxAAAAABJRU5ErkJggg==';
CookieConsentDialog.customImages.cbCheckedDisabled = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjgzMjc3NEM2QkJDMjExRTNBN0ExOUJFMzFCMzdBRjdEIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjgzMjc3NEM3QkJDMjExRTNBN0ExOUJFMzFCMzdBRjdEIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6ODMyNzc0QzRCQkMyMTFFM0E3QTE5QkUzMUIzN0FGN0QiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6ODMyNzc0QzVCQkMyMTFFM0E3QTE5QkUzMUIzN0FGN0QiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz54CbH2AAABFElEQVR42oxSLQ/CQAy9I6hZMrVgQW4aCdnvGIoER8Lm+AcbWBIcFo0cFuw0dkxMMAlyvC69y/hek6VN19e+16ssy1JIKUUTC8Owh9o+wkNbNDSADICmCA18w1ZTIEAeg8juMkmS8h+oKAqR57nIsmzD0pYVVcdx5A+KHRQuLMuaEYj0+b5/br0UdT9QHANgcJwGQbCjWAOjKPKoM/yglhvB9dTW0WCrG5LGOI77SM5rz0IFKXILniRs2564rqsL2tzpQjQQKqoectdao9Q0zScJFVXwvsGteIr612F/Q279ql1rxKYqME8WNV17NL5+BSowCmnykUFngA6fnunt5Jj2Fhs9wV++XlKTy1GGzeptPQQYAF1/e0nsKZ1HAAAAAElFTkSuQmCC';
CookieConsentDialog.customImages.cbNotCheckedFocus = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOkUwQkVDMzlCQkQ4NTExRTM5RTEwRUIwNUNENTg2N0Q4IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOkUwQkVDMzlDQkQ4NTExRTM5RTEwRUIwNUNENTg2N0Q4Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6RTBCRUMzOTlCRDg1MTFFMzlFMTBFQjA1Q0Q1ODY3RDgiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6RTBCRUMzOUFCRDg1MTFFMzlFMTBFQjA1Q0Q1ODY3RDgiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7Y0XwIAAAAOElEQVR42mL8//8/AzmAiYFMQLZGxtLSUqLd2tXVxQhjs8AMIELf/4H146hGWmhkwRa5xACAAAMAL2gJGKxaSssAAAAASUVORK5CYII=';
CookieConsentDialog.customImages.cbCheckedFocus = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjk3MjVBRTM5QkQ4MDExRTM4RDBEOTEzMTQxN0RDRjc0IiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjk3MjVBRTNBQkQ4MDExRTM4RDBEOTEzMTQxN0RDRjc0Ij4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OTcyNUFFMzdCRDgwMTFFMzhEMEQ5MTMxNDE3RENGNzQiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OTcyNUFFMzhCRDgwMTFFMzhEMEQ5MTMxNDE3RENGNzQiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz7V1txIAAAA6UlEQVR42mL8//8/AyMjIwMxQHwRgwOQAuEJjMRqBGoSAFL3gRhEf2BiIB7Mh2oCgQ+MpaWl/wnpuC5yluG05D5kIUcWENnd3c2Ix4kKQOo8km0TXsYxHGBCU2RAwIkXgJoKQQwmJE0gBeeBdAKSWAE0FGEgEcZgQQpmmIb5QD7YdCDuhynUf2XFsKvk2AUYH2bjBShGdt56JP4F/ZfWKO4HawS6+wMopNA0K8CCHogD0T0O9yMOzSDQCJR7gFMjmuYFUKEDQLEJ2KKJBV0AqjkRGEALsdiOqhFr6rkMpUsRQqB0DQMAAQYAX31KK0vr8I0AAAAASUVORK5CYII=';
CookieConsentDialog.customImages.cbNotCheckedNoFocus = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAA4AAAAOCAYAAAAfSC3RAAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyBpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuMC1jMDYwIDYxLjEzNDc3NywgMjAxMC8wMi8xMi0xNzozMjowMCAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENTNSBXaW5kb3dzIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjYxNkU3NEJGQkJDMjExRTNCMzA3ODU5MUUzMDlDM0FDIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjYxNkU3NEMwQkJDMjExRTNCMzA3ODU5MUUzMDlDM0FDIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6NjE2RTc0QkRCQkMyMTFFM0IzMDc4NTkxRTMwOUMzQUMiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6NjE2RTc0QkVCQkMyMTFFM0IzMDc4NTkxRTMwOUMzQUMiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz71Yc/eAAAAOklEQVR42mL8//8/AzmAkf4aL1y4QLROfX19RjgHpBFkKyGMro6JgUwwqnFQaWQBERcvXiQ53QEEGADSSDs5lXMYKAAAAABJRU5ErkJggg==';
CookieConsentDialog.prechecked.preferences = false;
CookieConsentDialog.prechecked.statistics = false;
CookieConsentDialog.prechecked.marketing = false;
CookieConsentDialog.optionaloptinSettings.displayConsentBanner = true;
CookieConsentDialog.customColors.background = '#ffffff';
CookieConsentDialog.customColors.text = '#000000';
CookieConsentDialog.customColors.acceptbutton = '#00bed5';
CookieConsentDialog.customColors.selectionbutton = '#188600';
CookieConsentDialog.customColors.declinebutton = '#333333';
CookieConsentDialog.customColors.buttontext = '#ffffff';
CookieConsentDialog.customColors.tab = '#f5f5f5';
CookieConsentDialog.customColors.border = '#cccccc';
CookieConsentDialog.customTemplateDef.HTML = '<div id="cookiebanner" class="cookie-banner" lang="[#LANGUAGE#]" dir="[#TEXTDIRECTION#]" ng-non-bindable><div class="cookie-banner__wrapper"><div class="cookie-banner__wrapper-top"><p class="cookie-banner__wrapper-header">[#TITLE#]</p><p class="cookie-banner__wrapper-message">[#TEXT#]</p></div><div class="cookie-banner__wrapper-bottom"><div><a href="https://www.adjust.com/terms/impressum/" class="cookie-banner__buttons-settings"> Imprint </a></div><div class="cookie-banner__buttons"><a href="javascript:void(0)" id="cookie-open-settings" class="cookie-banner__buttons-settings"> Change cookie preferences </a><a href="javascript:void(0)" onclick="Cookiebot.dialog.submitConsent()" id="cookie-save-settings" class="cookie-banner__buttons-settings" style="display: none;"> Save preferences </a><a href="javascript:void(0)" id="cookie-allow-all" class="cookie-banner__buttons-cta"> [#ACCEPT#] </a></div></div></div><div id="cookie-details" style="display: none;"><div class="cookie-banner__details-wrapper"><div class="cookie-banner__details-selectors"><ul class="cookie-banner__details-tabs"><li class="cookieTabs cookie-banner__details-tab active" onclick="openCookieTab(event, \'Necessary\')"><input type="checkbox" name="necessary" value="necessary" disabled="disabled" checked="checked" id="CybotCookiebotDialogBodyLevelButtonNecessary" class="cookie-selectors__input"><label class="cookie-selectors__label" for="CybotCookiebotDialogBodyLevelButtonNecessary"> [#COOKIETYPE_NECESSARY_RAW#] </label></li><li class="cookieTabs cookie-banner__details-tab" onclick="openCookieTab(event, \'Preference\')"><input type="checkbox" name="preference" value="preference" id="CybotCookiebotDialogBodyLevelButtonPreferences" class="cookie-selectors__input"><label class="cookie-selectors__label" for="CybotCookiebotDialogBodyLevelButtonPreferences"> [#COOKIETYPE_PREFERENCE_RAW#] </label></li><li class="cookieTabs cookie-banner__details-tab" onclick="openCookieTab(event, \'Statistics\')"><input type="checkbox" name="statistics" value="statistics" id="CybotCookiebotDialogBodyLevelButtonStatistics" class="cookie-selectors__input"><label class="cookie-selectors__label" for="CybotCookiebotDialogBodyLevelButtonStatistics"> [#COOKIETYPE_STATISTICS_RAW#] </label></li><li class="cookieTabs cookie-banner__details-tab" onclick="openCookieTab(event, \'Advertising\')"><input type="checkbox" name="advertising" value="advertising" id="CybotCookiebotDialogBodyLevelButtonMarketing" class="cookie-selectors__input"><label class="cookie-selectors__label" for="CybotCookiebotDialogBodyLevelButtonMarketing"> [#COOKIETYPE_ADVERTISING_RAW#] </label></li><li class="cookieTabs cookie-banner__details-tab" onclick="openCookieTab(event, \'Unclassified\')"><input type="checkbox" name="unclassified" value="unclassified" id="CybotCookiebotDialogBodyLevelButtonUnclassified" class="cookie-selectors__input" disabled="disabled" checked="checked" style="visibility: hidden;"><label class="cookie-selectors__label" for="CybotCookiebotDialogBodyLevelButtonUnclassified"> [#COOKIETYPE_UNCLASSIFIED_RAW#] </label></li></ul></div><div class="cookie-banner__details-disclaimer"><div id="Necessary" class="tabContent"><p>[#COOKIETYPE_NECESSARY#]</p><p>[#COOKIETYPEINTRO_NECESSARY#]</p><span> [#COOKIETABLE_NECESSARY#] </span></div><div id="Preference" class="tabContent" style="display: none;"><p>[#COOKIETYPE_PREFERENCE#]</p><p>[#COOKIETYPEINTRO_PREFERENCE#]</p><span> [#COOKIETABLE_PREFERENCE#] </span></div><div id="Statistics" class="tabContent" style="display: none;"><p>[#COOKIETYPE_STATISTICS#]</p><p>[#COOKIETYPEINTRO_STATISTICS#]</p><span> [#COOKIETABLE_STATISTICS#] </span></div><div id="Advertising" class="tabContent" style="display: none;"><p>[#COOKIETYPE_ADVERTISING#]</p><p>[#COOKIETYPEINTRO_ADVERTISING#]</p><span> [#COOKIETABLE_ADVERTISING#] </span></div><div id="Unclassified" class="tabContent" style="display: none;"><p>[#COOKIETYPE_UNCLASSIFIED#]</p><p>[#COOKIETYPEINTRO_UNCLASSIFIED#]</p><span> [#COOKIETABLE_UNCLASSIFIED#] </span></div></div></div></div></div>';
CookieConsentDialog.customTemplateDef.CSS = '.cookie-banner{box-sizing:border-box;background-color:#fff;width:100%;padding:20px;position:fixed;z-index:9999999;box-shadow:0 0 15px -5px rgba(0,0,0,.9)}.cookie-banner p{font-size:14px;line-height:1.4}.cookie-banner .cookie-banner__wrapper-header{color:#1e3c96;font-weight:bold;margin-bottom:4px}.cookie-banner p.cookie-banner__wrapper-message{font-size:14px;color:#969ba5}.cookie-banner a{color:#4d4d4d;border-bottom:1px solid #4d4d4d}.cookie-banner a:hover{color:#1e3c96;border-bottom:1px solid #1e3c96}a.cookie-banner__buttons-settings{display:inline-block;font-size:14px;color:#969ba5;border:none;margin-right:15px}.cookie-banner a.cookie-banner__buttons-settings:hover{color:#4d4d4d;border:none}.cookie-banner a.cookie-banner__buttons-cta{display:inline-block;min-width:100px;height:40px;line-height:36px;padding:0 20px;border-radius:2px;border:2px solid #00bed5;text-align:center;cursor:pointer;background-color:#00bed5;color:#fff;text-decoration:none;transition:.2s;white-space:nowrap}.cookie-banner a.c-button:hover{background-color:#fff;color:#00bed5}.cookie-banner__wrapper{max-width:900px;margin:0 auto}.cookie-banner__wrapper-top{text-align:left}.cookie-banner__wrapper-bottom{margin-top:15px;text-align:right;display:flex;align-items:center;justify-content:space-between}.cookie-banner__details-wrapper{max-width:900px;width:100%;margin:0 auto;display:flex;flex-wrap:nowrap;margin-top:25px}.cookie-banner__details-selectors{margin-right:15px}.cookie-banner__details-tabs{padding:0}.cookie-banner__details-tab{display:block;min-width:150px;padding:10px 0;cursor:pointer;background:#fff;border-bottom:2px solid #e2e6ec}.cookie-banner__details-tab label{color:#1e3c96;font-size:12px;text-transform:uppercase}.cookie-banner__details-tab.active{border-bottom:2px solid #1e3c96}.cookie-banner__details-disclaimer{width:1005;flex-grow:1;height:300px;overflow:scroll}.CybotCookiebotDialogDetailBodyContentCookieTypeTable th{font-size:14px;font-weight:normal}.CybotCookiebotDialogDetailBodyContentCookieTypeTable td{font-size:12px;font-weight:normal}.CybotCookiebotDialogDetailBodyContentCookieTypeTable table{table-layout:fixed}.cookiebot-tabs .content h3{font-size:14px}@media only screen and (max-device-width:480px){.cookie-banner__details-wrapper{flex-wrap:wrap}.cookie-banner a.cookie-banner__buttons-cta{font-size:14px}.cookie-banner__details-tabs{display:flex;flex-wrap:wrap}.cookie-banner__details-disclaimer{padding-top:15px}}';
CookieConsentDialog.customTemplateDef.Script = 'function showCookieBanner(){var n=document.getElementById("cookiebanner"),t=parseInt(n.offsetHeight);n.style.bottom=cookieBannerSliderPos-t+"px";cookieBannerSliderPos+=4;cookieBannerSliderPos<t?setTimeout(function(){showCookieBanner()},1):(cookieBannerSliderPos=0,n.style.bottom="0px")}function hideCookieBanner(){var n=document.getElementById("cookiebanner");n.style.display="none"}function openCookieTab(n,t){for(var r,u=document.getElementsByClassName("tabContent"),i=0;i<u.length;i++)u[i].style.display="none";for(r=document.getElementsByClassName("cookieTabs"),i=0;i<r.length;i++)r[i].className=r[i].className.replace(" active","");document.getElementById(t).style.display="block";n.currentTarget.className+=" active"}var cookieBannerSliderPos=0;const cookieSettings=document.getElementById("cookie-open-settings"),cookieDetails=document.getElementById("cookie-details"),cookieSave=document.getElementById("cookie-save-settings");cookieSettings.addEventListener("click",()=>{cookieSettings.style.display="none",cookieDetails.style.display="inline",cookieSave.style.display="inline"});const allowAllButton=document.getElementById("cookie-allow-all"),cookiesPreferences=document.getElementById("CybotCookiebotDialogBodyLevelButtonPreferences"),cookiesStatistics=document.getElementById("CybotCookiebotDialogBodyLevelButtonStatistics"),cookiesMarketing=document.getElementById("CybotCookiebotDialogBodyLevelButtonMarketing");allowAllButton.addEventListener("click",()=>{cookiesPreferences.checked=!0,cookiesStatistics.checked=!0,cookiesMarketing.checked=!0,Cookiebot.dialog.submitConsent()})';
CookieConsentDialog.customTemplateDef.FunctionShowName = 'showCookieBanner';
CookieConsentDialog.customTemplateDef.FunctionHideName = 'hideCookieBanner';
CookieConsentDialog.lastUpdatedText = 'Cookie declaration last updated on {0} by <a href="https://www.cookiebot.com" target="_blank" rel="noopener" title="Cookiebot">Cookiebot</a>';
CookieConsentDialog.lastUpdatedDate = 1601392935320;
CookieConsentDialog.cookieTableNecessary = [
    ["CookieConsent", "adjust.com", "Stores the user\'s cookie consent state for the current domain", "1 year", "HTTP", "1", "", "cookiebot.com"],
    ["rc::a", "google.com", "This cookie is used to distinguish between humans and bots. This is beneficial for the website, in order to make valid reports on the use of their website.", "Persistent", "HTML", "2", "", "google.com"],
    ["JSESSIONID", "linkedin.com", "Preserves users states across page requests.", "Session", "HTTP", "1", "", "linkedin.com"],
    ["debug", "adjust.com", "Pending", "Persistent", "HTML", "2", "", "www.adjust.com"]
];
CookieConsentDialog.cookieTablePreference = [
    ["_biz_flagsA", "adjust.com", "This cookie serves multiple purposes; it determines whether the user has submitted any forms, performed cross-domain migration or has made any tracking opt-out choices. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["dc", "adjust.com", "Necessary for the functionality of the website\'s chat-box function. ", "Session", "HTTP", "1", "", "www.adjust.com"],
    ["driftt_aid", "adjust.com", "Necessary for the functionality of the website\'s chat-box function. ", "2 years", "HTTP", "1", "", "www.adjust.com"],
    ["driftt_sid", "adjust.com", "Identifies the visitor across devices and visits, in order to optimize the chat-box function on the website. ", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["lang", "ads.linkedin.com<br/>linkedin.com", "Remembers the user\'s selected language version of a website", "Session", "HTTP", "1", "", "ads.linkedin.com<br/>linkedin.com"]
];
CookieConsentDialog.cookieTableStatistics = [
    ["_ga", "adjust.com", "Registers a unique ID that is used to generate statistical data on how the visitor uses the website.", "2 years", "HTTP", "1", "", "www.adjust.com"],
    ["_gat", "adjust.com", "Used by Google Analytics to throttle request rate", "1 day", "HTTP", "1", "^_gat(_.+)*$", "www.adjust.com"],
    ["_gid", "adjust.com", "Registers a unique ID that is used to generate statistical data on how the visitor uses the website.", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["_hjAbsoluteSessionInProgress", "adjust.com", "This cookie is used to count how many times a website has been visited by different visitors - this is done by assigning the visitor an ID, so the visitor does not get registered twice.", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["_hjid", "adjust.com", "Sets a unique ID for the session. This allows the website to obtain data on visitor behaviour for statistical purposes.", "1 year", "HTML", "1", "", "www.adjust.com"],
    ["_hjIncludedInPageviewSample", "adjust.com", "Determines if the user\'s navigation should be registered in a certain statistical place holder.", "1 day", "HTML", "1", "", "www.adjust.com"],
    ["_hjTLDTest", "adjust.com", "Detects the SEO-ranking for the current website. This service is part of a third-party statistics and analysis service. ", "Session", "HTTP", "1", "", "www.adjust.com"],
    ["DFTT_END_USER_PREV_BOOTSTRAPPED", "adjust.com", "Used by the website to detect whether the visitor has had any previous interaction with the live chat function on the website - This is used to optimize the chat function on the website.  ", "2 years", "HTTP", "1", "", "www.adjust.com"],
    ["Drift.Targeting.activeSessionStartedAt", "adjust.com", "This cookie is used to collect information about how the visitor interacts with the live chat function on the website.", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.currentReferrer", "adjust.com", "Allows the website to recoqnise the visitor, in order to optimize the chat-box functionality. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.referrerDomain", "adjust.com", "Allows the website to recoqnise the visitor, in order to optimize the chat-box functionality. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["hjViewportId", "adjust.com", "Sets a unique ID for the session. This allows the website to obtain data on visitor behaviour for statistical purposes.", "Session", "HTML", "2", "", "www.adjust.com"],
    ["loglevel", "adjust.com", "Collects data on visitor interaction with the website\'s video-content - This data is used to make the website\'s video-content more relevant towards the visitor.  ", "Persistent", "HTML", "2", "", "fast.wistia.com"],
    ["undefined", "adjust.com", "Collects data on visitor interaction with the website\'s video-content - This data is used to make the website\'s video-content more relevant towards the visitor.  ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["wistia", "adjust.com", "Used by the website to track the visitor\'s use of video-content - The cookie roots from Wistia, which provides video-software to websites.", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["vuid", "vimeo.com", "Collects data on the user\'s visits to the website, such as which pages have been read.", "2 years", "HTTP", "1", "", "vimeo.com"]
];
CookieConsentDialog.cookieTableAdvertising = [
    ["__tld__", "adjust.com", "Used to track visitors on multiple websites, in order to present relevant advertisement based on the visitor\'s preferences. ", "Session", "HTTP", "1", "", "www.adjust.com"],
    ["_biz_nA", "adjust.com", "Collects data on visitors\' preferences and behaviour on the website - This information is used make content and advertisement more relevant to the specific visitor. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["_biz_pendingA", "adjust.com", "Collects data on visitors\' preferences and behaviour on the website - This information is used make content and advertisement more relevant to the specific visitor. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["_biz_sid", "adjust.com", "Collects data on visitors\' preferences and behaviour on the website - This information is used make content and advertisement more relevant to the specific visitor. ", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["_biz_uid", "adjust.com", "Collects data on visitors\' preferences and behaviour on the website - This information is used make content and advertisement more relevant to the specific visitor. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["_fbp", "adjust.com", "Used by Facebook to deliver a series of advertisement products such as real time bidding from third party advertisers.", "3 months", "HTTP", "1", "", "www.adjust.com"],
    ["_gac_UA-#", "adjust.com", "Stores information about ad campaigns from Google Adwords to show targeted ads to the visitor.", "3 months", "HTTP", "1", "^_gac_UA-[0-9\-]*$", "www.adjust.com"],
    ["cb_anonymous_id", "adjust.com", "Collects data on visitor behaviour from multiple websites, in order to present more relevant advertisement - This also allows the website to limit the number of times that they are shown the same advertisement. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["cb_group_id", "adjust.com", "Collects data on visitors. This information is used to assign visitors into segments, making website advertisement more efficient. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["cb_user_id", "adjust.com", "Collects data on visitor behaviour from multiple websites, in order to present more relevant advertisement - This also allows the website to limit the number of times that they are shown the same advertisement. ", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["Drift.Targeting.currentPageViewStarted", "adjust.com", "Necessary for the functionality of the website\'s chat-box function. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.currentSessionStartedAt", "adjust.com", "Identifies the visitor across devices and visits, in order to optimize the chat-box function on the website. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.firstVisit", "adjust.com", "Necessary for the functionality of the website\'s chat-box function. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.lastTargetingEvalUUID", "adjust.com", "Sets a unique ID for the specific user. This allows the website to target the user with relevant offers through its chat functionality. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.lastVisit", "adjust.com", "Necessary for the functionality of the website\'s chat-box function. ", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.numberOfSessions", "adjust.com", "Determines the number of visits of the specific visitor. This is used in order to make the chat-box function more relevant.", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.numberOfVisits", "adjust.com", "Determines the number of visits of the specific visitor. This is used in order to make the chat-box function more relevant.", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["Drift.Targeting.previousPage", "adjust.com", "Identifies the last page visited by the visitor. This is used in order to make the chat-box function more relevant.", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["utm_campaign", "adjust.com", "Collects information on user preferences and/or interaction with web-campaign content - This is used on CRM-campaign-platform used by website owners for promoting events or products.", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["utm_content", "adjust.com", "Used to send data to Google Analytics about the visitor\'s device and behavior. Tracks the visitor across devices and marketing channels.", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["utm_medium", "adjust.com", "Collects information on user preferences and/or interaction with web-campaign content - This is used on CRM-campaign-platform used by website owners for promoting events or products.", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["utm_source", "adjust.com", "Determines how the visitor accessed the website - This information is used by the website operator in order to determine the efficiency of their marketing efforts.    ", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["_BUID", "bizible.com<br/>bizibly.com", "Collects data on visitors\' preferences and behaviour on the website - This information is used make content and advertisement more relevant to the specific visitor. ", "1 year", "HTTP", "1", "", "bizible.com<br/>cdn.bizibly.com"],
    ["m/ipv", "cdn.bizible.com", "Registers user behaviour and navigation on the website, and any interaction with active campaigns. This is used for optimizing advertisement and for efficient retargeting.  ", "Session", "Pixel", "5", "", "cdn.bizible.com"],
    ["IDE", "doubleclick.net", "Used by Google DoubleClick to register and report the website user\'s actions after viewing or clicking one of the advertiser\'s ads with the purpose of measuring the efficacy of an ad and to present targeted ads to the user.", "1 year", "HTTP", "1", "", "doubleclick.net"],
    ["test_cookie", "doubleclick.net", "Used to check if the user\'s browser supports cookies.", "1 day", "HTTP", "1", "", "doubleclick.net"],
    ["fr", "facebook.com", "Used by Facebook to deliver a series of advertisement products such as real time bidding from third party advertisers.", "3 months", "HTTP", "1", "", "www.facebook.com"],
    ["tr", "facebook.com", "Used by Facebook to deliver a series of advertisement products such as real time bidding from third party advertisers.", "Session", "Pixel", "5", "", "www.facebook.com"],
    ["pardot", "go.adjust.com<br/>pardot.com", "Used to identify the visitor across visits and devices. This allows the website to present the visitor with relevant advertisement - The service is provided by third party advertisement hubs, which facilitate real-time bidding for advertisers. ", "Session", "HTTP", "1", "", "www.adjust.com<br/>pi.pardot.com"],
    ["ads/ga-audiences", "google.com", "Used by Google AdWords to re-engage visitors that are likely to convert to customers based on the visitor\'s online behaviour across websites.", "Session", "Pixel", "5", "", "www.google.com"],
    ["rc::c", "google.com", "Used in context with video-advertisement. The cookie limits the number of times a visitor is shown the same advertisement-content. The cookie is also used to ensure relevance of the video-advertisement to the specific visitor.  ", "Session", "HTML", "2", "", "google.com"],
    ["__ptq.gif", "hubspot.com", "Sends data to the marketing platform Hubspot about the visitor\'s device and behaviour. Tracks the visitor across devices and marketing channels.", "Session", "Pixel", "5", "", "track.hubspot.com"],
    ["bcookie", "linkedin.com", "Used by the social networking service, LinkedIn, for tracking the use of embedded services.", "2 years", "HTTP", "1", "", "linkedin.com"],
    ["bscookie", "linkedin.com", "Used by the social networking service, LinkedIn, for tracking the use of embedded services.", "2 years", "HTTP", "1", "", "linkedin.com"],
    ["lidc", "linkedin.com", "Used by the social networking service, LinkedIn, for tracking the use of embedded services.", "1 day", "HTTP", "1", "", "linkedin.com"],
    ["lissc", "linkedin.com", "Used by the social networking service, LinkedIn, for tracking the use of embedded services.", "1 year", "HTTP", "1", "", "linkedin.com"],
    ["UserMatchHistory", "linkedin.com", "Used to track visitors on multiple websites, in order to present relevant advertisement based on the visitor\'s preferences.  ", "29 days", "HTTP", "1", "", "linkedin.com"],
    ["i/adsct", "t.co", "The cookie is used by Twitter.com in order to determine the number of visitors accessing the website through twitter advertisement content. ", "Session", "Pixel", "5", "", "t.co"],
    ["personalization_id", "twitter.com", "This cookie is set by Twitter - The cookie allows the visitor to share content from the website onto their Twitter profile. ", "2 years", "HTTP", "1", "", "analytics.twitter.com"],
    ["usage.gif", "usage.trackjs.com", "Used to track the visitor\'s usage of GIFs - This serves for analytical and marketing purposes.", "Session", "Pixel", "5", "", "usage.trackjs.com"],
    ["snowplowOutQueue_snowplow_cf_get", "wistia.com", "Registers statistical data on users\' behaviour on the website. Used for internal analytics by the website operator. ", "Persistent", "HTML", "2", "", "liftoff.wistia.com"],
    ["VISITOR_INFO1_LIVE", "youtube.com", "Tries to estimate the users\' bandwidth on pages with integrated YouTube videos.", "179 days", "HTTP", "1", "", "www.youtube.com"],
    ["YSC", "youtube.com", "Registers a unique ID to keep statistics of what videos from YouTube the user has seen.", "Session", "HTTP", "1", "", "www.youtube.com"],
    ["yt-remote-cast-installed", "youtube.com", "Stores the user\'s video player preferences using embedded YouTube video", "Session", "HTML", "2", "", "youtube.com"],
    ["yt-remote-connected-devices", "youtube.com", "Stores the user\'s video player preferences using embedded YouTube video", "Persistent", "HTML", "2", "", "youtube.com"],
    ["yt-remote-device-id", "youtube.com", "Stores the user\'s video player preferences using embedded YouTube video", "Persistent", "HTML", "2", "", "youtube.com"],
    ["yt-remote-fast-check-period", "youtube.com", "Stores the user\'s video player preferences using embedded YouTube video", "Session", "HTML", "2", "", "youtube.com"],
    ["yt-remote-session-app", "youtube.com", "Stores the user\'s video player preferences using embedded YouTube video", "Session", "HTML", "2", "", "youtube.com"],
    ["yt-remote-session-name", "youtube.com", "Stores the user\'s video player preferences using embedded YouTube video", "Session", "HTML", "2", "", "youtube.com"],
    ["visitor_id#", "adjust.com<br/>go.adjust.com<br/>pardot.com", "Pending", "10 years", "HTTP", "1", "^visitor_id\d+$", "www.adjust.com<br/>pardot.com"],
    ["visitor_id#-hash", "adjust.com<br/>go.adjust.com<br/>pardot.com", "Pending", "10 years", "HTTP", "1", "^visitor_id\d+-hash$", "www.adjust.com<br/>pardot.com"],
    ["pagead/1p-user-list/#", "google.com", "Pending", "Session", "Pixel", "5", "", "www.google.com"],
    ["lpv597731", "pardot.com", "Pending", "1 day", "HTTP", "1", "", "pi.pardot.com"],
    ["_w_session", "wistia.com", "Pending", "13 days", "HTTP", "1", "", "wistia.com"],
    ["minilogSettings", "wistia.com", "Pending", "Persistent", "HTML", "2", "", "liftoff.wistia.com"]
];
CookieConsentDialog.cookieTableUnclassified = [
    ["algoliasearch-client-js-4.2.0-D9ETOI7EEZ", "adjust.com", "Pending", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["articleReadStatus", "adjust.com", "Pending", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["cb%3Atest", "adjust.com", "Pending", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["cb_group_properties", "adjust.com", "Pending", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["cb_user_traits", "adjust.com", "Pending", "Persistent", "HTML", "2", "", "www.adjust.com"],
    ["pfjs%3Acookies", "adjust.com", "Pending", "1 year", "HTTP", "1", "", "www.adjust.com"],
    ["utm_channel", "adjust.com", "Pending", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["utm_term", "adjust.com", "Pending", "1 day", "HTTP", "1", "", "www.adjust.com"],
    ["wcs_bt", "adjust.com", "Pending", "72999 days", "HTTP", "1", "", "www.adjust.com"],
    ["wistia-video-progress-#", "adjust.com", "Pending", "Persistent", "HTML", "2", "^wistia-video-progress-[0-9a-z]{10}$", "www.adjust.com"],
    ["m/muc", "cdn.bizible.com", "Pending", "Session", "Pixel", "5", "", "cdn.bizible.com"],
    ["u", "cdn.bizibly.com", "Pending", "Session", "Pixel", "5", "", "cdn.bizibly.com"],
    ["snowplow/constriction_thought/i", "events.fivetran.com", "Pending", "Session", "Pixel", "5", "", "events.fivetran.com"],
    ["m", "wcs.naver.com", "Pending", "Session", "Pixel", "5", "", "wcs.naver.com"],
    ["NWB", "wcs.naver.com", "Pending", "5 years", "HTTP", "1", "", "wcs.naver.com"]
];
CookieConsentDialog.cookieTableNecessaryCount = 4;
CookieConsentDialog.cookieTablePreferenceCount = 6;
CookieConsentDialog.cookieTableStatisticsCount = 16;
CookieConsentDialog.cookieTableAdvertisingCount = 61;
CookieConsentDialog.cookieTableUnclassifiedCount = 15;
CookieConsent.whitelist = ['CookieConsent', 'rc::a', 'JSESSIONID', 'debug'];
CookieConsentDialog.privacyPolicies = [
    ['ads.linkedin.com', 'LinkedIn', 'https://www.linkedin.com/legal/privacy-policy'],
    ['analytics.twitter.com', 'Twitter', 'https://twitter.com/en/privacy'],
    ['bizible.com', 'Bizible', 'https://www.bizible.com/privacy-policy'],
    ['cdn.bizible.com', 'Bizible', 'https://www.bizible.com/privacy-policy'],
    ['cdn.bizibly.com', 'Bizibly', 'https://www.bizible.com/?utm_medium=redir&utm_source=bizibly'],
    ['cookiebot.com', 'Cookiebot', 'https://www.cookiebot.com/goto/privacy-policy/'],
    ['doubleclick.net', 'Google', 'https://policies.google.com/privacy'],
    ['events.fivetran.com', 'Fivetran', 'https://fivetran.com/privacy'],
    ['fast.wistia.com', 'Wistia', 'https://wistia.com/privacy'],
    ['google.com', 'Google', 'https://policies.google.com/privacy'],
    ['liftoff.wistia.com', 'Wistia', 'https://wistia.com/privacy'],
    ['linkedin.com', 'LinkedIn', 'https://www.linkedin.com/legal/privacy-policy'],
    ['pardot.com', 'Salesforce', 'https://www.salesforce.com/company/privacy/'],
    ['pi.pardot.com', 'Salesforce', 'https://www.salesforce.com/company/privacy/'],
    ['t.co', 'Twitter', 'https://twitter.com/en/privacy'],
    ['track.hubspot.com', 'Hubspot', 'https://legal.hubspot.com/privacy-policy?_ga=2.250808134.1581177119.1522931914-1869930087.1510729546'],
    ['usage.trackjs.com', 'Tracksjs', 'https://trackjs.com/privacy/'],
    ['vimeo.com', 'Vimeo', 'https://vimeo.com/privacy'],
    ['wcs.naver.com', 'Naver', 'http://policy.naver.com/policy/privacy.html'],
    ['wistia.com', 'Wistia', 'https://wistia.com/privacy'],
    ['www.adjust.com', 'Adjust', 'https://www.adjust.com/privacy-policy/'],
    ['www.facebook.com', 'Facebook', 'https://www.facebook.com/policies/cookies/'],
    ['www.google.com', 'Google', 'https://policies.google.com/privacy'],
    ['www.youtube.com', 'YouTube', 'https://policies.google.com/privacy'],
    ['youtube.com', 'YouTube', 'https://policies.google.com/privacy']
];
CookieConsentDialog.privacyPolicyText = '{0}\'s privacy policy';
CookieConsentDialog.userCountry = 'NL';
if (typeof CookieConsent != 'undefined') {
    CookieConsent.userCountry = 'NL';
    if (typeof CookieConsent.updateRegulations != 'undefined') {
        CookieConsent.updateRegulations();
    }
}
CookieConsentDialog.userCulture = 'en-US';
CookieConsentDialog.init();