(window.webpackJsonp = window.webpackJsonp || []).push([
    [68], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var r = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1082: function(t, e, n) {
            "use strict";
            n(7), n(4), n(32), n(54), n(108), n(41);
            var r, o, c = n(10);
                youtubeDevApi: "https://content.googleapis.com/youtube/v3/videos",
                youtubeDevKey: "AIzaSyBzto_4Y78NUJP8xAezM8w6f5GUS4jmrp4",
                wistiaApi: "https://api.wistia.com/v1/medias/",
                wistiaApiPass: "1199f67903c765475c65c4aef3984cb5b51071c093d1dd452ebbe98d1d518b98",
                mapOrder: function(t, e, n) {
                    return t.sort((function(a, b) {
                        var t = a[n],
                            r = b[n];
                        return e.indexOf(t) > e.indexOf(r) ? 1 : -1
                    })), t
                },
                    var c, l, d, h, m, f;
                            case 0:
                                return c = n.createAsyncDataStoriesContext(e, {
                                    folderPath: "",
                                    byUuids: r
                            case 3:
                                return l = t.sent, d = l.data.stories[0].content.playlistItems.map((function(t) {
                                    return t.content
                                })), h = n.createAsyncDataStoriesContext(e, {
                                    folderPath: "",
                                    byUuids: d.join()
                            case 8:
                                    playlist: l.data.stories[0],
                                    playlistIndexItems: m.map((function(t) {
                                        return {
                                            title: t.content.pageTitle,
                                            linkDestination: "".concat(t.full_slug, "/?playlistId=").concat(r),
                                            uuid: t.uuid
                                        }
                                    })),
                                    playlistUpNext: m.slice(f + 1, f + 3)
                                });
                            case 12:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t, e, n, r) {
                    return o.apply(this, arguments)
                }),
                            case 0:
                                return r = {
                                    CCaseStudy: "contentBody",
                                    CBlogPost: "pageBody",
                                    CMagazineArticle: "pageBody",
                                    CVideo: "videoUrl"
                                }, o = n.map(function() {
                                        var o, c, d, h, m, f, v;
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    if (o = [], d = r[n.content.component], h = n.content[d], "CVideo" !== n.content.component) {
                                                        t.next = 19;
                                                        break
                                                    }
                                                    if (!n.content.videoUrl) {
                                                        t.next = 13;
                                                        break
                                                    }
                                                    return m = h.indexOf("/embed/") + 7, f = Math.max(h.indexOf("?"), 0), v = h.slice(m, f), t.next = 10, e.$axios.$get("".concat(l.youtubeDevApi, "?id=").concat(v, "&part=contentDetails&key=").concat(l.youtubeDevKey)).then((function(video) {
                                                    }));
                                                case 10:
                                                    return t.abrupt("return", t.sent);
                                                case 13:
                                                    if (!n.content.wistiaEmbedId) {
                                                        t.next = 17;
                                                        break
                                                    }
                                                    return t.next = 16, e.$axios.$get("".concat(l.wistiaApi).concat(n.content.wistiaEmbedId, ".json?api_password=").concat(l.wistiaApiPass)).then((function(video) {
                                                    }));
                                                case 16:
                                                    return t.abrupt("return", t.sent);
                                                case 17:
                                                    t.next = 27;
                                                    break;
                                                case 19:
                                                    if (!h) {
                                                        t.next = 26;
                                                        break
                                                    }
                                                    return h.forEach((function(section) {
                                                        section.rows.forEach((function(t) {
                                                            t.columns.forEach((function(t) {
                                                                t.children.forEach((function(t) {
                                                                    "AMarkdown" === t.component && o.push(t.content)
                                                                }))
                                                            }))
                                                        }))
                                                case 26:
                                                    return t.abrupt("return", n);
                                                case 27:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }), t)
                                    })));
                                    return function(e) {
                                        return t.apply(this, arguments)
                                    }
                            case 4:
                                return t.abrupt("return", t.sent);
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }), t)
                }))), function(t, e) {
                    return r.apply(this, arguments)
                })
            }
        },
        1136: function(t, e, n) {
            "use strict";
            n(1137)("link", (function(t) {
                return function(e) {
                    return t(this, "a", "href", e)
                }
            }))
        },
        1137: function(t, e, n) {
            var r = n(25),
                o = n(43),
                c = n(76),
                l = /"/g,
                d = function(t, e, n, r) {
                    var o = String(c(t)),
                        d = "<" + e;
                    return "" !== n && (d += " " + n + '="' + String(r).replace(l, "&quot;") + '"'), d + ">" + o + "</" + e + ">"
                };
                var n = {};
                n[t] = e(d), r(r.P + r.F * o((function() {
                    var e = "" [t]('"');
                    return e !== e.toLowerCase() || e.split('"').length > 3
                })), "String", n)
            }
        },
        1138: function(t, e, n) {
            var content = n(1238);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, n(6).default)("2c6ea65c", content, !1, {
                sourceMap: !1
            })
        },
        1237: function(t, e, n) {
            "use strict";
            var r = n(1138);
            n.n(r).a
        },
        1238: function(t, e, n) {
        },
        1280: function(t, e, n) {
            "use strict";
            n.r(e);
            n(54), n(1136), n(41);
            var r = n(10),
                o = n(107),
                c = n(1060),
                l = n(1082),
                d = {
                    name: "LtvMagazineIssuePage",
                    nuxtI18n: {
                        locales: ["en"]
                    },
                    mixins: [c.a],
                    fetch: function(t) {
                            var n;
                                    case 0:
                                        (n = t.store).commit("SET_NAV_DATA", {
                                            mainNav: {
                                                component: "MainNavPlaylist"
                                            },
                                            calloutBanner: {
                                                enabled: !1
                                            }
                                        }), n.commit("SET_CONVERSION_PARAMS", {
                                            conversionValue: 15,
                                            conversionLabel: "iaTACKTXjboBEJLl7MwD"
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                            schemaMarkup: {
                                "@context": "http://schema.org",
                                "@type": "WebPage",
                            }
                        });
                        return t.link.push({
                            rel: "stylesheet",
                            href: "https://fonts.googleapis.com/css2?family=Big+Shoulders+Text:wght@700;900&display=swap"
                        }), t
                    },
                    data: function() {
                        return {
                            story: {
                                content: {}
                            },
                            displaySubscriptionForm: !0,
                            formSubmitted: !1,
                        }
                    },
                    computed: {
                        stickyIndexOffset: function() {
                            return {
                                top: "65",
                            }
                        }
                    },
                    mounted: function() {
                    },
                    beforeDestroy: function() {
                    },
                    methods: {
                        formSubmitListner: function(t) {
                        },
                        partnerRelationText: function(article) {
                            return article.content.articlePartners.split(" ")[0]
                        },
                        articlePartners: function(article) {
                            return article.content.articlePartners.substring(article.content.articlePartners.indexOf(" ") + 1)
                        }
                    },
                    asyncData: function(t) {
                            var n, r, c, d, h, m;
                                    case 0:
                                        return n = o.a.createAsyncDataStoryContext(t, {
                                            folderPath: "resources/ltv-magazine/".concat(t.params.issue, "/"),
                                            slug: ""
                                    case 3:
                                        return r = e.sent, c = o.a.createAsyncDataStoriesContext(t, {
                                            folderPath: "resources/ltv-magazine/".concat(t.params.issue, "/"),
                                            slug: ""
                                    case 7:
                                    case 10:
                                        return h = e.sent, m = {
                                            story: r.data.story,
                                            articles: h
                                        }, e.abrupt("return", r ? m : t.error({
                                            statusCode: 404
                                        }));
                                    case 13:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                h = (n(1237), n(1)),
                component = Object(h.a)(d, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        directives: [{
                            name: "editable",
                            rawName: "v-editable",
                            value: t.story.content,
                            expression: "story.content"
                        }],
                        staticClass: "ltv-issue"
                    }, [t.articles.length ? n("div", [n("a-section", {
                        staticClass: "overflow-x-hidden",
                        attrs: {
                            wrapper: "full",
                            theme: "light",
                            "horizontal-padding": "none",
                            "b-padding": "none",
                            "t-padding": "none"
                        }
                    }, [n("a-row", {
                        attrs: {
                            "vertical-alignment": "top"
                        }
                    }, [n("a-column", {
                        staticClass: "smaller-device-subscription-form-container",
                        attrs: {
                            "horizontal-padding": "none",
                            "vertical-padding": "none"
                        }
                    }, [n("a-image", {
                        attrs: {
                            "primary-image": t.story.content.cardImage,
                            "is-progressive": "",
                            width: "full"
                        }
                    })], 1), t._v(" "), n("a-column", {
                        staticClass: "col-xs-12 col-md-12 col-lg-4 subscription-form-container",
                        attrs: {
                            "horizontal-padding": "none",
                            "vertical-padding": "none",
                            "child-spacing": "none",
                            "full-height-wrapper": ""
                        }
                    }, [n("div", {
                        directives: [{
                            name: "sticky",
                            rawName: "v-sticky",
                            value: t.shouldStick,
                            expression: "shouldStick"
                        }],
                        staticClass: "collection-left-col",
                        attrs: {
                            "sticky-offset": "stickyIndexOffset"
                        }
                    }, [n("a-image", {
                        attrs: {
                            "primary-image": t.story.content.coverImage,
                            "is-progressive": "",
                            width: "full"
                        }
                    }), t._v(" "), n("div", {
                        staticClass: "subscription-form"
                    }, [t.displaySubscriptionForm && !t.formSubmitted ? n("a-heading-block", {
                        attrs: {
                            "block-heading": t.story.content.subscriptionFormCta,
                            "block-heading-size": "size6",
                            "block-heading-h-tag": "p",
                            theme: "light"
                        }
                    }) : t._e(), t._v(" "), t.displaySubscriptionForm ? n("a-lead-form", {
                        attrs: {
                            "pardot-form-url": t.story.content.subscriptionForm,
                            theme: "light"
                        }
                    }) : t._e(), t._v(" "), n("a-social-sharing", {
                        attrs: {
                            title: t.story.content.pageTitle,
                            "icon-color": "white"
                        }
                    })], 1)], 1)]), t._v(" "), n("a-column", {
                        staticClass: "col-xs-12 col-md-12 col-lg-8 collection-right-col"
                    }, [n("a-row", {
                        attrs: {
                            "horizontal-alignment": "start"
                        }
                    }, [n("a-column", {
                        attrs: {
                            "horizontal-padding": "large",
                            width: "full"
                        }
                    }, [n("a-heading-block", {
                        attrs: {
                            "block-byline": t.story.content.issueName,
                            "block-heading": "LTV MAGAZINE",
                            "block-heading-h-tag": "h2",
                            "block-heading-size": "size1",
                            "block-byline-size": "size3",
                            "block-byline-h-tag": "h5",
                            alignment: "left"
                        }
                    }), t._v(" "), n("a-heading-block", {
                        attrs: {
                            "block-heading": t.story.content.pageByline,
                            alignment: "left",
                            "block-heading-h-tag": "p",
                            "block-heading-size": "size5"
                        }
                    })], 1), t._v(" "), t._l(t.articles, (function(article) {
                        return n("a-column", {
                            key: article.id,
                            attrs: {
                                "horizontal-padding": "large",
                                width: "full"
                            }
                        }, [n("a-link", {
                            style: {
                                width: "100%"
                            },
                            attrs: {
                                "link-destination": t.stripEn(article.full_slug),
                                "data-label": article.content.pageTitle,
                                "tracking-class": "tracking_handler_ltvMag_issuePage"
                            }
                        }, [n("a-card", {
                            attrs: {
                                shadow: "none"
                            }
                        }, [n("a-row", [n("a-column", {
                            attrs: {
                                width: "half",
                                "horizontal-padding": "medium",
                                "full-height-wrapper": "",
                                "vertical-alignment": "middle",
                                "child-spacing": "small"
                            }
                        }, [n("a-heading-block", {
                            staticClass: "-article-title",
                            attrs: {
                                "block-heading": article.content.pageTitle,
                                alignment: "left",
                                "block-heading-h-tag": "h2",
                                "block-heading-size": "size1"
                            }
                        }), t._v(" "), n("a-heading-block", {
                            attrs: {
                                "block-heading": article.content.searchDescription,
                                alignment: "left",
                                "block-heading-h-tag": "p",
                                "block-heading-size": "size5"
                            }
                        }), t._v(" "), n("div", {
                            staticClass: "article-partners"
                        }, [n("span", [t._v(t._s(t.partnerRelationText(article)) + ": ")]), t._v(" "), n("span", {
                            staticClass: "partners-names"
                        }, [t._v(t._s(t.articlePartners(article)))])]), t._v(" "), n("div", [article.content.readTime ? n("span", {
                            staticClass: "article-item__info-label"
                        }, [t._v(t._s(article.content.readTime) + " Min Read")]) : t._e()])], 1), t._v(" "), n("a-column", {
                            attrs: {
                                width: "half",
                                "full-height-wrapper": "",
                                alignment: "right"
                            }
                        }, [n("div", [article.content.issuePageArticleImage ? n("a-image", {
                            attrs: {
                                "primary-image": article.content.issuePageArticleImage,
                                "is-progressive": "",
                                width: "large"
                            }
                        }) : t._e()], 1)])], 1)], 1)], 1)], 1)
                    }))], 2)], 1)], 1)], 1)], 1) : n("div", t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    })), 1)])
                }), [], !1, null, null, null);
        }
    }
]);