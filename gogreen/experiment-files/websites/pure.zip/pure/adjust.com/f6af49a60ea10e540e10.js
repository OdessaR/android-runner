(window.webpackJsonp = window.webpackJsonp || []).push([
    [87], {
        1053: function(t, e, n) {
            "use strict";
            n.r(e);
            var o = {
                    name: "MainFooterDefault",
                    computed: {
                        productLinks: function() {
                            }
                        },
                        companyLinks: function() {
                            }
                        },
                        socialLinks: function() {
                            }
                        },
                        quickLinks: function() {
                            }
                        },
                        resourcesLinks: function() {
                            }
                        }
                    }
                },
                l = (n(1261), n(1)),
                component = Object(l.a)(o, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        staticClass: "footer"
                    }, [n("div", {
                        staticClass: "footer-list"
                    }, [n("h5", {
                        staticClass: "footer__list-heading"
                    }, [t._v(t._s(t.quickLinks.heading))]), t._v(" "), n("ul", t._l(t.quickLinks.links, (function(link) {
                        return n("li", {
                            key: link.linkId,
                            staticClass: "footer__list-item"
                        }, [n("a-nav-link", {
                            staticClass: "footer__link",
                            attrs: {
                                "link-destination": link.linkDestination,
                                "is-no-follow": link.opensNewTab,
                                "opens-new-tab": link.opensNewTab,
                                "data-label": "Quick Links > " + link.linkText,
                                "tracking-class": "tracking_handler_bottomnavigation"
                            }
                        }, [t._v(t._s(link.linkText))])], 1)
                    })), 0)]), t._v(" "), n("div", {
                        staticClass: "footer-list"
                    }, [n("h5", {
                        staticClass: "footer__list-heading"
                    }, [t._v(t._s(t.productLinks.heading))]), t._v(" "), n("ul", t._l(t.productLinks.links, (function(link) {
                        return n("li", {
                            key: link.linkId,
                            staticClass: "footer__list-item"
                        }, [n("a-nav-link", {
                            staticClass: "footer__link",
                            attrs: {
                                "link-destination": link.linkDestination,
                                "data-label": "Product > " + link.linkText,
                                "tracking-class": "tracking_handler_bottomnavigation"
                            }
                        }, [t._v(t._s(link.linkText))]), n("br")], 1)
                    })), 0)]), t._v(" "), n("div", {
                        staticClass: "footer-list"
                    }, [n("h5", {
                        staticClass: "footer__list-heading"
                    }, [t._v(t._s(t.resourcesLinks.heading))]), t._v(" "), n("ul", t._l(t.resourcesLinks.links, (function(link) {
                        return n("li", {
                            key: link.linkId,
                            staticClass: "footer__list-item"
                        }, [n("a-nav-link", {
                            staticClass: "footer__link",
                            attrs: {
                                "link-destination": link.absoluteLink || link.linkDestination,
                                "data-label": "Resources > " + link.linkText,
                                "tracking-class": "tracking_handler_bottomnavigation"
                            }
                        }, [t._v(t._s(link.linkText))]), n("br")], 1)
                    })), 0)]), t._v(" "), n("div", {
                        staticClass: "footer-list"
                    }, [n("h5", {
                        staticClass: "footer__list-heading"
                    }, [t._v(t._s(t.companyLinks.heading))]), t._v(" "), n("ul", t._l(t.companyLinks.links, (function(link) {
                        return n("li", {
                            key: link.linkId,
                            staticClass: "footer__list-item"
                        }, [n("a-nav-link", {
                            staticClass: "footer__link",
                            attrs: {
                                "link-destination": link.linkDestination,
                                "data-label": "Company > " + link.linkText,
                                "tracking-class": "tracking_handler_bottomnavigation"
                            }
                        }, [t._v(t._s(link.linkText))]), n("br")], 1)
                    })), 0)]), t._v(" "), n("div", {
                        staticClass: "footer-list"
                    }, [n("h5", {
                        staticClass: "footer__list-heading"
                    }, [t._v(t._s(t.socialLinks.heading))]), t._v(" "), n("ul", [t._l(t.socialLinks.links, (function(link) {
                        return n("li", {
                            key: link.linkId,
                            staticClass: "footer__list-item"
                        }, [n("a-nav-link", {
                            staticClass: "footer__link",
                            attrs: {
                                "link-destination": link.linkDestination,
                                "data-label": "Connect with us > " + link.linkText,
                                "opens-new-tab": "",
                                "is-no-follow": "",
                                "tracking-class": "tracking_handler_bottomnavigation"
                            }
                        }, [t._v(t._s(link.linkText))]), n("br")], 1)
                    })), t._v(" "), "zh" === t.$i18n.locale ? n("li", {
                        attrs: {
                            id: "main-footer_wechat-qr"
                        }
                    }, [n("a-image", {
                        attrs: {
                            width: "xSmall",
                            "primary-image": "https://a.storyblok.com/f/47007/300x399/f108b18683/wechat-300.png"
                        }
                    })], 1) : t._e()], 2)])])
                }), [], !1, null, "4300ae98", null);
        },
        1150: function(t, e, n) {
            var content = n(1262);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, n(6).default)("7c7a3b3a", content, !1, {
                sourceMap: !1
            })
        },
        1261: function(t, e, n) {
            "use strict";
            var o = n(1150);
            n.n(o).a
        },
        1262: function(t, e, n) {
        }
    }
]);