(window.webpackJsonp = window.webpackJsonp || []).push([
    [49], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var r = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1097: function(t, e, n) {
            var content = n(1176);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, n(6).default)("d738d2e8", content, !1, {
                sourceMap: !1
            })
        },
        1175: function(t, e, n) {
            "use strict";
            var r = n(1097);
            n.n(r).a
        },
        1176: function(t, e, n) {
        },
        1308: function(t, e, n) {
            "use strict";
            n.r(e);
            n(41);
            var r = n(10),
                c = n(107),
                o = {
                    nuxtI18n: {
                        locales: ["en", "zh", "ja", "fr", "id", "ko"]
                    },
                    mixins: [n(1060).a],
                    fetch: function(t) {
                            var n;
                                    case 0:
                                        (n = t.store).commit("SET_NAV_DATA", {
                                            mainNav: {
                                                ctaScrollOnPage: {
                                                    enabled: !0,
                                                    ctaText: "Request a Demo",
                                                    sectionId: "#demo-request"
                                                }
                                            }
                                        }), n.commit("SET_CONVERSION_PARAMS", {
                                            conversionValue: 30,
                                            conversionLabel: "2WDxCOmFj7oBEJLl7MwD"
                                        });
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                        })
                    },
                    asyncData: function(t) {
                            var n, r, o, l;
                                    case 0:
                                        return n = c.a.createAsyncDataStoryContext(t, {
                                            slug: "",
                                            folderPath: "pricing/"
                                    case 3:
                                        if (r = e.sent, o = {
                                                continent_code: ""
                                            }, "en" !== t.store.app.i18n.locale) {
                                            break
                                        }
                                    case 9:
                                        break;
                                    case 12:
                                    case 15:
                                        return l = {
                                            geoData: o,
                                            story: r.data.story
                                        }, e.abrupt("return", r ? l : t.error({
                                            statusCode: 404
                                        }));
                                    case 17:
                                    case "end":
                                        return e.stop()
                                }
                            }), e, null, [
                                [6, 12]
                            ])
                        })))()
                    }
                },
                l = (n(1175), n(1)),
                component = Object(l.a)(o, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        directives: [{
                            name: "editable",
                            rawName: "v-editable",
                            value: t.story.content,
                            expression: "story.content"
                        }]
                    }, [n("a-section", {
                        staticClass: "bg-color-dark-blue bg-separator-down"
                    }, [n("a-row", [n("a-column", {
                        attrs: {
                            "vertical-padding": "medium",
                            "child-spacing": "medium",
                            width: "full",
                            alignment: "center"
                        }
                    }, [n("a-heading-block", {
                        attrs: {
                            "block-heading": t.story.content.pageTitle,
                            "block-byline": t.story.content.pageByline,
                            "block-heading-size": "size2",
                            "block-heading-h-tag": "h1",
                            "block-byline-size": "size4",
                            "block-byline-h-tag": "h2",
                            theme: "light",
                            alignment: "center"
                        }
                    })], 1)], 1), t._v(" "), n("a-row", t._l(t.story.content.planCards, (function(e, r) {
                        return n("a-column", t._b({
                            key: r,
                            attrs: {
                                width: "third",
                                "full-height-wrapper": ""
                            }
                        }, "a-column", e, !1), [n("a-card", {
                            staticClass: "a-card__pricing-card full-height"
                        }, [n("div", {
                            class: "a-card__pricing-card-stripe-" + r
                        }), t._v(" "), n("div", {
                            staticClass: "padded -v-padded-2 -h-padded-2 align-center"
                        }, [n("a-heading-block", {
                            staticClass: "margin -b-margin-1",
                            attrs: {
                                "block-heading": e.cardHeading,
                                "block-heading-size": "size3",
                                "block-heading-h-tag": "h3",
                                alignment: "center"
                            }
                        }), t._v(" "), n("div", {
                            staticClass: "margin -b-margin-1"
                        }, ["EU" != t.geoData.continent_code && e.cardCta[0] ? n("a-link", {
                            attrs: {
                                "link-text": e.cardCta[0].linkText,
                                "link-destination": e.cardCta[0].linkDestination.url,
                                "data-label": e.cardHeading + " > " + e.cardCta[0].linkText,
                                "tracking-class": "tracking_handler_pricing_plan",
                                "link-style": "ghost"
                            }
                        }) : n("a-link", {
                            attrs: {
                                "link-text": t.$t("Contact Us"),
                                "data-label": e.cardHeading + " > Contact us",
                                "tracking-class": "tracking_handler_pricing_plan",
                                "link-destination": "#demo-request",
                                "link-style": "ghost"
                            }
                        })], 1), t._v(" "), n("p", {
                            staticClass: "margin -b-margin-1"
                        }, [t._v(t._s(e.cardDescription))]), t._v(" "), n("a-list", {
                            attrs: {
                                "list-items": e.cardList,
                                "item-padding-size": "reduced",
                                "icon-style": "tick"
                            }
                        })], 1)])], 1)
                    })), 1)], 1), t._v(" "), n("a-section", {
                        attrs: {
                            "t-padding": "none"
                        }
                    }, [n("a-column", {
                        attrs: {
                            width: "full",
                            "vertical-padding": "none",
                            alignment: "center"
                        }
                    }, [n("a-markdown", {
                        attrs: {
                            content: t.story.content.disclaimer
                        }
                    })], 1)], 1), t._v(" "), t._l(t.story.content.highlightedFeatures, (function(section) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: section._uid
                        }, "a-section", section, !1))
                    })), t._v(" "), n("a-section", {
                        attrs: {
                            "bg-color": "lightGrey",
                            "bg-angle-top": "up",
                            "bg-angle-bottom": "up",
                            "t-padding": "none"
                        }
                    }, [n("a-row", [n("a-column", {
                        attrs: {
                            "vertical-padding": "large",
                            "child-spacing": "medium",
                            width: "full",
                            alignment: "center"
                        }
                    }, [n("h2", {
                        staticClass: "font-size-2 line-breaks"
                    }, [t._v("\n          " + t._s(t.story.content.addonSectionTitle) + "\n        ")])])], 1), t._v(" "), n("a-row", t._l(t.story.content.addonCards, (function(e, r) {
                        return n("a-column", t._b({
                            key: r,
                            attrs: {
                                width: "third",
                                "full-height-wrapper": ""
                            }
                        }, "a-column", e, !1), [n("a-card", {
                            staticClass: "align-center full-height"
                        }, [n("div", {
                            staticClass: "bg-gradient-adjust"
                        }, [n("div", {
                            staticClass: "flex-row -center -middle card-header-overlay bg-image padded -h-padded-1"
                        }, [n("a-heading-block", {
                            attrs: {
                                "block-heading": e.cardHeading,
                                "block-heading-size": "size3",
                                "block-heading-h-tag": "h3",
                                alignment: "center",
                                theme: "light"
                            }
                        })], 1)]), t._v(" "), n("div", {
                            staticClass: "padded -v-padded-2 -h-padded-2"
                        }, [n("p", {
                            staticClass: "align-left margin -b-margin-1"
                        }, [t._v("\n              " + t._s(e.cardDescription) + "\n            ")]), t._v(" "), n("div", {
                            staticClass: "margin -b-margin-1"
                        }, [n("a-list", {
                            attrs: {
                                "list-items": e.cardList,
                                "item-padding-size": "reduced",
                                "icon-style": "tick"
                            }
                        })], 1), t._v(" "), e.cardCta[0] ? n("span", ["EU" != t.geoData.continent_code && e.cardCta[0] ? n("a-link", {
                            attrs: {
                                "link-text": e.cardCta[0].linkText,
                                "link-destination": e.cardCta[0].linkDestination.url,
                                "data-label": e.cardHeading + " > " + e.cardCta[0].linkText,
                                "tracking-class": "tracking_handler_pricing_element",
                                "link-style": "ghost"
                            }
                        }) : n("a-link", {
                            attrs: {
                                "link-text": t.$t("Contact Us"),
                                "data-label": e.cardHeading + " > Contact us",
                                "link-destination": "#demo-request",
                                "tracking-class": "tracking_handler_pricing_element",
                                "link-style": "ghost"
                            }
                        })], 1) : t._e()])])], 1)
                    })), 1)], 1), t._v(" "), t._l(t.story.content.pageBody, (function(section, e) {
                        return n("a-section", t._b({
                            directives: [{
                                name: "editable",
                                rawName: "v-editable",
                                value: section,
                                expression: "section"
                            }],
                            key: e
                        }, "a-section", section, !1))
                    }))], 2)
                }), [], !1, null, null, null);
        }
    }
]);