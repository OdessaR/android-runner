(window.webpackJsonp = window.webpackJsonp || []).push([
    [86], {
        1048: function(t, n, o) {
            "use strict";
            o.r(n);
            o(44);
            var e = {
                    name: "ProductNavDropdownSlot",
                    props: {
                        productLinks: {
                            type: Object,
                            default: function() {
                                return {}
                            }
                        }
                    },
                    data: function() {
                        return {
                            hoverColor: "",
                            activeLinkColor: ""
                        }
                    },
                    computed: {
                        styleObject: function() {
                            return {
                            }
                        }
                    },
                    methods: {
                        isActiveLink: function(link) {
                            var t = "/" === link.linkDestination.cached_url.substr(-1) ? link.linkDestination.cached_url : link.linkDestination.cached_url + "/";
                        }
                    }
                },
                r = (o(1243), o(1)),
                l = Object(r.a)(e, (function() {
                        n = t.$createElement,
                        o = t._self._c || n;
                    return o("div", {
                        staticClass: "product-dropdown"
                    }, [o("div", {
                        staticClass: "product-dropdown__grid"
                    }, t._l(t.productLinks.dropdownContent.links, (function(link, n) {
                        return o("a-link", {
                            key: n,
                            attrs: {
                                "data-label": "Product > " + link.linkText,
                                "link-destination": link.linkDestination.cached_url,
                                "tracking-class": "tracking_handler_topnavigation"
                            }
                        }, [o("div", {
                            staticClass: "product-dropdown__link full-height",
                            class: {
                                "is-exact-active": t.isActiveLink(link)
                            },
                            style: t.styleObject,
                            on: {
                                mouseover: function(n) {
                                    t.hoverColor = link.linkColor
                                },
                                mouseleave: function(n) {
                                    t.hoverColor = ""
                                }
                            }
                        }, [o("a-horizontal-strip", {
                            staticClass: "product-dropdown__link-heading",
                            style: {
                                "--color-heading": link.linkColor
                            },
                            attrs: {
                                "horizontal-alignment": "start",
                                "vertical-alignment": "middle"
                            }
                        }, [link.iconName ? o("div", {
                            staticClass: "product-dropdown__link-icon"
                        }, [o("a-icon", {
                            attrs: {
                                "icon-name": link.iconName,
                                "icon-size": "small",
                                "icon-color": "inherit"
                            }
                        })], 1) : t._e(), t._v(" "), o("span", {
                            staticClass: "uppercase"
                        }, [t._v(t._s(link.linkText))])]), t._v(" "), o("span", {
                            staticClass: "product-dropdown__link-text"
                        }, [o("p", [t._v(t._s(link.linkDescription))])])], 1)])
                    })), 1)])
                }), [], !1, null, "5ccfc3e0", null).exports,
                d = {
                    name: "ResourcesDropdownSlot",
                    props: {
                        resourcesLinks: {
                            type: Object,
                            default: function() {
                                return {}
                            }
                        }
                    }
                },
                c = (o(1245), Object(r.a)(d, (function() {
                        n = t.$createElement,
                        o = t._self._c || n;
                    return o("div", {
                        staticClass: "resources-dropdown"
                    }, [o("div", {
                        staticClass: "resources-dropdown__grid"
                    }, [o("div", {
                        staticClass: "resources-dropdown__grid-learn"
                    }, [o("a-horizontal-strip", {
                        staticClass: "resources-dropdown__heading",
                        attrs: {
                            "horizontal-alignment": "start",
                            "vertical-alignment": "middle"
                        }
                    }, [o("div", {
                        staticClass: "resources-dropdown__icon"
                    }, [o("a-icon", {
                        attrs: {
                            "icon-name": t.resourcesLinks.dropdownContent.learnIconName,
                            "icon-size": "small",
                            "icon-color": "inherit"
                        }
                    })], 1), t._v(" "), o("span", {
                        staticClass: "uppercase"
                    }, [t._v(t._s(t.resourcesLinks.dropdownContent.learnHeading))])]), t._v(" "), o("ul", t._l(t.resourcesLinks.dropdownContent.learnLinks, (function(link, n) {
                        return o("li", {
                            key: n
                        }, [o("a-nav-link", {
                            staticClass: "resources-dropdown__category-links",
                            attrs: {
                                "data-label": "Resources > " + link.linkText,
                                "link-destination": link.linkDestination.cached_url || link.linkDestination.url,
                                "tracking-class": "tracking_handler_topnavigation",
                                "exact-active-class": "is-exact-active"
                            }
                        }, [t._v("\n            " + t._s(link.linkText) + "\n          ")])], 1)
                    })), 0)], 1), t._v(" "), o("div", {
                        staticClass: "resources-dropdown__grid-attend"
                    }, [o("a-horizontal-strip", {
                        staticClass: "resources-dropdown__heading",
                        attrs: {
                            "horizontal-alignment": "start",
                            "vertical-alignment": "middle"
                        }
                    }, [o("div", {
                        staticClass: "resources-dropdown__icon"
                    }, [o("a-icon", {
                        attrs: {
                            "icon-name": t.resourcesLinks.dropdownContent.attendIconName,
                            "icon-size": "small",
                            "icon-color": "inherit"
                        }
                    })], 1), t._v(" "), o("span", {
                        staticClass: "uppercase"
                    }, [t._v(t._s(t.resourcesLinks.dropdownContent.attendHeading))])]), t._v(" "), o("ul", t._l(t.resourcesLinks.dropdownContent.attendLinks, (function(link, n) {
                        return o("li", {
                            key: n
                        }, [o("a-nav-link", {
                            staticClass: "resources-dropdown__category-links",
                            attrs: {
                                "data-label": "Resources > " + link.linkText,
                                "link-destination": link.linkDestination.cached_url || link.linkDestination.url,
                                "tracking-class": "tracking_handler_topnavigation",
                                "exact-active-class": "is-exact-active"
                            }
                        }, [t._v("\n            " + t._s(link.linkText) + "\n          ")])], 1)
                    })), 0)], 1), t._v(" "), o("div", {
                        staticClass: "resources-dropdown__grid-interact"
                    }, [o("a-horizontal-strip", {
                        staticClass: "resources-dropdown__heading",
                        attrs: {
                            "horizontal-alignment": "start",
                            "vertical-alignment": "middle"
                        }
                    }, [o("div", {
                        staticClass: "resources-dropdown__icon"
                    }, [o("a-icon", {
                        attrs: {
                            "icon-name": t.resourcesLinks.dropdownContent.interactIconName,
                            "icon-size": "small",
                            "icon-color": "inherit"
                        }
                    })], 1), t._v(" "), o("span", {
                        staticClass: "uppercase"
                    }, [t._v(t._s(t.resourcesLinks.dropdownContent.interactHeading))])]), t._v(" "), o("ul", t._l(t.resourcesLinks.dropdownContent.interactLinks, (function(link, n) {
                        return o("li", {
                            key: n
                        }, [o("a-nav-link", {
                            staticClass: "resources-dropdown__category-links",
                            attrs: {
                                "data-label": "Resources > " + link.linkText,
                                "link-destination": link.linkDestination.cached_url || link.linkDestination.url,
                                "tracking-class": "tracking_handler_topnavigation",
                                "exact-active-class": "is-exact-active"
                            }
                        }, [t._v("\n            " + t._s(link.linkText) + "\n          ")])], 1)
                    })), 0)], 1), t._v(" "), o("div", {
                        staticClass: "resources-dropdown__grid-feature"
                    }, [o("a-horizontal-strip", {
                        attrs: {
                            "vertical-alignment": "top",
                            "full-height": ""
                        }
                    }, [o("div", {
                        staticClass: "flex-row -column -start -top full-height"
                    }, [o("a-heading-block", {
                        attrs: {
                            "block-byline": t.resourcesLinks.dropdownContent.featuredResourceHeading,
                            "block-byline-size": "size6",
                            "block-byline-h-tag": "p",
                            alignment: "left"
                        }
                    }), t._v(" "), o("a-heading-block", {
                        staticClass: "margin -b-margin-2",
                        attrs: {
                            "block-heading": t.resourcesLinks.dropdownContent.featuredResourceByline,
                            "block-heading-size": "size5",
                            "block-heading-h-tag": "p",
                            alignment: "left"
                        }
                    }), t._v(" "), o("a-link", {
                        attrs: {
                            "data-label": "Resources > Read more - " + t.resourcesLinks.dropdownContent.featuredResourceLinkDestination.cached_url,
                            "link-text": t.resourcesLinks.dropdownContent.featuredResourceCtaText,
                            "link-destination": t.resourcesLinks.dropdownContent.featuredResourceLinkDestination,
                            "tracking-class": "tracking_handler_topnavigation",
                            "link-style": "button"
                        }
                    })], 1), t._v(" "), o("div", [o("a-link", {
                        attrs: {
                            "data-label": "Resources > Image - " + t.resourcesLinks.dropdownContent.featuredResourceLinkDestination.cached_url,
                            "link-destination": t.resourcesLinks.dropdownContent.featuredResourceLinkDestination,
                            "tracking-class": "tracking_handler_topnavigation"
                        }
                    }, [t.resourcesLinks.dropdownContent.featuredResourceImage ? o("a-image", {
                        attrs: {
                            "primary-image": t.resourcesLinks.dropdownContent.featuredResourceImage,
                            width: "large"
                        }
                    }) : t._e()], 1)], 1)])], 1)])])
                }), [], !1, null, "495d0bfd", null).exports),
                _ = {
                    name: "BlogNavDropdownSlot",
                    components: {
                        CardBlog: o(1080).a
                    },
                    props: {
                        blogLinks: {
                            type: Object,
                            default: function() {
                                return {}
                            }
                        }
                    },
                    computed: {
                        stories: function() {
                        }
                    }
                },
                k = (o(1247), Object(r.a)(_, (function() {
                        n = t.$createElement,
                        o = t._self._c || n;
                    return o("div", {
                        staticClass: "blog-dropdown"
                    }, [o("div", {
                        staticClass: "blog-dropdown__grid"
                    }, [o("div", {
                        staticClass: "blog-dropdown__grid-block"
                    }, [o("div", {
                        staticClass: "blog-dropdown__cta-block full-height"
                    }, [o("a-heading-block", {
                        staticClass: "margin -b-margin-2",
                        attrs: {
                            "block-byline": t.blogLinks.dropdownContent.blogIntroHeading,
                            "block-byline-size": "size5",
                            "block-byline-h-tag": "P",
                            alignment: "left"
                        }
                    }), t._v(" "), o("a-heading-block", {
                        staticClass: "margin -b-margin-2",
                        attrs: {
                            "block-heading": t.blogLinks.dropdownContent.blogIntroByline,
                            "block-heading-size": "size4",
                            "block-heading-h-tag": "h2",
                            alignment: "left"
                        }
                    }), t._v(" "), o("a-link", {
                        attrs: {
                            "link-text": t.blogLinks.dropdownContent.blogIntroCtaText,
                            "link-destination": t.localePath({
                                name: "blog"
                            }),
                            "data-label": "Blog > Go to blog",
                            "tracking-class": "tracking_handler_topnavigation",
                            "link-style": "button"
                        }
                    })], 1)]), t._v(" "), o("div", {
                        staticClass: "blog-dropdown__grid-block"
                    }, [o("card-blog", t._b({
                        attrs: {
                            "data-label": "Blog > Featured - " + t.blogLinks.dropdownContent.featuredArticle.story.pageTitle,
                            "full-slug": t.blogLinks.dropdownContent.featuredArticle.story.full_slug,
                            "tracking-class": "tracking_handler_topnavigation"
                        }
                    }, "card-blog", t.blogLinks.dropdownContent.featuredArticle.story, !1))], 1), t._v(" "), o("div", {
                        staticClass: "blog-dropdown__grid-block"
                    }, [o("a-heading-block", {
                        attrs: {
                            "block-byline": t.blogLinks.dropdownContent.latestArticlesHeading,
                            "block-byline-size": "size5",
                            "block-byline-h-tag": "P",
                            alignment: "left"
                        }
                    }), t._v(" "), o("ul", {
                        staticClass: "blog-dropdown__list"
                    }, t._l(t.blogLinks.dropdownContent.latestBlogPosts, (function(link, n) {
                        return o("li", {
                            key: n,
                            staticClass: "blog-dropdown__list-item"
                        }, [o("a-link", {
                            attrs: {
                                "data-label": "Blog > Latest articles - " + link.pageTitle,
                                "link-destination": link.full_slug,
                                "tracking-class": "tracking_handler_topnavigation"
                            }
                        }, [o("span", {
                            staticClass: "flex-row -middle -nowrap -start"
                        }, [o("div", {
                            staticClass: "blog-dropdown__list-icon"
                        }, [o("a-icon", {
                            attrs: {
                                "icon-name": "caret-right",
                                "icon-size": "small",
                                "icon-color": "adjust"
                            }
                        })], 1), t._v(" "), o("p", [t._v(t._s(link.pageTitle))])])])], 1)
                    })), 0), t._v(" "), o("a-link", {
                        attrs: {
                            "link-text": t.blogLinks.dropdownContent.latestArticlesCtaText,
                            "link-destination": t.localePath({
                                name: "blog"
                            }),
                            "data-label": "Blog > View all",
                            "tracking-class": "tracking_handler_topnavigation",
                            "link-icon": "page-arrow"
                        }
                    })], 1)])])
                }), [], !1, null, "682fcf14", null).exports),
                h = {
                    name: "SolutionsNavDropdownSlot",
                    props: {
                        solutionsLinks: {
                            type: Object,
                            default: function() {
                                return {}
                            }
                        }
                    },
                    methods: {
                        isActiveLink: function(link) {
                            var t = "/" === link.linkDestination.cached_url.substr(-1) ? link.linkDestination.cached_url : link.linkDestination.cached_url + "/";
                        }
                    }
                },
                v = (o(1249), {
                    name: "MainNavDefault",
                    components: {
                        ProductDropdownSlot: l,
                        ResourcesDropdownSlot: c,
                        BlogDropdownSlot: k,
                        SolutionsDropdownSlot: Object(r.a)(h, (function() {
                                n = t.$createElement,
                                o = t._self._c || n;
                            return o("div", {
                                staticClass: "solutions-dropdown"
                            }, [o("div", {
                                staticClass: "solutions-dropdown__heading full-width"
                            }, [o("a-heading-block", {
                                staticClass: "margin -h-margin-2 -v-margin-1",
                                attrs: {
                                    "block-heading": t.solutionsLinks.dropdownContent.dropdownHeading,
                                    "block-heading-size": "size5",
                                    "block-heading-h-tag": "h2",
                                    alignment: "left"
                                }
                            })], 1), t._v(" "), o("div", {
                                staticClass: "solutions-dropdown__grid"
                            }, t._l(t.solutionsLinks.dropdownContent.links, (function(link, n) {
                                return o("a-nav-link", {
                                    key: n,
                                    attrs: {
                                        "data-label": "Solutions > " + link.linkText,
                                        "link-destination": link.linkDestination.cached_url,
                                        "tracking-class": "tracking_handler_topnavigation"
                                    }
                                }, [o("div", {
                                    staticClass: "solutions-dropdown__link full-height",
                                    class: {
                                        "is-exact-active": t.isActiveLink(link)
                                    }
                                }, [o("a-horizontal-strip", {
                                    staticClass: "solutions-dropdown__link-heading",
                                    attrs: {
                                        "horizontal-alignment": "start",
                                        "vertical-alignment": "middle"
                                    }
                                }, [link.iconName ? o("div", {
                                    staticClass: "solutions-dropdown__link-icon"
                                }, [o("a-icon", {
                                    attrs: {
                                        "icon-name": link.iconName,
                                        "icon-size": "small",
                                        "icon-color": "inherit"
                                    }
                                })], 1) : t._e(), t._v(" "), o("span", {
                                    staticClass: "uppercase"
                                }, [t._v(t._s(link.linkText))])]), t._v(" "), o("span", {
                                    staticClass: "solutions-dropdown__link-text"
                                }, [o("p", [t._v(t._s(link.linkDescription))])])], 1)])
                            })), 1)])
                        }), [], !1, null, "0806f988", null).exports
                    },
                    data: function() {
                        return {
                            mobileNavIsActive: !1
                        }
                    },
                    computed: {
                        hasShareComponent: function() {
                        },
                        hasProgressBar: function() {
                        },
                        showRequestDemoButton: function() {
                        },
                        resourcesLinks: function() {
                                return "resources-dropdown" == t.linkId
                            }))
                        },
                        blogLinks: function() {
                                return "blog-dropdown" == t.linkId
                            }))
                        },
                        productLinks: function() {
                                return "products-dropdown" == t.linkId
                            }))
                        },
                        solutionsLinks: function() {
                                return "solutions-dropdown" == t.linkId
                            }))
                        },
                        pricingLink: function() {
                                return "pricing" == t.linkId
                            }))
                        },
                        customersLink: function() {
                                return "customers" == t.linkId
                            }))
                        },
                        partnersLink: function() {
                                return "partners" == t.linkId
                            }))
                        },
                        mainNavCtaParams: function() {
                                title: "Go to Dashboard",
                            } : {
                            }
                        },
                        showLogIn: function() {
                        },
                        dashEnvironment: function() {
                                case "www.adjust.com":
                                    return "https://dash.adjust.com/";
                                case "www.adjust.com":
                                case "qa-1.adjust.com":
                                    return "https://dash-qa-1.adjust.com/";
                                case "qa-2.adjust.com":
                                    return "https://dash-qa-2.adjust.com/";
                                case "demo-1.adjust.com":
                                    return "https://dash-demo-1.adjust.com/";
                                case "demo-2.adjust.com":
                                    return "https://dash-demo-2.adjust.com/";
                                case "staging.adjust.com":
                                    return "https://staging.adjust.com/";
                                default:
                                    return "https://dash.adjust.com/"
                            }
                        }
                    },
                    methods: {
                        toggleMobileNav: function() {
                        },
                        uncollapseDemoForm: function() {
                        }
                    }
                }),
                m = (o(1251), Object(r.a)(v, (function() {
                        n = t.$createElement,
                        o = t._self._c || n;
                    return o("a-navbar", {
                        staticStyle: {
                            position: "relative"
                        },
                        attrs: {
                            height: 65,
                            "has-share-component": t.hasShareComponent,
                            "has-progress-bar": t.hasProgressBar
                        }
                    }, [o("template", {
                        slot: "navLogo"
                    }, [o("u-logo", {
                        attrs: {
                            "tracking-class": "tracking_handler_topnavigation",
                            "data-label": "Logo"
                        }
                    })], 1), t._v(" "), o("template", {
                        slot: "leftSide"
                    }, [t.productLinks ? o("a-dropdown", {
                        staticClass: "hide-on-mobile margin -r-margin-1",
                        attrs: {
                            "primary-link-text": t.productLinks.linkText,
                            "primary-link-destination": t.productLinks.linkDestination.cached_url,
                            "data-label": "Products",
                            "tracking-class": "tracking_handler_topnavigation",
                            "hover-tracking-class": "tracking_handler_topnavigation_hover",
                            "main-route-name": "product"
                        }
                    }, [o("product-dropdown-slot", {
                        attrs: {
                            slot: "links",
                            "product-links": t.productLinks
                        },
                        slot: "links"
                    })], 1) : t._e(), t._v(" "), t.solutionsLinks ? o("a-dropdown", {
                        staticClass: "hide-on-mobile margin -r-margin-1 main-nav__reduced-links",
                        attrs: {
                            "primary-link-text": t.solutionsLinks.linkText,
                            "data-label": "Solutions",
                            "hover-tracking-class": "tracking_handler_topnavigation_hover",
                            "main-route-name": "industries"
                        }
                    }, [o("solutions-dropdown-slot", {
                        attrs: {
                            slot: "links",
                            "solutions-links": t.solutionsLinks
                        },
                        slot: "links"
                    })], 1) : t._e(), t._v(" "), t.pricingLink ? o("a-nav-link", {
                        staticClass: "hide-on-mobile margin -r-margin-1",
                        attrs: {
                            "link-text": t.pricingLink.linkText,
                            "link-destination": t.pricingLink.linkDestination.cached_url,
                            "data-label": "Pricing",
                            "tracking-class": "tracking_handler_topnavigation"
                        }
                    }) : t._e(), t._v(" "), t.resourcesLinks ? o("a-dropdown", {
                        staticClass: "hide-on-mobile margin -r-margin-1",
                        attrs: {
                            "primary-link-destination": t.resourcesLinks.linkDestination.cached_url,
                            "primary-link-text": t.resourcesLinks.linkText,
                            "data-label": "Learn",
                            "tracking-class": "tracking_handler_topnavigation",
                            "hover-tracking-class": "tracking_handler_topnavigation_hover",
                            "main-route-name": "resources"
                        }
                    }, [o("resources-dropdown-slot", {
                        attrs: {
                            slot: "links",
                            "resources-links": t.resourcesLinks
                        },
                        slot: "links"
                    })], 1) : t._e(), t._v(" "), t.blogLinks ? o("a-dropdown", {
                        staticClass: "hide-on-mobile margin -r-margin-1",
                        attrs: {
                            "primary-link-destination": t.blogLinks.linkDestination.cached_url,
                            "primary-link-text": t.blogLinks.linkText,
                            "data-label": "Blog",
                            "tracking-class": "tracking_handler_topnavigation",
                            "hover-tracking-class": "tracking_handler_topnavigation_hover",
                            "main-route-name": "blog"
                        }
                    }, [o("blog-dropdown-slot", {
                        attrs: {
                            slot: "links",
                            "blog-links": t.blogLinks
                        },
                        slot: "links"
                    })], 1) : t._e(), t._v(" "), t.customersLink ? o("a-nav-link", {
                        staticClass: "hide-on-mobile margin -r-margin-1",
                        attrs: {
                            "link-text": t.customersLink.linkText,
                            "link-destination": t.customersLink.linkDestination.cached_url,
                            "data-label": "Customers",
                            "tracking-class": "tracking_handler_topnavigation"
                        }
                    }) : t._e(), t._v(" "), t.partnersLink ? o("a-nav-link", {
                        staticClass: "hide-on-mobile main-nav__reduced-links",
                        attrs: {
                            "link-text": t.partnersLink.linkText,
                            "link-destination": t.partnersLink.linkDestination.cached_url,
                            "data-label": "Partners",
                            "tracking-class": "tracking_handler_topnavigation"
                        }
                    }) : t._e()], 1), t._v(" "), o("template", {
                        slot: "rightSide"
                    }, ["en" === t.$i18n.locale ? o("a-nav-link", {
                        staticClass: "margin -r-margin-1 hide-on-mobile",
                        attrs: {
                            "link-destination": t.localePath({
                                name: "search"
                            }),
                            "tracking-class": "tracking_handler_topnavigation",
                            "data-label": "Search"
                        }
                    }, [o("a-icon", {
                        attrs: {
                            "icon-name": "search",
                            "icon-color": "darkBlue"
                        }
                    })], 1) : t._e(), t._v(" "), t.showLogIn ? o("a-nav-link", {
                        staticClass: "margin -r-margin-1",
                        attrs: {
                            "link-text": t.$t("Log In"),
                            "link-destination": t.dashEnvironment,
                            "opens-new-tab": "",
                            "is-no-follow": "",
                            "tracking-class": "tracking_handler_topnavigation",
                            "data-label": "Log In"
                        }
                    }) : t._e(), t._v(" "), t.showRequestDemoButton ? o("a-link", {
                        staticClass: "hide-on-mobile",
                        attrs: {
                            "data-label": t.mainNavCtaParams.title,
                            "link-text": t.$t(t.mainNavCtaParams.title),
                            "link-destination": t.mainNavCtaParams.destination,
                            "tracking-class": "tracking_handler_topnavigation",
                            theme: "brand",
                            "link-style": "button"
                        },
                        nativeOn: {
                            click: function(n) {
                                return t.uncollapseDemoForm()
                            }
                        }
                    }) : t._e(), t._v(" "), o("button", {
                        staticClass: "main-nav__hamburger hide-on-desktop hide-on-tablet",
                        attrs: {
                            "aria-label": "Close"
                        },
                        on: {
                            click: t.toggleMobileNav
                        }
                    }, [o("a-icon", {
                        staticClass: "a-dropdown__primary-link-icon",
                        attrs: {
                            width: "medium",
                            "icon-name": "hamburger"
                        }
                    })], 1)], 1)], 2)
                }), [], !1, null, "5072ed8a", null));
        },
        1071: function(t, n, o) {
            var content = o(1079);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("707bab6b", content, !1, {
                sourceMap: !1
            })
        },
        1078: function(t, n, o) {
            "use strict";
            var e = o(1071);
            o.n(e).a
        },
        1079: function(t, n, o) {
        },
        1080: function(t, n, o) {
            "use strict";
            var e = {
                    name: "CardBlog",
                    props: {
                        pageTitle: {
                            type: String,
                            default: ""
                        },
                        pageByline: {
                            type: String,
                            default: ""
                        },
                        partnerLogos: {
                            type: Array,
                            default: function() {
                                return []
                            }
                        },
                        cardImage: {
                            type: String,
                            default: ""
                        },
                        fullSlug: {
                            type: String,
                            default: ""
                        },
                        publishedDate: {
                            type: String,
                            default: ""
                        },
                        trackingClass: {
                            type: String,
                            default: "tracking_handler_blog_cards"
                        },
                        dataLabel: {
                            type: String,
                            default: ""
                        }
                    },
                    methods: {
                        trackHoverEvent: function() {}
                    }
                },
                r = (o(1078), o(1)),
                component = Object(r.a)(e, (function() {
                        n = t.$createElement,
                        o = t._self._c || n;
                    return o("a-link", {
                        attrs: {
                            "link-destination": t.stripEn(t.fullSlug),
                            "data-label": t.dataLabel ? t.dataLabel : t.stripEn(t.fullSlug),
                            "tracking-class": t.trackingClass
                        },
                        nativeOn: {
                            mouseenter: function(n) {
                                return t.trackHoverEvent(n)
                            }
                        }
                    }, [o("a-card", {
                        staticClass: "card-blog",
                        attrs: {
                            shadow: "medium"
                        }
                    }, [o("div", {
                        staticClass: "card-blog__hover-layer"
                    }, [o("div", {
                        staticClass: "card-blog__hover-layer-background"
                    }), t._v(" "), o("div", {
                        staticClass: "card-blog__hover-layer-content padded -h-padded-2 -v-padded-2 flex-row -center -middle"
                    }, [o("h4", {
                        staticClass: "align-center"
                    }, [t._v(t._s(t._f("truncate")(t.pageByline, 200)))]), t._v(" "), o("span", {
                        staticClass: "a-link -theme-light -button -ghost"
                    }, [t._v(t._s(t.$t("Read more")))])])]), t._v(" "), o("div", {
                        staticClass: "card-blog__main-content"
                    }, [o("div", {
                        staticClass: "card-blog__image"
                    }, [o("div", {
                        staticClass: "card-blog__image-wrapper"
                    }, [t.cardImage ? o("a-image", {
                        attrs: {
                            "primary-image": t.cardImage,
                            "is-progressive": "",
                            width: "full"
                        }
                    }) : t._e()], 1)]), t._v(" "), o("div", {
                        staticClass: "padded -h-padded-2 -t-padded-1"
                    }, [o("div", {
                        staticClass: "card-blog__type-label"
                    }, [o("span", [t._v(t._s(t.momentize(t.publishedDate, "ll", t.$i18n.locale)))])]), t._v(" "), t._t("cardBlogTitle", [o("h2", {
                        staticClass: "card-blog__title"
                    }, [t._v(t._s(t._f("truncate")(t.pageTitle, 100)))])])], 2)])])], 1)
                }), [], !1, null, null, null);
        },
        1141: function(t, n, o) {
            var content = o(1244);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("24c75285", content, !1, {
                sourceMap: !1
            })
        },
        1142: function(t, n, o) {
            var content = o(1246);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("7c6fb90e", content, !1, {
                sourceMap: !1
            })
        },
        1143: function(t, n, o) {
            var content = o(1248);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("19cc8363", content, !1, {
                sourceMap: !1
            })
        },
        1144: function(t, n, o) {
            var content = o(1250);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("1d952526", content, !1, {
                sourceMap: !1
            })
        },
        1145: function(t, n, o) {
            var content = o(1252);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, o(6).default)("3edcbf96", content, !1, {
                sourceMap: !1
            })
        },
        1243: function(t, n, o) {
            "use strict";
            var e = o(1141);
            o.n(e).a
        },
        1244: function(t, n, o) {
        },
        1245: function(t, n, o) {
            "use strict";
            var e = o(1142);
            o.n(e).a
        },
        1246: function(t, n, o) {
        },
        1247: function(t, n, o) {
            "use strict";
            var e = o(1143);
            o.n(e).a
        },
        1248: function(t, n, o) {
        },
        1249: function(t, n, o) {
            "use strict";
            var e = o(1144);
            o.n(e).a
        },
        1250: function(t, n, o) {
        },
        1251: function(t, n, o) {
            "use strict";
            var e = o(1145);
            o.n(e).a
        },
        1252: function(t, n, o) {
        }
    }
]);