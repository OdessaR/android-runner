(window.webpackJsonp = window.webpackJsonp || []).push([
    [35], {
        1060: function(t, e, n) {
            "use strict";
            n(13), n(36), n(40);
                mounted: function() {
                    }));
                    n.lastIndexOf("/") !== n.length - 1 && (n += "/");
                    var o = {
                        event: "virtualPageview",
                        pagePath: n,
                    };
                        e.$bus.$emit("setPageLocales", e.story.alternates)
                    }), 300)
                }
            }
        },
        1091: function(t, e, n) {
            var content = n(1164);
            "string" == typeof content && (content = [
                [t.i, content, ""]
            (0, n(6).default)("dcc11c24", content, !1, {
                sourceMap: !1
            })
        },
        1163: function(t, e, n) {
            "use strict";
            var o = n(1091);
            n.n(o).a
        },
        1164: function(t, e, n) {
        },
        1274: function(t, e, n) {
            "use strict";
            n.r(e);
            var o = n(148),
                r = (n(41), n(10)),
                l = n(107),
                c = n(1060),
                d = {
                    name: "CardEvent",
                    props: {
                        location: {
                            type: String,
                            default: ""
                        },
                        eventTitle: {
                            type: String,
                            default: ""
                        },
                        cardImage: {
                            type: String,
                            default: ""
                        },
                        startTime: {
                            type: String,
                            default: ""
                        },
                        endTime: {
                            type: String,
                            default: ""
                        },
                        metaDescription: {
                            type: String,
                            default: ""
                        },
                        fullSlug: {
                            type: String,
                            default: ""
                        }
                    }
                },
                m = (n(1163), n(1)),
                h = {
                    nuxtI18n: {
                        locales: ["en", "ja", "zh"]
                    },
                    components: {
                        CardEvent: Object(m.a)(d, (function() {
                                e = t.$createElement,
                                n = t._self._c || e;
                            return n("a-link", {
                                attrs: {
                                    "link-destination": t.stripEn(t.fullSlug)
                                }
                            }, [n("a-card", {
                                staticClass: "card-event",
                                attrs: {
                                    shadow: "medium"
                                }
                            }, [n("div", {
                                staticClass: "card-event__main-content"
                            }, [n("div", {
                                staticClass: "card-event__image"
                            }, [t.cardImage ? n("a-image", {
                                attrs: {
                                    "primary-image": t.cardImage,
                                    width: "xLarge"
                                }
                            }) : t._e(), t._v(" "), n("div", {
                                staticClass: "card-event__chevron"
                            }, [n("svg", {
                                staticStyle: {
                                    "enable-background": "new 0 0 849 111"
                                },
                                attrs: {
                                    version: "1.1",
                                    xmlns: "http://www.w3.org/2000/svg",
                                    "xmlns:xlink": "http://www.w3.org/1999/xlink",
                                    x: "0px",
                                    y: "0px",
                                    viewBox: "0 0 849 151.5",
                                    "xml:space": "preserve"
                                }
                            }, [n("style", {
                                attrs: {
                                    type: "text/css"
                                }
                            }, [t._v("\n              .st0 {\n              fill: #ffffff;\n              }\n              .st1 {\n              opacity: 0.5;\n              }\n            ")]), t._v(" "), n("polygon", {
                                staticClass: "st0",
                                attrs: {
                                    points: "0,87.7 0,151.7 848.7,151.7 848.7,57.7 "
                                }
                            }), t._v(" "), n("polygon", {
                                staticClass: "st1",
                                style: {
                                    fill: "#EAEAEA"
                                },
                                attrs: {
                                    points: "-0.2,0.3 -0.2,87 849,56.8 849,110.8 "
                                }
                            }), t._v(" "), n("path", {
                                style: {
                                    fill: "#EAEAEA"
                                },
                                attrs: {
                                    d: "M848.5,111"
                                }
                            })])])], 1), t._v(" "), n("a-row", [n("a-column", {
                                attrs: {
                                    width: "full",
                                    alignment: "center",
                                    "vertical-padding": "none"
                                }
                            }, [n("a-horizontal-strip", {
                                attrs: {
                                    "horizontal-alignment": "center"
                                }
                            }, [n("div", {
                                staticClass: "c-events__date-badge"
                            }, [n("div", {
                                staticClass: "full-width full-height flex-row -center -middle -column"
                            }, [n("p", {
                                staticClass: "font-size-4 margin"
                            }, [t._v("\n                  " + t._s(t.momentize(t.startTime, "MMM", t.$i18n.locale)) + "\n                ")]), t._v(" "), n("p", {
                                staticClass: "font-size-3"
                            }, [n("span", [t._v(t._s(t.momentize(t.startTime, "D", t.$i18n.locale)))]), t._v(" "), t.momentize(t.endTime, "D", t.$i18n.locale) != t.momentize(t.startTime, "D", t.$i18n.locale) ? n("span", [t._v("\n                    - " + t._s(t.momentize(t.endTime, "D", t.$i18n.locale)) + "\n                  ")]) : t._e()])])])])], 1)], 1), t._v(" "), n("div", {
                                staticClass: "padded -h-padded-2"
                            }, [n("span", {
                                staticClass: "card-event__type-label"
                            }, [t._v(t._s(t.location))]), t._v(" "), n("h2", {
                                staticClass: "card-event__title"
                            }, [t._v(t._s(t.eventTitle))])]), t._v(" "), n("div", {
                                staticClass: "padded -h-padded-2 -v-padded-2 card-event__description"
                            }, [n("span", [t._v(t._s(t._f("truncate")(t.metaDescription, 130)))])])], 1), t._v(" "), n("div", {
                                staticClass: "card-event__footer"
                            }, [n("div", {
                                staticClass: "padded -h-padded-2 -b-padded-1"
                            }, [n("span", {
                                staticClass: "a-link -theme-dark -button -ghost"
                            }, [t._v(t._s(t.$t("Read more")))])])])])], 1)
                        }), [], !1, null, "0b3ac0bc", null).exports
                    },
                    mixins: [c.a],
                    fetch: function(t) {
                                    case 0:
                                        t.store.commit("SET_NAV_DATA", {});
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    },
                    head: function() {
                        })
                    },
                    computed: {
                        sortedEvents: function() {
                                var n = new Date(t.content.endTime);
                                return new Date(e.content.endTime) - n
                            }))
                        },
                        upcoming: function() {
                                return t.$moment().diff(e.content.endTime, "hours") < 0
                            }))
                        },
                        past: function() {
                                return t.$moment().diff(e.content.endTime, "hours") >= 0
                            }))
                        }
                    },
                    asyncData: function(t) {
                            var n, o, r, c, d;
                                    case 0:
                                        return n = l.a.createAsyncDataStoriesContext(t, {
                                            folderPath: "events/",
                                            isStartpage: !1
                                        }), o = l.a.createAsyncDataStoryContext(t, {
                                            folderPath: "events/",
                                            slug: ""
                                    case 4:
                                    case 7:
                                        return c = e.sent, d = {
                                            story: c.data.story,
                                            events: r ? r.data : []
                                        }, e.abrupt("return", d || t.error({
                                            statusCode: 404
                                        }));
                                    case 10:
                                    case "end":
                                        return e.stop()
                                }
                            }), e)
                        })))()
                    }
                },
                v = Object(m.a)(h, (function() {
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", [n("a-section", {
                        attrs: {
                            "bg-color": "white",
                            "bg-angle-bottom": "up"
                        }
                    }, [n("a-row", {
                        attrs: {
                            "vertical-alignment": "top"
                        }
                    }, [n("a-column", {
                        attrs: {
                            width: "full"
                        }
                    }, [n("a-heading-block", {
                        attrs: {
                            "block-heading": t.story.content.pageTitle,
                            "block-byline": 0 !== t.upcoming.length ? t.story.content.pageByline : null,
                            "block-heading-size": "size1",
                            "block-heading-h-tag": "h1",
                            "block-byline-size": "size5",
                            "block-byline-h-tag": "h2",
                            alignment: "center"
                        }
                    }), t._v(" "), 0 === t.upcoming.length ? n("a-heading-block", {
                        attrs: {
                            "block-heading": t.$t("No upcoming events right now."),
                            "block-byline": t.$t("Check again soon."),
                            theme: "dark",
                            "block-heading-size": "size5",
                            "block-heading-h-tag": "h3",
                            "block-byline-size": "size6",
                            "block-byline-h-tag": "p",
                            alignment: "center"
                        }
                    }) : t._e()], 1)], 1)], 1), t._v(" "), 0 !== t.upcoming.length ? n("a-section", {
                        attrs: {
                            "bg-color": "lightGrey",
                            "t-padding": "xLarge",
                            "b-padding": "xLarge",
                            "bg-angle-top": "up",
                            "bg-angle-bottom": "up"
                        }
                    }, [n("a-row", t._l(t.upcoming, (function(e) {
                        return n("a-column", {
                            key: e.id,
                            attrs: {
                                width: "third"
                            }
                        }, [n("card-event", t._b({
                            attrs: {
                                "card-image": e.content.bannerImage,
                                "full-slug": e.full_slug,
                                location: e.content.city,
                                "event-title": e.content.metaTitle || e.name
                            }
                        }, "card-event", e.content, !1))], 1)
                    })), 1)], 1) : t._e(), t._v(" "), n("a-section", {
                        attrs: {
                            "bg-color": 0 === t.upcoming.length ? "lightGrey" : ""
                        }
                    }, [n("a-row", [n("a-column", {
                        attrs: {
                            width: "full"
                        }
                    }, [n("a-heading-block", {
                        attrs: {
                            "block-heading": t.$t("Past events"),
                            theme: "dark",
                            "block-heading-size": "size2",
                            "block-heading-h-tag": "h2",
                            alignment: "center"
                        }
                    })], 1)], 1), t._v(" "), n("a-row", t._l(t.past, (function(e) {
                        return n("a-column", {
                            key: e.id,
                            attrs: {
                                width: "third",
                                "child-spacing": "small",
                                "vertical-padding": "large"
                            }
                        }, [n("div", {
                            staticClass: "full-width full-height"
                        }, [n("span", {
                            staticClass: "font-size-4 uppercase"
                        }, [t._v(t._s(t.momentize(e.content.startTime, "MMM", t.$i18n.locale)))]), t._v(" "), n("span", {
                            staticClass: "font-size-4"
                        }, [t._v("\n            " + t._s(t.momentize(e.content.startTime, "D", t.$i18n.locale)) + "\n            "), t.momentize(e.content.endTime, "D", t.$i18n.locale) != t.momentize(e.content.startTime, "D", t.$i18n.locale) ? n("span", [t._v("\n              - " + t._s(t.momentize(e.content.endTime, "D", t.$i18n.locale)) + "\n            ")]) : t._e()])]), t._v(" "), n("div", [e.content.city ? n("a-heading-block", {
                            attrs: {
                                "block-byline": e.content.city.toUpperCase(),
                                "block-byline-size": "size7",
                                "block-byline-h-tag": "p"
                            }
                        }) : t._e(), t._v(" "), n("a-heading-block", {
                            attrs: {
                                "block-heading": e.content.metaTitle,
                                "block-heading-size": "size5",
                                "block-heading-h-tag": "h3"
                            }
                        })], 1), t._v(" "), n("div", [n("a-link", {
                            attrs: {
                                "link-destination": t.localePath({
                                    name: "events-slug",
                                    params: {
                                        slug: e.slug
                                    }
                                }),
                                "link-text": t.$t("View event"),
                                "link-icon": "page-arrow"
                            }
                        })], 1)])
                    })), 1)], 1)], 1)
                }), [], !1, null, null, null);
        }
    }
]);