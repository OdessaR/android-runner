define("mod/common/searchCity", [], function() {
    var index = 0;

    function showData(data) {
        var html = "";
        if (data.state == 0) {
            $(".errorMsg").remove();
            $(".auto_result").remove();
            html += "<div class='auto_result'><ul>";
            var citylist = data.citylist;
            if (citylist.length > 0) {
                for (var i = 0; i < citylist.length; i++) {
                    var city = citylist[i];
                    var reg = new RegExp(/\{[a-zA-Z]+\}/);
                    if (city.city) {
                        toUrl = toUrl.replace(reg, city.city)
                    }
                    if (city.cityname) {
                        html += "<li index='" + i + "'><a href='" + toUrl + "'>" + city.cityname + "</a></li>";
                    }
                }
            }
            html += "</ul></div>"
        } else {
            $(".errorMsg").remove();
            if (data.promptMsg) {
                html += "<div class='errorMsg'>*" + data.promptMsg + "</div>"
            }
        }
        if (html) {
            $("#searchInput").after(html);
            $(".auto_result li").on("mouseover", function() {
                var value = $(this).find("a").html();
                index = $(this).attr("index");
                $("#searchInput").val(value)
            })
        }
    }

    function handle_input(obj, event) {
        var inputVal = $(obj).val();
        var inputVal = inputVal ? inputVal : String.fromCharCode(event.which);
        if (!inputVal) return;
        var searchAction = decodeURI($(obj).attr("search-action"));
        inputVal = encodeURI(inputVal);
            key: inputVal
        }, function(data) {
            showData(data)
        })
    }
    $("#searchInput").keyup(function(event) {
        handle_input(this, event);
        var list = $(".auto_result li");
        var length = list.length;
        var key_code = event.which || event.keyCode;
        if (event.keyCode == 40) {
            ++index;
            if (index > length) {
                index = 0
            }
            var value = $(list[index]).find("a").html();
            $("#searchInput").val(value);
            $(list).each(function(i) {
                if (i == index) {
                    $(this).addClass("current")
                } else {
                    $(this).removeClass("current")
                }
            })
        } else if (event.keyCode == 38) {
            index--;
            if (index < -1) {
                index = length - 1
            }
            var value = $(list[index]).find("a").html();
            $("#searchInput").val(value);
            $(list).each(function(i) {
                if (i == index) {
                    $(this).addClass("current")
                } else {
                    $(this).removeClass("current")
                }
            })
        } else if (key_code == 13) {
            var inputVal = $("#searchInput").val();
            var reg = new RegExp(/\{[a-zA-Z]+\}/);
            if (city) {
                toUrl = toUrl.replace(reg, city);
            }
        }
    }).bind("paste", function(e) {
        setTimeout(function() {
            handle_input($(that), e)
        }, 100)
    });
    $(".auto_result").on("mouseover", function() {
        $("#searchInput").blur();
        $(".auto_result").show()
    });
    $("#searchInput").on("blur", function() {
        $(".errorMsg").remove();
        $(".auto_result").on("mouseleave", function() {
            $(".auto_result").hide()
        })
    })
});
define("mod/common/bottom_float", [], function() {
    var u = {
        running: 0,
        d_wrap: $(".footer-float-wai"),
        shake_f: !0,
        open_f: !1,
        expand: function() {
            0 == e.running && (e.running = 1, $(".footer-top-open-in").animate({
                left: "100%"
            }, 300, "swing", function() {
                $(this).parent().hide();
                $(".footer-float").animate({
                    left: "0%"
                }, 800, "swing", function() {
                    e.running = 0
                }).parent().show()
            }))
        },
        collapse: function() {
            0 == e.running && (e.running = 1, $(".footer-float").animate({
                left: "100%"
            }, 800, "swing", function() {
                $(this).parent().hide();
                $(".footer-top-open-in").animate({
                    left: "0%"
                }, 300, "swing", function() {
                    e.running = 0
                }).parent().show()
            }))
        }
    };
    $(".close").bind("click", function() {
        u.collapse()
    });
    $(".footer-top-open-in").bind("click", function() {
        u.expand()
    });
    $(window).bind("scroll", function() {
        if ($(document).scrollTop() + $(window).height() >= $(document).height()) {
            var newH = $(".content-wrap").height() + 75;
            $(".content-wrap").height(newH);
            $(window).unbind("scroll")
        }
    })
});
define("mod/common/tab", [], function() {
    $(function() {
        $(".tab .tit span").on("mouseover", function() {
            $(".tab .tit span").removeClass("active");
            $(this).addClass("active");
            $(".tab .tab-box ul").hide();
            var tab_index = $(this).attr("index");
            $(".tab .tab-box ul").each(function(i) {
                var ul_index = $(this).attr("index");
                if (tab_index === ul_index) $(this).show();
                else $(this).hide()
            })
        })
    });
    $(function() {
        $("#tab_tuijian .tit span").on("mouseover", function() {
            $("#tab_tuijian .tit span").removeClass("active");
            $(this).addClass("active");
            $("#tab_tuijian .tab-box ul").hide();
            var tab_index = $(this).attr("index");
            $("#tab_tuijian .tab-box ul").each(function(i) {
                var ul_index = $(this).attr("index");
                if (tab_index === ul_index) $(this).show();
                else $(this).hide()
            })
        })
    });
    $(function() {
        $("#tab_class .tit span").on("mouseover", function() {
            $("#tab_class .tit span").removeClass("active");
            $(this).addClass("active");
            $("#tab_class .tab_list_box ul").hide();
            var tab_index = $(this).attr("index");
            $("#tab_class .tab_list_box ul").each(function(i) {
                var ul_index = $(this).attr("index");
                if (tab_index === ul_index) $(this).show();
                else $(this).hide()
            })
        })
    });
    $(function() {
        $("#footer-nav li a").bind("mouseover", function() {
            $("#footer-nav li a").removeClass("selected");
            $(this).addClass("selected");
            $(".footer-top-inner").hide();
            var tab_index = $(this).attr("index");
            $(".footer-top-inner").each(function(i) {
                var ul_index = $(this).attr("index");
                if (tab_index === ul_index) {
                    $(this).show()
                } else {
                    $(this).hide()
                }
            })
        })
    })
});
define("pkg/common/search_city", ["mod/common/searchCity", "mod/common/bottom_float", "mod/common/tab"], function(common_searchCity, common_bottom_float, common_tab) {});