(function() {
    var h = {},
        mt = {},
        c = {
            id: "f1527f186a53bd6e02d9e810f8b47b4d",
            dm: ["g.58.com"],
            js: "tongji.baidu.com/hm-web/js/",
            etrk: [],
            cetrk: [],
            cptrk: [],
            icon: '',
            ctrk: [],
            nv: -1,
            vdur: 1800000,
            age: 31536000000,
            rec: 0,
            rp: [],
            trust: 0,
            vcard: 0,
            qiao: 0,
            lxb: 0,
            kbtrk: 0,
            pt: 0,
            spa: 0,
            oc: 0,
            aet: '',
            hca: '849234E04F27169D',
            conv: 0,
            med: 0,
            cvcc: '',
            cvcf: [],
            apps: ''
        };
    var q = void 0,
        u = !0,
        w = null,
        x = !1;
    mt.cookie = {};
    mt.cookie.set = function(a, b, g) {
        var d;
        g.Q && (d = new Date, d.setTime(d.getTime() + g.Q));
    };
    mt.cookie.get = function(a) {
    };
    mt.cookie.hc = function(a, b) {
        try {
            var g = "Hm_ck_" + +new Date;
            mt.cookie.set(g, "is-cookie-enabled", {
                domain: a,
                path: b,
                Q: q
            });
            var d = "is-cookie-enabled" === mt.cookie.get(g) ? "1" : "0";
            mt.cookie.set(g, "", {
                domain: a,
                path: b,
                Q: -1
            });
            return d
            return "0"
        }
    };
    mt.lang = {};
    mt.lang.d = function(a, b) {
        return "[object " + b + "]" === {}.toString.call(a)
    };
    mt.lang.Za = function(a) {
        return mt.lang.d(a, "Number") && isFinite(a)
    };
    mt.lang.H = function(a) {
        return mt.lang.d(a, "String")
    };
    mt.lang.isArray = function(a) {
        return mt.lang.d(a, "Array")
    };
    mt.lang.h = function(a) {
        return a.replace ? a.replace(/'/g, "'0").replace(/\*/g, "'1").replace(/!/g, "'2") : a
    };
    mt.lang.trim = function(a) {
        return a.replace(/^\s+|\s+$/g, "")
    };
    mt.lang.G = function(a, b) {
        var g = x;
        if (a == w || !mt.lang.d(a, "Array") || b === q) return g;
        if (Array.prototype.indexOf) g = -1 !== a.indexOf(b);
        else
            for (var d = 0; d < a.length; d++)
                if (a[d] === b) {
                    g = u;
                    break
                } return g
    };
    mt.url = {};
    mt.url.m = function(a, b) {
        var g = a.match(RegExp("(^|&|\\?|#)(" + b + ")=([^&#]*)(&|$|#)", ""));
        return g ? g[3] : w
    };
    mt.url.Ec = function(a) {
    };
    mt.url.Mb = function(a) {
    };
    mt.url.L = function(a) {
    };
    mt.url.wa = function(a) {
    };
    (function() {
        var a = mt.lang,
            b = mt.url;
        mt.f = {};
        mt.f.Ua = function(a) {
        };
        mt.f.ua = function(a) {
            if (!a) return w;
            try {
                a = String(a);
                if (0 === a.indexOf("!HMCQ!")) return a;
                    if (-1 < d[b].indexOf("#")) {
                        var f = d[b].split("#")[1];
                        d = d.splice(b + 1, d.length - (b + 1));
                        break
                    } for (a =
                    0; e && a < d.length;) {
                    var l = String(d[a]).toLowerCase();
                    if (!("html" === l || "body" === l)) {
                        var b = 0,
                            n = d[a].match(/\[(\d+)\]/i),
                            f = [];
                        if (n) b = n[1] - 1, l = l.split("[")[0];
                        else if (1 !== e.childNodes.length) {
                            for (var p = 0, s = 0, t = e.childNodes.length; s < t; s++) {
                                var v = e.childNodes[s];
                                1 === v.nodeType && v.nodeName.toLowerCase() === l && p++;
                                if (1 < p) return w
                            }
                            if (1 !== p) return w
                        }
                        if (!f[b]) return w;
                        e = f[b]
                    }
                    a++
                }
                return e
                return w
            }
        };
        mt.f.wa = function(a, d) {
            var e = [],
                b = [];
            if (!a) return b;
            for (; a.parentNode != w;) {
                for (var f = 0, l = 0, n = a.parentNode.childNodes.length, p = 0; p < n; p++) {
                    var s = a.parentNode.childNodes[p];
                    if (s.nodeName === a.nodeName && (f++, s === a && (l = f), 0 < l && 1 < f)) break
                }
                if ((n = "" !== a.id) && d) {
                    e.unshift("#" + encodeURIComponent(a.id));
                    break
                } else n && (n = "#" + encodeURIComponent(a.id), n = 0 < e.length ? n + ">" + e.join(">") : n, b.push(n)), e.unshift(encodeURIComponent(String(a.nodeName).toLowerCase()) + (1 < f ? "[" + l + "]" : ""));
                a = a.parentNode
            }
            b.push(e.join(">"));
            return b
        };
        mt.f.xa = function(a) {
            return (a = mt.f.wa(a, u)) && a.length ? String(a[0]) : ""
        };
        mt.f.Qb = function(a) {
            return mt.f.wa(a, x)
        };
        mt.f.Fb = function(a) {
            var d;
            for (d = "A";
                (a = a.parentNode) && 1 == a.nodeType;)
                if (a.tagName == d) return a;
            return w
        };
        mt.f.Ib = function(a) {
            return 9 === a.nodeType ? a : a.ownerDocument || a.document
        };
        mt.f.Ob = function(a) {
            var d = {
                top: 0,
                left: 0
            };
            if (!a) return d;
            var e = mt.f.Ib(a).documentElement;
            "undefined" !== typeof a.getBoundingClientRect && (d = a.getBoundingClientRect());
            return {
                    (e.clientTop || 0),
            }
        };
        mt.f.getAttribute = function(a, d) {
            var e = a.getAttribute && a.getAttribute(d) || w;
            if (!e && a.attributes && a.attributes.length)
                for (var b = a.attributes, f = b.length, l = 0; l < f; l++) b[l].nodeName === d && (e = b[l].nodeValue);
            return e
        };
        mt.f.T = function(a) {
            var d = "document";
            a.tagName !== q && (d = a.tagName);
            return d.toLowerCase()
        };
        mt.f.Tb = function(b) {
            var d = "";
            b.textContent ? d = a.trim(b.textContent) : b.innerText && (d = a.trim(b.innerText));
            d && (d = d.replace(/\s+/g,
                " ").substring(0, 255));
            return d
        };
        mt.f.S = function(g, d) {
            var e;
            return String(e || "").substring(0,
                255)
        };
        (function() {
            (mt.f.gb = function() {
                function a() {
                    if (!a.fa) {
                        a.fa = u;
                        for (var d = 0, b = r.length; d < b; d++) r[d]()
                    }
                }

                function d() {
                    try {
                    } catch (b) {
                        setTimeout(d, 1);
                        return
                    }
                    a()
                }
                var b = x,
                    r = [],
                    f;
                    a()
                });
                (function() {
                    if (!b)
                        var l = x;
                        try {
                    }
                })();
                return function(d) {
                    a.fa ? d() : r.push(d)
                }
            }()).fa = x
        })();
        return mt.f
    })();
    mt.event = {};
    mt.event.e = function(a, b, g) {
        a.attachEvent ? a.attachEvent("on" + b, function(d) {
            g.call(a, d)
        }) : a.addEventListener && a.addEventListener(b, g, x)
    };
    mt.event.preventDefault = function(a) {
    };
    (function() {
        var a = mt.event;
        mt.g = {};
        mt.g.Nb = function() {
            return a ? +a[1] || 0 : 0
        };
        mt.g.Gc = function() {
            try {
            } catch (a) {
                return x
            }
        };
        mt.g.U = function() {
            var a;
        };
        mt.g.M = function() {
        };
        mt.g.ob =
            0;
        mt.g.Vb = function() {
        };
        mt.g.orientation = 0;
        (function() {
            function b() {
                var a = 0;
                mt.g.orientation = a;
                mt.g.ob = mt.g.Vb()
            }
            b();
            a.e(window, "orientationchange", b)
        })();
        return mt.g
    })();
    mt.s = {};
    mt.s.parse = function(a) {
        return (new Function("return (" + a + ")"))()
    };
    mt.s.stringify = function() {
        function a(a) {
                var d = g[a];
                if (d) return d;
                d = a.charCodeAt();
                return "\\u00" + Math.floor(d / 16).toString(16) + (d % 16).toString(16)
            }));
            return '"' + a + '"'
        }

        function b(a) {
            return 10 > a ? "0" + a : a
        }
        var g = {
            "\b": "\\b",
            "\t": "\\t",
            "\n": "\\n",
            "\f": "\\f",
            "\r": "\\r",
            '"': '\\"',
            "\\": "\\\\"
        };
        return function(d) {
            switch (typeof d) {
                case "undefined":
                    return "undefined";
                case "number":
                    return isFinite(d) ? String(d) : "null";
                case "string":
                    return a(d);
                case "boolean":
                    return String(d);
                default:
                    if (d === w) return "null";
                    if (d instanceof Array) {
                        var e = ["["],
                            g = d.length,
                            f, l, n;
                        for (l = 0; l < g; l++) switch (n = d[l], typeof n) {
                            case "undefined":
                            case "function":
                            case "unknown":
                                break;
                            default:
                                f && e.push(","), e.push(mt.s.stringify(n)), f = 1
                        }
                        e.push("]");
                        return e.join("")
                    }
                    if (d instanceof Date) return '"' + d.getFullYear() + "-" + b(d.getMonth() + 1) + "-" + b(d.getDate()) + "T" + b(d.getHours()) + ":" + b(d.getMinutes()) + ":" + b(d.getSeconds()) + '"';
                    for (g in d)
                            case "undefined":
                            case "unknown":
                            case "function":
                                break;
                            default:
                        }
            }
        }
    }();
    mt.localStorage = {};
    mt.localStorage.ma = function() {
        if (!mt.localStorage.l) try {
            return x
        }
        return u
    };
    mt.localStorage.set = function(a, b, g) {
        var d = new Date;
        d.setTime(d.getTime() + g || 31536E6);
        try {
    };
    mt.localStorage.get = function(a) {
                var b = a.indexOf("|"),
                    g = a.substring(0, b) - 0;
                if (g && g > (new Date).getTime()) return a.substring(b + 1)
            }
        } else if (mt.localStorage.ma()) try {
        return w
    };
    mt.localStorage.remove = function(a) {
        else if (mt.localStorage.ma()) try {
    };
    mt.sessionStorage = {};
    mt.sessionStorage.set = function(a, b) {
        try {
    };
    mt.sessionStorage.get = function(a) {
        try {
            return w
        }
    };
    mt.sessionStorage.remove = function(a) {
        try {
    };
    mt.lb = {};
    mt.lb.log = function(a, b) {
            d = "mini_tangram_log_" + Math.floor(2147483648 * Math.random()).toString(36);
        g.onload = function() {
            g.onload = w;
            b && b(a)
        };
        g.src = a
    };
    mt.Ka = {};
    mt.Ka.Ub = function() {
        var a = "";
            b && b.description && (a = b.description.replace(/^.*\s+(\S+)\s+\S+$/, "$1"))
        return a
    };
    mt.Ka.Dc = function(a, b, g, d, e) {
        return '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" id="' + a + '" width="' + g + '" height="' + d + '"><param name="movie" value="' + b + '" /><param name="flashvars" value="' + (e || "") + '" /><param name="allowscriptaccess" value="always" /><embed type="application/x-shockwave-flash" name="' + a + '" width="' + g + '" height="' + d + '" src="' + b + '" flashvars="' + (e || "") + '" allowscriptaccess="always" /></object>'
    };
    h.D = {
        Fc: "http://tongji.baidu.com/hm-web/welcome/ico",
        fb: "hm.baidu.com/hm.gif",
        vb: /^(tongji|hmcdn).baidu.com$/,
        nb: "tongji.baidu.com",
        Zb: "hmmd",
        $b: "hmpl",
        xc: "utm_medium",
        Yb: "hmkw",
        zc: "utm_term",
        Wb: "hmci",
        wc: "utm_content",
        ac: "hmsr",
        yc: "utm_source",
        Xb: "hmcu",
        vc: "utm_campaign",
        N: 0,
        J: Math.round(+new Date / 1E3),
        Ea: "https:",
        Hc: 0,
        Bc: 6E5,
        Ic: 6E5,
        lc: 5E3,
        Cc: 5,
        pa: 1024,
        Ac: 1,
        Ga: 2147483647,
        mb: "hca kb cc cf ci ck cl cm cp cu cw ds vl ep et fl ja ln lo lt rnd si su v cv lv api sn r ww p ct u tt".split(" "),
        V: u,
        Ra: ["a", "input", "button"],
        Oa: {
            id: "data-hm-id",
            aa: "data-hm-class",
            $: "data-hm-xpath",
            content: "data-hm-content",
            ia: "data-hm-tag",
            link: "data-hm-link"
        },
        Qa: "data-hm-enabled",
        Pa: "data-hm-disabled",
        ic: "https://hmcdn.baidu.com/static/tongji/plugins/",
        eb: ["UrlChangeTracker", "OcpcCbHm"]
    };
    (function() {
        var a = {
            F: {},
            e: function(a, g) {
            },
            K: function(a, g) {
            }
        };
        return h.z = a
    })();
    (function() {
        var a = mt.lang,
            b = /^https?:\/\//,
            g = {
                Hb: function(a) {
                    var e;
                    try {
                        e = JSON.parse(decodeURIComponent(a[0]))
                    } catch (b) {}
                    return e
                },
                $a: function(a, e) {
                    b.test(a) || (g = g.replace(b, ""));
                    a = a.replace(/\/$/, "");
                    g = g.replace(/\/$/, "");
                    e && (g = g.replace(/^(https?:\/\/)?www\./, "$1"));
                    return RegExp("^" + a.replace(/[?.+^${}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*") + "$").test(g)
                },
                ca: function(d, e) {
                    var b = g.Hb(d);
                    if (!a.d(b, "Undefined")) {
                        if (a.d(b, "Array")) {
                            for (var f = 0; f < b.length; f++)
                                if (g.$a(b[f],
                                        e)) return u;
                            return x
                        }
                        if (a.d(b, "Object")) {
                            var f = [],
                                l;
                            for (l in b) b.hasOwnProperty(l) && g.$a(l, e) && (f = f.concat(b[l]));
                            return f
                        }
                    }
                }
            };
        return h.ra = g
    })();
    (function() {
        function a(a, d) {
            e.charset = "utf-8";
            b.d(d, "Function") && (e.readyState ? e.onreadystatechange = function() {
                if ("loaded" === e.readyState || "complete" === e.readyState) e.onreadystatechange = w, d()
            } : e.onload = function() {
                d()
            });
            e.src = a;
            r.parentNode.insertBefore(e, r)
        }
        var b = mt.lang;
    })();
    (function() {
        var a = mt.cookie,
            b = mt.localStorage,
            g = mt.sessionStorage,
            d = {
                getData: function(d) {
                    try {
                        return a.get(d) || g.get(d) || b.get(d)
                },
                setData: function(e, r, f) {
                    try {
                        a.set(e, r, {
                            domain: d.R(),
                            path: d.da(),
                            Q: f
                        }), f ? b.set(e, r, f) : g.set(e, r)
                },
                removeData: function(e) {
                    try {
                        a.set(e, "", {
                            domain: d.R(),
                            path: d.da(),
                            Q: -1
                        }), g.remove(e), b.remove(e)
                },
                W: function(a, d) {
                    a = "." + a.replace(/:\d+/, "");
                    d = "." + d.replace(/:\d+/, "");
                    var b = a.indexOf(d);
                    return -1 < b && b + d.length === a.length
                },
                ga: function(a, d) {
                    a = a.replace(/^https?:\/\//,
                        "");
                    return 0 === a.indexOf(d)
                },
                R: function() {
                        if (d.W(a, c.dm[b])) return c.dm[b].replace(/(:\d+)?[/?#].*/, "");
                    return a
                },
                da: function() {
                    for (var a = 0, b = c.dm.length; a < b; a++) {
                        var f = c.dm[a];
                    }
                    return "/"
                }
            };
        return h.qa = d
    })();
    (function() {
        var a = mt.lang,
            b = mt.s,
            g = h.qa,
            d = {
                pageview: {},
                session: {},
                autoEventTracking: {},
                customEvent: {},
                user: {}
            },
            e = {
                user: 1,
                session: 2,
                pageview: 3,
                autoEventTracking: 3,
                customEvent: 3,
                others: 3
            },
            r = ["session", "user"],
            f = "Hm_up_" + c.id,
            l = {
                init: function() {
                    l.ec()
                },
                ec: function() {
                    try {
                        var e = b.parse(decodeURIComponent(g.getData(f)));
                        a.d(e, "Object") && (d.user = e)
                },
                A: function(a) {
                    var b = {};
                    d[a] !== q && (b = d[a]);
                    for (var e in b) b.hasOwnProperty(e) && (a[e] = b[e]);
                    return a
                },
                ya: function() {
                    for (var a = {}, b, e = r.length -
                            1; 0 <= e; e--) {
                        b = d[r[e]];
                        for (var t in b) b.hasOwnProperty(t) && (a[t] = b[t])
                    }
                    return a
                },
                setProperty: function(e, f, g) {
                    var t = d[e];
                    if (a.d(t, "Object") && a.d(f, "Object")) {
                        for (var v in f)
                            if (f.hasOwnProperty(v)) {
                                var k = a.h(String(v));
                                if (g || !/^_/.test(k) && !/_$/.test(k) || /^(_iden|ei_|ec_|ex_|en_|et_|el_)$/.test(k)) {
                                    var m = f[v];
                                    if (m == w) delete t[k];
                                    else {
                                        if (a.d(m, "Object") || a.d(m, "Array")) m = b.stringify(m);
                                        m = a.h(String(m));
                                        l.gc(e, k, m) && (t[k] = {
                                            value: m,
                                            scope: l.Wa(e)
                                        })
                                    }
                                }
                            }
                        "user" === e && l.Ia()
                    }
                },
                o: function(b) {
                    b !== q && ("userId" ===
                        b && a.d(d.user, "Object") ? (delete d.user.uid_, l.Ia()) : "user" === b && a.d(d.user, "Object") ? (b = d.user.uid_, d.user = b === q ? {} : {
                            uid_: b
                        }, l.Ia()) : d[b] !== q && (d[b] = {}))
                },
                Ia: function() {
                    try {
                        g.setData(f, encodeURIComponent(b.stringify(d.user)), c.age)
                    } catch (a) {}
                },
                gc: function(a, b, e) {
                    var f = u,
                        g = d[a];
                    if (256 < encodeURIComponent(String(b)).length || 256 < encodeURIComponent(String(e)).length) f = x;
                    else {
                        var k = g[b];
                        g[b] = {
                            value: e,
                            scope: l.Wa(a)
                        };
                        a = l.O(l.A(a));
                        2048 < encodeURIComponent(a).length && (k !== q ? g[b] = k : delete g[b], f = x)
                    }
                    return f
                },
                O: function(a) {
                    var b = [],
                        d, e;
                    for (e in a) a.hasOwnProperty(e) && (d = [e, a[e].value], (1 === a[e].scope || 2 === a[e].scope) && d.push(a[e].scope), b.push(d.join("*")));
                    return b.join("!")
                },
                Wa: function(a) {
                    a = e[a];
                    return a !== q ? a : e.others
                }
            };
        return h.P = l
    })();
    (function() {
        var a = mt.f,
            b = mt.lang,
            g = h.z,
            d = h.ra,
            e = h.P,
            r = e.O;
        if (b.isArray(c.cptrk) && 0 < c.cptrk.length) {
            var f = {
                cb: {},
                ka: {},
                init: function() {
                    for (var a, e = d.ca(c.cptrk) || [], g = 0; g < e.length; g++)
                        if (a = e[g], a.a !== q && b.d(a.a, "Object")) {
                            a = a.a;
                            for (var s in a) a.hasOwnProperty(s) && (f.ka[s] = String(a[s]))
                        }
                },
                bb: function() {
                    var b, d, e;
                    for (e in f.ka)
                        if (f.ka.hasOwnProperty(e) && f.cb[e] === q && (b = f.ka[e], b = a.ua(b))) d = d === q ? {} : d, d[e] = a.S(b, x), f.cb[e] = u;
                    return d
                },
                Aa: function() {
                    var a = f.bb();
                    a && f.nc(a)
                },
                dc: function() {
                    "MutationObserver" in
                        childList: u,
                        subtree: u
                },
                nc: function(a) {
                    if (b.d(a, "Object")) try {
                        e.setProperty("pageview", a);
                        var d = h.c.b.p,
                            f = h.c.b.ep;
                        h.c.b.et = 9;
                        h.c.b.ep = "";
                        h.c.b.p = r(e.A("pageview"));
                        h.c.i();
                        h.c.b.p = d;
                        h.c.b.ep = f;
                        e.o("pageview")
                    } catch (g) {}
                }
            };
            f.init();
            g.e("pv-b", function() {
                var a = f.bb();
                a && e.setProperty("pageview", a)
            });
            f.dc();
            a.gb(f.Aa)
        }
    })();
    (function() {
        var a = mt.lang,
            b = mt.f,
            g = h.ra,
            d = {
                ba: function(a, r) {
                    return function(f) {
                        var l = f.target || f.srcElement;
                        if (l) {
                            var n = g.ca(r) || [],
                                p = l.getAttribute(a.la);
                            if (p && p === f) l.removeAttribute(a.la);
                            else if (0 < n.length && (l = b.Qb(l)) && l.length)
                                if (n = l.length, p = l[l.length - 1], 1E4 > n * p.split(">").length)
                                    for (p = 0; p < n; p++) d.jb(a, l[p]);
                                else d.jb(a, p)
                        }
                    }
                },
                jb: function(b, d) {
                    for (var f = {}, g = String(d).split(">").length, n = 0; n < g; n++) f[d] = "", d = d.substring(0, d.lastIndexOf(">"));
                    b && (a.d(b, "Object") && b.Sa) &&
                        b.Sa(f)
                },
                jc: function(a, b) {
                    return function(d) {
                        (d.target || d.srcElement).setAttribute(a.la, d.clientX + ":" + d.clientY);
                    }
                }
            };
        return h.ta = d
    })();
    (function() {
        var a = mt.f,
            b = mt.event,
            g = mt.lang,
            d = h.D,
            e = h.ra,
            r = h.ta,
            f = h.P,
            l = f.O,
            n = {
                la: "HM_ce",
                pb: function() {
                    if (c.cetrk && 0 < c.cetrk.length) {
                        b.e(document, "click", r.ba(n, c.cetrk));
                        for (var d = e.ca(c.cetrk) || [], f = 0, g = d.length; f < g; f++) {
                            var v = d[f],
                                k = v.p || ""; - 1 === k.indexOf(">") && (0 === k.indexOf("#") && (k = k.substring(1)), (k = a.Ua(k)) && b.e(k, "click", r.jc(n, v)))
                        }
                    }
                },
                Sa: function(a) {
                    for (var b = e.ca(c.cetrk) || [], d = 0; d < b.length; d++) {
                        var f = b[d],
                            k = n.Kb(f.p, a);
                        k && n.w(f, k)
                    }
                },
                Kb: function(a, b) {
                    a = String(a);
                    if (0 < a.indexOf("*")) {
                        var d =
                            RegExp("^" + a.replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\*/, "\\d+") + "$"),
                            e;
                        for (e in b)
                            if (b.hasOwnProperty(e) && d.test(e)) return e;
                        return w
                    }
                    return b.hasOwnProperty(a) ? a : w
                },
                w: function(b, d) {
                    h.c.b.et = 7;
                    var e = b && b.k || "",
                        e = g.h(e),
                        v = {};
                    if (b && b.a && g.d(b.a, "Object")) {
                        var k = b.a,
                            m;
                        for (m in k)
                            if (k.hasOwnProperty(m)) {
                                var y = n.Rb(k[m] || "", d),
                                    y = y ? a.S(y, x) : "";
                                v[m] = y
                            }
                    }
                    v = n.Gb(v, d || b && b.p);
                    v._iden = e;
                    f.setProperty("customEvent", v);
                    h.c.b.ep = "";
                    h.c.b.p = l(f.A("customEvent"));
                    h.c.i();
                    h.c.b.p = "";
                    f.o("customEvent")
                },
                Gb: function(b, e) {
                    var f = a.ua(e),
                        g = d.Oa;
                    f && (c.aet && c.aet.length ? (b.ei_ = a.getAttribute(f, g.id) || a.getAttribute(f, "id") || "", b.ec_ = a.getAttribute(f, g.aa) || a.getAttribute(f, "class") || "", b.ex_ = a.getAttribute(f, g.$) || a.xa(f), b.en_ = a.getAttribute(f, g.content) || a.S(f, u), b.et_ = a.getAttribute(f, g.ia) || a.T(f), b.el_ = a.getAttribute(f, g.link) || a.getAttribute(f, "href") || "") : (b.ex_ = a.getAttribute(f, g.$) || a.xa(f), b.en_ = a.getAttribute(f, g.content) || a.S(f, u)));
                    return b
                },
                Rb: function(b, d) {
                    b = String(b);
                    d = String(d);
                    if (0 < b.indexOf("*")) {
                        var e =
                            /.*\[(\d+)\]$/.exec(d);
                        b = b.replace("*", e ? e[1] : "1")
                    }
                    return a.ua(b)
                }
            };
        h.z.e("pv-b", n.pb);
        return n
    })();
    (function() {
        var a = mt.lang,
            b = mt.f,
            g = mt.event,
            d = mt.g,
            e = h.D,
            r = h.z,
            f = h.P,
            l = f.O,
            n = +new Date,
            p = [],
            s = {
                ba: function() {
                    return function(d) {
                        if (h.c && h.c.V && c.aet && c.aet.length) {
                            var f = d.target || d.srcElement;
                            if (f) {
                                var g = h.c.Ra,
                                    m = b.getAttribute(f, e.Qa) != w ? u : x;
                                if (b.getAttribute(f, e.Pa) == w)
                                    if (m) s.na(s.va(f, d));
                                    else {
                                        var y = b.T(f);
                                        if (a.G(g, "*") || a.G(g, y)) s.na(s.va(f, d));
                                        else
                                            for (; f.parentNode != w;) {
                                                var m = f.parentNode,
                                                    y = b.T(m),
                                                    z = "a" === y && a.G(g, "a") ? u : x,
                                                    y = "button" === y && a.G(g, "button") ? u : x,
                                                    A = b.getAttribute(m, e.Qa) != w ? u : x;
                                                if (b.getAttribute(m, e.Pa) == w && (z || y || A)) {
                                                    s.na(s.va(m, d));
                                                    break
                                                }
                                                f = f.parentNode
                                            }
                                    }
                            }
                        }
                    }
                },
                va: function(f, g) {
                    var k = {},
                        m = e.Oa;
                    k.id = b.getAttribute(f, m.id) || b.getAttribute(f, "id") || "";
                    k.aa = b.getAttribute(f, m.aa) || b.getAttribute(f, "class") || "";
                    k.$ = b.getAttribute(f, m.$) || b.xa(f);
                    k.content = b.getAttribute(f, m.content) || b.S(f, u);
                    k.ia = b.getAttribute(f, m.ia) || b.T(f);
                    k.link = b.getAttribute(f, m.link) || b.getAttribute(f, "href") || "";
                    k.type = g.type || "click";
                    m = a.Za(f.offsetTop) ? f.offsetTop : 0;
                    "click" === g.type ? m = d.Ca ? g.clientY +
                    k.uc = m;
                    k.Fa = m.Fa || 0;
                    k.Ha = m.Ha || 0;
                    k.Na = m.Na || 0;
                    k.za = m.za || 0;
                    k.La = m.La || "b";
                    return k
                },
                Jb: function(f) {
                    var e = f.target || f.srcElement,
                        g;
                    if (d.Ca) {
                        g = f.clientX + g;
                        f = f.clientY + m
                    } else g = f.pageX,
                        f = f.pageY;
                        z = 0,
                        A = 0;
                    return {
                        Ha: Math.round(100 * ((f - A) / y)),
                        za: y,
                        La: ("a" === (e.tagName || "").toLowerCase() ? e : b.Fb(e)) ? "a" : "b"
                    }
                },
                na: function(b) {
                    var d = a.h;
                    b = [+new Date - (h.c.X !== q ? h.c.X : n), d(b.id), d(b.aa), d(b.ia),
                        d(b.$), d(b.link), d(b.content), b.type, b.uc, b.Fa, b.Ha, b.Na, b.za, b.La
                    ].join("*");
                    s.oa(b);
                },
                oa: function(a) {
                    a.length > e.pa || (encodeURIComponent(p.join("!") + a).length > e.pa && (s.w(p.join("!")), p = []), p.push(a))
                },
                w: function(a) {
                    h.c.b.et = 5;
                    h.c.b.ep = a;
                    h.c.b.p = l(f.A("autoEventTracking"));
                    h.c.i();
                    h.c.b.p = ""
                },
                Z: function() {
                    return function() {
                        p && p.length && (s.w(p.join("!")), p = [])
                    }
                }
            };
        a.H(c.aet) && "" !== c.aet && r.e("pv-b", function() {
            g.e(document, "click", s.ba());
                g.e(window, "touchend", s.ba());
            g.e(window, "unload", s.Z())
        });
        return s
    })();
    (function() {
        var a = mt.lang,
            b = mt.event,
            g = mt.g,
            d = h.D,
            e = h.z,
            r = +new Date,
            f = [],
            l = w,
            n = {
                tb: function() {
                    a.H(c.aet) && "" !== c.aet && setInterval(n.ib, d.lc)
                },
                ib: function() {
                    var a = g.U() + g.M();
                    0 < a - h.c.b.vl && (h.c.b.vl = a)
                }
            },
            p = {
                Bb: function() {
                    return function() {
                            p.rb(g.U() + g.M())
                        }, 150))
                    }
                },
                rb: function(a) {
                    p.oa([+new Date - (h.c.X !== q ? h.c.X : r), a].join("*"))
                },
                oa: function(a) {
                    if (encodeURIComponent(f.join("!") + a).length > d.pa || 3 < f.length) p.w(f.join("!")),
                        f = [];
                    f.push(a)
                },
                w: function(a) {
                    n.ib();
                    h.c.b.et = 6;
                    h.c.b.vh = g.M();
                    h.c.b.ep = a;
                    h.c.i()
                },
                Z: function() {
                    return function() {
                        f && f.length && (p.w(f.join("!")), f = [])
                    }
                }
            };
        a.H(c.aet) && "" !== c.aet && e.e("pv-b", function() {
            b.e(window, "scroll", p.Bb());
            b.e(window, "unload", p.Z());
            n.tb()
        });
        return p
    })();
    (function() {
        function a() {
            return function() {
                h.c.b.nv = 0;
                h.c.b.st = 4;
                h.c.b.et = 3;
                h.c.b.ep = h.sa.Pb() + "," + h.sa.Lb();
                h.c.b.hca = c.hca;
                h.c.i()
            }
        }

        function b() {
            clearTimeout(z);
            var a;
            l = "undefined" == typeof a ? u : a;
            if ((!f || !n) && l && p) k = u, t = +new Date;
            else if (f && n && (!l || !p)) k = x, v += +new Date - t;
            f = l;
            n = p;
            z = setTimeout(b, 100)
        }

        function g(a) {
                b = "";
            if (a in m) b = a;
            else
                for (var d = ["webkit", "ms", "moz", "o"], e = 0; e < d.length; e++) {
                    var f = d[e] + a.charAt(0).toUpperCase() + a.slice(1);
                    if (f in m) {
                        b = f;
                        break
                    }
                }
            return b
        }

        function d(a) {
        }
        var e = mt.event,
            r = h.z,
            f = u,
            l = u,
            n = u,
            p = u,
            s = +new Date,
            t = s,
            v = 0,
            k = u,
            m = g("visibilityState"),
            y = g("hidden"),
            z;
        b();
        (function() {
            var a = m.replace(/[vV]isibilityState/, "visibilitychange");
            e.e(document, a, b);
            e.e(window, "pageshow", b);
            e.e(window, "pagehide", b);
                "focus", d), e.e(window, "blur", d))
        })();
        h.sa = {
            Pb: function() {
                return +new Date - s
            },
            Lb: function() {
                return k ? +new Date - t + v : v
            }
        };
        r.e("pv-b", function() {
            e.e(window, "unload", a())
        });
        r.e("duration-send", a());
        r.e("duration-done", function() {
            t = s = +new Date;
            v = 0
        });
        return h.sa
    })();
    (function() {
        var a = mt.lang,
            b = h.D,
            g = h.load,
            d = {
                bc: function(d) {
                        var r = h.c.R();
                        g([b.protocol, "//datax.baidu.com/x.js?si=", c.id, "&dm=", encodeURIComponent(r)].join(""), d)
                    }
                },
                tc: function(b) {
                }
            };
        return h.zb = d
    })();
    (function() {
        function a(a, b, d, f) {
            if (!(a === q || b === q || f === q)) {
                if ("" === a) return [b, d, f].join("*");
                for (var e, g = x, k = 0; k < a.length; k++)
                    if (e = a[k].split("*"), String(b) === e[0]) {
                        e[1] = d;
                        e[2] = f;
                        g = u;
                        break
                    } g || a.push([b, d, f].join("*"));
                return a.join("!")
            }
        }

        function b(a) {
            for (var f in a)
                if ({}.hasOwnProperty.call(a, f)) {
                    var e = a[f];
                }
        }
        var g = mt.url,
            d = mt.lang,
            e = mt.s,
            r = mt.g,
            f = h.D,
            l = h.z,
            n = h.zb,
            p = h.load,
            s = h.qa,
            t = h.P,
            v = t.O,
            k = {
                Y: [],
                ha: 0,
                Da: x,
                C: {
                    Ma: "",
                    page: ""
                },
                init: function() {
                    k.j = 0;
                    t.init();
                    l.e("pv-b", function() {
                        k.Ab();
                        k.Cb()
                    });
                    l.e("pv-d", function() {
                        k.Db();
                        k.C.page = ""
                    });
                    l.e("stag-b", function() {
                        h.c.b.api = k.j || k.ha ? k.j + "_" + k.ha : "";
                        h.c.b.ct = [decodeURIComponent(s.getData("Hm_ct_" + c.id) || ""), k.C.Ma, k.C.page].join("!")
                    });
                    l.e("stag-d", function() {
                        h.c.b.api = 0;
                        k.j = 0;
                        k.ha = 0
                    })
                },
                Ab: function() {
                        id: c.id,
                        cmd: {},
                        push: function() {
                                var m = arguments[b];
                                d.d(m, "Array") && (a.cmd[a.id].push(m), "_setAccount" === m[0] && (1 < m.length && /^[0-9a-f]{32}$/.test(m[1])) && (m = m[1], a.id = m, a.cmd[m] = a.cmd[m] || []))
                            }
                        }
                },
                Cb: function() {
                    if (a && a.cmd && a.cmd[c.id])
                        for (var b = a.cmd[c.id], d = /^_track(Event|MobConv|Order)$/, e = 0, f = b.length; e < f; e++) {
                            var g = b[e];
                            d.test(g[0]) ? k.Y.push(g) : k.Ja(g)
                        }
                    a.cmd[c.id] = {
                        push: k.Ja
                    }
                },
                Db: function() {
                    if (0 < k.Y.length)
                        for (var a = 0, b = k.Y.length; a < b; a++) k.Ja(k.Y[a]);
                    k.Y = w
                },
                Ja: function(a) {
                    var b =
                        a[0];
                    if (k.hasOwnProperty(b) && d.d(k[b], "Function")) k[b](a)
                },
                _setAccount: function(a) {
                    1 < a.length && /^[0-9a-f]{32}$/.test(a[1]) && (k.j |= 1)
                },
                _setAutoPageview: function(a) {
                },
                _trackPageview: function(a) {
                        a[1], h.c.b.p = v(t.A("pageview")), h.c.i(), h.c.b.p = "", h.c.X = +new Date, t.o("pageview"))
                },
                _trackEvent: function(a) {
                    2 < a.length && (k.j |= 8, h.c.b.nv = 0, h.c.b.st = 4, h.c.b.et = 4, h.c.b.ep = d.h(a[1]) + "*" + d.h(a[2]) + (a[3] ? "*" + d.h(a[3]) : "") + (a[4] ? "*" + d.h(a[4]) : ""), h.c.b.p = v(t.ya()), h.c.i(), h.c.b.p = "")
                },
                _setCustomVar: function(a) {
                    if (!(4 > a.length)) {
                        var b = a[1],
                            e = a[4] || 3;
                        if (0 < b && 6 > b && 0 < e && 4 > e) {
                            k.ha++;
                            for (var f = (h.c.b.cv || "*").split("!"), g = f.length; g < b - 1; g++) f.push("*");
                            f[b - 1] = e + "*" + d.h(a[2]) + "*" + d.h(a[3]);
                            h.c.b.cv = f.join("!");
                            "" !== a ? s.setData("Hm_cv_" + c.id, encodeURIComponent(a), c.age) : s.removeData("Hm_cv_" + c.id)
                        }
                    }
                },
                _setUserTag: function(b) {
                    if (!(3 > b.length)) {
                        var e = d.h(b[1]);
                        if (e !== q && b !== q) {
                            var f = decodeURIComponent(s.getData("Hm_ct_" + c.id) || ""),
                                f = a(f, e, 1, b);
                            s.setData("Hm_ct_" + c.id, encodeURIComponent(f), c.age)
                        }
                    }
                },
                _setVisitTag: function(b) {
                    if (!(3 > b.length)) {
                        var e = d.h(b[1]);
                        if (e !== q && b !== q) {
                            var f = k.C.Ma,
                                f = a(f, e, 2, b);
                            k.C.Ma = f
                        }
                    }
                },
                _setPageTag: function(b) {
                    if (!(3 >
                            b.length)) {
                        var f = d.h(b[1]);
                        if (f !== q && b !== q) {
                            var e = k.C.page,
                                e = a(e, f, 3, b);
                            k.C.page = e
                        }
                    }
                },
                _setReferrerOverride: function(a) {
                },
                _trackOrder: function(a) {
                    d.d(a, "Object") && (b(a), k.j |= 16, h.c.b.nv = 0, h.c.b.st = 4, h.c.b.et = 94, h.c.b.ep = e.stringify(a), h.c.b.p = v(t.ya()), h.c.i(), h.c.b.p = "")
                },
                _trackMobConv: function(a) {
                            webim: 1,
                            tel: 2,
                            map: 3,
                            sms: 4,
                            callback: 5,
                            share: 6
                        } [a[1]]) k.j |=
                        32, h.c.b.et = 93, h.c.b.ep = a, h.c.i()
                },
                _setDataxId: function(a) {
                    n.bc();
                    n.tc(a)
                },
                _setUserId: function(a) {
                    if (a !== q && (d.H(a) || d.Za(a))) {
                        var b = t.A("user").uid_;
                        if (!(b && b.value === d.h(String(a)))) {
                            var b = h.c.b.p,
                                e = h.c.b.ep;
                            h.c.b.et = 8;
                            h.c.b.ep = "";
                            h.c.b.p = "uid_*" + d.h(String(a));
                            h.c.i();
                            var f = {};
                            f.uid_ = a;
                            t.setProperty("user", f, u);
                            h.c.b.p = b;
                            h.c.b.ep = e
                        }
                    }
                },
                _clearUserId: function(a) {
                    1 < a.length && u === a[1] && t.o("userId")
                },
                _setUserProperty: function(a) {
                    d.d(a, "Object") && t.setProperty("user", a)
                },
                _clearUserProperty: function(a) {
                    1 <
                        a.length && u === a[1] && t.o("user")
                },
                _setSessionProperty: function(a) {
                    d.d(a, "Object") && t.setProperty("session", a)
                },
                _clearSessionProperty: function(a) {
                    1 < a.length && u === a[1] && t.o("session")
                },
                _setPageviewProperty: function(a) {
                    d.d(a, "Object") && t.setProperty("pageview", a)
                },
                _clearPageviewProperty: function(a) {
                    1 < a.length && u === a[1] && t.o("pageview")
                },
                _setAutoEventTrackingProperty: function(a) {
                    d.d(a, "Object") && t.setProperty("autoEventTracking", a)
                },
                _clearAutoEventTrackingProperty: function(a) {
                    1 < a.length &&
                        u === a[1] && t.o("autoEventTracking")
                },
                _setAutoTracking: function(a) {
                },
                _setAutoEventTracking: function(a) {
                },
                _trackPageDuration: function(a) {
                    l.K("duration-done")
                },
                _require: function(a) {
                },
                _providePlugin: function(a) {
                    if (1 < a.length) {
                            e = a[1];
                        if (d.G(f.eb,
                            for (var g = 0, k = a.length; g < k; g++) {
                                var l = a[g][2] || {};
                                if (b.plugins[e] && !b.I[e]) b.I[e] = new b.plugins[e](l), b.B.shift();
                                else break
                            }
                    }
                },
                _requirePlugin: function(a) {
                    if (1 < a.length) {
                            e = a[1],
                            g = a[2] || {};
                        if (d.G(f.eb, e))
                            if (b.plugins = b.plugins || {}, b.I = b.I || {}, b.plugins[e] && !b.I[e]) b.I[e] = new b.plugins[e](g);
                            else {
                                b.B = b.B || [];
                                for (var g = 0, l = b.B.length; g < l; g++)
                                    if (b.B[g][1] ===
                                        e) return;
                                b.B.push(a);
                                k._require([w, f.ic + e + ".js"])
                            }
                    }
                },
                _trackCustomEvent: function(a) {
                    if (1 < a.length) {
                        var b = a[1];
                        t.setProperty("customEvent", a);
                        h.c.b.et = 7;
                        h.c.b.ep = "";
                        h.c.b.p = v(t.A("customEvent"));
                        h.c.i();
                        h.c.b.p = "";
                        t.o("customEvent")
                    }
                }
            };
        k.init();
        h.wb = k;
        return h.wb
    })();
    (function() {
        var a = h.z;
        }))
    })();
    (function() {
        function a() {
        }
        var b = mt.url,
            g = mt.lb,
            d = mt.Ka,
            e = mt.lang,
            r = mt.cookie,
            f = mt.g,
            l = mt.sessionStorage,
            n = mt.s,
            p = mt.event,
            s = h.qa,
            t = h.P,
            v = t.O,
            k = h.D,
            m = h.load,
            y = h.z;
            W: function(a, b) {
                b = "." + b.replace(/:\d+/, "");
                var d = a.indexOf(b);
                return -1 < d && d + b.length === a.length
            },
            ga: function(a,
                b) {
                return 0 === a.indexOf(b)
            },
            ea: function(a) {
                for (var d = 0; d < c.dm.length; d++)
                    if (-1 < c.dm[d].indexOf("/")) {
                    } else {
                        var e = b.L(a);
                    } return x
            },
            R: function() {
                return a
            },
            da: function() {
                for (var a = 0, b = c.dm.length; a < b; a++) {
                    var d = c.dm[a];
                        "$1") + "/"
                }
                return "/"
            },
            Sb: function() {
                var a = x;
                return a ? k.J - k.N > c.vdur ? 1 : 4 : 3
            },
            rc: function() {
                var a, b, d, e, f, g;
                k.N = s.getData("Hm_lpvt_" + c.id) || 0;
                13 === k.N.length && (k.N = Math.round(k.N / 1E3));
                a = 4 !== b ? 1 : 0;
                if (g = s.getData("Hm_lvt_" + c.id)) {
                    e = g.split(",");
                    for (f = e.length - 1; 0 <= f; f--) 13 === e[f].length && (e[f] = "" + Math.round(e[f] /
                        1E3));
                    for (; 2592E3 < k.J - e[0];) e.shift();
                    f = 4 > e.length ? 2 : 3;
                    for (1 === a && e.push(k.J); 4 < e.length;) e.shift();
                    g = e.join(",");
                    e = e[e.length - 1]
                } else g = k.J, e = "", f = 1;
            },
            fc: function() {
                return !e.G("sjh.baidu.com isite.baidu.com ls.wejianzhan.com bs.wejianzhan.com product.weijianzhan.com qianhu.weijianzhan.com aisite.wejianzhan.com".split(" "),
                    a)
            },
            Eb: function() {
                    var d = a[b].split("=");
                    d.length && /Hm_(up|ct|cv|lp?vt)_[0-9a-f]{31}/.test(String(d[0])) && s.removeData(d[0]);
                    d.length && /Hm_ck_[0-9]{13}/.test(String(d[0])) && s.removeData(d[0])
                }
            },
            qc: function() {
                    var f = k.mb[d],
                    "undefined" !== typeof g && "" !== g && ("tt" !== f || "tt" === f && 0 === b) && ("ct" !== f || "ct" === f && 0 === b) && a.push(f + "=" + encodeURIComponent(g))
                }
                return a.join("&")
            },
            sc: function() {
                    k.Yb) || b.m(a, k.zc) || "";
            },
            init: function() {
                try {
                    var b = [];
                    b.push("si=" + c.id);
                    g.log(k.Ea + "//" + k.fb + "?" + b.join("&"))
                }
            },
            mc: function() {
                function a() {
                    y.K("pv-d")
                }
                t.o("pageview")
            },
            i: function(a) {
                    b.b.rnd = Math.round(Math.random() * k.Ga);
                    b.b.r = f.orientation;
                    b.b.ww = f.ob;
                    y.K("stag-b");
                    var d = k.Ea + "//" + k.fb + "?" + b.qc();
                    y.K("stag-d");
                    b.ub(d);
                    g.log(d, function(d) {
                        b.hb(d);
                        e.d(a, "Function") && a.call(b)
                    })
                }
            },
            yb: function() {
                    d = RegExp(c.id),
                    f =
                    b.m(a, "jn"),
                    g = /^select$/.test(f);
            },
            xb: function() {
                try {
                        p.e(window, "message", function(d) {
                            if (b.L(d.origin) === k.nb) {
                                d = d.data || {};
                                var e = d.jn || "",
                                    f = /^customevent$|^heatmap$|^pageclick$/.test(e);
                                if (RegExp(c.id).test(d.sd || "") && f) a.b.rnd = Math.round(Math.random() * k.Ga), m(k.protocol + "//" + c.js + e + ".js?" + a.b.rnd)
                            }
                        });
                            id: c.id,
                            status: "__Messenger__hmLoaded"
                        }, "*")
                    }
                } catch (d) {}
            },
            ub: function(a) {
                var b;
                try {
                    b = n.parse(l.get("Hm_unsent_" + c.id) || "[]")
                } catch (d) {
                    b = []
                }
                b.push(a.replace(/^https?:\/\//, "") + e);
                l.set("Hm_unsent_" + c.id,
                    n.stringify(b))
            },
            hb: function(a) {
                var b;
                try {
                    b = n.parse(l.get("Hm_unsent_" + c.id) || "[]")
                } catch (d) {
                    b = []
                }
                if (b.length) {
                    for (var e = 0; e < b.length; e++)
                        if (a.replace(/&u=[^&]*/, "") === b[e].replace(/&u=[^&]*/, "")) {
                            b.splice(e, 1);
                            break
                }
            },
            Ta: function() {
                l.remove("Hm_unsent_" + c.id)
            },
            pc: function() {
                    b;
                try {
                    b = n.parse(l.get("Hm_unsent_" + c.id) || "[]")
                } catch (d) {
                    b = []
                }
                if (b.length)
                    for (var e = function(b) {
                                g.log(k.Ea + "//" + b, function(b) {
                                    a.hb(b)
                                })
                            },
                            f = 0; f < b.length; f++) e(b[f])
            },
            Va: function() {
                return Math.round(+new Date / 1E3) % 65535
            }
        };
    })();
    var B = h.D,
        C = h.load;
    c.pt && C([B.protocol, "//ada.baidu.com/phone-tracker/insert_bdtj?sid=", c.pt].join(""));
    (function() {
        var a = mt.g,
            b = mt.lang,
            g = mt.event,
            d = mt.s;
        if ("undefined" !== typeof h.c && (c.med || (!a.Ca || 7 < a.Nb()) && c.cvcc)) {
            var e, r, f, l, n = function(a) {
                    if (a.item) {
                        for (var b = a.length, d = Array(b); b--;) d[b] = a[b];
                        return d
                    }
                    return [].slice.call(a)
                },
                p = function(a, b) {
                    for (var d in a)
                        if (a.hasOwnProperty(d) && b.call(a, d, a[d]) === x) return x
                },
                s = function(a, g) {
                    var k = {};
                    k.n = e;
                    k.t = "clk";
                    k.v = a;
                    if (g) {
                        var l = g.getAttribute("href"),
                            n = g.getAttribute("onclick") ? "" + g.getAttribute("onclick") : w,
                            p = g.getAttribute("id") || "";
                        f.test(l) ? (k.sn =
                            "mediate", k.snv = l) : b.d(n, "String") && f.test(n) && (k.sn = "wrap", k.snv = n);
                        k.id = p
                    }
                    h.c.b.et = 86;
                    h.c.b.ep = d.stringify(k);
                    h.c.i();
                    for (k = +new Date; 400 >= +new Date - k;);
                };
            if (c.med) r = "/zoosnet", e = "swt", f = /swt|zixun|call|chat|zoos|business|talk|kefu|openkf|online|\/LR\/Chatpre\.aspx/i, l = {
                click: function() {
                        d.getAttribute("onclick"), d = d.getAttribute("href"), (f.test(e) || f.test(d)) && a.push(b[g]);
                    return a
                }
            };
            else if (c.cvcc) {
                r = "/other-comm";
                e = "other";
                f = c.cvcc.q || q;
                var t = c.cvcc.id || q;
                l = {
                    click: function() {
                            f.test(g) || t.test(d)) && a.push(b[k])) : (f.test(e) || f.test(g)) && a.push(b[k])) : t !== q && (d = d.getAttribute("id"), t.test(d) && a.push(b[k]));
                        return a
                    }
                }
            }
            if ("undefined" !== typeof l && "undefined" !== typeof f) {
                var v;
                r += /\/$/.test(r) ? "" : "/";
                var k = function(a, d) {
                    if (v === d) return s(r + a, d), x;
                    if (b.d(d, "Array") || b.d(d, "NodeList"))
                        for (var e = 0, f = d.length; e < f; e++)
                            if (v === d[e]) return s(r + a + "/" + (e + 1), d[e]), x
                };
                g.e(document, "mousedown", function(a) {
                    v = a.target || a.srcElement;
                    var d = {};
                    for (p(l, function(a, e) {
                            d[a] = b.d(e,
                })
            }
        }
    })();
    (function() {
        var a = mt.f,
            b = mt.lang,
            g = mt.event,
            d = mt.s;
        if ("undefined" !== typeof h.c && b.d(c.cvcf, "Array") && 0 < c.cvcf.length) {
            var e = {
                qb: function() {
                    for (var b = c.cvcf.length, d, l = 0; l < b; l++)(d = a.Ua(decodeURIComponent(c.cvcf[l]))) && g.e(d, "click", e.ta())
                },
                ta: function() {
                    return function() {
                        h.c.b.et = 86;
                        var a = {
                            n: "form",
                            t: "clk"
                        };
                        h.c.b.ep = d.stringify(a);
                        h.c.i()
                    }
                }
            };
            a.gb(function() {
                e.qb()
            })
        }
    })();
    (function() {
        var a = mt.event,
            b = mt.s;
        if (c.med && "undefined" !== typeof h.c) {
            var g = {
                    n: "anti",
                    sb: 0,
                    kb: 0,
                    clk: 0
                },
                d = function() {
                    h.c.b.et = 86;
                    h.c.b.ep = b.stringify(g);
                    h.c.i()
                };
            a.e(document, "click", function() {
                g.clk++
            });
            a.e(document, "keyup", function() {
                g.kb = 1
            });
            a.e(window, "scroll", function() {
                g.sb++
            });
            a.e(window, "load", function() {
                setTimeout(d, 5E3)
            })
        }
    })();
})();