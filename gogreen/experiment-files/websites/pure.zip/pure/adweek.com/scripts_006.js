"use strict";
! function(a) {
    function e() {
        return e
    }
    a(".aw-flickr-gallery-btn-dl").each(function() {
        var r = a(this);
    }), a(window).on('load', function() {
        var e = a(".aw-flickr-gallery-btns");
        awIsUserLoggedIn() && e.removeClass("hide-for-nonsubs")
    }), a(".aw-flickr-gallery-btn-dl").on("click", function(r) {
        var t = a(this);
            if ("undefined" == typeof e()) {
                r.preventDefault();
                var i = t.next(".aw-modal-wrapper");
                return i.toggle(), !1
            }
            t.removeClass("aw-modal-trigger")
        }
    }), a(".aw-flickr-gallery-accept-tac").on("click", function() {
        var e = a(this);
            expires: 30
    })
}(jQuery);