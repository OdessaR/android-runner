// Awesomplete - Lea Verou - MIT license
! function() {
    function t(t) {
        var e = Array.isArray(t) ? {
            label: t[0],
            value: t[1]
        } : "object" == typeof t && "label" in t && "value" in t ? t : {
            label: t,
            value: t
        };
    }

    function e(t, e, i) {
        for (var n in e) {
            var s = e[n],
                r = t.input.getAttribute("data-" + n.toLowerCase());
        }
    }

    function i(t, e) {
    }

    function n(t, e) {
    }

    function s() {
        n("input.awesomplete").forEach(function(t) {
            new r(t)
        })
    }
    var r = function(t, n) {
            minChars: 2,
            maxItems: 10,
            autoFirst: !1,
            data: r.DATA,
            filter: r.FILTER_CONTAINS,
            sort: !1 !== n.sort && r.SORT_BYLENGTH,
            container: r.CONTAINER,
            item: r.ITEM,
            replace: r.REPLACE,
            tabSelect: !1
            hidden: "hidden",
            role: "listbox",
            className: "visually-hidden",
            role: "status",
            "aria-live": "assertive",
            "aria-atomic": !0,
            input: {
                    reason: "blur"
                }),
                keydown: function(t) {
                    var e = t.keyCode;
                    s.opened && (13 === e && s.selected ? (t.preventDefault(), s.select()) : 9 === e && s.selected && s.tabSelect ? s.select() : 27 === e ? s.close({
                        reason: "esc"
                    }) : 38 !== e && 40 !== e || (t.preventDefault(), s[38 === e ? "previous" : "next"]()))
                }
            },
            form: {
                    reason: "submit"
                })
            },
            ul: {
                mousedown: function(t) {
                    t.preventDefault()
                },
                click: function(t) {
                    var e = t.target;
                        for (; e && !/li/i.test(e.nodeName);) e = e.parentNode;
                        e && 0 === t.button && (t.preventDefault(), s.select(e, t.target))
                    }
                }
            }
    };
    r.prototype = {
        set list(t) {
                var e = [];
                o.apply(t.children).forEach(function(t) {
                    if (!t.disabled) {
                        var i = t.textContent.trim(),
                            n = t.value || i,
                            s = t.label || i;
                        "" !== n && e.push({
                            label: s,
                            value: n
                        })
                    }
            }
        },
        get selected() {
        },
        get opened() {
        },
        close: function(t) {
        },
        open: function() {
        },
        destroy: function() {
            }
            var e = r.all.indexOf(this); - 1 !== e && r.all.splice(e, 1)
        },
        next: function() {
        },
        previous: function() {
        },
        goto: function(t) {
            }))
        },
        select: function(t, e) {
                    text: n,
                    origin: e || t
                    reason: "select"
                    text: n
                }))
            }
        },
        evaluate: function() {
            }).filter(function(t) {
                return e.filter(t, i)
                e.ul.appendChild(e.item(t, i, n))
                reason: "nomatches"
                reason: "nomatches"
        }
    }, r.all = [], r.FILTER_CONTAINS = function(t, e) {
    }, r.FILTER_STARTSWITH = function(t, e) {
    }, r.SORT_BYLENGTH = function(t, e) {
        return t.length !== e.length ? t.length - e.length : t < e ? -1 : 1
    }, r.CONTAINER = function(t) {
            className: "awesomplete",
            around: t
        })
    }, r.ITEM = function(t, e, n) {
            role: "option",
            "aria-selected": "false",
        })
    }, r.REPLACE = function(t) {
    }, r.DATA = function(t) {
        return t
        get: function() {
        }
    };
    var o = Array.prototype.slice;
        for (var s in e) {
            var r = e[s];
            if ("inside" === s) i(r).appendChild(n);
            else if ("around" === s) {
                var o = i(r);
                o.parentNode.insertBefore(n, o), n.appendChild(o), null != o.getAttribute("autofocus") && o.focus()
            } else s in n ? n[s] = r : n.setAttribute(s, r)
        }
        return n
        if (t)
            for (var i in e) {
                var n = e[i];
                i.split(/\s+/).forEach(function(e) {
                    t.addEventListener(e, n)
                })
            }
        if (t)
            for (var i in e) {
                var n = e[i];
                i.split(/\s+/).forEach(function(e) {
                    t.removeEventListener(e, n)
                })
            }
        n.initEvent(e, !0, !0);
        for (var s in i) n[s] = i[s];
        return t.dispatchEvent(n)
        return t.replace(/[-\\^$*+?.()|[\]{}]/g, "\\$&")
        return e
}();
//# sourceMappingURL=awesomplete.min.js.map