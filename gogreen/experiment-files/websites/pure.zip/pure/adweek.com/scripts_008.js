"use strict";
! function(a) {
    a(window).on('load', function() {
        var i = a('[name="redirect_url"]');
        if (i && i.length) {
            var e = i.val();
        }
        var r = awGetUserCookie();
            action: "check_event_signup_status",
            user_id: r.api_guid
        }, function(i) {
        });
            var d = a("#aw-all-webinars-link");
            d.removeClass("hide")
        }
    })
}(jQuery);