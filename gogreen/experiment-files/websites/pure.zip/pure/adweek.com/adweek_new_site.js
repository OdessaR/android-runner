/* Script:New%20Site%20Design - ScriptInstance:2d0ee0a293c44e55b3884682f90294e3 - CompiledAt:2020-08-31 15:54:23 */

(function() {
    var compiledTemplate_gs_sm = "";
    var compiledTemplate_gs_lg = "";
    var compiledTemplate_herohome = "";
    var compiledTemplate_heroarticle = "";
    var homeNative = "";
    var agencySpy = "";
    var adWeekGrid = "";
    var adWeekMulti = "";
    var adWeekMultiPartnerExperts = "";
    var searchFeed = "";
    var adWeekCategory = "";
    var verticalLandingPage = "";
    var articleEditorPick = "";
    templates();
    var q = function() {
    };
    q().push(["setPropertyID", "NA-ADWEEKRESPSITE-11238673"]);
    q().push(["setWillLinkRedirect", function() {
        return false
    }]);
    var gs_sm_location = "";
        gs_sm_location = "#section-3 > .aw-element.title-only.parent-width.show-for-medium-only.title-only--medium:eq(0)"
    } else {
        gs_sm_location = "#section-2 > div.aw-element.title-only.parent-width.xlarge-12.large-6.medium-6.nob-l.title-only--medium"
    }
        q().push(["insertPreview", {
            label: "homepage-grid-placement-small",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "grid-placement-small"
                }
            },
            location: gs_sm_location,
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_sm,
            onRender: function($element, data) {
                $element.next().remove();
                switch (gs_sm_location) {
                    case "#section-3 > .aw-element.title-only.parent-width.show-for-medium-only.title-only--medium:eq(0)":
                        $element.addClass("aw-element title-only parent-width show-for-medium-only title-only--medium");
                        break;
                    case "#section-2 > div.aw-element.title-only.parent-width.xlarge-12.large-6.medium-6.nob-l.title-only--medium":
                        $element.addClass("aw-element title-only parent-width xlarge-12 large-6 medium-6 nob-l title-only--medium");
                        break
                }
            },
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
    var switchGridTemplate = function($element, data) {
        switch (data.custom.grid_template_type) {
            case "v2_white_background":
                $element.css("border", "0");
                $element.css("background-color", "#fff");
                break;
            case "v3_white_bg_byline":
                $element.css("border", "0");
                $element.css("background-color", "#fff");
                $element.children(".plr-disclosure-gl").children("h2").children("a").attr("style", "color: #c8c8c8 !important");
                if (data.custom.byline) {
                    $element.children("a:eq(1)").append("<a href= 'data.link' class='plr-byline contributor'>by " + data.custom.byline + "</a>")
                }
                break;
            default:
                break
        }
    };
        q().push(["insertPreview", {
            label: "homepage-grid-placement-large",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "grid-placement-large",
                    order: "2"
                }
            },
            location: "section.col-12.col-lg > div > div > div > div.row.justify-content-center.justify-content-lg-start.grid-item-container > div:nth-child(2)",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_lg,
            onRender: function($element, data) {
                $element.next().hide();
                switchGridTemplate($element, data);
                $element.wrap('<div class="col-10 col-md-6"></div>')
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-disclosure { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "homepage-grid-placement-large",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "grid-placement-large",
                    order: "4"
                }
            },
            location: "section.col-12.col-lg > div > div > div > div.row.justify-content-center.justify-content-lg-start.grid-item-container > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_lg,
            onRender: function($element, data) {
                $element.next().hide();
                switchGridTemplate($element, data);
                $element.wrap('<div class="col-10 col-md-6"></div>')
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-disclosure { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "homepage-featured-placement",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "featured-placement",
                    order: "4"
                }
            },
            location: ".main-content .aw-container.container-grid.flexbox .aw-element:eq(3)",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_lg,
            onRender: function($element, data) {
                $element.next().hide();
                switchGridTemplate($element, data);
                $element.wrap("<div class='aw-element vertical parent-width border-right nobr-s xlarge-3 large-3 medium-6 small-12'></div>")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
        q().push(["insertPreview", {
            label: "homepage-featured-placement",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "featured-placement",
                    order: "8"
                }
            },
            location: ".main-content .aw-container.container-grid.flexbox .aw-element:eq(7)",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_lg,
            onRender: function($element, data) {
                $element.next().hide();
                switchGridTemplate($element, data);
                $element.wrap("<div class='aw-element vertical parent-width border-right nobr-s xlarge-3 large-3 medium-6 small-12 nob-xl nob-l nob-m'></div>")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
    var targetHero = {
        placement: "hero-placement"
    };
        targetHero["page"] = "home"
    }
        q().push(["insertPreview", {
            label: "homepage-hero-placement",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: targetHero
            },
            location: ".main-content > div > div > div.postup-adweek-wall-section",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_herohome,
            onRender: function($element, data) {
                $element.next(".postup-adweek-wall-section").hide()
            },
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
        q().push(["insertPreview", {
            label: "articlepage-end-of-article-hero",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "end-of-article-hero"
                }
            },
            location: "#single-post > .ad-div-a0-wrapper:eq(0)",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_heroarticle,
            onRender: function($element, data) {},
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
        q().push(["insertPreview", {
            label: "articlepage-rightrail",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "right-rail"
                }
            },
            location: ".main-content > aside > div.widget-area.sticky-container > div > div",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_lg,
            onRender: function($element, data) {
                switchGridTemplate($element, data);
                $element.children(".plr-disclosure-gl").children("h2").css("margin-bottom", "0");
                $element.wrap("<div class='sticky widget'></div>")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
        q().push(["insertPreview", {
            label: "articlepage-kickout",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "kick-out"
                }
            },
            location: ".entry-content .post-text:eq(0) p:eq(3)",
            infoText: "",
            infoButtonText: "",
            template: compiledTemplate_gs_lg,
            onRender: function($element, data) {
                switchGridTemplate($element, data);
                $element.css("max-width", "300px");
                $element.children(".plr-disclosure-gl").children("h2").css("margin-bottom", "0");
                $element.wrap("<div class='kickout justify-left ko-image-container plr-ad-kickout'></div>")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
    q().push(["injectCSS", ["", ".polar-learn-more-btn{", "   background-color: #ed1d25 !important;", "}", "", ".polar-learn-more-btn:hover{", "   color: #fff !important;", "   background-color: #801515 !important;", "}", ""].join("\n"), "head"]);
    q().push(["injectCSS", ["", ".plr-ad-link-gs {", "    border-left: 4px solid #F6A623 !important;", "}", ".plr-ad-title-gs {", '    font-family: "FlamaSlab-SemiBold", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;', "    color: #333333;", "    size: 24px;", "    line-height: 30px", "}", ".plr-ad-disclosure-gs {", '    font-family: "Flama-BookItalic", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;', "    color: #333333;", "    padding-top: 20px;", "    font-size: 14px !important;", "    margin-bottom: 0;", "}", ".plr-ad-wrapper-gl {", "    height: 100%;", "    background-color: #F4F4F4;", "    border: 1px solid #D4D4D4;", "}", ".plr-disclosure-gl {", " text-align: center;", "}", ".plr-disclosure-gl a {", "    color: #F6a623 !important;", "    font-size: 12px;", "    line-height: 0;", "    text-transform: uppercase;", "}", ".plr-title-gl {", "margin-top: 0;", "margin-bottom: auto;", "color: #333;", "text-align: center;", "font-size: 18px !important;", "line-height: 24px !important;", "margin-top: 4px;", 'font-family: "Flama-Bold", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;', "padding: 0 10px !important;", "}", ".plr-ad-disclosure-hero {", "    color: #FFFFFF !important;", '    font-family: "Flama-BookItalic", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif !important;', "    font-size: 14px !important;", "    margin-bottom: 4px;", "}", ".plr-ad-hero {", "z-index: 1;", "}", ".plr-border-hero {", "    border-bottom: 4px solid #F6A623;", "    width: 65px;", "    margin-bottom: 8px;", "}", ".plr-ad-title-hero {", '    font-family: "FlamaSlab-SemiBold", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif !important;', "    font-size: 38px !important;", "    line-height: 50px !important;", "}", "@media screen and (max-width: 680px) {", "    .plr-border-hero {", "        margin: 0 auto;", "        margin-bottom: 5px;", "    }", "    .plr-ad-disclosure-hero {", "        color: #666 !important;", "        text-align: center;", "    }", "    .plr-ad-title-hero {", "        color: #333 !important;", "        font-size: 18px !important;", "        line-height: 23px !important;", "        text-align: center;", "    }", "}", ".plr-ad-hero-a {", "    width: 100%;", "    padding: 10px;", "}", "", ".plr-image-wrapper-hero-a {", "    width: 100%;", "    height: 420px;", "    position: relative;", "}", ".plr-ad-content-hero-a {", "    position: relative;", "    background: rgba(51, 51, 51, 0.43);", "    margin: 0 50px;", "    padding: 30px;", "    top: 45%;", "}", ".plr-link-hero-a{", "    position: absolute;", "    height: 100%;", "    width: 100%;", "    z-index: 1;", "}", ".plr-ad-title-hero-a {", "    color: #FFFFFF;", '    font-family: "FlamaSlab-SemiBold", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;', "    font-size: 36px;", "    line-height: 43px;", "    text-align: center;", "}", ".plr-ad-disclosure-hero-a {", "    color: #FFFFFF;", '    font-family: "Flama-BookItalic", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;', "    font-size: 18px;", "    margin-bottom: 4px;", "    text-align: center;", "    margin-top: 0;", "}", ".plr-ad-border-hero-a {", "    border-bottom: 4px solid #F6A623;", "    width: 65px;", "    margin: 0 auto;", "    margin-bottom: 10px;", "}", "@media screen and (max-width: 570px) {", "    .plr-ad-content-hero-a {", "        top: 20%;", "        padding: 25px;", "        margin: 0 40px;", "    }", "    .plr-ad-title-hero-a {", "        font-size: 30px;", "        line-height: 36px;", "    }", "    .plr-ad-disclosure-hero-a {", "        font-size: 12px;", "    }", "}", "@media screen and (min-width: 570px) and (max-width: 740px) {", "    .plr-ad-content-hero-a {", "        top: 40%;", "    }", "}", " .plr-ad-kickout {", "    border-right: 1px solid #e3e3e3;", "    width: 40% !important;", "    min-width: 320px !important;", "    margin-right: 20px !important;", "}", "@media screen and (max-width: 450px) {", ".plr-ad-kickout {", "    border-right: 0;", "    width: 100% !important;", "    margin: 0 !important;", "    padding: 0;", "}", ".plr-ad-kickout .plr-ad-wrapper-gl {", "width: 290px !important;", "max-width: 290px !important;", "min-width: 0 !important;", "margin: 0 auto !important;", "margin-bottom: 15px !important;", "}", "}", "@media screen and (max-width: 340px) {", ".plr-ad-kickout .plr-ad-wrapper-gl {", "margin: 0 !important;", "}", "}", ""].join("\n"), "head"]);
        q().push(["insertPreview", {
            label: "Vertical Landing",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "vertical_landing",
                    veritcal: vertical
                }
            },
            location: ".content-section .aw-element:eq(1)",
            infoText: "",
            infoButtonText: "",
            template: homeNative,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ["", ".plr-disclosure{", "     color: #666 !important;", "}", "", ".plr-disclosure-desk{", "     color: #c8c8c8 !important;", "}", "", ".plr-sponsor-desk{", "    display: inline-block;", '    font-family: "Flama-Book", "Helvetica Neue", Helvetica, Roboto, Arial, sans-serif;', "    color: #666 !important;", "    font-size: 14px !important;", "}", "", ""].join("\n"), "head"]);
            q().push(["insertPreview", {
                label: "Search Page In-Feed",
                unit: {
                    server: "dfp",
                    id: "/319737315/Adweek/native_ads",
                    size: "2x2",
                    targets: {
                        placement: "search"
                    }
                },
                location: ".main-content .post:eq(1)",
                infoText: "",
                infoButtonText: "",
                template: searchFeed,
                onRender: function($element, data) {
                    $element.next().css("display", "none")
                },
                onFill: function(data) {},
                onError: function(error) {}
            }])
        }
        q().push(["injectCSS", ["", ".plr-disclosure{", "     color: #c8c8c8 !important;", "}", "", ".plr-byline{", "    clear: none !important;", "}", "", ""].join("\n"), "head"]);
        var listOfPathNames = ["/agencies/", "/brand-marketing/", "/digital/", "/tv-video/", "/creativity/"];
            q().push(["insertPreview", {
                label: "Vertical Landing Grid",
                unit: {
                    server: "dfp",
                    id: "/319737315/Adweek/native_ads",
                    size: "2x2",
                    targets: {
                        placement: "vertical_landing_grid",
                        veritcal: vertical
                    }
                },
                location: ".aw-container.container-grid .aw-element:eq(1)",
                infoText: "",
                infoButtonText: "",
                template: adWeekGrid,
                onRender: function($element, data) {
                    $element.next().css("display", "none")
                },
                onFill: function(data) {},
                onError: function(error) {}
            }])
        }
        q().push(["injectCSS", [".plr-disc-grid, .plr-sponsor-grid{", "    text-align: center !important;", "}", "", "", " .plr-disc-grid{", "   font-size: 12px !important;", "    color: #c8c8c8 !important;", '    font-family: "Flama-Bold", "Helvetica Neue", Helvetica, Roboto, Arial;', "}", "", " .plr-sponsor-grid{", "   margin-top: 11px;", "    font-size: 14px !important;", "    color: #666 !important;", "}", " .plr-ad h2{", "   margin-top: 0 !important;", "}", ""].join("\n"), "head"])
    }
    var listOfPathNames = ["/category/connected-world/"];
        q().push(["insertPreview", {
            label: "Connected-World Category Page",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "connected-world"
                }
            },
            location: ".main-content .post:eq(2)",
            infoText: "",
            infoButtonText: "",
            template: adWeekCategory,
            onRender: function($element, data) {},
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["insertPreview", {
            label: "Connected-World Category Page",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "connected-world"
                }
            },
            location: ".main-content .post:eq(4)",
            infoText: "",
            infoButtonText: "",
            template: adWeekCategory,
            onRender: function($element, data) {},
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["insertPreview", {
            label: "Connected-World Category Page",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "connected-world"
                }
            },
            location: ".main-content .post:eq(6)",
            infoText: "",
            infoButtonText: "",
            template: adWeekCategory,
            onRender: function($element, data) {},
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["insertPreview", {
            label: "Connected-World Category Page",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "connected-world"
                }
            },
            location: ".main-content .post:eq(8)",
            infoText: "",
            infoButtonText: "",
            template: adWeekCategory,
            onRender: function($element, data) {},
            onFill: function(data) {},
            onError: function(error) {}
        }])
    }
        q().push(["insertPreview", {
            label: "Homepage Multi Creative",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "multi_creative_home"
                }
            },
            location: ".main-content > div > div > div:nth-of-type(6)",
            infoText: "",
            infoButtonText: "",
            collectionSize: 4,
            template: {
                collection: adWeekMulti
            },
            onRender: function($element, data) {
                $element.next(".more-stories.secton--.container.my-5").hide()
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ["", ".plr-ad-thumb{", "    padding-bottom: 56.1%;", "    -webkit-border-radius: .22222rem;", "}", "", "}", ""].join("\n"), "head"])
    }
        q().push(["insertPreview", {
            label: "Homepage Multi Creative - Partner Experts",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "partner_experts_home"
                }
            },
            location: ".main-content > div > div > div:nth-of-type(7)",
            infoText: "",
            infoButtonText: "",
            collectionSize: 4,
            template: {
                collection: adWeekMultiPartnerExperts
            },
            onRender: function($element, data) {
                $element.next(".more-stories.secton--.container.my-5").hide()
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ["", ".plr-ad-thumb{", "    padding-bottom: 56.1%;", "    -webkit-border-radius: .22222rem;", "}", "", "}", ""].join("\n"), "head"])
    }
    var listOfPathNames = ["/agencies/", "/brand-marketing/", "/digital/", "/tv-video/", "/creativity/"];
        q().push(["insertPreview", {
            label: "Vertical Multi Creative",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "multi-creative-vertical",
                    veritcal: vertical
                }
            },
            location: ".wpb_wrapper:eq(3)",
            infoText: "",
            infoButtonText: "",
            collectionSize: 4,
            template: {
                collection: adWeekMulti
            },
            onRender: function($element, data) {},
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ["", ".plr-ad-thumb{", "    padding-bottom: 56.1%;", "}", "", "}", ""].join("\n"), "head"])
    }
            q().push(["insertPreviewCollection", {
                label: "Social Brand Stream Multi-creative",
                unit: {
                    server: "mvdirect",
                    id: "promofeed-collection_9fda1e845bcb49d79ae7b082bbbd8ec1"
                },
                location: "#single-post > div.interstitial-container",
                infoText: "",
                infoButtonText: "",
                collectionSize: 4,
                template: {
                    collection: "4cbc3fa4bc4b44b19c73cdc688673494"
                }
            }])
        }
    }
        q().push(["insertPreview", {
            label: "Vertical Landing Page - Agencies",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "agencies"
                }
            },
            location: "div.flexbox.section-2.xlarge-4.small-12 > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: verticalLandingPage,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "Vertical Landing Page - Brand Marketing",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "brand-marketing"
                }
            },
            location: "div.flexbox.section-2.xlarge-4.small-12 > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: verticalLandingPage,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "Vertical Landing Page - Programmatic",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "programmatic"
                }
            },
            location: "div.flexbox.section-2.xlarge-4.small-12 > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: verticalLandingPage,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "Vertical Landing Page - Creativity",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "creativity"
                }
            },
            location: "div.flexbox.section-2.xlarge-4.small-12 > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: verticalLandingPage,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "Vertical Landing Page - TV Video",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "tv-video"
                }
            },
            location: "div.flexbox.section-2.xlarge-4.small-12 > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: verticalLandingPage,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "Vertical Landing Page - Digital",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "digital"
                }
            },
            location: "div.flexbox.section-2.xlarge-4.small-12 > div:nth-child(4)",
            infoText: "",
            infoButtonText: "",
            template: verticalLandingPage,
            onRender: function($element, data) {
                $element.next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
        q().push(["insertPreview", {
            label: "Article Editor's Pick",
            unit: {
                server: "dfp",
                id: "/319737315/Adweek/native_ads",
                size: "2x2",
                targets: {
                    placement: "editors-pick-article"
                }
            },
            location: "#adw_recommended_posts > div > div > div:nth-child(2) > div > div > div:nth-child(2)",
            infoText: "",
            infoButtonText: "",
            template: articleEditorPick,
            onRender: function($element, data) {
                $element.next().next().next().css("display", "none")
            },
            onFill: function(data) {},
            onError: function(error) {}
        }]);
        q().push(["injectCSS", ".plr-sponsor a { color: #c8c8c8 !important; }", "head"])
    }
    q().push(["configureSecondaryPage", {
        track: function() {
                return "inbound"
            }
        }
    }]);

    function templates() {
        compiledTemplate_gs_sm = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, functionType = "function",

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n                " + escapeExpression((stack1 = (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n            ";
                return buffer
            }

            function program3(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n                Promoted Content by " + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n             ";
                return buffer
            }
            buffer += '<div class="plr-ad-gs">\n<a class ="plr-ad-link-gs" href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '">\n    <h2 class = "plr-ad-title-gs">';
            if (stack1 = helpers.title) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.title;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '</h2>\n    <p class= "plr-ad-disclosure-gs" >\n      ';
            stack2 = helpers["if"].call(depth0, (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), {
                hash: {},
                inverse: self.program(3, program3, data),
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack2 || stack2 === 0) {
                buffer += stack2
            }
            buffer += "   \n    </p>\n  </a>\n</div>";
            return buffer
        };
        compiledTemplate_gs_lg = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing,

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n     " + escapeExpression((stack1 = (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n ";
                return buffer
            }

            function program3(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n     Promoted Content By " + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n ";
                return buffer
            }
            buffer += '<section class="section section--teaser section--teaser_partners  p-0">\n      <div class="section--teaser_partner" style="--aspect-ratio:16/9">                   \n       <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '">\n       <img src="';
            options = {
                hash: {
                    width: 342,
                    height: 197
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '" class="image">\n       </a>                 \n      </div>\n      <div class="section--teaser_info">\n         <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '" class="link-reset">\n            <p class="section__kickerlabel plr-disclosure">  \n          ';
            stack2 = helpers["if"].call(depth0, (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), {
                hash: {},
                inverse: self.program(3, program3, data),
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack2 || stack2 === 0) {
                buffer += stack2
            }
            buffer += '\n              </p>\n         </a>\n         <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '" class="link-reset">\n            <p class="section__title">';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</p>\n         </a>\n         <p class="section__byline"><a class="link-reset" href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">By ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</a> </p>\n      </div>\n   </section>\n\n\n\n\n";
            return buffer
        };
        compiledTemplate_herohome = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing,

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n            " + escapeExpression((stack1 = (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n         ";
                return buffer
            }

            function program3(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n            Promoted Content From " + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n         ";
                return buffer
            }
            buffer += '<div class="postup-adweek-wall-section">\n   <div class="hero hero--overlay container-fluid">\n      <div class="hero__image">\n      <img width="1600" height="680" src="';
            options = {
                hash: {
                    width: 1600
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '" class="attachment-aw-full size-aw-full">\n      </div>\n      <div class="container">\n         <div class="col">\n            <div class="row">\n               <div class="col col-sm-12 show-for-medium hero__featured-header"></div>\n               <div class="col  col-sm-12  hero__text section">\n                  <h1 class="section__label section__label--white">     ';
            stack2 = helpers["if"].call(depth0, (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), {
                hash: {},
                inverse: self.program(3, program3, data),
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack2 || stack2 === 0) {
                buffer += stack2
            }
            buffer += '  </h1>\n                  <p><a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '"></a></p>\n                  <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '" class="link-reset">\n                     <div class="section__text">';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</div>\n                  </a>\n                  <p><a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '"></a></p>\n                  <p class="section__byline"> </p>\n               </div>\n            </div>\n         </div>\n      </div>\n   </div>\n</div>\n\n\n\n';
            return buffer
        };
        compiledTemplate_heroarticle = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing,

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n                " + escapeExpression((stack1 = (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n            ";
                return buffer
            }

            function program3(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n                Promoted Content by " + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n             ";
                return buffer
            }
            buffer += '<div class="interstitial-container plr-ad-hero-a">\n    <div class="plr-image-wrapper-hero-a">\n      <div class="plr-image-hero-a" style="background: url(\'';
            options = {
                hash: {
                    width: "908px"
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '\') no-repeat center center; background-size: cover !important; max-width: 908px; height: 100%; margin: 0 auto; position: relative;">\n          <a class="plr-link-hero-a" href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '"></a>\n                <div class="plr-ad-content-hero-a">\n                  <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">\n                    <p class="plr-ad-disclosure-hero-a">\n                      ';
            stack2 = helpers["if"].call(depth0, (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), {
                hash: {},
                inverse: self.program(3, program3, data),
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack2 || stack2 === 0) {
                buffer += stack2
            }
            buffer += ' \n                    \n                     </p>\n                    <div class="plr-ad-border-hero-a"></div>\n                    <div class="plr-ad-title-hero-a">';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + "</div>\n                </a>\n              </div>\n        </div>\n    </div>\n</div>\n";
            return buffer
        };
        homeNative = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing;
            buffer += '          <div class="aw-element horizontal parent-width plr-home-desktop">\n              <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '" class="horizontal-image" id="dierlam-1-section-1-link-1">\n                  <div class="ar ar-4-3"><img width="640" height="360" src="';
            options = {
                hash: {
                    width: 640,
                    height: 360,
                    autocrop: 1
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '">\n                  </div>\n              </a>\n              <div class="sponsor-bar ">\n                  <h2 class="cat-name plr-disclosure-desk">PROMOTED CONTENT</h2>\n              </div>\n\n              <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '" id="dierlam-1-section-1-link-1">\n                <h2>';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</h2>\n              </a>\n              <p class="plr-sponsor-desk">by ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</p>\n          </div>";
            return buffer
        };
        searchFeed = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing;
            buffer += '<div id="plr" class="post">\n   <div class="archive-image">\n    <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '" class="ar ar-4-3">\n    <img src="';
            options = {
                hash: {
                    width: 300,
                    height: 225
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '">\n    </a>\n   </div>\n   <div class="archive-post">\n      <header>\n         <div class="sponsor-bar">\n            <h2 class="cat-name plr-disclosure">\n               Promoted Content  \n            </h2>\n         </div>\n         <h2 class="entry-title plr-title">\n            <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</a>\n         </h2>\n      </header>\n      <div class="entry-content">\n         ';
            if (stack2 = helpers.summary) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.summary;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '  \n      </div>\n      <footer>\n         <div class="byline plr-byline">\n            <div id="contributor-byline">\n               <div class="contributor">By <span itemprop="name">' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</span></div>\n            </div>\n         </div>\n      </footer>\n   </div>\n   <hr>\n</div>\n\n\n\n";
            return buffer
        };
        adWeekCategory = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing;
            buffer += '<div id="plr" class="post">\n   <div class="archive-image">\n    <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '" class="ar ar-4-3">\n    <img src="';
            options = {
                hash: {
                    width: 300,
                    height: 225
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '">\n    </a>\n   </div>\n   <div class="archive-post">\n      <header>\n         <h2 class="entry-title plr-title">\n            <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</a>\n         </h2>\n      </header>\n      <div class="entry-content">\n         ';
            if (stack2 = helpers.summary) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.summary;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + ' \n      </div>\n      <footer>\n         <div class="byline plr-byline">\n            <div id="contributor-byline">\n               <div class="plr-sponsor-category">Promoted Content from <span itemprop="name">' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</span></div>\n            </div>\n         </div>\n      </footer>\n   </div>\n   <hr>\n</div>\n\n\n\n";
            return buffer
        };
        adWeekGrid = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing;
            buffer += '<div class="aw-element vertical parent-width border-right nobr-s xlarge-3 large-3 medium-6 small-12 nobr-m plr-ad">\n    <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '">\n        <div class="ar ar-16-9">\n         <img width="640" height="360" src="';
            options = {
                hash: {
                    width: 640,
                    height: 360,
                    autrocrop: 1
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '">\n        </div>\n    </a>\n\n    <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">\n     <div class="plr-disc-grid"> PROMOTED CONTENT </div>\n     <h2>';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</h2>\n      <div class="plr-sponsor-grid"> by ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + " </div>\n    </a>\n\n</div>";
            return buffer
        };
        adWeekMulti = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, functionType = "function",

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += '\n      <div class="col-10 col-md-5 col-lg-3">\n         <!-- BEGIN: molecules-teaser-partner-more -->         \n         <section class="section section--teaser section--teaser_partners  p-0">\n            <div class="section--teaser_partner" style="--aspect-ratio:16/9">                    \n            <a href="';
                if (stack1 = helpers.link) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.link;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '">\n              <div class="plr-ad-thumb" style="background: url(\'';
                if (stack1 = helpers.getThumbHref) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.getThumbHref;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '\') no-repeat center center/cover"></div>\n            </a>                  \n            </div>\n            <div class="section--teaser_info">\n               <a href="';
                if (stack1 = helpers.link) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.link;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '" class="link-reset">\n                  <p class="section__title"> ';
                if (stack1 = helpers.title) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.title;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + ' </p>\n               </a>\n               <p class="section__byline"><a class="link-reset" href="';
                if (stack1 = helpers.link) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.link;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '">By ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</a> </p>\n            </div>\n         </section>\n      </div>\n       ";
                return buffer
            }
            buffer += '      \n   <div class="more-stories secton-- container my-5">\n   <div class="row justify-content-around justify-content-md-start">\n      <div class="col-10 col-md-8 col-lg-12 align-left">\n         <header class="section__label"> Promoted Content </header>\n      </div>\n   </div>\n   <div class="row justify-content-center justify-content-lg-start grid-item-container">\n               ';
            stack1 = helpers.each.call(depth0, depth0.creatives, {
                hash: {},
                inverse: self.noop,
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack1 || stack1 === 0) {
                buffer += stack1
            }
            buffer += "\n   </div>\n</div>\n\n\n\n";
            return buffer
        };
        adWeekMultiPartnerExperts = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, functionType = "function",

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += '\n      <div class="col-10 col-md-5 col-lg-3">\n         <!-- BEGIN: molecules-teaser-partner-more -->         \n         <section class="section section--teaser section--teaser_partners  p-0">\n            <div class="section--teaser_partner" style="--aspect-ratio:16/9">                    \n            <a href="';
                if (stack1 = helpers.link) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.link;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '">\n              <div class="plr-ad-thumb" style="background: url(\'';
                if (stack1 = helpers.getThumbHref) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.getThumbHref;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '\') no-repeat center center/cover"></div>\n            </a>                  \n            </div>\n            <div class="section--teaser_info">\n               <a href="';
                if (stack1 = helpers.link) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.link;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '" class="link-reset">\n                  <p class="section__title"> ';
                if (stack1 = helpers.title) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.title;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + ' </p>\n               </a>\n               <p class="section__byline"><a class="link-reset" href="';
                if (stack1 = helpers.link) {
                    stack1 = stack1.call(depth0, {
                        hash: {},
                        data: data
                    })
                } else {
                    stack1 = depth0.link;
                    stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
                }
                buffer += escapeExpression(stack1) + '">By ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</a> </p>\n            </div>\n         </section>\n      </div>\n       ";
                return buffer
            }
            buffer += '      \n   <div class="more-stories secton-- container my-5">\n   <div class="row justify-content-around justify-content-md-start">\n      <div class="col-10 col-md-8 col-lg-12 align-left">\n         <header class="section__label"> Partner Experts </header>\n      </div>\n   </div>\n   <div class="row justify-content-center justify-content-lg-start grid-item-container">\n               ';
            stack1 = helpers.each.call(depth0, depth0.creatives, {
                hash: {},
                inverse: self.noop,
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack1 || stack1 === 0) {
                buffer += stack1
            }
            buffer += "\n   </div>\n</div>\n\n\n\n";
            return buffer
        };
        verticalLandingPage = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing,

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n     " + escapeExpression((stack1 = (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n ";
                return buffer
            }

            function program3(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n     Promoted Content by " + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n ";
                return buffer
            }
            buffer += '<div class="aw-element vertical parent-width xlarge-12 medium-6 plr-container">\n  <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '">\n    <div class="ar ar-16-9"><img width="640" height="360" src="';
            options = {
                hash: {
                    width: 640
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '" class="attachment-aw-text size-aw-text" ></div>\n   </a>\n   <div class="sponsor-bar">\n      <h2 class="cat-name plr-sponsor"><a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">\n          ';
            stack2 = helpers["if"].call(depth0, (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), {
                hash: {},
                inverse: self.program(3, program3, data),
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack2 || stack2 === 0) {
                buffer += stack2
            }
            buffer += '\n        </a>   </h2>\n   </div>\n     <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">\n    <h2 class ="plr-title-gl">';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</h2>\n   </a>\n  <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '" class="contributor">by ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</a>\n</div>\n\n\n\n";
            return buffer
        };
        articleEditorPick = function(Handlebars, depth0, helpers, partials, data) {
            var buffer = "",
                stack1, stack2, options, functionType = "function",
                helperMissing = helpers.helperMissing,

            function program1(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n     " + escapeExpression((stack1 = (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n ";
                return buffer
            }

            function program3(depth0, data) {
                var buffer = "",
                    stack1;
                buffer += "\n     Promoted Content by " + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "\n ";
                return buffer
            }
            buffer += '<div class="aw-element vertical parent-width border-right nobr-s xlarge-3 large-3 medium-6 small-12 nobr-m">\n   <a href="';
            if (stack1 = helpers.link) {
                stack1 = stack1.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack1 = depth0.link;
                stack1 = typeof stack1 === functionType ? stack1.apply(depth0) : stack1
            }
            buffer += escapeExpression(stack1) + '" id="grid-1-link-2">\n      <div class="ar ar-16-9"><img width="640" height="360" src="';
            options = {
                hash: {
                    width: 640
                },
                data: data
            };
            buffer += escapeExpression((stack1 = helpers.getThumbHref || depth0.getThumbHref, stack1 ? stack1.call(depth0, options) : helperMissing.call(depth0, "getThumbHref", options))) + '" class="attachment-aw-text size-aw-text" ></div>\n   </a>\n   <div class="sponsor-bar plr-sponsor ">\n      <h2 class="cat-name"><a href="https://www.adweek.com/category/adfreak/" id="grid-1-link-2-cat">          ';
            stack2 = helpers["if"].call(depth0, (stack1 = depth0.custom, stack1 == null || stack1 === false ? stack1 : stack1.AlternativeLabel), {
                hash: {},
                inverse: self.program(3, program3, data),
                fn: self.program(1, program1, data),
                data: data
            });
            if (stack2 || stack2 === 0) {
                buffer += stack2
            }
            buffer += '</a></h2>\n   </div>\n   <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '">\n      <h2>';
            if (stack2 = helpers.title) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.title;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '</h2>\n   </a>\n   <a href="';
            if (stack2 = helpers.link) {
                stack2 = stack2.call(depth0, {
                    hash: {},
                    data: data
                })
            } else {
                stack2 = depth0.link;
                stack2 = typeof stack2 === functionType ? stack2.apply(depth0) : stack2
            }
            buffer += escapeExpression(stack2) + '" class="contributor" id="grid-1-link-2-author">by ' + escapeExpression((stack1 = (stack1 = depth0.sponsor, stack1 == null || stack1 === false ? stack1 : stack1.name), typeof stack1 === functionType ? stack1.apply(depth0) : stack1)) + "</a>\n</div>\n\n\n\n";
            return buffer
        }
    }
})();
(function() {
    var q = function() {
    };
    q().push(["setPropertyID", "NA-ADWEEKRESPSITE-11238673"]);
    q().push(["configureSecondaryPage", {
        track: function() {
            return "inbound"
        }
    }])
})();
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0],
        p = d.location.protocol;
    if (d.getElementById(id)) {
        return
    }
    js = d.createElement(s);
    js.id = id;
    js.type = "text/javascript";
    js.async = true;
    js.src = (p == "https:" ? p : "http:") + "//plugin.mediavoice.com/plugin.js";
    fjs.parentNode.insertBefore(js, fjs)
})(document, "script", "nativeads-plugin");