(function($) {
    'use strict';

    let recipientId = $('[name="recipient-id"]').attr('value');
    let listId = $('[name="list"]').attr('value');
    let listName = $('[name="list-name"]').attr('value');
    let status = $('[name="status"]').attr('value');
    let pu_single_unsub_button = $('.pu_single_unsubscribe_button');

    pu_single_unsub_button.on('click', function(event) {
        event.preventDefault();

        if (status === 'NORMAL' || status === 'N') {

            $(this).text('Updating...');

            var data = {
                'action': 'pu_single_unsubscribe',
                'recipient-id': recipientId,
                'list-name': listName,
                'list': listId,
                'nonce': recipientId.nonce
            };

                if (response.success) {
                    $('.thanks').css({
                        display: 'block',
                    });

                    $('.review-preferences-message').css({
                        display: 'block',
                    });

                    pu_single_unsub_button.text('Submit');
                    pu_single_unsub_button.attr('disabled', true);
                }
            });

        } else if (status === 'UNSUB') {
            $(this).text('Submit')

            $('.nochange').css({
                display: 'block',
            });

            $('.review-preferences-message').css({
                display: 'block',
            });

        } else {
            $(this).text('Submit')

            $('.error').css({
                display: 'block',
            });

            $('.review-preferences-message').css({
                display: 'block',
            });
        }

    });

})(jQuery);