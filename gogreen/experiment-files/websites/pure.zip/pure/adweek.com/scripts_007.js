! function(a) {
    a(document).ready(function() {
        function n() {
            if (a.get("rdt") && a.get("rdt").length > 0) {
                var n = a.get("rdt");
                return getParameterByName("source") && (n = n + "&source=" + getParameterByName("source")), n
            }
        }

        function e() {
            a('#form-magic-link input[name="rdt_url"]').length > 0 && a('#form-magic-link input[name="rdt_url"]').val(n())
        }
        e()
    })
}(jQuery),
function(a) {
    a(document).ready(function() {
        function n() {
            function n(a) {
                var n = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
                return n.test(a)
            }

            function e() {
                var e = i;
                return i.text(""), n(t.val()) ? a("#magic-link-submit-btn").removeClass("disable") : (e.text("Please enter a valid email"), e.css({
                    color: "red"
                }), a("#magic-link-submit-btn").addClass("disable")), !1
            }
            var t = a("#email"),
                i = a(".ml-form-feedback"),
                r = '<div class="la-ball-pulse la-dark la-sm"><div></div><div></div><div></div></div>',
                o = 200,
                s = [10, 0];
            t.on("change", function() {
                    targets: ".ml-form-feedback",
                    translateY: s,
                    duration: o,
                    easing: "easeOutQuad"
                })
            }), a("#form-magic-link").ajaxForm({
                success: function(n) {
                        targets: ".magic-link-success",
                        translateY: s,
                        duration: o,
                        easing: "easeOutQuad"
                    })
                },
                error: function(a) {
                },
                resetForm: !0
            }), a("#form-magic-link").submit(function() {
                return !1
            }), a("#magic-link-submit-btn").on("click", function() {
                0 === t.val().length ? (i.text("Please enter a valid email"), i.css({
                    "margin-bottom": "1em"
                    targets: ".during-ml-submission",
                    translateY: s,
                    duration: o,
                    easing: "easeOutQuad"
                }), anime({
                    targets: ".before-ml-submission",
                    duration: o,
                    delay: 1e3,
                    opacity: [1, .5]
                })))
            })
        }
        n()
    })
}(jQuery);