jQuery(document).ready(function($) {
                var s = r.lastIndexOf(t, e);
                return -1 !== s && s === e
        $(t).each(function(t) {
            var e = jQuery(this),
                r = e.attr("id"),
                s = e.attr("class"),
                i = e.attr("src");
            i.endsWith("svg") && $.get(i, function(i) {
                var n = $(i).find("svg"),
                    a = n.attr("id");
                void 0 === r ? void 0 === a ? (r = "svg-replaced-" + t, n = n.attr("id", r)) : r = a : n = n.attr("id", r), void 0 !== s && (n = n.attr("class", s + " replaced-svg svg-replaced-" + t)), n = n.removeAttr("xmlns:a"), e.replaceWith(n), $(document).trigger("svg.loaded", [r])
            }, "xml")
        })
    })()
});