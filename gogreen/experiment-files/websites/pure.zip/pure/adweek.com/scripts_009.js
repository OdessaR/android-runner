"use strict";

function _toConsumableArray(e) {
    if (Array.isArray(e)) {
        for (var n = 0, o = Array(e.length); n < e.length; n++) o[n] = e[n];
        return o
    }
    return Array.from(e)
}
window.fbAsyncInit = function() {
            appId: "557217331729194",
            autoLogAppEvents: !0,
            xfbml: !0,
            version: "v4.0"
        })
    },
    function(e) {
        e(document).ready(function() {
            function n(e, n, o, t) {
            }

            function o(e, n, o, t) {
            }

            function t() {}

            function i() {}
            var a, r, s, c, l;
            if (e("article").length > 0) {
                var g = function() {
                    },
                    d = e("article").attr("data-title");
            }
            var w = encodeURIComponent(c),
                h = encodeURIComponent(s),
                u = encodeURIComponent("I thought you would be interested in this from Adweek.com...\n\n" + s + ":\n" + c);
            e("#share-on-facebook").on("click", function(e) {
                    method: "share",
                    href: c
                }, function(e) {})
            }), e("#share-on-twitter").on("click", function(e) {
                e.preventDefault();
                var o = "https://twitter.com/intent/tweet?original_referer=" + w + "&text=" + h + "&url=" + w + "&via=Adweek";
                n(o, "Share on Twitter", 700, 650)
            }), e("#share-on-linkedin").on("click", function(e) {
                e.preventDefault();
                var n = "https://www.linkedin.com/shareArticle";
                n += "?mini=true", n += "&url=" + w, n += "&title=" + h, n += "&source=Adweek";
                var t = "Share on LinkedIn";
                o(n, t, 700, 650)
            }), awIsMobile() ? e("#share-on-messenger").show() : e("#share-on-messenger").remove(), e("#share-on-messenger").on("click", function(e) {
            var m;
                p = [].concat(_toConsumableArray(p)), p = p.map(function(e) {
                    return e.innerText
                }), p = p.toString(), p = p.replace(",", ", "), m = encodeURIComponent(p)
            var f = e("#print-friendly");
            if (e(window).on("load", function() {
                var v = function() {
                    return e("#share-toggle-open-icon").hasClass("social-inactive") ? (e(".aw-social-share-icon").show(), void anime({
                        targets: ".aw-social-share-icon",
                        opacity: [0, 1],
                        translateX: ["-10px", "0px"],
                        duration: 1e3,
                        begin: function(n) {
                            anime({
                                targets: "#share-toggle-open-icon img",
                                rotate: ["0", "25"],
                                scale: ["1", ".5"],
                                opacity: [1, 0],
                                duration: 500,
                                complete: function(n) {
                                        targets: "#share-toggle-open-icon img",
                                        rotate: ["-25", "0"],
                                        scale: [".5", "1"],
                                        opacity: [0, 1],
                                        duration: 500
                                    })
                                }
                            })
                        },
                        complete: function(n) {
                            e("#share-toggle-open-icon").addClass("social-active").removeClass("social-inactive")
                        }
                    })) : e("#share-toggle-open-icon").hasClass("social-active") ? void anime({
                        targets: ".aw-social-share-icon",
                        opacity: [1, 0],
                        translateX: ["0px", "-10px"],
                        duration: 1e3,
                        begin: function(n) {
                            anime({
                                targets: "#share-toggle-open-icon img",
                                rotate: ["0", "25"],
                                opacity: [1, 0],
                                scale: ["1", ".5"],
                                duration: 500,
                                complete: function(n) {
                                        targets: "#share-toggle-open-icon img",
                                        rotate: ["-25", "0"],
                                        scale: [".5", "1"],
                                        opacity: [0, 1],
                                        duration: 500
                                    })
                                }
                            })
                        },
                        complete: function(n) {
                            e("#share-toggle-open-icon").addClass("social-inactive").removeClass("social-active")
                        }
                    }) : void 0
                };
                    order: 1
                    targets: "#share-toggle-open-icon",
                    opacity: [0, 1],
                    duration: 1e3,
                    delay: 4e3
                })) : (e(".aw-social-share-icon").show(), anime({
                    targets: ".aw-social-share-icon, #share-toggle-open-icon",
                    opacity: [0, 1],
                    duration: 1e3,
                    delay: 4e3
                })), e("#share-toggle-open-icon").on("click", function(e) {
                    v()
                })
            } else e("#share-toggle-open-icon").hide(), e(".aw-social-share-icon").show(), awIsMobile() && f.remove();
            if (e(window).resize(function() {
                    var n = e(window).width();
                    r = !(n >= 700), a = function() {
                        r ? r && t() : i(), awIsMobile() && f.remove()
                    }, setTimeout(a, "1000")
                var y = function(n) {
                        n.forEach(function(n) {
                            n.intersectionRatio > 0 && e("#aw-social-share-id").fadeIn("slow"), 0 == n.intersectionRatio && e("#aw-social-share-id").fadeOut("slow")
                        })
                    },
                    b = {
                        root: null,
                        rootMargin: "-10% 0% 200px 0%",
                        threshold: [0, 1]
                    },
                I.observe(_)
            }
        })
    }(jQuery);