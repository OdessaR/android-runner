! function(e) {
    var n;
        o.noConflict = function() {
        }
    }
}(function() {
    function f() {
        for (var e = 0, n = {}; e < arguments.length; e++) {
            var t = arguments[e];
            for (var o in t) n[o] = t[o]
        }
        return n
    }

    function a(e) {
        return e.replace(/(%[0-9A-Z]{2})+/g, decodeURIComponent)
    }
    return function e(u) {
        function c() {}

        function t(e, n, t) {
                    path: "/"
                try {
                    var o = JSON.stringify(n);
                } catch (e) {}
                var r = "";
                for (var i in t) t[i] && (r += "; " + i, !0 !== t[i] && (r += "=" + t[i].split(";")[0]));
            }
        }

        function n(e, n) {
                    var i = o[r].split("="),
                        c = i.slice(1).join("=");
                    n || '"' !== c.charAt(0) || (c = c.slice(1, -1));
                    try {
                        var f = a(i[0]);
                        if (c = (u.read || u)(c, f) || a(c), n) try {
                            c = JSON.parse(c)
                        } catch (e) {}
                        if (t[f] = c, e === f) break
                    } catch (e) {}
                }
                return e ? t[e] : t
            }
        }
            return n(e, !1)
            return n(e, !0)
            t(e, "", f(n, {
                expires: -1
            }))
    }(function() {})
});