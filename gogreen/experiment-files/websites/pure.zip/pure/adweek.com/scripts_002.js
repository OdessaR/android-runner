"use strict";
! function(i) {
    var t = i(".aw-site-notification");
    t.each(function() {
        var t = i(this),
            e = t.data("site-notification-id"),
        s && "dismissed" === s || t.removeClass("hide")
    }), i(".aw-site-notification-close-btn").on("click", function(t) {
        t.preventDefault();
        var e = i(this),
            s = e.parents(".aw-site-notification"),
            a = s.data("site-notification-id");
    })
}(jQuery);