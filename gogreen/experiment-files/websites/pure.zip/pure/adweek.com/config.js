(function(w) {
    var lyticsId = "abdd09476411aa251d907649c25e11e9",
        widgetConfig;
    widgetConfig = w.pathfora.utils.initWidgetScaffold();
    var pfaVariations = [];
    var acctConfig = {};
    if (pfaVariations.length) {
        w.pathfora.initializeABTesting(pfaVariations);
    }
    w.pathfora.initializeWidgets(widgetConfig, acctConfig);
}(window));