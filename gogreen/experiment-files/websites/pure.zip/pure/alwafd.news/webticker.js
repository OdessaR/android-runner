/*!
 * webTicker 2.2.0
 * Examples and documentation at:
 * http://jonmifsud.com/open-source/jquery/jquery-webticker/
 * 2011 Jonathan Mifsud
 * Version: 2.2.0 (15-FEB-2016)
 * Dual licensed under the Creative Commons and DonationWare licenses:
 * http://creativecommons.org/licenses/by-nc/3.0/
 * https://github.com/jonmifsud/Web-Ticker/blob/master/licence.md
 * Requires:
 * jQuery v1.4.2 or later
 *
 */
(function($) {
    var cssTransitionsSupported = (function() {
            v = ['ms', 'O', 'Moz', 'Webkit'];
        if (s.transition === '') {
            return true;
        }
        while (v.length) {
            if (v.pop() + 'Transition' in s) {
                return true;
            }
        }
        return false;
    })();

    function getStripWidth($strip) {
        var stripWidth = 0;
        $strip.children('li').each(function() {
            stripWidth += $(this).outerWidth(true);
        });
        return stripWidth;
    }

    function getItemWidth($strip) {
        return Math.max.apply(Math, $strip.children().map(function() {
            return $(this).width();
        }).get());
    }

    function animationSettings($strip) {
        var settings = $strip.data('settings') || {
            direction: 'left',
            speed: 50
        };
        var first = $strip.children().first();
        var distance = Math.abs(-$strip.css(settings.direction).replace('px', '').replace('auto', '0') - first.outerWidth(true));
        var timeToComplete = distance * 1000 / settings.speed;
        var animationSettings = {};
        animationSettings[settings.direction] = $strip.css(settings.direction).replace('px', '').replace('auto', '0') - distance;
        return {
            'css': animationSettings,
            'time': timeToComplete
        };
    }

    function moveFirstElement($strip) {
        var settings = $strip.data('settings') || {
            direction: 'left'
        };
        $strip.css('transition-duration', '0s').css(settings.direction, '0');
        var $first = $strip.children().first();
        if ($first.hasClass('webticker-init')) {
            $first.remove();
        } else {
            $strip.children().last().after($first);
        }
    }

    function scrollitems($strip, moveFirst) {
        var settings = $strip.data('settings') || {
            direction: 'left'
        };
        if (typeof moveFirst === 'undefined') {
        }
        if (moveFirst) {
            moveFirstElement($strip);
        }
        var options = animationSettings($strip);
        $strip.animate(options.css, options.time, 'linear', function() {
            $strip.css(settings.direction, '0');
            scrollitems($strip, true);
        });
    }

    function css3Scroll($strip, moveFirst) {
        if (typeof moveFirst === 'undefined') {
        }
        if (moveFirst) {
            moveFirstElement($strip);
        }
        var options = animationSettings($strip);
        var time = options.time / 1000;
        time += 's';
        $strip.css(options.css).css('transition-duration', time);
    }

    function updaterss(rssurl, type, $strip) {
        var list = [];
        $.get(rssurl, function(data) {
            var $xml = $(data);
            $xml.find('item').each(function() {
                var $this = $(this),
                    item = {
                        title: $this.find('title').text(),
                        link: $this.find('link').text()
                    };
                var listItem = '<li><a href="' + item.link + '"">' + item.title + '</a></li>';
                list += listItem;
            });
            $strip.webTicker('update', list, type);
        });
    }

    function initialize($strip, init) {
        if ($strip.children('li').length < 1) {
            return false;
        }
        var settings = $strip.data('settings');
        settings.duplicateLoops = settings.duplicateLoops || 0;
        $strip.width('auto');
        var stripWidth = 0;
        $strip.children('li').each(function() {
            stripWidth += $(this).outerWidth(true);
        });
        var height = $strip.find('li:first').height();
        var itemWidth;
        if (settings.duplicate) {
            itemWidth = getItemWidth($strip);
            var duplicateLoops = 0;
            while (stripWidth - itemWidth < $strip.parent().width() || $strip.children().length === 1 || duplicateLoops < settings.duplicateLoops) {
                var listItems = $strip.children().clone();
                $strip.append(listItems);
                stripWidth = 0;
                stripWidth = getStripWidth($strip);
                itemWidth = getItemWidth($strip);
                duplicateLoops++;
            }
            settings.duplicateLoops = duplicateLoops;
        } else {
            var emptySpace = $strip.parent().width() - stripWidth;
            emptySpace += $strip.find('li:first').width();
            if ($strip.find('.ticker-spacer').length > 0) {
                $strip.find('.ticker-spacer').width(emptySpace);
            } else {
                $strip.append('<li class="ticker-spacer" style="float: ' + settings.direction + ';width:' + emptySpace + 'px;height:' + height + 'px;"></li>');
            }
        }
        if (settings.startEmpty && init) {
            $strip.prepend('<li class="webticker-init" style="float: ' + settings.direction + ';width:' + $strip.parent().width() + 'px;height:' + height + 'px;"></li>');
        }
        stripWidth = 0;
        stripWidth = getStripWidth($strip);
        $strip.width(stripWidth + 200);
        var widthCompare = 0;
        widthCompare = getStripWidth($strip);
        while (widthCompare >= $strip.width()) {
            $strip.width($strip.width() + 200);
            widthCompare = 0;
            widthCompare = getStripWidth($strip);
        }
        return true;
    }
    var methods = {
        init: function(settings) {
                speed: 50,
                direction: 'left',
                moving: true,
                startEmpty: true,
                duplicate: false,
                rssurl: false,
                hoverpause: true,
                rssfrequency: 0,
                updatetype: 'reset',
                transition: 'linear',
                height: '30px',
                maskleft: '',
                maskright: '',
                maskwidth: 0
            }, settings);
                jQuery(this).data('settings', settings);
                var $strip = jQuery(this);
                var $mask = $strip.wrap('<div class="mask"></div>');
                $mask.after('<span class="tickeroverlay-left">&nbsp;</span><span class="tickeroverlay-right">&nbsp;</span>');
                var $tickercontainer = $strip.parent().wrap('<div class="tickercontainer"></div>');
                var resizeEvt;
                $(window).resize(function() {
                    clearTimeout(resizeEvt);
                    resizeEvt = setTimeout(function() {
                        initialize($strip, false);
                    }, 500);
                });
                $strip.children('li').css('white-space', 'nowrap');
                $strip.children('li').css('float', settings.direction);
                $strip.children('li').css('padding', '0 7px');
                $strip.children('li').css('line-height', settings.height);
                $mask.css('position', 'relative');
                $mask.css('overflow', 'hidden');
                $strip.closest('.tickercontainer').css('height', settings.height);
                $strip.closest('.tickercontainer').css('overflow', 'hidden');
                $strip.css('float', settings.direction);
                $strip.css('position', 'relative');
                $strip.css('font', 'bold 10px Verdana');
                $strip.css('list-style-type', 'none');
                $strip.css('margin', '0');
                $strip.css('padding', '0');
                if ((settings.maskleft !== '') && (settings.maskright !== '')) {
                    var backgroundimage = 'url("' + settings.maskleft + '")';
                    $tickercontainer.find('.tickeroverlay-left').css('background-image', backgroundimage);
                    $tickercontainer.find('.tickeroverlay-left').css('display', 'block');
                    $tickercontainer.find('.tickeroverlay-left').css('pointer-events', 'none');
                    $tickercontainer.find('.tickeroverlay-left').css('position', 'absolute');
                    $tickercontainer.find('.tickeroverlay-left').css('z-index', '30');
                    $tickercontainer.find('.tickeroverlay-left').css('height', settings.height);
                    $tickercontainer.find('.tickeroverlay-left').css('width', settings.maskwidth);
                    $tickercontainer.find('.tickeroverlay-left').css('top', '0');
                    $tickercontainer.find('.tickeroverlay-left').css('left', '-2px');
                    backgroundimage = 'url("' + settings.maskright + '")';
                    $tickercontainer.find('.tickeroverlay-right').css('background-image', backgroundimage);
                    $tickercontainer.find('.tickeroverlay-right').css('display', 'block');
                    $tickercontainer.find('.tickeroverlay-right').css('pointer-events', 'none');
                    $tickercontainer.find('.tickeroverlay-right').css('position', 'absolute');
                    $tickercontainer.find('.tickeroverlay-right').css('z-index', '30');
                    $tickercontainer.find('.tickeroverlay-right').css('height', settings.height);
                    $tickercontainer.find('.tickeroverlay-right').css('width', settings.maskwidth);
                    $tickercontainer.find('.tickeroverlay-right').css('top', '0');
                    $tickercontainer.find('.tickeroverlay-right').css('right', '-2px');
                } else {
                    $tickercontainer.find('.tickeroverlay-left').css('display', 'none');
                    $tickercontainer.find('.tickeroverlay-right').css('display', 'none');
                }
                $strip.children('li').last().addClass('last');
                var started = initialize($strip, true);
                if (settings.rssurl) {
                    updaterss(settings.rssurl, settings.type, $strip);
                    if (settings.rssfrequency > 0) {
                            updaterss(settings.rssurl, settings.type, $strip);
                        }, settings.rssfrequency * 1000 * 60);
                    }
                }
                if (cssTransitionsSupported) {
                    $strip.css('transition-timing-function', settings.transition);
                    $strip.css('transition-duration', '0s').css(settings.direction, '0');
                    if (started) {
                        css3Scroll($strip, false);
                    }
                    $strip.on('transitionend webkitTransitionEnd oTransitionEnd otransitionend', function(event) {
                        if (!$strip.is(event.target)) {
                            return false;
                        }
                        css3Scroll($(this), true);
                    });
                } else {
                    if (started) {
                        scrollitems($(this));
                    }
                }
                if (settings.hoverpause) {
                    $strip.hover(function() {
                        if (cssTransitionsSupported) {
                            var currentPosition = $(this).css(settings.direction);
                            $(this).css('transition-duration', '0s').css(settings.direction, currentPosition);
                        } else {
                            jQuery(this).stop();
                        }
                    }, function() {
                        if (jQuery(this).data('settings').moving) {
                            if (cssTransitionsSupported) {
                                css3Scroll($(this), false);
                            } else {
                                scrollitems($strip);
                            }
                        }
                    });
                }
            });
        },
        stop: function() {
            var settings = $(this).data('settings');
            if (settings.moving) {
                settings.moving = false;
                    if (cssTransitionsSupported) {
                        var currentPosition = $(this).css(settings.direction);
                        $(this).css('transition-duration', '0s').css(settings.direction, currentPosition);
                    } else {
                        $(this).stop();
                    }
                });
            }
        },
        cont: function() {
            var settings = $(this).data('settings');
            if (!settings.moving) {
                settings.moving = true;
                    if (cssTransitionsSupported) {
                        css3Scroll($(this), false);
                    } else {
                        scrollitems($(this));
                    }
                });
            }
        },
        transition: function(transition) {
            var $strip = $(this);
            if (cssTransitionsSupported) {
                $strip.css('transition-timing-function', transition);
            }
        },
        update: function(list, type, insert, remove) {
            if (typeof insert === 'undefined') {
            }
            if (typeof remove === 'undefined') {
            }
            if (typeof list === 'string') {
            }
            var $strip = $(this);
            $strip.webTicker('stop');
            var settings = $(this).data('settings');
            if (type === 'reset') {
                $strip.html(list);
                initialize($strip, true);
            } else if (type === 'swap') {
                var id;
                var match;
                var $listItem;
                var stripWidth;
                if ($strip.children('li').length < 1) {
                    $strip.html(list);
                    $strip.css(settings.direction, '0');
                    initialize($strip, true);
                } else if (settings.duplicate === true) {
                    $strip.children('li').addClass('old');
                    for (var i = list.length - 1; i >= 0; i--) {
                        id = $(list[i]).data('update');
                        match = $strip.find('[data-update="' + id + '"]');
                        if (match.length < 1) {
                            if (insert) {
                                if ($strip.find('.ticker-spacer:first-child').length === 0 && $strip.find('.ticker-spacer').length > 0) {
                                    $strip.children('li.ticker-spacer').before(list[i]);
                                } else {
                                    $listItem = $(list[i]);
                                    if (i === list.length - 1) {
                                        $listItem.addClass('last');
                                    }
                                    $strip.find('last').after($listItem);
                                    $strip.find('last').removeClass('last');
                                }
                            }
                        } else {
                            $strip.find('[data-update="' + id + '"]').replaceWith(list[i]);
                        }
                    }
                    $strip.children('li.webticker-init, li.ticker-spacer').removeClass('old');
                    if (remove) {
                        $strip.children('li').remove('.old');
                    }
                    stripWidth = 0;
                    stripWidth = getStripWidth($strip);
                    $strip.width(stripWidth + 200);
                    if ($strip.find('li.webticker-init').length < 1) {
                        settings.startEmpty = false;
                    }
                    $strip.html(list);
                    $strip.children('li').css('white-space', 'nowrap');
                    $strip.children('li').css('float', settings.direction);
                    $strip.children('li').css('padding', '0 7px');
                    $strip.children('li').css('line-height', settings.height);
                    initialize($strip, true);
                } else {
                    $strip.children('li').addClass('old');
                    for (var x = 0; x < list.length; x++) {
                        id = $(list[x]).data('update');
                        match = $strip.find('[data-update="' + id + '"]');
                        if (match.length < 1) {
                            if (insert) {
                                if ($strip.find('.ticker-spacer:first-child').length === 0 && $strip.find('.ticker-spacer').length > 0) {
                                    $strip.children('li.ticker-spacer').before(list[x]);
                                } else {
                                    $listItem = $(list[x]);
                                    if (x === list.length - 1) {
                                        $listItem.addClass('last');
                                    }
                                    $strip.find('.old.last').after($listItem);
                                    $strip.find('.old.last').removeClass('last');
                                }
                            }
                        } else {
                            $strip.find('[data-update="' + id + '"]').replaceWith(list[x]);
                        }
                    }
                    $strip.children('li.webticker-init, li.ticker-spacer').removeClass('old');
                    $strip.children('li').css('white-space', 'nowrap');
                    $strip.children('li').css('float', settings.direction);
                    $strip.children('li').css('padding', '0 7px');
                    $strip.children('li').css('line-height', settings.height);
                    if (remove) {
                        $strip.children('li').remove('.old');
                    }
                    stripWidth = 0;
                    stripWidth = getStripWidth($strip);
                    $strip.width(stripWidth + 200);
                }
            }
            $strip.webTicker('cont');
        }
    };
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method ' + method + ' does not exist on jQuery.webTicker');
        }
    };
})(jQuery);