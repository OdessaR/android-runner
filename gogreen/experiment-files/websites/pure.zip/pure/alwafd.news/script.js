/*! Copyright (c) 2011 Brandon Aaron (http://brandonaaron.net)
 * Licensed under the MIT License (LICENSE.txt).
 *
 * Thanks to: http://adomas.org/javascript-mouse-wheel/ for some pointers.
 * Thanks to: Mathias Bank(http://www.mathias-bank.de) for a scope bug fix.
 * Thanks to: Seamus Leahy for adding deltaX and deltaY
 *
 * Version: 3.0.6
 *
 * Requires: 1.2.2+
 */
(function($) {
    var types = ['DOMMouseScroll', 'mousewheel'];
    if ($.event.fixHooks) {
        for (var i = types.length; i;) {
        }
    }
        setup: function() {
                for (var i = types.length; i;) {
                }
            } else {
            }
        },
        teardown: function() {
                for (var i = types.length; i;) {
                }
            } else {
            }
        }
    };
    $.fn.extend({
        mousewheel: function(fn) {
        },
        unmousewheel: function(fn) {
        }
    });

    function handler(event) {
            args = [].slice.call(arguments, 1),
            delta = 0,
            returnValue = true,
            deltaX = 0,
            deltaY = 0;
        if (orgEvent.wheelDelta) {
            delta = orgEvent.wheelDelta / 120;
        }
        if (orgEvent.detail) {
            delta = -orgEvent.detail / 3;
        }
        deltaY = delta;
        if (orgEvent.axis !== undefined && orgEvent.axis === orgEvent.HORIZONTAL_AXIS) {
            deltaY = 0;
            deltaX = -1 * delta;
        }
        if (orgEvent.wheelDeltaY !== undefined) {
            deltaY = orgEvent.wheelDeltaY / 120;
        }
        if (orgEvent.wheelDeltaX !== undefined) {
            deltaX = -1 * orgEvent.wheelDeltaX / 120;
        }
        args.unshift(event, delta, deltaX, deltaY);
        return ($.event.dispatch || $.event.handle).apply(this, args);
    }
})(jQuery);
(function($) {
        });
    }
            direction: '',
            mainItemSelector: 'li',
            navInnerSelector: 'ul',
            navSelector: 'li',
            navigatorEvent: 'click',
            wapperSelector: '.sliders-wrap-inner',
            interval: 5000,
            auto: false,
            maxItemDisplay: 3,
            startItem: 0,
            navPosition: 'vertical',
            navigatorHeight: 100,
            navigatorWidth: 310,
            duration: 600,
            navItemsSelector: '.navigator-wrap-inner li',
            navOuterSelector: '.navigator-wrapper',
            isPreloaded: false,
            easing: 'easeInOutQuad',
            onPlaySlider: function(obj, slider) {},
            onComplete: function(slider, index) {},
            rtl: false
        }
        }
        }
        } else {
        }
                'opacity': 0,
                'z-index': 1
                'opacity': 1,
                'z-index': 3
            });
        } else {
                });
            else
                });
        }
        } else {
        }
        } else {
        }
        $(obj).hover(function() {
            self.stop();
        }, function() {
                if (self.settings.auto) {
                    self.play(self.settings.interval, 'next', true);
                }
            }
        });
                self.settings.auto = true;
                self.play(self.settings.interval, 'next', true);
            } else {
                self.settings.auto = false;
                self.stop();
            }
        });
    }
    $.lofSidernews.fn.extend({
        startUp: function(obj, wrapper) {
                }));
                $(item).css({
                });
            })
            }
        },
        onComplete: function() {
            setTimeout(function() {
                $('.preload').fadeOut(900, function() {
                    $('.preload').remove();
                });
            }, 400);
        },
        preLoadImage: function(callback) {
            var count = 0;
            images.each(function(index, image) {
                if (!image.complete) {
                        count++;
                        if (count >= images.length) {
                            self.onComplete();
                        }
                    }
                        count++;
                        if (count >= images.length) {
                            self.onComplete();
                        }
                    }
                } else {
                    count++;
                    if (count >= images.length) {
                        self.onComplete();
                    }
                }
            });
        },
        navivationAnimate: function(currentIndex) {
                }
            }
                duration: 500,
                easing: 'easeInOutQuad'
            });
        },
        setNavActive: function(index, item) {
            }
        },
        __getPositionMode: function(position) {
            if (position == 'horizontal') {
                else
            }
        },
        __getDirectionMode: function() {
                case 'opacity':
                    return ['opacity', 'opacity'];
                default:
                        return ['right', 'width'];
                    else
                        return ['left', 'width'];
            }
        },
        registerWheelHandler: function(element, obj) {
            element.bind('mousewheel', function(event, delta) {
                var dir = delta > 0 ? 'Up' : 'Down',
                    vel = Math.abs(delta);
                if (delta > 0) {
                    obj.previous(true);
                } else {
                    obj.next(true);
                }
                return false;
            });
        },
        registerButtonsControl: function(eventHandler, objects, self) {
            for (var action in objects) {
                switch (action.toString()) {
                    case 'next':
                        objects[action].click(function() {
                            self.next(true)
                        });
                        break;
                    case 'previous':
                        objects[action].click(function() {
                            self.previous(true)
                        });
                        break;
                }
            }
        },
        onProcessing: function(manual, start, end) {
        },
        finishFx: function(manual) {
            }
        },
        getObjectDirection: function(start, end) {
        },
        fxStart: function(index, obj, currentObj) {
                    opacity: 0
                }, {
                    complete: function() {
                        s.slides.css("z-index", "1")
                        s.slides.eq(index).css("z-index", "3");
                    }
                });
                    opacity: 1
                }, {
                    complete: function() {
                        s.settings.onComplete($(s.slides).eq(index), index);
                    }
                });
            } else {
                    complete: function() {
                        s.settings.onComplete($(s.slides).eq(index), index)
                    }
                });
            }
        },
        jumping: function(no, manual) {
        },
        next: function(manual, item) {
        },
        previous: function(manual, item) {
        },
        play: function(delay, direction, wait) {
            if (!wait) {
            }
                self[direction](true);
            }, delay);
        },
        stop: function() {
        }
    })
})(jQuery)