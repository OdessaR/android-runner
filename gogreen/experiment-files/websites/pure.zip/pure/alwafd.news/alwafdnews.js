var TWAGORAINARTICLE = TWAGORAINARTICLE || function() {

    var getHTScriptElement = function() {
        var hTClass = 'pa-ht-class';
        else {

            var currentHTag = 'pahtag.tech/c/alwafdnews.js';
            var sl = scripts.length;
            for (var s = 0; s < sl; s++) {
                if ((scripts[s].src.indexOf(currentHTag) !== -1) && !scripts[s].classList.contains(hTClass)) {
                    scripts[s].classList.add(hTClass);
                    break;
                }
            }

            return scripts[s];
        }
    }

    var getQueryString = function(script) {
        var queryString = script.src.replace(/^[^\?]+\??/, '');
        return '?' + queryString;
    }

    var getParameterByName = function(name, url) {
        var regex = new RegExp('[?&]' + name + '(=([^&#]*)|&|#|$)'),
            results = regex.exec(url);
        if (!results) return null;
        if (!results[2]) return '';
        try {
            return decodeURIComponent(results[2].replace(/\+/g, ' '));
            return null;
        }
    }

    var getPartnerSCOfromHTUrl = function(currentScript) {
        var schain = null;
        var currentHTScript = currentScript;
        var qS = getQueryString(currentHTScript);
        if (qS) schain = getParameterByName('schain', qS);

        return schain;

    }


    var config = {
        "site_name": "alwafdnews",
        "rules": [{
            "name": "inarticle pages desktop",
            "priority": 3,
            "type": "Magic",
            "product": {
                "magic": {
                    "enabled": true,
                    "formats": {
                        "inarticle": {
                            "pmp": {
                                "paragraphLimit": 2,
                                "placementId": "19147696",
                                "probability": 5,
                                "tagNames": ["p"],
                                "selectorType": "querySelector",
                                "selectorName": "div.blog.article",
                                "isLight": true,
                                "flipQuizEnabled": true
                            },
                            "direct": {
                                "paragraphLimit": 4,
                                "placementId": "",
                                "probability": 0,
                                "tagNames": ["p"],
                                "selectorType": "class",
                                "selectorName": ""
                            }
                        },
                        "vast": {
                            "pmp": {
                                "paragraphLimit": 2,
                                "placementId": "19147612,\/\/ads.stickyadstv.com\/vast\/vpaid-adapter\/11535681,\/\/adx.adform.net\/adx\/?mid=839024&t=2,\/\/www8.smartadserver.com\/ac?siteid=339447&pgid=1290915&fmtid=47614&ab=1&tgt=&oc=1&out=vast3&ps=1&pb=0&visit=S&vcn=s&tmstp=[timestamp]&pgdomain=%%PA_PAGE_URL%%&vpw=PA_width&vph=PA_height&gdpr=&gdpr_consent=",
                                "probability": 95,
                                "tagNames": ["p"],
                                "selectorType": "querySelector",
                                "selectorName": "div.blog.article"
                            },
                            "direct": {
                                "paragraphLimit": 4,
                                "placementId": "",
                                "probability": 0,
                                "tagNames": ["p"],
                                "selectorType": "class",
                                "selectorName": ""
                            }
                        }
                    },
                    "rulePassback": "<script async src=\"https:\/\/securepubads.g.doubleclick.net\/tag\/js\/gpt.js\"><\/script><script>  var inArticleSlot = null;  window.googletag = window.googletag || {cmd: []};  googletag.cmd.push(function() {    inArticleSlot = googletag.defineSlot('\/1025510\/19147612_alwafd.news_inarticle_300x250', [[640, 480], [300, 250], [720, 300], [336, 280], [640, 360]], 'div-gpt-ad-1591959262617-0').addService(googletag.pubads()).setCollapseEmptyDiv(true,true);    googletag.pubads().enableSingleRequest();    googletag.enableServices();  });<\/script><!-- \/1025510\/19147612_alwafd.news_inarticle_300x250 --><div id='div-gpt-ad-1591959262617-0'>  <script>    googletag.cmd.push(function() {if (googletag.pubads().isInitialLoadDisabled()) {googletag.pubads().refresh([inArticleSlot]);} else {googletag.display('div-gpt-ad-1591959262617-0');}});  <\/script><\/div>",
                    "adMngrPassback": "<!-- PA Ad Tag - alwafd.news_inarticle-adtag_300x250 <- DO NOT MODIFY --><script src=\"\/\/ads.projectagoraservices.com\/?id=10456\" type=\"text\/javascript\"><\/script><!-- End PA Ad Tag -->"
                }
            },
            "targeting": {
                "device_targeting": "desktop"
            }
        }, {
            "name": "inarticle pages mobile",
            "priority": 3,
            "type": "Magic",
            "product": {
                "magic": {
                    "enabled": true,
                    "formats": {
                        "inarticle": {
                            "pmp": {
                                "paragraphLimit": 2,
                                "placementId": "19147696",
                                "probability": 5,
                                "tagNames": ["p"],
                                "selectorType": "querySelector",
                                "selectorName": "div.blog.article",
                                "isLight": true,
                                "socialCardsEnabled": true,
                                "flipQuizEnabled": true
                            },
                            "direct": {
                                "paragraphLimit": 3,
                                "placementId": "",
                                "probability": 0,
                                "tagNames": ["p"],
                                "selectorType": "class",
                                "selectorName": ""
                            }
                        },
                        "vast": {
                            "pmp": {
                                "paragraphLimit": 2,
                                "placementId": "19147612,\/\/ads.stickyadstv.com\/vast\/vpaid-adapter\/11535681,\/\/adx.adform.net\/adx\/?mid=839024&t=2,\/\/www8.smartadserver.com\/ac?siteid=339447&pgid=1290915&fmtid=47614&ab=1&tgt=&oc=1&out=vast3&ps=1&pb=0&visit=S&vcn=s&tmstp=[timestamp]&pgdomain=%%PA_PAGE_URL%%&vpw=PA_width&vph=PA_height&gdpr=&gdpr_consent=",
                                "probability": 95,
                                "tagNames": ["p"],
                                "selectorType": "querySelector",
                                "selectorName": "div.blog.article",
                                "viewability": {
                                    "enabled": true
                                }
                            },
                            "direct": {
                                "paragraphLimit": 3,
                                "placementId": "",
                                "probability": 0,
                                "tagNames": ["p"],
                                "selectorType": "class",
                                "selectorName": ""
                            }
                        }
                    },
                    "rulePassback": "<script async src=\"https:\/\/securepubads.g.doubleclick.net\/tag\/js\/gpt.js\"><\/script><script>  var inArticleSlot = null;  window.googletag = window.googletag || {cmd: []};  googletag.cmd.push(function() {    inArticleSlot = googletag.defineSlot('\/1025510\/19147612_alwafd.news_inarticle_300x250', [[640, 480], [300, 250], [720, 300], [336, 280], [640, 360]], 'div-gpt-ad-1591959262617-0').addService(googletag.pubads()).setCollapseEmptyDiv(true,true);    googletag.pubads().enableSingleRequest();    googletag.enableServices();  });<\/script><!-- \/1025510\/19147612_alwafd.news_inarticle_300x250 --><div id='div-gpt-ad-1591959262617-0'>  <script>    googletag.cmd.push(function() {if (googletag.pubads().isInitialLoadDisabled()) {googletag.pubads().refresh([inArticleSlot]);} else {googletag.display('div-gpt-ad-1591959262617-0');}});  <\/script><\/div>",
                    "adMngrPassback": "<!-- PA Ad Tag - alwafd.news_inarticle-adtag_300x250 <- DO NOT MODIFY --><script src=\"\/\/ads.projectagoraservices.com\/?id=10456\" type=\"text\/javascript\"><\/script><!-- End PA Ad Tag -->"
                }
            },
            "targeting": {
                "device_targeting": "mobile"
            }
        }],
        "sco": {
            "paSellerId": "100165",
            "paOwns": "Operated Only"
        }
    };

    var currentHTScript = getHTScriptElement();

    return {
        getConfig: function() {
            return config;
        },
        getPartnersSCO: function() {
            return getPartnerSCOfromHTUrl(currentHTScript);
        }
    }

}();

! function(e, t, a) {
    var n, r = e.getElementsByTagName(t)[0];
    e.getElementById("pa-tag") || ((n = e.createElement(t)).id = "pa-tag", n.src = "//praght.tech/libs/projectagora.min.js", r.parentNode.insertBefore(n, r))
}(document, "script");