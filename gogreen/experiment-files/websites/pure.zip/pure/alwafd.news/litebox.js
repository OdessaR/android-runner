;
(function($, window, document, undefined) {
    var pluginName = 'liteBox',
        defaults = {
            revealSpeed: 400,
            background: 'rgba(0,0,0,.8)',
            overlayClose: true,
            escKey: true,
            navKey: true,
            closeTip: 'tip-l-fade',
            closeTipText: 'Close',
            prevTip: 'tip-t-fade',
            prevTipText: 'Previous',
            nextTip: 'tip-t-fade',
            nextTipText: 'Next',
            callbackInit: function() {},
            callbackBeforeOpen: function() {},
            callbackAfterOpen: function() {},
            callbackBeforeClose: function() {},
            callbackAfterClose: function() {},
            callbackError: function() {},
            callbackPrev: function() {},
            callbackNext: function() {},
            errorMessage: 'Error loading content.'
        };

    function liteBox(element, options) {
    }

    function winHeight() {
        return window.innerHeight ? window.innerHeight : $(window).height();
    }

    function preloadImageArray(images) {
        $(images).each(function() {
            if (image.width > 0)
                $('<img />').attr('src', this).addClass('litebox-preload').appendTo('body').hide();
        });
    }
        init: function() {
                e.preventDefault();
                $this.openLitebox();
            });
            $('body').off('keyup').on('keyup', function(e) {
                    $this.closeLitebox();
                    $('.litebox-prev').trigger('click');
                    $('.litebox-next').trigger('click');
            });
        },
        openLitebox: function() {
            $this.buildLitebox();
            $this.populateLitebox(link);
            if ($this.options.overlayClose)
                        $this.closeLitebox();
                });
                $this.closeLitebox();
            });
                var imageArray = [];
                $('[data-litebox-group="' + groupName + '"]').each(function() {
                    var src = $(this).attr('href');
                    imageArray.push(src);
                });
                preloadImageArray(imageArray);
                $('.litebox-nav').show();
                    $this.options.callbackPrev.call(this);
                    var index = group.index(link);
                    link = group.eq(index - 1);
                    if (!$(link).length)
                        link = group.last();
                    $this.populateLitebox(link);
                });
                    $this.options.callbackNext.call(this);
                    var index = group.index(link);
                    link = group.eq(index + 1);
                    if (!$(link).length)
                        link = group.first();
                    $this.populateLitebox(link);
                });
            }
        },
        buildLitebox: function() {
                'class': 'litebox-overlay'
                'class': 'litebox-text'
                'class': 'litebox-container'
                'class': 'litebox-loader'
            });
            }));
        },
        populateLitebox: function(link) {
                href = link.attr('href'),
                $currentContent = $('.litebox-content');
            var $text = link.attr('data-litebox-text');
            if (typeof $text == 'undefined' || $text == '') {
                $('.litebox-text').removeClass('active');
                $('.litebox-text').html();
            } else {
                $('.litebox-text').html($text);
                $('.litebox-text').addClass('active');
            }
            if (href.match(/\.(jpeg|jpg|gif|png|bmp)/i) !== null) {
                var $img = $('<img>', {
                    'src': href,
                    'class': 'litebox-content'
                });
                $this.transitionContent('image', $currentContent, $img);
                $img.error(function() {
                    $this.liteboxError();
                });
                var src = '';
                if (src) {
                    var $iframe = $('<iframe>', {
                        'src': src,
                        'frameborder': '0',
                        'vspace': '0',
                        'hspace': '0',
                        'scrolling': 'no',
                        'allowfullscreen': '',
                        'class': 'litebox-content',
                        'style': 'background: #000'
                    });
                    $this.transitionContent('embed', $currentContent, $iframe);
                    $iframe.load(function() {
                    });
                }
            } else if (href.substring(0, 1) == '#') {
                if ($(href).length) {
                        'class': 'litebox-content litebox-inline-html'
                    });
                    $this.transitionContent('inline', $currentContent, $html);
                } else {
                    $this.liteboxError();
                }
            } else {
                var $iframe = $('<iframe>', {
                    'src': href,
                    'frameborder': '0',
                    'vspace': '0',
                    'hspace': '0',
                    'scrolling': 'auto',
                    'class': 'litebox-content',
                    'allowfullscreen': ''
                });
                $this.transitionContent('iframe', $currentContent, $iframe);
                $iframe.load(function() {
                });
            }
        },
        transitionContent: function(type, $currentContent, $newContent) {
            if (type != 'inline')
            $currentContent.remove();
            if (type == 'inline')
            $this.centerContent();
            $(window).on('resize', function() {
                $this.centerContent();
            });
        },
        centerContent: function() {
                'height': winHeight()
            });
            });
                $('.litebox-inline-html').css({
                    'margin-top': '-' + ($('.litebox-inline-html').outerHeight()) / 2 + 'px',
                    'top': '50%'
                });
        },
        closeLitebox: function() {
                $('.litebox-nav').hide();
                $('.litebox-preload').remove();
            });
                $(this).remove();
            });
            $('.litebox-prev').off('click');
            $('.litebox-next').off('click');
        },
        liteboxError: function() {
        }
    };
            if (!$.data(this, pluginName))
        });
    };
})(jQuery, window, document);