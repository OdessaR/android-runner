window.CSbuttons = window.CSbuttons || {};
CSbuttons.init = function() {
}
CSbuttons.socialSharing = function() {
    } else {
        var buttons = $(".social-sharing");
    }
    } else {
        var fbLink = $('.share-facebook'),
            twitLink = $('.share-twitter'),
            pinLink = $('.share-pinterest'),
            googleLink = $('.share-google');
    }
            if (data.shares) {
            } else {
            }
        });
    };
            if (data.count > 0) {
            } else {
            }
        });
    };
            if (data.count > 0) {
            } else {
            }
        });
    };
    }
    shareLinks.on('click', function(e) {
        e.preventDefault();
        var el = $(this),
            popup = el.attr('class').replace('-', '_'),
            link = el.attr('href'),
            w = 700,
            h = 400;
        switch (popup) {
            case 'share-twitter':
                h = 300;
                break;
            case 'share-fancy':
                w = 480;
                h = 720;
                break;
            case 'share-google':
                w = 500;
                break;
        }
    });
        if (num >= 1e6) {
        } else if (num >= 1e3) {
        }
        return num;
    };
}
$(function() {
});
(function(d, s, id) {
    var js, fjs = d.getElementsByTagName(s)[0];
    if (d.getElementById(id)) return;
    js = d.createElement(s);
    js.id = id;
    js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8";
    fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
(function(E, n, G, A, g, Y, a) {
    a.parentNode.insertBefore(Y, a)
})(window, document, 'script', '//widget.engageya.com/engageya_loader.js', '__engWidget');
__engWidget('createWidget', {
    wwei: 'POSTQUARE_WIDGET_82058_' + window.aid,
    pubid: 160768,
    webid: 121132,
    wid: 82058
});
(function(E, n, G, A, g, Y, a) {
    a.parentNode.insertBefore(Y, a)
})(window, document, 'script', '//widget.engageya.com/engageya_loader.js', '__engWidget');
__engWidget('createWidget', {
    wwei: 'POSTQUARE_WIDGET_82058_' + window.aid,
    pubid: 160768,
    webid: 121132,
    wid: 82058
});