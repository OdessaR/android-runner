var _ENGAGEYA_WIDGETS = _ENGAGEYA_WIDGETS || [],
    _ENG_is_google_tag_ran = _ENG_is_google_tag_ran || !1,
    _ENG_is_yandex_tag_ran = _ENG_is_yandex_tag_ran || !1,
    _ENG_is_sr_started_loading = _ENG_is_sr_started_loading || !1,
    _ENG_is_av_started_loading = _ENG_is_av_started_loading || !1,
    _ENG_is_prebid_js_loaded = _ENG_is_prebid_js_loaded || !1,
    _ENG_is_feed_js_loaded = _ENG_is_feed_js_loaded || !1,
    googletag = googletag || {};
googletag.cmd = googletag.cmd || [];
var _ENG_PARTNERS_SAVED_SESSION_IDS_TO_WIDGET_ID = _ENG_PARTNERS_SAVED_SESSION_IDS_TO_WIDGET_ID || new Map,
    _ENG_OPTOUT_MODAL_ELM = _ENG_OPTOUT_MODAL_ELM || null,
    _ENG_PAGE_SESSION_ID = _ENG_PAGE_SESSION_ID || "",
    ENGAGEYA = function(t) {
            [],
            ["BUFFERING", "PLAYING"],
            [0, 2, 3],
            [1]
            ALL: "ALL",
            WARNING: "WARNING",
            INFO: "INFO",
            ERROR: "ERROR"
            val: 1,
            title: "Uninteresting"
        }, {
            val: 2,
            title: "Misleading"
        }, {
            val: 3,
            title: "Offensive"
        }, {
            val: 4,
            title: "Repetitive"
        }, {
            val: 5,
            title: "Other"
            STREAM_RAIL: 1,
            ANY_VIEW: 3
            WIDTH: "[WIDTH]",
            HEIGHT: "[HEIGHT]",
            PAGE_URL: "[PAGE_URL]",
            DNT: "[DO_NOT_TRACK]",
            CACHE_BUSTER: "[CACHE_BUSTER]",
            PAGE_TITLE: "[PAGE_TITLE]",
            SUB_ID: "[SUB_ID]",
            AD_URL: "[AD_URL]"
            width: 0,
            height: 0
            ENG_PIXEL_TRACK_IMP: "ENG_PIXEL_TRACK_IMP",
            ENG_PIXEL_TRACK_RIMP: "ENG_PIXEL_TRACK_RIMP",
            ENG_PIXEL_TRACK_CLK: "ENG_PIXEL_TRACK_CLK",
            ENG_PIXEL_TRACK_IMP_JS: "ENG_PIXEL_TRACK_IMP_JS",
            ENG_PIXEL_TRACK_RIMP_JS: "ENG_PIXEL_TRACK_RIMP_JS",
            ENG_PIXEL_TRACK_CLK_JS: "ENG_PIXEL_TRACK_CLK_JS"
            0: {
                type: "string",
                bid_param: "title",
                rec_param: "title"
            },
            1: {
                type: "object",
                bid_param: ["image", "url"],
                rec_param: "thumbnail_path"
            },
            2: {
                type: "string",
                bid_param: "clickUrl",
                rec_param: "clickUrl"
            },
            3: {
                type: "array",
                bid_param: "impressionTrackers",
                separator: "",
                rec_param: "impressionUrls"
            },
            4: {
                type: "array",
                bid_param: "clickTrackers",
                separator: "",
                rec_param: "impressionUrls"
            },
            5: {
                type: "string",
                bid_param: "sponsoredBy",
                rec_param: "displayName"
            },
            6: {
                type: "string",
                bid_param: "cpm",
                rec_param: "cpm",
                obj: "bid"
            }
            DEFAULT: 1,
            PAGE_SESSION: 2,
            FEED: 3
    };
ENGAGEYA_MULTI_WIDGETS = function(t) {
};
var ENGAGEYA_VIDEO = function(t) {
        VAST: "VAST",
        DIRECT: "DIRECT"
        AD_START: "AS",
        AD_FIRST_QUARTILE: "FQ",
        AD_MID_POINT: "MP",
        AD_THIRD_QUARTILE: "TQ",
        AD_COMPLETE: "CO",
        AD_CLICK: "CLK",
        ALL_ADS_COMPLETED: "ALADCM",
        AD_TIMEOUT: "TOUT",
        ADS_READY: "ADRDY",
        AD_ERROR: "ADER"
        top: 20,
        bottom: 0
        top: 1,
        bottom: 1
        src: "//widget.engageya.com/videojs/dummy_video.mp4",
        type: "video/mp4"
};
ENGAGEYA_VIDEO.prototype = new ENGAGEYA({}), ENGAGEYA_MULTI_WIDGETS.prototype = new ENGAGEYA({}), ENGAGEYA.prototype.run = function() {
}, ENGAGEYA.prototype.populate_page_session_id = function() {
        try {
}, ENGAGEYA.prototype.add_message_listener = function() {
            var e = t.data;
            try {
                var i = e.split("^");
            } catch (t) {}
        }
    })
}, ENGAGEYA.prototype.attach_player_events = function() {
}, ENGAGEYA.prototype.attach_jwplayer_events = function() {
        t.on_play_action()
        t.on_play_action()
        t.on_pause_action()
        t.on_idle_action()
        t.on_complete_action()
}, ENGAGEYA.prototype.attach_flowplayer_events = function() {
        e = null,
    try {
        e.onStart(function() {
            i.on_play_action()
        }), e.onLoad(function() {
            i.on_play_action()
        }), e.getClip().onResume(function() {
            i.on_play_action()
        }), e.getClip().onPause(function() {
            i.on_pause_action()
        }), e.getClip().onStop(function() {
            i.on_pause_action()
        }), e.getClip().onFinish(function() {
            i.on_complete_action()
        e.bind("load", function(t, e) {
            i.on_play_action()
        }), e.bind("click", function(t, e) {
            i.is_user_initiated_event = !0
        }), e.bind("resume", function(t, e) {
            i.on_play_action()
        }), e.bind("pause", function(t, e) {
            i.is_user_initiated_event && (i.on_pause_action(), i.is_user_initiated_event = !1)
        }), e.bind("stop", function(t, e) {
            i.on_pause_action()
        }), e.bind("finish", function(t, e) {
            i.on_complete_action()
            return 1
        }
    }
}, ENGAGEYA.prototype.attach_generic_player_events = function() {
    try {
    } catch (t) {}
    try {
            t.on_play_action()
        })
    } catch (t) {}
    try {
            t.on_play_action()
        })
    } catch (t) {}
    try {
            t.on_play_action()
        })
    } catch (t) {}
    try {
            t.on_play_action()
        }
    } catch (t) {}
    try {
            t.on_play_action()
        })
    } catch (t) {}
    try {
            t.on_play_action()
        })
    } catch (t) {}
    try {
            t.on_play_action()
        })
    } catch (t) {}
    try {
            t.on_pause_action()
        })
    } catch (t) {}
    try {
            t.on_pause_action()
        }
    } catch (t) {}
    try {
            t.on_pause_action()
        })
    } catch (t) {}
    try {
            t.on_complete_action()
        })
    } catch (t) {}
    try {
            t.on_complete_action()
        }
    } catch (t) {}
    try {
            t.on_complete_action()
        })
    } catch (t) {}
    try {
            return 1
        }
    } catch (t) {}
}, ENGAGEYA.prototype.on_play_action = function() {
}, ENGAGEYA.prototype.on_pause_action = function() {
}, ENGAGEYA.prototype.on_idle_action = function() {
}, ENGAGEYA.prototype.on_complete_action = function() {
}, ENGAGEYA.prototype.state_events = function() {
}, ENGAGEYA.prototype.is_load_recs_state = function() {
}, ENGAGEYA.prototype.show_widget = function() {
}, ENGAGEYA.prototype.hide_widget = function(t) {
    try {
    } catch (t) {}
}, ENGAGEYA.prototype.attach_widget_events = function() {
    try {
            t.hide_widget(t)
        })
    }
}, ENGAGEYA.prototype.create_generic_elms = function() {
    try {
    }
}, ENGAGEYA.prototype.generate_modal_elm = function(t, e, i) {
    var _ = "eng_modal_id_" + t,
        s = "eng_modal_content_" + t,
        n = "eng_modal_close_" + t,
        a = '<div id="' + s + '"><span id="' + n + '">&times;</span>' + (e || '<iframe frameborder="0" allowtransparency="true" style="width:100%!important;height:500px;overflow:scroll;"></iframe>') + "</div>",
        r = "<style>#" + (o.id = _) + "{display:" + i + ";position:fixed;z-index:9999;left:0;top:0;width:100%;height:100%;overflow:auto;background-color:#000;background-color:rgba(0,0,0,.4)}#" + s + "{position:absolute;top:50%;left:50%;transform:translate(-50%, -50%);border-radius:10px;max-width:750px;background-color:#fefefe;margin:auto;padding:20px;border:1px solid #888;width:80%}#" + n + "{color:#aaa;float:right;font-size:28px;font-weight:700}#" + n + ":focus,#" + n + ":hover{color:#000;text-decoration:none;cursor:pointer}</style>";
        o.style.display = "none"
        t.target == o && (o.style.display = "none")
    }), o
}, ENGAGEYA.prototype.widget_clicks_events = function() {
}, ENGAGEYA.prototype.attach_on_click_widget_optout_event = function() {
    var _;
        var e = _.jq(_ENG_OPTOUT_MODAL_ELM).find("iframe"),
            i = _.widget_optout_url + "?swebid=" + _.website_id + "&ref=" + _.get_page_url();
        return e.attr("src", i), _.jq(_ENG_OPTOUT_MODAL_ELM).fadeIn(), !1
    })
}, ENGAGEYA.prototype.attach_on_click_pixel_event = function() {
    if (e.click_pixels) try {
        for (var t = 0; t < e.click_pixels.length; t++) {
            for (var i = e.click_pixels[t], _ = i.urls.split(";"), s = "", n = 0; n < _.length; n++) i.etype && 0 != i.etype ? 1 == i.etype && (s = _) : s += '<img src="' + _[n] + '" style="display:none;" width="1px" height="1px" />';
            var o, a = ".eng_widget_href,.eng_m_widget_href";
            0 != i.type && (a = ".eng_widget_href." + (o = e.rec_types[i.type]) + ",.eng_m_widget_href." + o), i.etype && 0 != i.etype ? 1 == i.etype && e.get_recs_holder_elm().find(a).mousedown({
                pxls: s
            }, function(t) {
                try {
                    for (var e = t.data.pxls, i = 0; i < e.length; i++) {
                        var _, s, n, o, a = e[i],
                            r = a.match("engcval_(.*?)['|\"],");
                    }
                } catch (t) {
                }
            }) : e.get_recs_holder_elm().find(a).mousedown({
                pxls: s
            }, function(t) {
                e.jq(this).append(e.populate_place_holders(this, t.data.pxls))
            })
        }
    }
}, ENGAGEYA.prototype.widget_imgs_events = function() {
}, ENGAGEYA.prototype.attach_on_hover_brand_img_event = function() {
    e && e.imghvr && t.get_recs_holder_elm().hover(function() {
        t.jq(this).find("#eng_brnd_img_" + t.widget_id).attr("src", e.imghvr)
    }, function() {
        t.jq(this).find("#eng_brnd_img_" + t.widget_id).attr("src", e.img.src)
    }), e && e.img2hvr && t.get_recs_holder_elm().hover(function() {
        t.jq(this).find("#eng_brnd_img2_" + t.widget_id).attr("src", e.img2hvr)
    }, function() {
        t.jq(this).find("#eng_brnd_img2_" + t.widget_id).attr("src", e.img2.src)
    })
}, ENGAGEYA.prototype.attach_on_img_load_event = function() {
    function t() {
        try {
            e.is_amp_widget && e.amp_caller_obj && e.amp_caller_obj.resizeAMPWidget(), e.is_run_ext_video_started || e.run_ext_video()
    }
        i = e.get_recs_holder_elm().find(".eng_widget_img,.eng_m_widget_img");
    void 0 !== i.error ? i.load(t) : i.on("load", t)
}, ENGAGEYA.prototype.attach_on_img_error_event = function() {
    function t() {
        try {
                s = n.image_load_retries_arr[_];
                i.src = e + "?" + +new Date
            }, 300))
        }
    }

    function e() {
        t && (t[1], n.jq(this).unbind("error"))
    }
        i = n.get_recs_holder_elm().find(".eng_widget_img,.eng_m_widget_img");
    void 0 !== i.error ? (i.error(t), i.load(e)) : (i.on("error", t), i.on("load", e))
}, ENGAGEYA.prototype.set_default_image = function(t, e) {
    var i = Math.floor(3 * Math.random() + 1),
        _ = t.custom_default_image || "//" + t.default_imgs_url + "def/def_" + i + ".jpg";
    t.jq(e).unbind("error").attr("src", _)
}, ENGAGEYA.prototype.start_run = function() {
}, ENGAGEYA.prototype.generate_random_number = function() {
    return Math.ceil(1e7 * Math.random())
}, ENGAGEYA.prototype.doc_ready = function(t) {
}, ENGAGEYA.prototype.validate_jquery_loaded = function(t) {
    if (t.jq) t.inner_run();
        t.validate_jquery_loaded(t)
    }, 100)
}, ENGAGEYA.prototype.load_jQuery = function() {
}, ENGAGEYA.prototype.getAndPopulateTCData = function() {
    try {
        i.is_tcfapi_exists() && !i.is_tcdata_called && (i.is_tcdata_called = !0, __tcfapi("getTCData", 2, function(t, e) {
            e && t && (i.tcData = t).gdprApplies && (i.gdpr_consent = t.tcString ? t.tcString : "", i.is_gdpr_user = t.tcString ? 1 : 0)
        }, [i.gdpr_vendor_id]))
    }
}, ENGAGEYA.prototype.is_tcfapi_exists = function() {
}, ENGAGEYA_MULTI_WIDGETS.prototype.inner_run = function(t) {
        e.inner_run(e)
        e.inner_run(e)
    for (var i = 0; i < e.multi_widget_ids_arr.length; i++) {
        var _ = e.input_obj,
            s = e.multi_widget_ids_arr[i];
    }
            for (var i, _, s = 0; s < t.length; s++) {
            }
    };
    var n = e.get_page_url(),
        o = (e.get_lang(), e.get_page_ttl()),
        a = e.get_meta_content("keywords", "content"),
        d = e.guid(),
    e.append_script_to_head(l, e.random_id), e.trigger_partners_header_bidding(d, e.multi_widget_ids)
}, ENGAGEYA.prototype.inner_run = function(t) {
    if (!e.is_multi_widgets) {
            e.inner_run(e)
            e.inner_run(e)
    }
            if (t && 0 < t.recs.length) {
                        break
                    } if (!_)
                            break
                        } i && (i.data_json = t, i.widget_id = t.widget.id, e = {
                    widget: t.widget.additionalData || "{}",
                    network: t.widget.anad || "{}"
                }, i.populate_add_data(e), i.populate_widget_data(t), t.widget.widgetType && t.widget.widgetType == i.widget_types.FEED ? i.load_feed_loader_js() : (i.reposition_widget(), i.build_layout(), i.add_player_wmode(), i.create_generic_elms(), i.attach_widget_events(), i.run_prebidjs(), i.run_criteo(), i.run_outbrain(), i.run_target(), i.run_google_tags(), i.run_yandex_tags(), i.run_posts_preview(), i.run_widget_alignments()), i.widget_ready())
            }
        e.inner_run(e)
    e.create_placement(), e.is_widget_wrapper_dom_ready = !0;
    var i, _ = e.get_page_url(),
        s = e.get_lang(),
        n = e.get_page_ttl(),
        o = e.get_meta_content("keywords", "content"),
        r = "",
        d = "";
}, ENGAGEYA.prototype.load_feed_loader_js = function() {
    })
}, ENGAGEYA.prototype.load_feed_widget = function() {
    initEngageyaInfiniteWidget(t)
}, ENGAGEYA.prototype.get_feed_widget_instructions = function() {
    var t = {};
}, ENGAGEYA.prototype.set_urls_for_pp = function() {
}, ENGAGEYA.prototype.load_real_imps_events = function() {
        var t = e.is_elm_visible(e.widget_wrapper_elm);
        if (t && !e.is_amp_widget) {
            if (e.is_real_imps_called) return;
            e.is_real_imps_called = !0, 1 == e.is_index_page ? e.fire_widget_real_impression_event(e) : e.fire_real_impression_pixels()
        }
        return t
}, ENGAGEYA.prototype.fire_widget_real_impression_event = function(t) {
    var e = t.data_json,
        i = t.visible_posts_and_types;
    if (0 < i.length) {
        for (var _ = "", s = 0; s < i.length; s++) _ += i[s].pi + ":" + i[s].pt, s != i.length - 1 && (_ += ",");
        var n = (new Date).getTime() - t.load_time_start;
        t.fire_real_impression_pixels();
        o.src = "https://" + t.event_url + "?irid=" + e.requestId + "&webid=" + e.srcWebsiteId + "&wid=" + e.srcWidgetId + "&spid=" + e.srcPostId + "&tpids=" + _ + "&tti=" + n + "&ucc=" + e.requestGeoCountry, e.ipu && e.guid && (o.src += "&u=" + e.guid);
        try {
        } catch (t) {
        }
    }
}, ENGAGEYA.prototype.trigger_partners_header_bidding = function(t, e) {
}, ENGAGEYA.prototype.import_partners_header_bidding_libs = function() {
}, ENGAGEYA.prototype.guid = function() {
    return t() + t() + "-" + t() + "-" + t() + "-" + t() + "-" + t() + t() + t();

    function t() {
        return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
    }
}, ENGAGEYA.prototype.run_prebidjs = function() {
    var _;
    }))
}, ENGAGEYA.prototype.populate_prebid_data = function() {
    try {
            if (t && t.partners) {
            }
        }
    }
}, ENGAGEYA.prototype.get_prebid_bids = function(t) {
        }, 100);
            width: 300,
            height: 250
        }
    }
    i.que = i.que || [];
    i.que.push(function() {
        i.addAdUnits(_), i.requestBids({
            bidsBackHandler: function(t) {
                e.handle_prebid_bid_responses(t)
            }
        })
    })
}, ENGAGEYA.prototype.handle_prebid_bid_responses = function(t) {
    var e, i;
}, ENGAGEYA.prototype.choose_recs_to_replace = function() {
            _ && 0 < _.ecpm && e.push(_.index)
        }
            if (s && 0 < s.length)
        }
        return e
    }
}, ENGAGEYA.prototype.get_lowest_ecpm_rec = function() {
        i && !i.isChosen && (null == t ? t = i : i.ecpm > t.ecpm && ((t = i).index = e + 1))
    }
    return t.isChosen = !0, t
}, ENGAGEYA.prototype.replace_recs_if_possible = function(t, e) {
    for (var i = 0; i < e.length; i++) {
        var _ = e[i] - 1;
    }
}, ENGAGEYA.prototype.inject_rec_by_idx = function(t, e) {
    else {
        try {
                l.jq(this).replaceWith(i), i.hide().fadeIn("fast")
        } catch (t) {
        }
    }
}, ENGAGEYA.prototype.remove_post_from_visible_posts_and_types = function(t) {
            break
        }
    }
}, ENGAGEYA.prototype.get_widget_slide_by_idx = function(t) {
}, ENGAGEYA.prototype.transform_bids_to_recommendations = function() {
    return t
}, ENGAGEYA.prototype.bid_to_rec = function(d, t) {
    var l = null,
        p = {};
        var i = e.type,
            _ = e.bid_param,
            s = e.rec_param,
            n = e.addition,
            o = e.separator;
        switch (l = "bid" == e.obj ? d : d.native, i) {
            case "string":
                p[s] = l[_];
                break;
            case "object":
                for (var a = null, r = 0; r < _.length; r++) a = a ? a[_[r]] : l[_[r]];
                p[s] = a;
                break;
            case "array":
                if (l[_])
                    for (r = 0; r < l[_].length; r++) p[s] || (p[s] = []), p[s].push(l[_][r] + n + o)
        }
    }), p
}, ENGAGEYA.prototype.order_bids = function(t) {
        e && e.bids && i.jq.each(e.bids, function(t, e) {
            i.prebid_ordered_bids.push(e)
        })
        return t.cpm - e.cpm
}, ENGAGEYA.prototype.get_prebid_ad_units = function() {
    var t = [];
            _ = JSON.parse(i);
        _ && _.adUnits && t.push(_.adUnits)
    } catch (t) {
    }
    return t
}, ENGAGEYA.prototype.populate_prebid_placeholders = function(t) {
}, ENGAGEYA.prototype.run_criteo = function() {
    var t, e;
}, ENGAGEYA.prototype.run_outbrain = function() {
    try {
    } catch (t) {
    }
}, ENGAGEYA.prototype.run_target = function() {
    try {
    } catch (t) {
    }
}, ENGAGEYA.prototype.run_yandex_tags = function() {
        try {
                        blockId: t,
                        renderTo: _,
                        async: !0
                    })
                }))
            }
        }
    }
    var n, o, a, r, d
}, ENGAGEYA.prototype.run_google_tags = function() {
            n && (n.id = _, n.innerHTML = "", function(t, e, i) {
                })
            }(e, i, _), function(t) {
                })
            }(_))
        }
    }
}, ENGAGEYA.prototype.run_yandex_tag = function() {
    var t, e, i, _, s, n, o, a, r, d, l;
            blockId: "R-A-278832-1",
            renderTo: "yandex_rtb_R-A-278832-1",
            async: !0
        })
            blockId: "R-A-260176-1",
            renderTo: "yandex_rtb_R-A-260176-1",
            async: !0
        })
    }), l = a.getElementsByTagName("script")[0], (d = a.createElement("script")).type = "text/javascript", d.src = "//an.yandex.ru/system/context.js", d.async = !0, l.parentNode.insertBefore(d, l)))
}, ENGAGEYA.prototype.run_posts_preview = function() {
    try {
            s = [];
}, ENGAGEYA.prototype.run_ext_video = function(t, e, i) {
            try {
                _ = JSON.parse(e)
            } catch (t) {
            }
        } catch (t) {
        } else {
            }, 100)
        }
}, ENGAGEYA.prototype.get_external_video_target_element = function() {
    if (t && 0 < t.length) return t;
    var e = t.find(".eng_asw,.eng_m_asw");
    return e && 0 < e.length ? e : null
}, ENGAGEYA.prototype.run_aniview_video = function(t) {
}, ENGAGEYA.prototype.run_streamrail_video = function(t) {
}, ENGAGEYA.prototype.is_load_ext_video = function() {
}, ENGAGEYA.prototype.is_widget_ext_video_already_loaded = function() {
}, ENGAGEYA.prototype.populate_aniview_placeholders = function(t) {
}, ENGAGEYA.prototype.populate_srail_placeholders = function(t) {
    if (t && t.macros) try {
        var i = JSON.stringify(t.macros);
    } catch (t) {
    }
}, ENGAGEYA.prototype.is_enough_space_for_ext_video = function() {
    return !0
}, ENGAGEYA.prototype.set_ext_video_dims = function() {
}, ENGAGEYA.prototype.set_ext_video_final_player_dims = function() {
        width: t,
        height: Math.ceil(t / 1.777777)
    }
}, ENGAGEYA.prototype.get_ext_video_elm_id = function() {
}, ENGAGEYA.prototype.get_ext_video_wrapper_elm_id = function() {
}, ENGAGEYA.prototype.run_aniview_ads = function(_) {
    var s;
        var t = _;
        var e, i;
            s.init_aniview_player(t)
    }())
}, ENGAGEYA.prototype.run_streamrail_ads = function(t) {
    var e, i, _, s, n, o, a;
        e.init_srail_player(t)
}, ENGAGEYA.prototype.wait_for_aniview_init = function(t, e) {
    var i;
    }, 100) : i.init_aniview_player(t))
}, ENGAGEYA.prototype.wait_for_srail_init = function(t, e) {
    var i;
    }, 100) : i.init_srail_player(t))
}, ENGAGEYA.prototype.init_aniview_player = function(t) {
}, ENGAGEYA.prototype.init_srail_player = function(t) {
        (e.srPlayer = t).resize(e.ext_video_dims.width, e.ext_video_dims.height), e.subscribe_srplayer_events()
}, ENGAGEYA.prototype.subscribe_avplayer_events = function() {
}, ENGAGEYA.prototype.attach_aniview_visibility_events = function() {
        e.animate_show_ext_video_player()
        e.animate_hide_ext_video_player()
    }
}, ENGAGEYA.prototype.subscribe_srplayer_events = function() {
}, ENGAGEYA.prototype.attach_srail_visibility_events = function() {
    ["AdImpression"].map(function(t) {
        e.on(t, function(t) {
            i.animate_show_ext_video_player()
        })
    }), ["AdVideoComplete"].map(function(t) {
        e.on(t, function(t) {
            i.animate_hide_ext_video_player()
        })
    }), ["AdVolumeChange"].map(function(t) {
        e.on(t, function(t) {})
    }), ["stick"].map(function(t) {
        e.on(t, function(t) {
            var e = i.jq("#" + i.get_ext_video_elm_id());
            i.jq("#" + i.get_ext_video_wrapper_elm_id());
            e.css("z-index", 999999999)
        })
    }), ["unstick"].map(function(t) {
        e.on(t, function(t) {
            var e = i.jq("#" + i.get_ext_video_elm_id());
            i.jq("#" + i.get_ext_video_wrapper_elm_id());
            e.css("z-index", 0)
        })
    }), ["playerReady"].map(function(t) {
        e.on(t, function(t) {
            i.jq("#" + i.get_ext_video_elm_id()).addClass("height-hidden")
        })
    })
}, ENGAGEYA.prototype.attach_aniview_mouse_over_event = function() {
        e && e.unmuteOnHover && t.AVPlayer.unmute()
    })
}, ENGAGEYA.prototype.attach_srail_mouse_over_event = function() {
        e && e.unmuteOnHover && (t.is_sr_blade ? t.srPlayer.muted = !1 : (t.srPlayer.muted(!1), t.srPlayer.volume(1)))
    })
}, ENGAGEYA.prototype.attach_aniview_mouse_out_event = function() {
        !t.AVPlayer.muted && e.unmuteOnHover && t.AVPlayer.mute()
    })
}, ENGAGEYA.prototype.attach_srail_mouse_out_event = function() {
        e.unmuteOnHover && (t.is_sr_blade && !t.srPlayer.muted ? t.srPlayer.muted = !0 : t.is_sr_blade || t.srPlayer.muted() || t.srPlayer.muted(!0))
    })
}, ENGAGEYA.prototype.animate_show_ext_video_player = function() {
    t.removeClass("height-hidden"), t.css("z-index", 0), e.css("paddingTop", "10px"), e.css("paddingBottom", "10px"), t.animate({
        opacity: 1,
    }, 1e3)
}, ENGAGEYA.prototype.animate_hide_ext_video_player = function() {
    t.animate({
        height: 0,
        opacity: 0
    }, 1e3, function() {
        e.hide()
    })
}, ENGAGEYA.prototype.generate_ext_video_elm = function() {
    e.id = i, e.className = "eng_" + t;
    _.type = "text/css";
}, ENGAGEYA.prototype.run_widget_alignments = function() {
}, ENGAGEYA.prototype.align_widget_text_height = function() {
    var i, t, _;
        _.jq(e).height() && (i = Math.max(_.jq(e).height(), i))
}, ENGAGEYA.prototype.align_widget_dims = function(t) {
    try {
                n = !0;
                break
            }
        }
            s.jq(e).height() < 300 && (_ = Math.max(s.jq(e).height(), _), i = Math.max(s.jq(e).width(), i))
            width: i,
            height: _
            var i = s.jq(e);
            i.height() != _ && (i.height(_), s.is_hard_align_dims && (i.css("cssText", "height:" + _ + "px !important;display:inline-block;"), i.width("auto"), i.parent().css("text-align", "center"), i.css("margin", "0 auto")))
        }, 100))
    } catch (t) {
    }
}, ENGAGEYA.prototype.get_posts_for_preview = function(t) {
                g = h.jq(".eng_widget_href:not(.eng_test_ppid),.eng_m_widget_href:not(.eng_test_ppid)");
        };
            var s = e[_];
        }
    }
}, ENGAGEYA.prototype.shuffle_array = function(t) {
    for (var e = t.length - 1; 0 < e; e--) {
        var i = Math.floor(Math.random() * (e + 1)),
            _ = t[e];
    }
    return t
}, ENGAGEYA.prototype.get_cookie = function(t) {
    return e ? e[1] : null
}, ENGAGEYA.prototype.get_slide_elm_by_idx = function(t) {
}, ENGAGEYA.prototype.widget_ready = function() {
}, ENGAGEYA.prototype.isShouldBeRTL = function(e) {
    try {
        if (!e.match(/[\u0590-\u083F]|[\u08A0-\u08FF]|[\uFB1D-\uFDFF]|[\uFE70-\uFEFF]/gm)) return !1
    }
    return !0
}, ENGAGEYA.prototype.decode_html = function(e) {
    try {
        return e
    }
}, ENGAGEYA.prototype.external_is_amp_elm_visible = function(t) {
    var e = t;
    try {
        return 100 < e.height
    } catch (t) {
        return !1
    }
}, ENGAGEYA.prototype.is_elm_visible = function(t) {
    var e = t.getBoundingClientRect();
    try {
    } catch (t) {
        return !1
    }
}, ENGAGEYA.prototype.is_premium = function() {
    try {
        return !1
    }
}, ENGAGEYA.prototype.populate_widget_data = function(t) {
    try {
        var e = t.widget,
            i = e.layoutTypeId;
    } catch (t) {
    }
}, ENGAGEYA.prototype.sort_results_by_post_id = function() {
        i = [];
    for (var _ in e) e[_].partner_id == t && i.push(e[_]);
    i.sort(function(t, e) {
        return e.postId - t.postId
    });
    }
}, ENGAGEYA.prototype.reposition_widget = function() {
            switch (e) {
                case 0:
                    i.appendTo(t);
                    break;
                case 1:
                    i.prependTo(t);
                    break;
                case 2:
                    i.insertAfter(t);
                    break;
                case 3:
                    i.insertBefore(t);
                    break;
                default:
                    i.appendTo(t)
            }
        }
    }
}, ENGAGEYA.prototype.populate_add_data = function(t) {
    try {
    } catch (t) {
    }
}, ENGAGEYA.prototype.get_add_data = function(t) {
}, ENGAGEYA.prototype.set_add_data = function(t, e) {
}, ENGAGEYA.prototype.add_player_wmode = function() {}, ENGAGEYA.prototype.get_page_url = function() {
}, ENGAGEYA.prototype.get_total_slides = function(t, e) {
}, ENGAGEYA.prototype.get_script = function(t, e) {
        type: "GET",
        url: t,
        success: e,
        scriptCharset: "utf-8",
        dataType: "script",
        cache: !0
    })
}, ENGAGEYA.prototype.logger = function(t, e) {
}, ENGAGEYA.prototype.generate_img_pixel = function(t) {
}, ENGAGEYA.prototype.is_mobile_conditions_satisfied = function() {
}, ENGAGEYA.prototype.build_layout = function() {
}, ENGAGEYA.prototype.build_vertical_layout = function() {
    for (var r = t.recs, d = "", l = 0; l < e; l++) {
        var p = null;
            if (!r[l].sNAD) continue;
            try {
                p = JSON.parse(r[l].sNAD), r[l].sNPData = p
            } catch (t) {
                continue
            }
        }
        var h = r[l].postId,
            g = r[l].recTypeDB,
            pi: h,
            pt: g
        });
            E = f ? "" : " eng_m_no_img",
            y = "";
            j = "";
    }
}, ENGAGEYA.prototype.build_horizontal_layout = function() {
    var e = t.widget.displayRows,
    for (var d = t.recs, l = "", p = 0; p < i; p++) {
        var h = null;
            if (!d[p].sNAD) continue;
            try {
                h = JSON.parse(d[p].sNAD), d[p].sNPData = h
            } catch (t) {
                continue
            }
        }
        var g = d[p].postId,
            c = d[p].recTypeDB,
            pi: g,
            pt: c
            E = f ? "" : " eng_no_img",
            y = "",
            T = "";
    }
}, ENGAGEYA.prototype.get_exclude_posts_box_elms = function(t) {
    var e = '<div class="eng_excludebox_wrapper" data-id="' + t.postId + '">' + '<div class="eng_excludebox_title">Remove</div><div class="eng_excludebox_question_main"><div class="eng_excludebox_question"><div class="eng_excludebox_question_title">Tell us why?</div>';
}, ENGAGEYA.prototype.get_exclude_reasons_elms = function() {
    }
    return t
}, ENGAGEYA.prototype.get_default_css = function(t, e) {
    var i = "",
    switch (t) {
        case "DESKTOP":
            break;
        case "DESKTOP_NON_VIDEO":
            i = "#" + e + " .eng_ww_widget{color:#000;}#" + e + " .eng_widget_sw{vertical-align:top;margin-bottom:10px}#" + e + " .eng_widget_vsw .eng_widget_img_w::after{content:'';background-image: url(" + s + ");position:absolute;left:40%;top:42%;width:35px;height:26px;z-index:2;}#" + e + " .eng_widget_href{position:relative;display:block !important;visibility:visible !important;}#" + e + " .eng_widget_in{width:100%;line-height:1.4;}#" + e + " .eng_widget_dn{color:#CDCDCD;}#" + e + " .eng_ww_title{padding:0px;margin:0px 0px 5px 0px;}#" + e + " .eng_ww_ttl_span1{display:block;padding:5px 0px;float:none !important;}#" + e + " .eng_widget_img_w{position:relative;}#" + e + " .eng_widget_img{margin-bottom:5px;display:block;}";
            break;
        case "DESKTOP_VIDEO":
            break;
        case "MOBILE_VERTICAL":
            break;
        case "VIDEO_ONLY":
    }
    return i
}, ENGAGEYA.prototype.get_description = function(t) {
    if (t) {
        var e = t.description;
            if (!t.sNPData || !t.sNPData.desc) return;
            e = t.sNPData.desc
        }
        try {
        } catch (t) {
        }
        return e
    }
}, ENGAGEYA.prototype.get_abstract = function(t) {
    if (t) {
        var e = "";
            if (!t.sNPData || !t.sNPData.abs) return;
            e = t.sNPData.abs;
            try {
            } catch (t) {
            }
        }
        return e
    }
}, ENGAGEYA.prototype.get_ad_brand = function(t) {
    if (!t) return "";
    var e = "";
        var i = "";
        try {
            if (t.sNPData && t.sNPData.adbrnd && (i = t.sNPData.adbrnd), !i) return "";
            var _ = !1;
        } catch (t) {
        }
    }
    return e
}, ENGAGEYA.prototype.get_title = function(t) {
    if (t) {
        var e = t.title;
        try {
        } catch (t) {
        }
        return e
    }
}, ENGAGEYA.prototype.shorten_string = function(t, e) {
}, ENGAGEYA.prototype.get_meta_tag_obj = function(t) {
    if (t) {
        var e = {
            label: "",
            id: ""
        };
        try {
            t.metatagLabels && t.metatags && (e.label = t.metatagLabels[0] || "", e.id = t.metatags.split(",")[0] || "", e.label = e.label.replace(/\^/g, " "))
        } catch (t) {
        }
        return e
    }
}, ENGAGEYA.prototype.get_click_defs = function(t, e) {
        s = 'onclick="' + _ + '"',
        n = !!t.ajx,
        o = "",
        a = t.clickUrl,
}, ENGAGEYA.prototype.array_to_csv = function(t) {
    for (var e = "", i = 0; i < t.length; i++) e += t[i], i != t.length - 1 && (e += ",");
    return e
}, ENGAGEYA.prototype.get_rec_type = function(t) {
    return "eng_" + t.recType.split("_")[1].toLowerCase()
}, ENGAGEYA.prototype.is_video_post = function(t) {
    var e = !1,
    return i && i.drgx && (e = null != t.url.match(i.drgx)), e
}, ENGAGEYA.prototype.get_impression_pixel_imgs_and_populate_other_pixel_types = function(t) {
    var e = "";
    if (t && null != t && 0 < t.length)
        for (var i = 0; i < t.length; i++)
            for (var _ = t[i].split("^"), s = 0; s < _.length; s++) {
                var n, o = _[s];
                } else {
                    try {
                    } catch (t) {}
                }
            }
    return e
}, ENGAGEYA.prototype.get_display_name = function(t, e) {
    try {
        var i = "";
    } catch (t) {
    }
}, ENGAGEYA.prototype.get_link_name = function(t) {
    var e = "";
}, ENGAGEYA.prototype.populate_widget_directions = function() {
}, ENGAGEYA.prototype.get_cancle_click_bubble = function() {
}, ENGAGEYA.prototype.get_recs_holder_elm = function() {
}, ENGAGEYA.prototype.align_widget_elements = function() {
}, ENGAGEYA.prototype.get_widget_branding = function() {
    var t, e, i = "",
        _ = null,
        s = {
            img: "",
            img2: ""
        };
        href: "//www.engageya.com",
        name: "",
        ttl: "Engageya",
        img: {
            src: t + "eng_logo.png",
            width: 41,
            height: 12
        },
        imghvr: t + "eng_logo_c.png",
        href2: "",
        name2: "",
        ttl2: "",
        img2: "",
        img2hvr: ""
        href: "",
        name: "",
        ttl: "",
        img: "",
        imghvr: "",
        adds: "",
        href2: "",
        name2: "",
        ttl2: "",
        img2: "",
        adds2: "",
        img2hvr: ""
}, ENGAGEYA.prototype.is_mobile = function() {
    try {
        return !1
    }
}, ENGAGEYA.prototype.get_tablet_cls = function() {
    var t = "";
}, ENGAGEYA.prototype.is_tablet_conditions_satisfied = function() {
}, ENGAGEYA.prototype.get_mobile_device_OS = function() {
}, ENGAGEYA.prototype.align_widget_title = function() {}, ENGAGEYA.prototype.get_thumb = function(t, e, i, _) {
        o = 4,
        a = 3;
    if (e)
        for (r = 1; r <= o; r++)
            if (r != n && -1 != (s = e.lastIndexOf("_" + r + "."))) {
                break
            } return e
}, ENGAGEYA.prototype.shorten = function(t, e) {
    if (!t) return "";
    var i = t.length,
        _ = t.indexOf(" ", e);
}, ENGAGEYA.prototype.click = function(t, e, i) {
}, ENGAGEYA.prototype.get_href_target = function(t, e) {
    var i = "";
}, ENGAGEYA.prototype.is_in_iframe = function() {
    try {
    }
}, ENGAGEYA.prototype.is_start_of_row = function(t, e) {
    return t % e == 0
}, ENGAGEYA.prototype.add_row_if_required = function(t, e, i) {
    return t % e == 0 && t != i ? '<div style="clear: both" class="eng_rows_seperator"></div>' : ""
}, ENGAGEYA.prototype.floor_figure = function(t, e) {
    var i = Math.pow(10, e);
    return (parseInt(t * i) / i).toFixed(e)
}, ENGAGEYA.prototype.calc_slides_dims = function() {
    try {
    }
}, ENGAGEYA.prototype.populate_required_fields = function() {
}, ENGAGEYA.prototype.calculate_widget_wrapper_dims = function() {
    try {
    } catch (t) {
    }
}, ENGAGEYA.prototype.get_exact_width = function(t) {
}, ENGAGEYA.prototype.create_placement = function() {
    e.type = "text/css";
        s = "";
}, ENGAGEYA.prototype.get_page_ttl = function() {
    var t = "",
    if (e && 0 < e.length) try {
        t = (t = e[0].innerText || e[0].textContent).substring(0, 100).substring(0, t.lastIndexOf(" ")), t = encodeURIComponent(t)
    } catch (t) {}
    return t
}, ENGAGEYA.prototype.get_meta_content = function(t, e) {
        if (i[s].getAttribute("property") == t || i[s].getAttribute("name") == t) {
            try {
                _ = (_ = i[s].getAttribute(e)).substring(0, 200).substring(0, _.lastIndexOf(" ")), _ = encodeURIComponent(_)
            } catch (t) {}
            break
        } return _
}, ENGAGEYA.prototype.get_lang = function() {
}, ENGAGEYA.prototype.append_script_to_head = function(t, e) {
    i.type = "text/javascript", i.id = e, i.src = t, i.charset = "UTF-8", i.async = !0;
    _.parentNode.insertBefore(i, _)
}, ENGAGEYA.prototype.append_link_to_head = function(t, e, i, _, s) {
    n.type = i, n.id = e, n.href = t, n.rel = _, n.async = s;
    o.parentNode.insertBefore(n, o)
}, ENGAGEYA.prototype.getQS = function(t) {
    var e = t.replace(/^[^\?]+\??/, ""),
        i = new Object;
    if (!e) return i;
    for (var _ = e.split(/[;&]/), s = 0; s < _.length; s++) {
        for (var n = _[s].replace(/(pid=.*)=.*/, "$1"), o = _[s].length - n.length, a = 0; a < o; a++) n += "%3D";
        var r, d, l = n.split(/=(.*)/);
        !l || l.length < 2 || (r = unescape(l[0]), d = (d = l[1]).replace(/\+/g, " "), i[r] = d)
    }
    return i
}, ENGAGEYA.prototype.inj_init_binding = function(t) {
        try {
        } catch (t) {}
            } catch (t) {
                setTimeout(e, 10)
            }
        })
    }
}, ENGAGEYA.prototype.in_array = function(t, e) {
    for (var i in e)
        if (e[i] == t) return !0;
    return !1
};
var _eng_do_async_click = function(t) {
    },
    _eng_fire_async_pixels = function(t) {
        if (t)
            for (var e = t.split(","), i = 0; i < e.length; i++) {
                var _ = e[i],
                s.src = _;
                try {
                } catch (t) {
                }
            }
    };
ENGAGEYA.prototype.fire_real_impression_pixels = function() {
            try {
            } catch (t) {}
            try {
            } catch (t) {
            }
        }
    }, ENGAGEYA.prototype.fire_real_impression_js_pixels = function() {
        } catch (t) {
        }
    }, ENGAGEYA_VIDEO.prototype.attach_widget_events = function() {
        try {
                t.get_videojs_obj().dispose(), t.close_video()
            })
        }
    }, ENGAGEYA.prototype.posts_exclusion_box_events = function() {
            var e = n.jq(this).parents(".eng_widget_sw");
            e.find(".eng_excludebox_question,.eng_user_exclude_btn").css("display", "none");
            var i = e.find(".eng_excludebox_wrapper");
            i.css("height", "100px"), e.find(".eng_excludebox_question_main").html(n.exclude_posts_box_default_thank_you), i.delay(2500).fadeOut(500, function() {});
            var _ = i.attr("data-id"),
                s = n.jq(this).val();
            n.fire_exclude_event(_, s)
            t.preventDefault();
            var e = n.jq(this).parents(".eng_widget_sw");
            n.jq(this).hasClass("eng_user_undo_btn") ? (n.jq(this).toggleClass("eng_user_undo_btn"), e.find(".eng_excludebox_wrapper").css("display", "none"), e.find(".eng_widget_in,.eng_widget_img").css("opacity", "1"), n.jq(this).text("")) : (n.jq(this).toggleClass("eng_user_undo_btn"), e.find(".eng_excludebox_wrapper").css("display", "block"), e.find(".eng_widget_in,.eng_widget_img").css("opacity", "0.3"), n.jq(this).text("Undo"))
        }))
    }, ENGAGEYA.prototype.fire_exclude_event = function(t, e) {
        var i;
    }, ENGAGEYA_VIDEO.prototype.visibility_load_video_js_event = function(t) {
    }, ENGAGEYA_VIDEO.prototype.visibility_play_video_event = function(t) {
                _.play_video(_)
            }, 150)
        }
    }, ENGAGEYA_VIDEO.prototype.handle_video_widget_visibility = function() {
    }, ENGAGEYA_VIDEO.prototype.show_video_widget = function() {
            visibility: "visible",
            opacity: 0
        }).animate({
            opacity: 1
        }, 500)
    }, ENGAGEYA_VIDEO.prototype.visibility_pause_video_event = function(t) {
    }, ENGAGEYA_VIDEO.prototype.play_video = function(e) {
        try {
        }
    }, ENGAGEYA_VIDEO.prototype.pause_video = function() {
        try {
    }, ENGAGEYA_VIDEO.prototype.on_visibility_change = function(e) {
        return function() {
            var t = e.widget_wrapper_elm;
            e.visibility_load_video_js_event(t), e.is_load_videojs_called && e.populate_video_tag(), e.is_video_tag_populated && e.ads_ready && (e.visibility_pause_video_event(t), e.visibility_play_video_event(t))
        }
    }, ENGAGEYA_VIDEO.prototype.set_window_active = function(t) {
        return function() {
        }
    }, ENGAGEYA_VIDEO.prototype.set_window_blur = function(t) {
        return function() {
        }
    }, ENGAGEYA_VIDEO.prototype.load_video_view_events = function() {
            i(), t()
        }, !1), addEventListener("blur", function() {
            e(), t()
        }, !1), addEventListener("touchstart", function() {
            t()
        }, !1), addEventListener("click", function() {
            t()
            i(), t()
        }), attachEvent("onblur", function() {
            e(), t()
        })), t()
    }, ENGAGEYA_VIDEO.prototype.get_video_js_scripts = function(_) {
    }, ENGAGEYA_VIDEO.prototype.load_videojs = function() {
        }
    }, ENGAGEYA_VIDEO.prototype.is_elm_visible_conditions = function(t, e, i) {
        var _ = t.getBoundingClientRect(),
            s = Math.ceil(_.height) * e / 100,
            o = _.top < n - s && _.top + _.height >= s,
            a = _.bottom > s;
        return "above" === i ? o : "below" === i ? a : !o && !a
    }, ENGAGEYA_VIDEO.prototype.get_total_slides = function() {
        return 1
    }, ENGAGEYA_VIDEO.prototype.get_video_additional_data = function(t) {
        var e = {};
        if (!t.vMAD) return e;
        try {
        } catch (t) {
        }
        return e
    }, ENGAGEYA_VIDEO.prototype.build_layout = function() {
    }, ENGAGEYA_VIDEO.prototype.build_video_layout = function() {
        var e = t.widget.displayRows,
        for (var d, l, p, h, g, c, u, m, w, v, f, E, y, A, b, G, x, N, j = t.recs, I = "", T = 0; T < i; T++) {
                pi: d,
                pt: l
        }
    }, ENGAGEYA_VIDEO.prototype.populate_video_additional_data = function(t) {
    }, ENGAGEYA_VIDEO.prototype.get_videojs_obj = function() {
    }, ENGAGEYA_VIDEO.prototype.get_videojs_wrapper_obj = function() {
    }, ENGAGEYA_VIDEO.prototype.populate_video_tag = function() {
        try {
            if (!i[0]) return;
        }
    }, ENGAGEYA.prototype.populate_place_holders = function(t, e) {
        try {
        } catch (t) {
        }
        return e
    }, ENGAGEYA_VIDEO.prototype.populate_place_holders = function(t) {
    }, ENGAGEYA_VIDEO.prototype.get_video_rec = function() {
    }, ENGAGEYA_VIDEO.prototype.attach_mouse_move_events = function() {
    }, ENGAGEYA_VIDEO.prototype.attach_mouse_over_event = function() {
            t.is_unmute_on_mouse_over && t.is_muted && (t.get_videojs_obj().muted(!1), t.logger(t.log_types.INFO, "VIDEO UNMUTED"))
        })
    }, ENGAGEYA_VIDEO.prototype.attach_mouse_out_event = function() {
            t.is_muted && t.is_unmute_on_mouse_over && (t.get_videojs_obj().muted(!0), t.logger(t.log_types.INFO, "VIDEO MUTED"))
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ads_events = function() {
    }, ENGAGEYA_VIDEO.prototype.attach_after_ad_started_events = function() {
    }, ENGAGEYA_VIDEO.prototype.attach_ad_complete_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_COMPLETE), t.logger(t.log_types.INFO, "AD COMPLETED")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_thirdQuartile_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_THIRD_QUARTILE), t.logger(t.log_types.INFO, "AD THIRD QUARTILE")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_midpoint_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_MID_POINT), t.logger(t.log_types.INFO, "AD MID POINT")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_firstQuartile_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_FIRST_QUARTILE), t.logger(t.log_types.INFO, "AD FIRST QUARTILE")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_ended_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.ALL_ADS_COMPLETED), t.is_close_player_when_ads_completed && t.close_video(), t.logger(t.log_types.INFO, "ALL ADS COMPLETED")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_clicked_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_CLICK), t.logger(t.log_types.INFO, "AD CLICKED")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_started_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_START), t.logger(t.log_types.INFO, "AD STARTED"), t.attach_after_ad_started_events()
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ads_ready_event = function() {
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_timeout_event = function() {
            t.fire_all_relevant_pixels(t.video_event_types.AD_TIMEOUT), t.is_close_video_on_ad_timeout && t.close_video(), t.logger(t.log_types.INFO, "AD TIMEOUT")
        })
    }, ENGAGEYA_VIDEO.prototype.attach_ad_error_event = function() {
            t.ads_manager.destroy(), t.fire_all_relevant_pixels(t.video_event_types.AD_ERROR), t.is_close_video_on_ad_error && t.close_video(), t.logger(t.log_types.INFO, "AD ERROR")
        })
    }, ENGAGEYA_VIDEO.prototype.close_video = function() {
    }, ENGAGEYA_VIDEO.prototype.get_video_sources_elemets = function() {
        var t = "";
        return t
    }, ENGAGEYA_VIDEO.prototype.fire_all_relevant_pixels = function(t) {
    }, ENGAGEYA_VIDEO.prototype.fire_clicks = function(t) {
        if (e)
    }, ENGAGEYA_VIDEO.prototype.fire_click_pixels = function(t) {}, ENGAGEYA_VIDEO.prototype.get_click_defs = function(t, e) {
            s = 'onclick="' + _ + '"',
            n = (t.ajx, ""),
            o = (o = "").replace("ecs1.engageya.com/gas-api", "ecs3.engageya.com/rec-api"),
    }, ENGAGEYA_VIDEO.prototype.run_posts_preview = function() {}, ENGAGEYA_VIDEO.prototype.calc_slides_dims = function() {
    },
    function() {
        function t(t, e) {
            switch (t) {
                case "createWidget":
                    break;
                case "createVideoWidget":
                    break;
                case "createMultiWidgets":
            }
        }
            t(_[0], _[1])
        }
    }();