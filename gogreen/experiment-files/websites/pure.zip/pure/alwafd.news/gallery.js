var GPlusGallery = (function($) {
    var $nz = function(value, defaultvalue) {
        if (typeof(value) === undefined || value == null) {
            return defaultvalue;
        }
        return value;
    };
    var calculateCutOff = function(len, delta, items) {
        var cutoff = [];
        var cutsum = 0;
        for (var i in items) {
            var item = items[i];
            var fractOfLen = item.twidth / len;
            cutoff[i] = Math.floor(fractOfLen * delta);
            cutsum += cutoff[i];
        }
        var stillToCutOff = delta - cutsum;
        while (stillToCutOff > 0) {
            for (i in cutoff) {
                cutoff[i]++;
                stillToCutOff--;
                if (stillToCutOff == 0) break;
            }
        }
        return cutoff;
    };
    var buildImageRow = function(maxwidth, items) {
        var row = [],
            len = 0;
        var marginsOfImage = 6;
        while (items.length > 0 && len < maxwidth) {
            var item = items.shift();
            row.push(item);
            len += (item.twidth + marginsOfImage);
        }
        var delta = len - maxwidth;
        if (row.length > 0 && delta > 0) {
            var cutoff = calculateCutOff(len, delta, row);
            for (var i in row) {
                var pixelsToRemove = cutoff[i];
            }
        } else {
            for (var i in row) {
            }
        }
        return row;
    };
    var createImageElement = function(parent, item) {
        var imageContainer = $('<li class="preview"/>');
        var overflow = $('<div/>');
        overflow.css("width", "" + $nz(item.vwidth, 180) + "px");
        overflow.css("height", "" + $nz(item.theight, 180) + "px");
        overflow.css("overflow", "hidden");
        var link = $('<a class="trigger" href="#"/>');
        var img = $('<img/>');
        img.attr("title", item.title);
        img.css("width", "" + $nz(item.twidth, 180) + "px");
        img.css("height", "" + $nz(item.theight, 180) + "px");
        img.css("margin-left", "" + (item.vx ? (-item.vx) : 0) + "px");
        img.css("margin-top", "" + 0 + "px");
        img.hide();
        link.append(img);
        overflow.append(link);
        imageContainer.append(overflow);
        var entry = $('<div class="entry"/>');
        var close = $('<div class="close_button"/>');
        var closelink = $('<a class="close" href="#"/>');
        closelink.append('&times;');
        close.append(closelink);
        var content = $('<div class="content"/>');
        var bigdiv = $('<div class="bigdiv"/>');
        var middlediv = $('<div class="middlediv"/>');
        bigdiv.append(middlediv);
        var imgdiv = $('<div class="imgdiv"/>');
        imgdiv.css("height", "" + item.height + "px");
        imgdiv.css("background-size", "contain");
        imgdiv.attr("data-image-url", item.imageUrl);
        imgdiv.attr("data-image-title", item.title);
        imgdiv.attr("data-image-height", item.height);
        var loadingdiv = $('<div class="loading"/>');
        imgdiv.append(loadingdiv);
        middlediv.append(imgdiv);
        var titdet = $('<div class="titdet"/>');
        var title = $('<div class="title"/>');
        title.append(item.title);
        var details = $('<div class="imagedecr"/>');
        details.append(item.description);
        var imagelinkdiv = $('<div class="imagelinkdiv"/>');
        imagelink.append("\u0639\u0631\u0636 \u0627\u0644\u0635\u0648\u0631\u0629");
        imagelinkdiv.append(imagelink);
        entry.append(close);
        titdet.append(title);
        titdet.append(details);
        titdet.append(imagelinkdiv);
        content.append(bigdiv);
        content.append(titdet);
        entry.append(content);
        img.bind("load", function() {
            $(this).fadeIn(500);
        });
        $('#og-grid').append(imageContainer);
        $('#og-grid').append(entry);
        return imageContainer;
    };
    var updateImageElement = function(item) {
        var overflow = item.el.find("div:first");
        var img = overflow.find("img:first");
        overflow.css("width", "" + $nz(item.vwidth, 180) + "px");
        overflow.css("height", "" + $nz(item.theight, 180) + "px");
        img.css("margin-left", "" + (item.vx ? (-item.vx) : 0) + "px");
        img.css("margin-top", "" + 0 + "px");
    };
    return {
        showImages: function(imageContainer, realItems) {
            var containerWidth = imageContainer.width() - 1;
            var items = realItems.slice();
            var rows = [];
            while (items.length > 0) {
                rows.push(buildImageRow(containerWidth, items));
            }
            for (var r in rows) {
                for (var i in rows[r]) {
                    var item = rows[r][i];
                    if (item.el) {
                        updateImageElement(item);
                    } else {
                        createImageElement(imageContainer, item);
                    }
                }
            }
        }
    }
    $('.litebox').liteBox({
        revealSpeed: 400,
        background: 'rgba(0,0,0,.8)',
        overlayClose: true,
        escKey: true,
        navKey: true,
        callbackInit: function() {},
        callbackBeforeOpen: function() {},
        callbackAfterOpen: function() {},
        callbackBeforeClose: function() {},
        callbackAfterClose: function() {},
        callbackError: function() {},
        callbackPrev: function() {},
        callbackNext: function() {},
        errorMessage: 'Error loading content.'
    });
})(jQuery);