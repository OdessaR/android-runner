(window.webpackJsonp = window.webpackJsonp || []).push([
    ["c778"], {
        "/ykl": function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
            }));
            var n = r("ilXw"),
                i = r.n(n);

            function o() {
                return i.a.get("china-guest-loop")
            }
        },
        "7vv6": function(e, t, r) {
            "use strict";

            function n(e, t) {
                var r = e.longTasks,
                    n = t.start,
                    i = t.end;
                return r.filter((function(e) {
                    return e.startTime > n && (!i || e.startTime < i)
                })).sort((function(e, t) {
                    return e.startTime - t.startTime
                })).map((function(e, t) {
                    return {
                        entry: e,
                        index: t
                    }
                }))
            }

            function i(e, t) {
                return n(e, t).reduce((function(e, t) {
                    return e + t.entry.duration - 50
                }), 0)
            }

            function o(e) {
                var t = e.ttfcp;
                return i(e, {
                    start: void 0 === t ? 0 : t
                })
            }

            function a(e, t) {
                var r = e.ttfcp;
                if (void 0 !== t) return i(e, {
                    start: void 0 === r ? 0 : r,
                    end: t
                })
            }

            function s(e, t) {
                var r = e.ttfcp,
                    n = void 0 === r ? 0 : r;
                if (void 0 !== t) return i(e, {
                    start: Math.max(t, n)
                })
            }

            function c(e) {
                var t = e.ttfcp,
                    r = void 0 === t ? 0 : t,
                    i = n(e, {
                        start: r
                    });
                if (0 !== i.length) return n(e, {
                    start: r
                }).reduce((function(e, t) {
                    return t.entry.duration > e.entry.duration ? t : e
                }), i[0])
            }

            function u(e) {
                var t = c(e);
                if (t) return t.entry.duration - 50
            }

            function l(e) {
                var t;
                return null === (t = c(e)) || void 0 === t ? void 0 : t.index
            }
            r.d(t, "e", (function() {
            })), r.d(t, "d", (function() {
            })), r.d(t, "c", (function() {
            })), r.d(t, "b", (function() {
            })), r.d(t, "a", (function() {
            }))
        },
        F52i: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            })), r.d(t, "b", (function() {
                return i
            })), r.d(t, "c", (function() {
                return o
            }));
            var n = "FMP-target",
                i = "hydrate-meaningful-element",
                o = "hydrate-performance-hoc"
        },
        ItxH: function(e, t, r) {
            "use strict";

            function n() {
                    case "visible":
                        return 1;
                    case "hidden":
                        return 2;
                    case "prerender":
                        return 3;
                    default:
                        return 4
                }
            }
            r.d(t, "a", (function() {
            }))
        },
        acAX: function(e, t, r) {
            "use strict";
            r.d(t, "d", (function() {
            })), r.d(t, "k", (function() {
            })), r.d(t, "j", (function() {
            })), r.d(t, "h", (function() {
            })), r.d(t, "q", (function() {
            })), r.d(t, "r", (function() {
            })), r.d(t, "c", (function() {
            })), r.d(t, "n", (function() {
            })), r.d(t, "i", (function() {
            })), r.d(t, "f", (function() {
            })), r.d(t, "o", (function() {
            })), r.d(t, "p", (function() {
            })), r.d(t, "g", (function() {
            })), r.d(t, "m", (function() {
            })), r.d(t, "l", (function() {
            })), r.d(t, "e", (function() {
            })), r.d(t, "a", (function() {
            })), r.d(t, "b", (function() {
            }));
            var n = function() {
            };

            function i() {
            }
            var o = {
                android: /Android/i,
                iphone: /iPhone|iPod/,
                ipad: /iPad/,
                webview: /Airbnb/,
                wechatBrowser: /micromessenger/i,
                chrome: /Chrome/i,
                firefox: /Firefox/i,
                bot: /bot|spider|facebookexternalhit|twitterbot|linkedinbot|googlebot|bingbot|msnbot|yandexbot|slurp|baiduspider/i,
                googleVendor: /Google/i,
                mafengwo: /mafengwo/i,
                alipay: /aliapp/i,
                ucbrowser: /ucbrowser/i,
                ucbrowserU3: /ucbrowser.* u3\//i,
                cmblife: /cmblife/i,
                msie: /msie/i,
                msieAlt: /Trident/i,
                msedge: /Edge/i,
                facebook: /FBAN|FBAV/i,
                qqAppBrowser: /QQ/i,
                safari: /Safari/i,
                weibo: /weibo/i,
                mailapp: /mailapp/i,
                baidu: /baiduboxapp/i,
                validFirefox: /Firefox\/[5-9][0-9]/i
            };

            function a() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.android.test(e)
            }

            function s() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.iphone.test(e)
            }

            function c() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.ipad.test(e)
            }

            function u() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return s(e) || c(e)
            }

            function l() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.webview.test(e)
            }

            function d() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.wechatBrowser.test(e)
            }

            function f() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.mafengwo.test(e)
            }

            function h() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.alipay.test(e)
            }

            function p() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.cmblife.test(e)
            }

            function m() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.ucbrowser.test(e)
            }

            function v() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.qqAppBrowser.test(e)
            }

            function b() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.ucbrowserU3.test(e)
            }

            function g() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n(),
                    t = "test_private_safari";
                try {
                } catch (t) {
                    if (e && e.includes("Safari")) return !0
                }
                return !1
            }

            function _() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && u(e) && e.includes("CriOS")
            }

            function w() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n(),
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i();
                return !!e && o.chrome.test(e) && !!t && o.googleVendor.test(t) || _(e)
            }

            function y() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && (u(e) && !e.includes("CriOS") && !o.wechatBrowser.test(e) && !o.alipay.test(e) && !o.weibo.test(e) && !o.mailapp.test(e) && !o.baidu.test(e) && !o.qqAppBrowser.test(e) && !o.ucbrowser.test(e))
            }

            function P() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && !o.chrome.test(e) && o.safari.test(e)
            }

            function T() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.firefox.test(e)
            }

            function M() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && (o.msie.test(e) || o.msieAlt.test(e))
            }

            function O() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && o.msedge.test(e)
            }

            function k() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && T(e) && !o.validFirefox.test(e)
            }

            function S() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n();
                return !!e && (o.bot.test(e) || k(e))
            }

            function C() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n(),
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i();
                return d(e) ? "wechatBrowser" : h(e) ? "alipayAppBrowser" : f(e) ? "mfwBrowser" : p(e) ? "cmbLifeBrowser" : m(e) ? "ucBrowser" : b(e) ? "ucBrowserU3" : l(e) ? "webview" : w(e, t) ? "chrome" : T(e) ? "firefox" : M(e) ? "msie" : O(e) ? "msedge" : g(e) ? "privateSafari" : y(e) ? "safari" : "other"
            }

            function F() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : n(),
                    t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : i();
                if (S(e)) return "bot";
                var r = C(e, t);
                return a(e) ? "".concat(r, "_android") : u(e) ? "".concat(r, "_ios") : r
            }
        },
        iljR: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
            }));
            var n = {
                transfer_size: 0,
                encodedbody_size: 0,
                decodedbody_size: 0,
                count: 0,
                cache_hit_ratio: 0
            };

            function i(e) {
                var t, r, i, o, a, s = e.resources;
                if (!(0 === s.length || s.length > 0 && void 0 === s[0].decodedBodySize)) {
                    var c, u, l = ["link", "img", "css", "script", "other"],
                        d = [{
                            type: "css",
                            initiatorList: ["link"],
                            regex: /.+(muscache|localhost).+\.css(\?.*)?$/
                        }, {
                            type: "img",
                            initiatorList: ["img", "css"],
                            regex: /.+(muscache|localhost).+(jpg|png|gif|webp)(\?.*)?$/
                        }, {
                            type: "js",
                            category: "airbnb",
                            initiatorList: ["link", "script"],
                            regex: /.+(muscache|localhost).+\.m?(js|bundle)(\?.*)?$/
                        }, {
                            type: "js",
                            category: "third_party",
                            initiatorList: ["link", "script"],
                            regex: /^((?!(muscache|localhost)).)*\.m?js(\?.*)?$/
                        }, {
                            type: "font",
                            initiatorList: ["link", "css", "other"],
                            regex: /^.+(muscache|localhost).+\.woff2(\?.*)?$/
                        }],
                        f = {
                            css: Object.assign({}, n),
                            js: {
                                airbnb: Object.assign({}, n),
                                third_party: Object.assign({}, n)
                            },
                            img: Object.assign({}, n),
                            font: Object.assign({}, n)
                        };
                    if (s.filter((function(e) {
                            var t = e.initiatorType;
                            return l.includes(t)
                        })).forEach((function(e) {
                            var t = e.name,
                                r = e.initiatorType,
                                n = e.decodedBodySize,
                                i = e.transferSize,
                                o = e.encodedBodySize;
                            d.find((function(e) {
                                var a = e.type,
                                    s = e.initiatorList,
                                    c = e.regex,
                                    u = e.category;
                                if (s.includes(r) && t.match(c)) {
                                    var l = u ? f[a][u] : f[a],
                                        d = l.count * l.cache_hit_ratio + (0 === i ? 1 : 0);
                                    return l.count += 1, l.cache_hit_ratio = d ? d / l.count : 0, l.transfer_size += i, l.encodedbody_size += o, l.decodedbody_size += n, !0
                                }
                                return !1
                            }))
                        })), f.css = (null === (t = f.css) || void 0 === t ? void 0 : t.count) ? f.css : void 0, null === (r = f.js) || void 0 === r || null === (i = r.airbnb) || void 0 === i ? void 0 : i.count) 0 === (null === (c = f.js) || void 0 === c || null === (u = c.third_party) || void 0 === u ? void 0 : u.count) && (f.js.third_party.cache_hit_ratio = 1);
                    else f.js = void 0;
                    if (f.img = (null === (o = f.img) || void 0 === o ? void 0 : o.count) ? f.img : void 0, f.font = (null === (a = f.font) || void 0 === a ? void 0 : a.count) ? f.font : void 0, Object.values(f).find((function(e) {
                            return !!e
                        }))) return f
                }
            }
        },
        lqUL: function(e, t, r) {
            "use strict";
            var n = r("Y195"),
                i = r("g8Fj"),
                o = r("ANar"),
                a = r("acAX"),
                s = r("lVss"),
                c = r("wO/7");
                    pauseStart: 0,
                    pauseDuration: 0,
                    pausePending: !1
                    var r = e.performanceRecorders[e.performanceRecorders.length - 1];
                    r && (r.universalPageName = t.universalPageName, r.impressionUuid = t.impressionUuid, r.eventData = t.eventData, r.eventDataSchema = t.eventDataSchema, r.isDirectRequest || r.setTTFCP(t.timestampOfFCP))
                    t.listen(e.onHistoryChange)
                    e.ignorePathnameUpdate = t
                    e.ignorePathnameUpdate = void 0
                    e.includeHistoryUpdate = t
                    e.includeHistoryUpdate = void 0
                    e.nextPageCreatedAt = Object(s.b)().now()
                    e.pauseInfo.pausePending = !0, e.pauseInfo.pauseStart = Object(s.b)().now()
                    e.pauseInfo.pausePending = !1, e.pauseInfo.pauseDuration += Object(s.b)().now() - e.pauseInfo.pauseStart, e.pauseInfo.pauseStart = 0
                    var r = t.isDirectRequest,
                        n = e.performanceRecorders[e.performanceRecorders.length - 1];
                    n && n.retire();
                    var i = e.getNextPageCreatedAt();
                    e.performanceRecorders.push(new c.a({
                        isDirectRequest: r,
                        pageCreatedAt: i
                    }))
                    var t;
                    var n = t.pathname,
                        i = t.search;
                    e.isPageTransition({
                        action: r,
                        prevPathname: e.currentPathname,
                        prevSearch: e.currentSearch,
                        nextPathname: n,
                        nextSearch: i
                    }) && (e.flushAllEvents(), e.createNewRecorder({
                        isDirectRequest: !1
                    })), e.currentPathname = n, e.currentSearch = i
                    if ("function" == typeof e.includeHistoryUpdate) return e.includeHistoryUpdate(t);
                    var r = t.action,
                        n = t.prevPathname,
                        i = t.nextPathname;
                    return !(!n || !i) && (n !== i && (("function" != typeof e.ignorePathnameUpdate || !e.ignorePathnameUpdate(n, i)) && ["POP", "PUSH", "REPLACE"].includes(r)))
                    Object(a.e)() || (e.performanceRecorders.forEach((function(e) {
                        e.retired || e.retire(), i.a.queueJitneyEvent({
                            schema: n.a,
                            event_data: {
                                assets: e.unthrottleableMetrics.assets,
                                page_request_method: e.pageRequestMethod,
                                universal_page_name: e.universalPageName,
                                impression_uuid: e.impressionUuid,
                                ttfcp: e.throttleableMetrics.ttfcp,
                                ttfmp: e.throttleableMetrics.ttfmp,
                                fid: e.throttleableMetrics.fid,
                                tbt: e.throttleableMetrics.totalBlockingTime,
                                event_data: e.eventData,
                                event_data_schema: e.eventDataSchema,
                                domain_and_path: e.domainAndPath,
                                network_information: e.networkInformation,
                                web_performance_timing: e.throttleableMetrics.webPerformanceTiming,
                                tbt_pre_hydrate: e.throttleableMetrics.tbtPreHydrate,
                                tbt_post_hydrate: e.throttleableMetrics.tbtPostHydrate,
                                time_to_hydrate: e.throttleableMetrics.timeToHydrate,
                                recorder_duration: e.throttleableMetrics.recorderDuration,
                                time_to_fid: e.throttleableMetrics.timeToFid,
                                number_of_blocking_tasks: e.throttleableMetrics.numberOfBlockingTasks,
                                longest_blocking_time: e.throttleableMetrics.longestBlockingTime,
                                longest_blocking_task_index: e.throttleableMetrics.longestBlockingTaskIndex,
                                cumulative_layout_shift: e.unthrottleableMetrics.cumulativeLayoutShift,
                                lcp: e.throttleableMetrics.lcp
                            }
                        })
                    })), e.performanceRecorders = [], i.a.getLogger().flushEventQueue())
                    isDirectRequest: !0
            }
        },
        r5zi: function(e, t, r) {
            "use strict";
            (function(e) {
                r.d(t, "b", (function() {
                })), r.d(t, "c", (function() {
                })), r.d(t, "a", (function() {
                })), r.d(t, "d", (function() {
                }));
                var n, i = r("8dvS"),
                    o = r.n(i),
                    a = r("ilXw"),
                    s = r.n(a),
                    c = r("Q/Zp"),
                    u = r("/ykl"),
                    l = r("lVss");

                function d() {
                        return !(!e || !e.active)
                    })).catch((function() {
                        return !1
                    })) : Promise.resolve(!1)).then((function(t) {
                        if (!t) return !1;
                        var r = e.window && Object(l.b)();
                        if (!r || !r.getEntriesByType) return !1;
                        var n = r.getEntriesByType("navigation");
                        if (!n || 0 === n.length) return !1;
                        var i = n[0].serverTiming;
                        return !(!i || 0 === i.length) && i.filter((function(e) {
                            return "serviceWorker" === e.name
                        })).length > 0
                    })).catch((function() {
                        return !1
                    }));
                    var t
                }

                function f(e) {
                    return d().then((function(t) {
                        return e ? Promise.resolve(2) : t ? Promise.resolve(4) : 1 === n ? Promise.resolve(5) : Promise.resolve(1)
                    }))
                }

                function h() {
                    return {
                        www_cdn_provider: s.a.get("wwwCdnProvider") || "Unknown"
                    }
                }

                function p() {
                        return {
                            effective_type: e.effectiveType,
                            rtt: e.rtt,
                            downlink: e.downlink
                        }
                    }
                }

                function m() {
                        return {
                            navigation_start_timestamp_in_ms: e.navigationStart,
                            time_to_redirect_start_in_ms: e.redirectStart,
                            time_to_redirect_end_in_ms: e.redirectEnd,
                            time_to_fetch_start_in_ms: e.fetchStart,
                            time_to_domain_lookup_start_in_ms: e.domainLookupStart,
                            time_to_domain_lookup_end_in_ms: e.domainLookupEnd,
                            time_to_connect_start_in_ms: e.connectStart,
                            time_to_connect_end_in_ms: e.connectEnd,
                            time_to_secure_connection_start_in_ms: e.secureConnectionStart,
                            time_to_request_start_in_ms: e.requestStart,
                            time_to_response_start_in_ms: e.responseStart,
                            time_to_response_end_in_ms: e.responseEnd,
                            time_to_dom_loading_in_ms: e.domLoading,
                            time_to_dom_interactive_in_ms: e.domInteractive,
                            time_to_dom_content_loaded_event_start_in_ms: e.domContentLoadedEventStart,
                            time_to_dom_content_loaded_event_end_in_ms: e.domContentLoadedEventEnd,
                            time_to_dom_complete_in_ms: e.domComplete,
                            time_to_load_event_start_in_ms: e.loadEventStart,
                            time_to_load_event_end_in_ms: e.loadEventEnd
                        }
                    }
                }(function() {
                    if (!Object(u.a)()) {
                            var i = t.slice(0, r);
                            o()("cache_state", -1, {
                                expires: -1,
                                domain: Object(c.a)(),
                                path: "".concat(i, "/")
                            }), r = i.lastIndexOf("/")
                        }
                        if ("0" === e) n = 2;
                        else if ("1" === e) n = 1;
                        else {
                            var a = Date.now(),
                                l = (s.a.get("layout-init") || {}).tracking_context,
                                d = void 0 === l ? null : l;
                            if (d && d.action && d.action.includes("app_shell")) return;
                            var f = s.a.get("pageGeneratedAt") || a;
                            n = a - f > 6e5 ? 1 : 3
                        }
                    }
                })()
            }).call(this, r("yLpj"))
        },
        "wO/7": function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return l
            }));
            var n = r("lVss"),
                i = r("6Tiy"),
                o = r("ItxH"),
                a = r("r5zi"),
                s = r("7vv6"),
                c = r("iljR"),
                u = r("F52i"),
                l = function(e) {
                        r = e.isDirectRequest,
                        l = e.pageCreatedAt;
                        longTasks: []
                        assets: {},
                        resources: []
                        t.listenForResources(), t.listenForCLS()
                        t.listenForFCP(), t.listenForFMP(), t.listenForFID(), t.listenForLongTasks(), t.listenForLCP(), t.throttleableMetrics.webPerformanceTiming = Object.assign({}, Object(a.c)(), t.isDirectRequest && Object(a.d)())
                        t.retired || t.throttleableMetrics.ttfcp || (t.throttleableMetrics.ttfcp = e - t.createdAt, t.isClientSideRequest && (t.performance.mark("TTFCP_END"), t.performance.measure("TTFCP", "CSR_PAGE_START", "TTFCP_END")), t.showLogs && t.consoleLogMetrics())
                        t.retired || (t.throttleableMetrics.ttfmp = e - t.createdAt, t.isClientSideRequest && (t.performance.mark("TTFMP_END"), t.performance.measure("TTFMP", "CSR_PAGE_START", "TTFMP_END")), t.showLogs && t.consoleLogMetrics())
                        if (!t.retired) {
                            t.throttleableMetrics.fid = e;
                            var n = r.timeStamp - t.createdAt;
                            n >= 0 && (t.throttleableMetrics.timeToFid = n), t.showLogs && t.consoleLogMetrics()
                        }
                        if (t.supportsPerformanceObserverWithType("longtask")) try {
                                var r;
                            })), t.longTaskObserver.observe({
                                type: "longtask",
                                buffered: t.isDirectRequest
                            })
                        } catch (e) {}
                        if (t.longTaskObserver) {
                            var e;
                            t.throttleableMetrics.totalBlockingTime = Object(s.e)(t.throttleableMetrics), t.throttleableMetrics.longestBlockingTime = Object(s.b)(t.throttleableMetrics), t.throttleableMetrics.longestBlockingTaskIndex = Object(s.a)(t.throttleableMetrics), t.throttleableMetrics.tbtPreHydrate = Object(s.d)(t.throttleableMetrics, t.calculateTimeToHydrate()), t.throttleableMetrics.tbtPostHydrate = Object(s.c)(t.throttleableMetrics, t.calculateTimeToHydrate()), t.throttleableMetrics.numberOfBlockingTasks = t.throttleableMetrics.longTasks.length, t.longTaskObserver.disconnect()
                        }
                            return e.startTime > t.createdAt
                        }));
                        if (0 !== e.length) return e.reduce((function(e, t) {
                            return e.startTime < t.startTime ? e : t
                        }), e[0]).startTime - t.createdAt
                        if (t.supportsPerformanceObserverWithType("layout-shift")) try {
                                type: "layout-shift",
                                buffered: t.isDirectRequest
                            })
                        } catch (e) {}
                        e.getEntries().forEach((function(e) {
                            e.hadRecentInput || (t.unthrottleableMetrics.cumulativeLayoutShift = t.unthrottleableMetrics.cumulativeLayoutShift || 0, t.unthrottleableMetrics.cumulativeLayoutShift += e.value, t.showLogs && t.consoleLogMetrics())
                        }))
                        t.clsObserver && ("function" == typeof t.clsObserver.takeRecords && t.clsObserver.takeRecords(), t.clsObserver.disconnect())
                        if (t.supportsPerformanceObserverWithType("resource")) try {
                                var r;
                            })), t.resourcesObserver.observe({
                                type: "resource",
                                buffered: t.isDirectRequest
                            })
                        } catch (e) {}
                        if (t.resourcesObserver) {
                            var e;
                            t.unthrottleableMetrics.assets = Object(c.a)({
                                resources: t.unthrottleableMetrics.resources
                            }), t.resourcesObserver.disconnect()
                        }
                        if (!t.isClientSideRequest && t.supportsPerformanceObserverWithType("largest-contentful-paint")) try {
                                e.getEntries().forEach(t.updateLCP)
                            })), t.lcpObserver.observe({
                                type: "largest-contentful-paint",
                                buffered: !0
                            })
                        } catch (e) {}
                        t.throttleableMetrics.lcp = e.startTime
                        t.lcpObserver && ("function" == typeof t.lcpObserver.takeRecords && t.lcpObserver.takeRecords().forEach(t.updateLCP), t.lcpObserver.disconnect())
                        var e = t.throttleableMetrics,
                            r = e.ttfcp,
                            n = e.ttfmp,
                            i = e.fid,
                            o = t.unthrottleableMetrics.cumulativeLayoutShift;
                        return (t ? "number" == typeof e ? "".concat(e.toFixed(2)) : "n/a" : e ? "".concat(Math.round(e).toLocaleString(), " ms") : "...").padStart(9, " ")
                        t.pageRequestMethod = e
                }
        }
    }
]);
//# sourceMappingURL=https://sourcemaps.d.musta.ch/airbnb/static/packages/c778-3c7c6c39.js.map