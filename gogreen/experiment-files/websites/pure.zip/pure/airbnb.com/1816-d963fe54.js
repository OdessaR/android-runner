(window.webpackJsonp = window.webpackJsonp || []).push([
    ["1816"], {
        "03jR": function(t, e, i) {
            "use strict";
            i.d(e, "k", (function() {
            })), i.d(e, "e", (function() {
            })), i.d(e, "c", (function() {
            })), i.d(e, "f", (function() {
            })), i.d(e, "a", (function() {
            })), i.d(e, "g", (function() {
            })), i.d(e, "d", (function() {
            })), i.d(e, "i", (function() {
            })), i.d(e, "n", (function() {
            })), i.d(e, "m", (function() {
            })), i.d(e, "b", (function() {
            })), i.d(e, "j", (function() {
            })), i.d(e, "h", (function() {
            })), i.d(e, "l", (function() {
            }));
            var n = i("cVPA"),
                a = i.n(n),
                o = i("Zi2E"),
                s = i("g8Fj"),
                c = i("wr5J"),
                r = i("D23X"),
                u = i("/D1r"),
                l = i("+fTD"),
                d = i("66eZ"),
                f = i("4DVv"),
                v = i("UA+1"),
                b = i("vXEq"),
                p = i("5jil"),
                h = i("FIkG"),
                y = i("1yGf"),
                _ = i("V/gg"),
                m = i("joRx"),
                g = i("irGw"),
                w = i("tlpZ"),
                O = i("sRqL");

            function T(t) {
                return {
                    type: v.v,
                    payload: t
                }
            }

            function I(t, e, i, n, a, o) {
                var s;
                switch (i) {
                    case _.a.LISTING:
                        Object(g.a)({
                            operation: "click",
                            sub_event: "add",
                            listing_id: e,
                            wishlist_id: t,
                            wishlisting_from: n
                        }), s = h.a.createWishlistedListing(t, e);
                        break;
                    case _.a.EXPERIENCE:
                        Object(g.a)({
                            operation: "click",
                            sub_event: "add",
                            experience_id: e,
                            wishlist_id: t,
                            wishlisting_from: n
                        }), s = h.a.createCollectionMtTemplate(t, e);
                        break;
                    case _.a.PLACE:
                        s = h.a.createCollectionPlace(t, e);
                        break;
                    case _.a.ACTIVITY:
                        s = h.a.createCollectionActivity(t, e);
                        break;
                    case _.a.STORY:
                        s = h.a.createCollectionStory(t, e);
                        break;
                    default:
                        s = Promise.resolve()
                }
                return function(u, b) {
                    u({
                        type: v.u,
                        promise: s,
                        meta: {
                            listId: t,
                            entityId: e,
                            entityType: i,
                            onFailure: function(t) {
                                var e = b().saveToListModal.visible;
                                !o || !t || e && Object(d.a)() ? o && t && Object(d.a)() && u(T(t)) : u(S(t))
                            },
                            onSuccess: function() {
                                var s = b().saveToListModal.visible;
                                Object(f.b)(), y.a.putListIdForCurrentSavedSearch(t), o && (s && Object(d.a)() || u(k(o, (function() {
                                    o.id && (Object(d.a)() ? Object(r.b)("/wishlists/".concat(o.id)) : (u(j(o.id, e, i, n)), u(C(a, e, i, n)), u(J({
                                        newToastVisible: !1
                                    }))))
                                }))), Object(l.a)() && c.default.emit("simpleHeader:refetchContent"))
                            }
                        }
                    })
                }
            }

            function j(t, e, i, n) {
                var a = Promise.resolve();
                switch (i) {
                    case _.a.LISTING:
                        Object(g.a)({
                            operation: "click",
                            sub_event: "remove",
                            listing_id: e,
                            wishlist_id: t,
                            wishlisting_from: n
                        }), a = h.a.removeWishlistedListing(t, e);
                        break;
                    case _.a.EXPERIENCE:
                        a = h.a.removeCollectionMtTemplate(t, e);
                        break;
                    case _.a.PLACE:
                        a = h.a.removeCollectionPlace(t, e);
                        break;
                    case _.a.ACTIVITY:
                        a = h.a.removeCollectionActivity(t, e);
                        break;
                    case _.a.STORY:
                        a = h.a.removeCollectionStory(t, e);
                        break;
                    default:
                        a = Promise.resolve()
                }
                return function(o, s) {
                    o({
                        type: v.t,
                        promise: a,
                        meta: {
                            listId: t,
                            entityId: e,
                            entityType: i,
                            onSuccess: function() {
                                Object(f.b)();
                                var a = s().saveToListModal,
                                    c = a.visible,
                                    r = a.lastListSavedTo,
                                    u = a.entity;
                                !c && Object(d.a)() && t === (null == r ? void 0 : r.id) && o(N(r, (function() {
                                    o(A(r, u, e, i, n || ""))
                                })))
                            },
                            onFailure: function(t) {
                                var e = s().saveToListModal.visible;
                                !t || e && Object(d.a)() ? t && Object(d.a)() && o(T(t)) : o(S(t))
                            }
                        }
                    })
                }
            }

            function E(t, e, i) {
                return {
                    type: v.m,
                    payload: {
                        listing: t,
                        listingId: e,
                        savingFrom: i
                    }
                }
            }

            function C(t, e, i, n) {
                return {
                    type: v.j,
                    payload: {
                        entity: t,
                        entityId: e,
                        entityType: i,
                        savingFrom: n
                    }
                }
            }

            function L() {
                return {
                    type: v.f,
                    promise: h.a.getSaveModalLists()
                }
            }

            function S(t) {
                var e;
                return J({
                    message: null == t || null === (e = t.responseJSON) || void 0 === e ? void 0 : e.error_message,
                    subtitle: void 0,
                    actionText: void 0,
                    onActionPress: void 0,
                    newToastVisible: !0,
                    status: void 0,
                    listHref: void 0
                })
            }

            function k(t, e) {
                return J({
                    message: a.a.t("wish_list.button.saved_to_wish_list_name", {
                        wish_list: t.name
                    }),
                    subtitle: Object(O.a)(t.checkin, t.checkout, {
                        forSaveToList: !0
                    }),
                    actionText: Object(d.a)() ? a.a.t("wish_list.button.open_list") : a.a.t("wish_list.button.change_wish_list"),
                    onActionPress: e,
                    newToastVisible: !0,
                    status: Object(d.a)() ? void 0 : w.b.CHANGE,
                    listHref: "/wishlists/".concat(t.id)
                })
            }

            function A(t, e, i, n, a) {
                return function(o, s) {
                    var c = s().saveToListModal.visible;
                    t.id && (o(I(t.id, i, n, a, e, t)), c || o(k(t, (function() {
                        t.id && (Object(d.a)() ? Object(r.b)("/wishlists/".concat(t.id)) : (o(j(t.id, i, n, a)), o(C(e, i, n, a)), o(J({
                            newToastVisible: !1
                        }))))
                    }))))
                }
            }

            function P(t, e, i, n, a, o) {
                return function(s, u) {
                    s(function(t) {
                        var e = t.listName,
                            i = t.entity,
                            n = t.entityId,
                            a = t.entityType,
                            o = t.savingFrom,
                            s = t.dispatch,
                            u = t.getState,
                            b = t.dedupeByName,
                            m = void 0 !== b && b,
                            O = t.filters,
                            I = t.finishCreating,
                            E = new Promise((function(t, f) {
                                var b, y = function(e) {
                                    h.a.getSaveModalList(e).then((function(f) {
                                        Object(d.a)() && u().saveToListModal.visible ? s({
                                            type: v.a,
                                            payload: {
                                                listId: e,
                                                change: w.a.ADDED
                                            }
                                        }) : s(k(f, (function() {
                                            f.id && (Object(d.a)() ? Object(r.b)("/wishlists/".concat(f.id)) : (s(j(f.id, n, a, o)), s(C(i, n, a, o)), s(J({
                                                newToastVisible: !1
                                            }))))
                                        }))), I && I(), Object(l.a)() && c.default.emit("simpleHeader:refetchContent"), t({
                                            list: f,
                                            entityType: a
                                        })
                                    })).catch(f)
                                };
                                O && (b = {
                                    checkin: O.checkin,
                                    checkout: O.checkout
                                });
                                b = Object(p.a)(), h.a.createList(Object.assign({}, b, {
                                    name: e,
                                    isPrivate: !0
                                }), "save_modal", "for_web_save_modal", m).then((function(t) {
                                    var e = t.id;
                                    if (e) switch (a) {
                                        case _.a.LISTING:
                                            h.a.createWishlistedListing(e, n).then((function() {
                                                y(e)
                                            })).catch(f);
                                            break;
                                        case _.a.EXPERIENCE:
                                            h.a.createCollectionMtTemplate(e, n).then((function() {
                                                y(e)
                                            })).catch(f);
                                            break;
                                        case _.a.PLACE:
                                            h.a.createCollectionPlace(e, n).then((function() {
                                                y(e)
                                            })).catch(f);
                                            break;
                                        case _.a.ACTIVITY:
                                            h.a.createCollectionActivity(e, n).then((function() {
                                                y(e)
                                            })).catch(f);
                                            break;
                                        case _.a.STORY:
                                            h.a.createCollectionStory(e, n).then((function() {
                                                y(e)
                                            })).catch(f)
                                    }
                                })).catch(f)
                            }));
                        return {
                            type: v.d,
                            promise: E,
                            meta: {
                                onSuccess: function(t) {
                                    var e = t.list;
                                    Object(f.b)();
                                    var i = e.id;
                                    y.a.putListIdForCurrentSavedSearch(i), a === _.a.LISTING && Object(g.a)({
                                        operation: "click",
                                        sub_event: "create",
                                        listing_id: n,
                                        wishlist_id: i,
                                        wishlisting_from: o
                                    })
                                },
                                onFailure: function(t) {
                                    var e = u().saveToListModal.visible;
                                    !t || e && Object(d.a)() ? t && Object(d.a)() && s(T(t)) : s(S(t))
                                },
                                optimisticSaveListingId: n
                            }
                        }
                    }({
                        listName: t,
                        entity: e,
                        entityId: i,
                        entityType: n,
                        savingFrom: a,
                        dispatch: s,
                        getState: u,
                        finishCreating: o
                    }))
                }
            }

            function N(t, e) {
                return J({
                    message: a.a.t("wish_list.button.removed_from_wish_list_name", {
                        wish_list: t.name
                    }),
                    actionText: a.a.t("wish_list.button.undo_remove_from_wish_list"),
                    subtitle: Object(O.a)(t.checkin, t.checkout, {
                        forSaveToList: !0
                    }),
                    onActionPress: e,
                    status: w.b.UNDO,
                    newToastVisible: !0,
                    listHref: "/wishlists/".concat(t.id)
                })
            }

            function F(t, e, i, n, a, o) {
                return function(s, c) {
                    var r = c().saveToListModal.visible;
                    t.id && (a ? (s(j(t.id, i, n, o)), r || Object(d.a)() || s(N(t, (function() {
                        s(A(t, e, i, n, o))
                    })))) : s(I(t.id, i, n, o, e, t)))
                }
            }

            function V(t, e, i, n, a) {
                var o = y.a.getListIdForCurrentSavedSearch(),
                    s = t.id,
                    c = o && !i && ! function(t, e, i) {
                        var n = e && e.find((function(e) {
                            return e.id === t
                        }));
                        return Object(b.b)(n, i)
                    }(o, e, _.a.ACTIVITY);
                return function(e) {
                    e(n ? c ? I(o, s, _.a.ACTIVITY, a) : function(t, e, i) {
                        return {
                            type: v.h,
                            payload: {
                                activity: t,
                                activityId: e,
                                savingFrom: i
                            }
                        }
                    }(t, s, a) : function(t, e, i) {
                        return {
                            type: v.i,
                            payload: {
                                activity: t,
                                activityId: e,
                                savingFrom: i
                            }
                        }
                    }(t, s, a))
                }
            }

            function M(t) {
                s.a.logJitneyEvent({
                    schema: o.a,
                    event_data: {
                        logging_id: t,
                        method: "onPress",
                        uuid: "",
                        operation: 2,
                        ancestor_logging_ids: [],
                        ancestor_uuids: []
                    }
                })
            }

            function R(t, e, i, n, a) {
                var o = t.id;
                M("saves.heart.listingHeart");
                var s = (e || []).filter((function(t) {
                    var e = t.listing_ids,
                        i = void 0 === e ? [] : e;
                    return i.includes(o) || i.includes(Number(o))
                }));
                return function(e) {
                    n ? s.length > 0 && !Object(d.a)() ? (s.forEach((function(t) {
                        t.id && e(j(t.id, o, _.a.LISTING, a))
                    })), e(N(s[0], (function() {
                        e(A(s[0], t, o, _.a.LISTING, a))
                    })))) : e(E(t, o, a)) : e(function(t, e, i) {
                        return {
                            type: v.n,
                            payload: {
                                listing: t,
                                listingId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a))
                }
            }

            function D(t, e, i, n, a) {
                var o = t.id;
                M("saves.heart.experienceHeart");
                var s = (e || []).filter((function(t) {
                    var e = t.mt_template_ids,
                        i = void 0 === e ? [] : e;
                    return i.includes(o) || i.includes(Number(o))
                }));
                return function(e) {
                    n ? s.length > 0 && !Object(d.a)() ? (s.forEach((function(t) {
                        t.id && e(j(t.id, o, _.a.EXPERIENCE, a))
                    })), e(N(s[0], (function() {
                        e(A(s[0], t, o, _.a.EXPERIENCE, a))
                    })))) : e(function(t, e, i) {
                        return Object(g.a)({
                            operation: "click",
                            sub_event: "show",
                            experience_id: e,
                            wishlisting_from: i
                        }), {
                            type: v.k,
                            payload: {
                                experience: t,
                                experienceId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a)) : e(function(t, e, i) {
                        return Object(g.a)({
                            operation: "click",
                            sub_event: "show",
                            experience_id: e,
                            wishlisting_from: i
                        }), {
                            type: v.l,
                            payload: {
                                experience: t,
                                experienceId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a))
                }
            }

            function x(t, e, i, n, a) {
                var o = t.primary_place.id;
                M("saves.heart.placeHeart");
                var s = (e || []).filter((function(t) {
                    var e = t.place_ids,
                        i = void 0 === e ? [] : e;
                    return i.includes(o) || i.includes(Number(o))
                }));
                return function(e) {
                    n ? s.length > 0 && !Object(d.a)() ? (s.forEach((function(t) {
                        t.id && e(j(t.id, o, _.a.PLACE, a))
                    })), e(N(s[0], (function() {
                        e(A(s[0], t, o, _.a.PLACE, a))
                    })))) : e(function(t, e, i) {
                        return Object(g.a)({
                            operation: "click",
                            sub_event: "show",
                            place_id: e,
                            wishlisting_from: m.a.PLACES_SEARCH
                        }), {
                            type: v.o,
                            payload: {
                                place: t,
                                placeId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a)) : e(function(t, e, i) {
                        return Object(g.a)({
                            operation: "click",
                            sub_event: "show",
                            place_id: e,
                            wishlisting_from: m.a.PLACES_SEARCH
                        }), {
                            type: v.p,
                            payload: {
                                place: t,
                                placeId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a))
                }
            }

            function H(t, e, i, n, a) {
                var o = t.id,
                    s = (e || []).filter((function(t) {
                        var e = t.article_ids,
                            i = void 0 === e ? [] : e;
                        return i.includes(o) || i.includes(Number(o))
                    }));
                return function(e) {
                    n ? s.length > 0 && !Object(d.a)() ? s.forEach((function(t) {
                        t.id && e(j(t.id, o, _.a.STORY, a))
                    })) : e(function(t, e, i) {
                        return Object(g.a)({
                            operation: "click",
                            sub_event: "show",
                            story_id: e,
                            wishlisting_from: m.a.CHINA_STORIES
                        }), {
                            type: v.q,
                            payload: {
                                story: t,
                                storyId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a)) : e(function(t, e, i) {
                        return Object(g.a)({
                            operation: "click",
                            sub_event: "show",
                            story_id: e,
                            wishlisting_from: m.a.CHINA_STORIES
                        }), {
                            type: v.r,
                            payload: {
                                story: t,
                                storyId: e,
                                savingFrom: i
                            }
                        }
                    }(t, o, a))
                }
            }

            function G() {
                return function(t) {
                    t(L()), t({
                        type: v.x
                    })
                }
            }

            function Y() {
                return function(t, e) {
                    var i = e().saveToListModal.isCreatingList;
                    t({
                        type: v.c
                    }), Object(d.a)() && (i || t((function(t, e) {
                        var i, n = e().saveToListModal,
                            o = n.entity,
                            s = n.entityId,
                            c = n.entityType,
                            l = n.lists,
                            d = n.listsChangedWhileModalOpen,
                            f = n.savingFrom,
                            v = !1;
                        if (s && c) {
                            for (var b = 0; b < (l || []).length && !v; b += 1) {
                                var p = (l || [])[b];
                                if (null == p ? void 0 : p.id) {
                                    var h = d[p.id];
                                    if (h) {
                                        var y = Object(u.a)(s, c, p);
                                        (y && h === w.a.ADDED || !y && h === w.a.REMOVED) && (i ? v = !0 : i = p)
                                    }
                                }
                            }
                            i && i.id && (v ? t(J({
                                message: a.a.t("wish_list.button.lists_updated"),
                                subtitle: void 0,
                                actionText: a.a.t("wish_list.button.go_to_saved"),
                                onActionPress: function() {
                                    Object(r.b)("/wishlists")
                                },
                                newToastVisible: !0,
                                status: void 0,
                                listHref: "/wishlists"
                            })) : d[i.id] === w.a.ADDED ? t(k(i, (function() {
                                var t;
                                Object(r.b)("/wishlists/".concat(null === (t = i) || void 0 === t ? void 0 : t.id))
                            }))) : d[i.id] === w.a.REMOVED && t(N(i, (function() {
                                i && t(A(i, o, s, c, f || ""))
                            }))))
                        }
                    })), t({
                        type: v.b
                    }))
                }
            }

            function X(t) {
                return {
                    payload: {
                        newListName: t
                    },
                    type: v.s
                }
            }

            function J(t) {
                return {
                    payload: t,
                    type: v.g
                }
            }

            function W(t) {
                var e = t.isValid,
                    i = t.shouldAlertOtherTabs;
                return !e && (void 0 !== i && i) && Object(f.b)(), {
                    payload: {
                        isValid: e
                    },
                    type: v.w
                }
            }
        }
    }
]);
//# sourceMappingURL=https://sourcemaps.d.musta.ch/airbnb/static/packages/1816-cc09dd51.js.map