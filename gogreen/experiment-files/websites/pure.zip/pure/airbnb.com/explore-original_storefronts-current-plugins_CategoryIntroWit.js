(window.webpackJsonp = window.webpackJsonp || []).push([
    ["42c7"], {
        "+JMM": function(e, t, n) {
            "use strict";
            var i = n("q1tI"),
                r = n.n(i),
                o = n("WKZH"),
                a = n("V/7F"),
                s = n("8fmn"),
                l = n("w93n"),
                c = n("Vc5N");
                var t, n, i = e.dls19;
                return {
                    body: Object.assign({}, i.typography.base.lg, (t = {
                        color: i.palette.foggy,
                        marginTop: i.spacing.primitives.size_small
                        color: i.palette.hof,
                        marginTop: 0
                        fontSize: 18,
                        lineHeight: "28px",
                        maxWidth: 460
                    }), t)),
                    bodyContainer: {
                        flex: 1
                    },
                        color: i.palette.hof,
                        display: "block"
                    }, i.responsive.queries.mediumAndAbove, {
                        display: "flex"
                    }),
                    footerLink: {
                        marginTop: 24
                    },
                    title: Object.assign({}, i.typography.titles.sm, (n = {
                        fontWeight: i.typography.weight.medium
                        fontWeight: i.typography.weight.bold
                        maxWidth: 460
                    })), n)),
                        flex: 1
                    }, i.responsive.queries.mediumAndAbove, {
                        paddingRight: 16
                    }),
                        display: "none"
                    }, i.responsive.queries.mediumAndAbove, {
                        display: "block"
                    }),
                        display: "none"
                    })
                }
            }), {
                pureComponent: !0
            })((function(e) {
                var t = e.body,
                    n = e.css,
                    i = e.footerLinkHref,
                    c = e.footerLinkText,
                    p = e.id,
                    d = e.onPress,
                    u = e.styles,
                    b = e.title,
                    f = !!i && !!c && r.a.createElement(s.a, {
                        href: i,
                        openInNewWindow: !0,
                        onPress: d
                    }, c);
                return r.a.createElement("div", Object.assign({}, n(u.container), {
                    id: p
                }), r.a.createElement("div", n(u.titleContainer), r.a.createElement("div", n(u.title), r.a.createElement(a.a, null, r.a.createElement(o.a, null, Object(l.a)(b)))), f && r.a.createElement("div", n(u.footerLink, u.visibleOnDesktopAndTablet), f)), r.a.createElement("div", n(u.bodyContainer), r.a.createElement("div", n(u.body), Object(l.a)(t), f && r.a.createElement("div", n(u.footerLink, u.visibleOnMobile), f))))
            }))
        },
        "9d3S": function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
            }));
            var i = n("q1tI"),
                r = n.n(i),
                o = n("W8W6"),
                a = n("Wc4+");

            function s(e) {
                var t, n = e.children,
                    i = e.config,
                    s = e.clearVerticalSpacing,
                    l = void 0 !== s && s,
                    p = i.fullWidth,
                    d = i.section,
                    u = i.showMap,
                    b = null == d || null === (t = d.display_configuration) || void 0 === t ? void 0 : t.section_width_type;
                return r.a.createElement(o.a, Object.assign({}, Object(a.a)({
                    fullWidth: p,
                    sectionWidthType: b,
                    showMap: u
                }), c, {
                    verticalSpacingBottom: !l,
                    verticalSpacingTop: !l
                }), n)
            }
        },
        "OL3/": function(e, t, n) {
            "use strict";
            n.d(t, "b", (function() {
                return i
            })), n.d(t, "c", (function() {
                return r
            })), n.d(t, "a", (function() {
                return o
            }));
            var i = " ",
                r = " ",
                o = 10
        },
        i6YV: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
            }));
            var i = n("MIRc");

            function r(e) {
                return Object(i.d)(e, "value_prop_items").map((function(e) {
                    return {
                        body: e.subheadline || "",
                        footerLinkHref: e.cta_url || void 0,
                        footerLinkText: e.cta_text || void 0,
                        title: e.headline || ""
                    }
                }))
            }
        },
        iTB4: function(e, t, n) {
            "use strict";
            n.r(t);
            var i = n("q1tI"),
                r = n.n(i),
                o = n("+JMM"),
                a = n("Vc5N"),
                s = n("9d3S"),
                l = n("i6YV");
                var t, n = e.dls19;
                return {
                    container: (t = {
                        margin: "32px 0 40px"
                        margin: "48px 0"
                        margin: "80px 0"
                    }), t)
                }
            }), {
                pureComponent: !0
            })((function(e) {
                var t = e.config,
                    n = e.css,
                    i = e.styles,
                    a = t.section,
                    c = r.a.useMemo((function() {
                        return Object(l.a)(a)
                    }), [a]);
                return r.a.createElement("div", n(i.container), r.a.createElement(s.a, {
                    clearVerticalSpacing: !0,
                    config: t
                }, c.map((function(e, n) {
                    return r.a.createElement(o.a, Object.assign({}, e, {
                        key: n,
                        onPress: t.onInsertCTAClick
                    }))
                }))))
            }))
        },
        w93n: function(e, t, n) {
            "use strict";
            n.d(t, "a", (function() {
            }));
            var i = n("OL3/");

            function r(e) {
                return "string" != typeof e || 2 === e.split(i.b).length ? e : (t = {
                    find: i.b,
                    replace: i.c,
                    string: e
                }, n = t.find, r = t.replace, o = t.string, -1 === (a = o.lastIndexOf(n)) || o.length - a > i.a ? o : o.slice(0, a) + r + o.slice(a + n.length));
                var t, n, r, o, a
            }
        }
    }
]);
//# sourceMappingURL=https://sourcemaps.d.musta.ch/airbnb/static/packages/explore-original_storefronts-current-plugins_CategoryIntroWithLinkSection-862e7434.js.map