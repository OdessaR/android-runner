(window.__twttrll = window.__twttrll || []).push([
    [3], {
        171: function(t, e, a) {
            var r = a(40),
                n = a(174),
                s = a(7);
        },
        172: function(t, e, a) {
            var r = a(37),
                n = a(30),
                s = a(39),
                i = a(0),
                o = a(7),
                u = a(34),
                c = a(5),
                l = a(178);
                t.params({
                    partner: {
                        fallback: o(u.val, u, "partner")
                    }
                }), t.define("scribeItems", function() {
                    return {}
                }), t.define("scribeNamespace", function() {
                    return {
                        client: "tfw"
                    }
                }), t.define("scribeData", function() {
                    return {
                        widget_origin: s.rootDocumentLocation(),
                        widget_frame: s.isFramed() && s.currentDocumentLocation(),
                        widget_site_screen_name: l(u.val("site")),
                        widget_site_user_id: c.asNumber(u.val("site:id")),
                        widget_creator_screen_name: l(u.val("creator")),
                        widget_creator_user_id: c.asNumber(u.val("creator:id"))
                    }
                }), t.define("scribe", function(t, e, a) {
                }), t.define("scribeInteraction", function(t, e, a) {
                    var r = n.extractTermsFromDOM(t.target);
                })
            }
        },
        173: function(t, e, a) {
            var r = a(5),
                n = a(0);
                t.define("widgetDataAttributes", function() {
                    return {}
                }), t.define("setDataAttributes", function() {
                        r.hasValue(a) && t.setAttribute("data-" + e, a)
                    })
                }), t.after("render", function() {
                })
            }
        },
        174: function(t, e, a) {
            var r = a(41),
                n = a(0),
                s = a(175);

            function i() {
            }
                factory: s,
                build: function() {
                    return r.prototype.build.apply(this, arguments)
                },
                selectors: function(t) {
                }
        },
        175: function(t, e, a) {
            var r = a(6),
                n = a(36),
                s = a(42),
                i = a(0),
                o = a(7),
                u = a(176),
                c = "twitter-widget-";
                var t = s();

                function e(e, a) {
                }
                    selectors: {},
                    hydrate: function() {
                        return r.resolve()
                    },
                    prepForInsertion: function() {},
                    render: function() {
                        return r.resolve()
                    },
                    show: function() {
                        return r.resolve()
                    },
                    resize: function() {
                        return r.resolve()
                    },
                    select: function(t, e) {
                    },
                    selectOne: function() {
                    },
                    selectLast: function() {
                    },
                    on: function(t, e, a) {
                            n.delegate(s, t, r, a)
                        } : function(t) {
                            s.addEventListener(t, a, !1)
                        }))
                    }
                }), e
            }
        },
        176: function(t, e) {
            var a = 0;
                return String(a++)
            }
        },
        178: function(t, e) {
                return t && "@" === t[0] ? t.substr(1) : t
            }
        },
        215: function(t, e) {
            var a = /\{\{([\w_]+)\}\}/g;
                return t.replace(a, function(t, a) {
                    return void 0 !== e[a] ? e[a] : t
                })
            }
        },
        219: function(t, e, a) {
            var r = a(6),
                n = a(171),
                s = a(34),
                i = a(20),
                o = a(215),
                u = a(0),
                c = a(11),
                l = a(7),
                p = a(72),
                h = a(70),
                m = p.followButtonHtmlPath,
                f = "Twitter Follow Button",
                d = "twitter-follow-button";

            function g(t) {
                return "large" === t ? "l" : "m"
            }
                t.params({
                    screenName: {
                        required: !0
                    },
                    lang: {
                        required: !0,
                        transform: h.matchLanguage,
                        fallback: "en"
                    },
                    size: {
                        fallback: "medium",
                    },
                    showScreenName: {
                        fallback: !0
                    },
                    showCount: {
                        fallback: !0
                    },
                    partner: {
                        fallback: l(s.val, s, "partner")
                    },
                    count: {},
                    preview: {}
                }), t.define("getUrlParams", function() {
                    return u.compact({
                        dnt: i.enabled(),
                        time: +new Date
                    })
                }), t.around("widgetDataAttributes", function(t) {
                    return u.aug({
                    }, t())
                }), t.around("scribeNamespace", function(t) {
                    return u.aug(t(), {
                        page: "button",
                        section: "follow"
                    })
                }), t.define("scribeImpression", function() {
                        action: "impression"
                    }, {
                    })
                }), t.override("render", function() {
                    var t = o(m, {
                        }),
                        a = p.resourceBaseUrl + t + "#" + e;
                })
            })
        },
        250: function(t, e, a) {
            var r = a(6),
                n = a(4),
                s = a(8),
                i = a(34),
                o = a(20),
                u = a(215),
                c = a(77),
                l = a(0),
                p = a(11),
                h = a(3),
                m = a(171),
                f = a(7),
                d = a(72),
                g = a(70),
                b = d.tweetButtonHtmlPath,
                w = "Twitter Tweet Button",
                v = "twitter-tweet-button",
                y = "twitter-share-button",
                _ = "twitter-hashtag-button",
                x = "twitter-mention-button",
                N = ["share", "hashtag", "mention"];

            function D(t) {
                return "large" === t ? "l" : "m"
            }

            function k(t) {
                return l.contains(N, t)
            }

            function z(t) {
                return h.hashTag(t, !1)
            }

            function A(t) {
                return /\+/.test(t) && !/ /.test(t) ? t.replace(/\+/g, " ") : t
            }
                t.params({
                    lang: {
                        required: !0,
                        transform: g.matchLanguage,
                        fallback: "en"
                    },
                    size: {
                        fallback: "medium",
                    },
                    type: {
                        fallback: "share",
                    },
                    text: {
                    },
                    screenName: {
                        transform: h.screenName
                    },
                    buttonHashtag: {
                    },
                    partner: {
                        fallback: f(i.val, i, "partner")
                    },
                    via: {},
                    related: {},
                    hashtags: {},
                    url: {}
                }), t.define("getUrlParams", function() {
                        i = c.getScreenNameFromPage();
                        text: t,
                        url: e,
                        via: a,
                        related: r,
                        original_referer: s.href,
                        dnt: o.enabled(),
                        time: +new Date
                    })
                }), t.around("widgetDataAttributes", function(t) {
                    }, t()) : l.aug({
                    }, t())
                }), t.around("scribeNamespace", function(t) {
                    return l.aug(t(), {
                        page: "button",
                    })
                }), t.define("scribeImpression", function() {
                        action: "impression"
                    }, {
                    })
                }), t.override("render", function() {
                    var t, e = u(b, {
                        }),
                        n = d.resourceBaseUrl + e + "#" + a;
                        case "hashtag":
                            t = _;
                            break;
                        case "mention":
                            t = x;
                            break;
                        default:
                            t = y
                    }
                })
            })
        },
        85: function(t, e, a) {
            var r = a(171);
        },
        91: function(t, e, a) {
            var r = a(171);
        }
    }
]);