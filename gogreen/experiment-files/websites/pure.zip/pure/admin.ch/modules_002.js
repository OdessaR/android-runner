(function($) {
    "use strict";
    /**
     * Test module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author  <>
     * @namespace Tc.Module
     * @class Embedcode
     * @extends Tc.Module
     */

        init: function($ctx, sandbox, modId) {
        },

        on: function(callback) {
                $ctx = _this.$ctx,
                $btnCopy = $('.js-iframe-info button.js-clipboard-btn', $ctx);

            _this._changeInputState();
            _this._onKeyUp();
            _this._onClickCopy($btnCopy);
            _this._callClipboard($btnCopy);

            callback(); // !do not remove
        },

        _generateIframeText: function(width, height) {
                $ctx = _this.$ctx,
                newIframeText = $ctx.find('.js-iframe-text').val().replace(/width=\"[0-9.%]*\"/, "width=\"" + width + "\"");

            newIframeText = newIframeText.replace(/height=\"[0-9.%]*\"/, "height=\"" + height + "\"");
            $ctx.find('.js-iframe-text').text(newIframeText);
        },

        _setDefaultSize: function() {
                $ctx = _this.$ctx,
                $defaultSize = $ctx.find('.js-default-size'),
                $defaultWidth = $defaultSize.data('default-width'),
                $defaultHeight = $defaultSize.data('default-height');

            _this._generateIframeText($defaultWidth, $defaultHeight);
        },

        _changeInputState: function() {

            // Disable/enable custom format input field
            $('.embed-form input:radio').change(function() {
                if ($(this).val() == 'custom-format') {
                    $('.js-custom-format-width').removeAttr('disabled');
                    _this._setDefaultSize();
                } else {
                    _this._setDefaultSize();
                    $('.js-custom-format-width').val('');
                    $('.js-custom-format-height').html('&nbsp;');
                    $('.js-custom-format-width').attr('disabled', 'disabled');
                }
                return;
            });
        },

        _calculateHeight: function(width) {
                $ctx = _this.$ctx,
                height;

            // Calculate height of custom width
            if (parseInt(width, 10) === undefined || isNaN(parseInt(width, 10))) {
                height = "&nbsp;";
            } else {
                height = Math.round((width) * 9 / 16) + 70;
                _this._generateIframeText(width, height);
            }

            $('.js-custom-format-height', $ctx).html(height);
        },

        _onKeyUp: function() {
                $ctx = _this.$ctx;

            $('.js-custom-format-width', $ctx).on('change keyup', function() {
                _this._calculateHeight($(this).val());
            });
        },

        _callClipboard: function($btnCopy) {
                $ctx = _this.$ctx;

            // Apply clipboard click event
            $btnCopy.clipboard({
                path: '/etc/designs/core/frontend/assets/swf/jquery.clipboard.swf',

                copy: function() {
                    // Return text
                    return $ctx.find('.js-iframe-text').text();
                }
            });
        },

        _onClickCopy: function($btnCopy) {
            // Disables other default handlers on click (avoid issues)
            $btnCopy.on('click', function(e) {
                e.preventDefault();
            });
        }
    });
}(Tc.$));

(function($) {
    "use strict";
    /**
     * Imagesbundesrat module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author  <>
     * @namespace Tc.Module
     * @class Imagesbundesrat
     * @extends Tc.Module
     */
        on: function(callback) {
                $ctx = _this.$ctx;

            _this._onWindowResize();
            _this._onWindowLoad();

            callback(); // !do not remove
        },

        _setAriaAttributes: function() {
                $ctx = _this.$ctx,
                $imgWrapper = $('.js-image-wrapper', $ctx),
                i = 1;

            $imgWrapper.find('li').each(function() {
                $(this).find('img').attr('aria-describedby', 'imagesbundesrat-dimg' + i);
                $(this).find('figcaption').attr('id', 'imagesbundesrat-dimg' + i);
                i++;
            });
        },

        _changeMarkupForPhone: function() {
            // Change markup for phones
                $ctx = _this.$ctx,
                $imgWrapper = $('.js-image-wrapper', $ctx),
                $mobileUrl = $imgWrapper.data('mobile-url'),
                newMarkup = '';

            // Toggle classes to check viewport on resize
            $imgWrapper.removeClass('js-large-screen').addClass('js-phone');

            $imgWrapper.find('li').each(function() {
                var $dataUrl = $(this).find('a').attr('href'),
                    $img = $(this).find('img'),
                    $legend = $(this).find('figcaption').get(0).outerHTML;

                newMarkup += '<li><figure><img src="' + $img.attr('src') + '" alt="' + $img.attr('alt') + '" data-url="' + $dataUrl + '">' + $legend + '</figure></li>';
            });

            $imgWrapper.html(newMarkup);

            // Wrap <a>-tag around the image-wrapper
            $ctx.find('a').addClass('js-mobile-landingpage').attr('href', $mobileUrl);

            // Set aria-attributes for screenreaders
            _this._setAriaAttributes();
        },

        _changeMarkupForLargerScreens: function() {

                $ctx = _this.$ctx,
                $imgWrapper = $('.js-image-wrapper', $ctx),
                $mobileLandingpage = $('.js-mobile-landingpage', $ctx),
                $mobileUrl = $($mobileLandingpage).attr('href') || '',
                newMarkup = '';

            // Toggle classes to check viewport on resize, saving mobile url
            $imgWrapper.removeClass('js-phone').addClass('js-large-screen').attr('data-mobile-url', $mobileUrl);

            // Change markup for tablet/desktop
            $mobileLandingpage.find('li').each(function() {
                var $dataUrl = $(this).find('img').data('url'),
                    $img = $(this).find('img').get(0).outerHTML,
                    $legend = $(this).find('img').next('figcaption').get(0).outerHTML;

                newMarkup += '<li><figure><a href="' + $dataUrl + '">' + $img + $legend + '</a></figure></li>';
            });

            $imgWrapper.html(newMarkup);
            $ctx.html($mobileLandingpage.html());

            // Set aria-attributes for screenreaders
            _this._setAriaAttributes();
        },

        _onWindowLoad: function() {
            if ($(window).width() > 767) {
                _this._changeMarkupForLargerScreens();
            }
        },

        _onWindowResize: function() {
                $ctx = _this.$ctx;

            $(window).on('resize', function() {
                var $imgWrapper = $ctx.find('.js-image-wrapper');

                if ($(window).width() > 767 && $imgWrapper.hasClass('js-phone')) {
                    _this._changeMarkupForLargerScreens();
                } else if ($(window).width() <= 767 && $imgWrapper.hasClass('js-large-screen')) {
                    _this._changeMarkupForPhone();
                }
            });
        }
    });
}(Tc.$));
(function($) {
    "use strict";
    /**
     * Mediaconferenceteaser module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author Elena Wessolek <elena.wessolek@namics.com>
     * @namespace Tc.Module
     * @class Mediaconferenceteaser
     * @extends Tc.Module
     */
        on: function(callback) {
                $ctx = _this.$ctx,
                $teaser = $ctx.find('.mediaconferenceteaser'),
                $interval = $teaser.data('refreshinterval') || 300000;

            setInterval(function() {
                _this._loadData($teaser);
            }, $interval);

            callback(); // !do not remove
        },

        _loadData: function($teaser) {
            var $url = $teaser.data('ajax');

            // get html of conferences
            $.ajax({
                type: 'GET',
                url: $url
            }).done(function(data) {
                if ($teaser.html() !== data) {
                    $teaser.html(data);
                }
            });
        }
    });
}(Tc.$));
(function($) {
    "use strict";
    /**
     * Mediarelations module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author Elena Wessolek <elena.wessolek@namics.com>
     * @namespace Tc.Module
     * @class Mediarelations
     * @extends Tc.Module
     */
        on: function(callback) {
                $ctx = _this.$ctx;

            _this._clickRelation();

            callback(); // !do not remove
        },

        _loadAdressList: function($url) {
                $ctx = _this.$ctx,
                $addressList = $ctx.find('.js-address-list');

            $.ajax({
                type: 'GET',
                url: $url
            }).done(function(data) {
                $addressList.html(data);
            });
        },

        _clickRelation: function() {
                $ctx = _this.$ctx,
                $relations = $ctx.find('.js-mediarelations a');

            $relations.on('click', function(e) {
                e.preventDefault();

                var $url = $(e.target).attr('href') || '#';
                _this._loadAdressList($url);

                e.stopPropagation();
            });
        }
    });
}(Tc.$));
(function($) {
    "use strict";
    /**
     * Newsabo module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author Elena Wessolek <elena.wessolek@namics.com>
     * @namespace Tc.Module
     * @class Newsabo
     * @extends Tc.Module
     */
        on: function(callback) {

            _this._initializeEvents();

            callback(); // !do not remove
        },

        _expandRows: function() {
                $ctx = _this.$ctx,
                $expandBtn = $ctx.find('.js-expand-all');

            // expand/collapse table rows
            $expandBtn.on('click', function() {
                var countCollapsedRows = 0;

                // check if there are more expanded or collapsed rows
                $ctx.find('table tbody th a').each(function() {
                    if ($(this).hasClass('collapsed')) {
                        countCollapsedRows = 1;
                    }
                });

                if (countCollapsedRows === 1) {
                    // expand all collapsed rows
                    $ctx.find('table th a').each(function() {
                        if ($(this).hasClass('collapsed')) {
                            $(this).click();
                        }
                    });
                } else {
                    // collapse all expanded rows
                    $ctx.find('table th a').each(function() {
                        if (!$(this).hasClass('collapsed')) {
                            $(this).click();
                        }
                    });
                }
            });
        },

        _showSpinnerIcon: function() {
                $ctx = _this.$ctx;

            $ctx.addClass('loading');
        },

        _hideSpinnerIcon: function() {
                $ctx = _this.$ctx;

            $ctx.removeClass('loading');
        },

        _ajaxDone: function(data) {
                $ctx = _this.$ctx;

            $ctx.html(data).scrollToMe();
            _this._initializeEvents();
        },

        _ajaxError: function() {
                $ctx = _this.$ctx,
                $ajaxError = $ctx.find('.js-newsabo-ajax-error');

            $ajaxError.removeClass('hidden');
        },

        _getData: function($url) {
                timestamp = Math.floor($.now() / 1000);

            // cache url
            if ($url.indexOf('?') === -1) {
            }

            // show spinner icon
            _this._showSpinnerIcon();

            $.ajax({
                type: 'GET',
                url: $url,
                success: function(data) {
                    _this._hideSpinnerIcon();
                    _this._ajaxDone(data);
                },
                error: function() {
                    _this._hideSpinnerIcon();
                    _this._ajaxError();
                }
            });
        },

        _postData: function($url, formEvt) {
                formData = formEvt.serialize(),
                timestamp = Math.floor($.now() / 1000);

            // cache url
            if ($url.indexOf('?') === -1) {
            }

            // show spinner icon
            _this._showSpinnerIcon();

            $.ajax({
                type: 'POST',
                url: $url,
                data: formData,
                success: function(data) {
                    _this._hideSpinnerIcon();
                    _this._ajaxDone(data);
                },
                error: function() {
                    _this._hideSpinnerIcon();
                    _this._ajaxError();
                }
            });
        },

        _deleteAccount: function($url, $confirmBoxTxt) {
                confirmBox = confirm($confirmBoxTxt);

            if (confirmBox === true) {
                $.ajax({
                    type: 'POST',
                    url: $url,
                    success: function(data) {
                        _this._ajaxDone(data);
                    },
                    error: function() {
                        _this._ajaxError();
                    }
                });
            }
        },

        _clickBtnNav: function() {
                $ctx = _this.$ctx,
                $btnNavi = $ctx.find('.newsabo-navigation button');

            $btnNavi.unbind('click').on('click', function(e) {
                var evt = $(e.target),
                    $url = evt.data('url');
                _this._getData($url);
            });
        },

        _btnActions: function() {
                $ctx = _this.$ctx,
                $forms = $ctx.find('form'), // Submit-buttons
                $buttons = $ctx.find('.js-btn'), // Buttons
                $btnsPrev = $ctx.find('.js-link'), // Links
                $deleteAccBtn = $ctx.find('.js-delete-account'); // Button delete account

            // Add class e-clicked to submit button to check wich button is clicked
            $forms.find('button[type="submit"]').on('click', function(e) {
                var evt = $(e.target);
                evt.addClass('e-clicked');
            });

            // Submit event
            $forms.on('submit', function(e) {
                e.preventDefault();
                var evt = $(e.target),
                    $mainUrl = evt.attr('action'),
                    $subUrl = evt.find('.e-clicked').data('sub-url');

                // Check wich submit button is clicked
                if (evt.find('.e-clicked').hasClass('js-main-submit')) {
                    _this._postData($mainUrl, evt);
                } else if (evt.find('.e-clicked').hasClass('js-sub-submit')) {
                    _this._postData($subUrl, evt);
                }

                evt.find('.e-clicked').removeClass('e-clicked');
            });

            // Button event
            $buttons.unbind('click').on('click', function(e) {
                var evt = $(e.target),
                    $url = evt.data('url') || '';

                _this._getData($url);
            });

            // Button event - delete account
            $deleteAccBtn.unbind('click').on('click', function(e) {
                e.preventDefault();

                var evt = $(e.target),
                    $url = evt.attr('href') || '',
                    $dataConfirmBoxTxt = evt.data('box-text');

                _this._deleteAccount($url, $dataConfirmBoxTxt);
            });

            // Link event
            $btnsPrev.unbind('click').on('click', function(e) {
                e.preventDefault();
                var evt = $(e.target),
                    $url = evt.attr('href') || '';

                _this._getData($url);
            });
        },

        _initializeEvents: function() {

            _this._clickBtnNav();
            _this._btnActions();
            _this._expandRows();
        }
    });
}(Tc.$));
(function($) {
    "use strict";
    /**
     * Survey module implementation.
     * https://gitlab.namics.com/snippets/2
     *
     * @author Elena Wessolek <elena.wessolek@namics.com>
     * @namespace Tc.Module
     * @class Survey
     * @extends Tc.Module
     */
        init: function($ctx, sandbox, modId) {

        },

        on: function(callback) {
            _this._initEvents(1);
            _this._setDateTo();

            callback(); // !do not remove
        },

        after: function() {
            _this.dataUrl = $(".survey-wrapper", _this.$ctx).data("url");
        },

        _setDateTo: function() {
                currentDate = new Date(),
                year = currentDate.getFullYear(),
                month = currentDate.getMonth() + 1,
                day = currentDate.getDate(),
                monthOut = (("" + month).length < 2 ? "0" : "") + month,
                dayOut = (("" + day).length < 2 ? "0" : "") + day,
                dateTo = dayOut + "." + monthOut + "." + year;

            $(".js-date-to", _this.$ctx).attr("value", dateTo);
        },

        _initEvents: function(configIndex) {
                $resultContainer = $(".survey-result", _this.$ctx);
            if (!$resultContainer.hasClass("done")) {
                $resultContainer.addClass("done");
            }
            _this._initPagination(configIndex);
            _this._filterEvent();
        },

        _loadContent: function(url, attributes, configIndex) {
                aUrl = attributes !== undefined && attributes !== null ? url + attributes : url,
                $resultContainer = $(".survey-result", _this.$ctx);
            $resultContainer.addClass("loading");
            $.ajax({
                type: "GET",
                url: aUrl
            }).done(function(data) {
                $resultContainer.html(data);
                _this._initEvents(configIndex);
                $resultContainer.removeClass("loading");
                $(window).trigger("viewportchange");
            });
        },

        _initPagination: function(configIndex) {
            $("ul.pagination a", _this.$ctx).unbind("click").click(function(event) {
                event.preventDefault();
                var loadPage = $(this).data("loadpage"),
                    $surveyFilter = _this.$ctx.find("" +
                        "input[name='fulltext'], " +
                        "input[name='referenceNumber'], " +
                        "input[name='title'], " +
                        "input[name='description'], " +
                        "input[name='keywords'], " +
                        "input[name='contractor'], " +
                        "input[name='creator'], " +
                        "input[name='dateFrom'], " +
                        "input[name='dateTo'], " +
                        "input[name='topic'], " +
                        "input[name='minCost'], " +
                        "input[name='maxCost'], " +
                        "input[name='budget']"),
                    attributes = $surveyFilter.length !== null ? "?_charset_=UTF-8" + "&pageIndex=" + loadPage + "&" + $surveyFilter.serialize() : "?pageIndex=" + loadPage;
                _this._loadContent(_this.dataUrl, attributes, 1);
            });
        },

        _filterEvent: function() {
            $(".js-survey-form-filter", _this.$ctx).unbind('submit').on("submit", function(event) {
                event.preventDefault();
                var $surveyFilter = $(".js-survey-form-filter"),
                    attributes = $surveyFilter.length !== null ? "?_charset_=UTF-8" + "&pageIndex=" + 0 + "&" + $surveyFilter.serialize() : "?pageIndex=" + 0;
                _this._loadContent(_this.dataUrl, attributes, 1);
            });
        }
    });
}(Tc.$));