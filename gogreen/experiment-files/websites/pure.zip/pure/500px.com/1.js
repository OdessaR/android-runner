(window.webpackJsonp = window.webpackJsonp || []).push([
    [1], {
        101: function(t, e, o) {
            "use strict";
            var n = o(13),
                r = o(9);
            Object.defineProperty(e, "__esModule", {
                value: !0
            var i = r(o(81)),
                s = n(o(3)),
                a = o(5),
                d = o(312),
                u = r(o(8));

            function l() {
                var t = (0, i.default)(["\n    font-weight: bold;\n  "]);
                    return t
                }, t
            }

            function m() {
                var t = (0, i.default)(["\n    ", ";\n  "]);
                    return t
                }, t
            }
            var p = (0, s.default)(a.Caption).attrs((function() {
                return {
                    mediumGrey: !0
                }
            })).withConfig({
                displayName: "TextStyles__PhotoCredit",
                componentId: "kbq0q1-0"
            })(["position:absolute;z-index:", " a,a:hover{color:", ";}", " ", " ", " ", ""], (function(t) {
                return t.zUpByOne ? 1 : "unset"
            }), (function(t) {
                return t.theme.mediumGrey
            }), (function(t) {
                return t.white && (0, s.css)(["color:", ";a,a:hover{color:", ";}"], t.theme.fontColorWhite, t.theme.fontColorWhite)
            }), (function(t) {
                return t.darkGrey && (0, s.css)(["color:", ";a,a:hover{color:", ";}"], t.theme.veryDarkGrey, t.theme.veryDarkGrey)
            }), (function(t) {
                return t.bottomLeft && (0, s.css)(["bottom:", ";left:0;"], t.theme.spacingXs)
            }), (function(t) {
                return t.bottomRight && (0, s.css)(["bottom:", ";right:0;"], t.theme.spacingXs)
            }));
            var c = s.default.span.withConfig({
                displayName: "TextStyles__DesktopColor",
                componentId: "kbq0q1-1"
            })(["", ""], u.default.minWidth.desktop(m(), d.fontColor));
            var f = s.default.span.withConfig({
                displayName: "TextStyles__DesktopBold",
                componentId: "kbq0q1-2"
            })(["", ""], u.default.minWidth.desktop(l()));
            var h = a.Paragraph.withComponent("ol"),
                y = a.Paragraph.withComponent("ul"),
                b = (0, s.default)(h).withConfig({
                    displayName: "TextStyles__OrderedList",
                    componentId: "kbq0q1-3"
                })(["li{margin-bottom:", ";}", ""], (function(t) {
                    return t.theme.spacingSm
                }), (function(t) {
                    return t.noListMobile && (0, s.css)(["@media (max-width:", "px){padding:0;list-style-type:none;}"], t.theme.responsiveMedium - 1)
                }));
            var g = (0, s.default)(y).withConfig({
                displayName: "TextStyles__UnorderedList",
                componentId: "kbq0q1-4"
            })(["li{margin-bottom:", ";}", ""], (function(t) {
                return t.theme.spacingSm
            }), (function(t) {
                return t.noListMobile && (0, s.css)(["@media (max-width:", "px){padding:0;list-style-type:none;}"], t.theme.responsiveMedium - 1)
            }));
        }
    }
]);