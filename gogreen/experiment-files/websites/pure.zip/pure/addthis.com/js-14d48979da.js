/*! js-cookie v2.2.0 | MIT */

! function(e) {
    var n = !1;
        t.noConflict = function() {
        }
    }
}(function() {
    function e() {
        for (var e = 0, n = {}; e < arguments.length; e++) {
            var o = arguments[e];
            for (var t in o) n[t] = o[t]
        }
        return n
    }

    function n(o) {
        function t(n, r, i) {
            var c;
                if (arguments.length > 1) {
                            path: "/"
                        var a = new Date;
                    }
                    try {
                    var s = "";
                    for (var f in i) i[f] && (s += "; " + f, !0 !== i[f] && (s += "=" + i[f]));
                }
                n || (c = {});
                    var l = p[u].split("="),
                        C = l.slice(1).join("=");
                    try {
                        var m = l[0].replace(d, decodeURIComponent);
                            C = JSON.parse(C)
                        if (n === m) {
                            c = C;
                            break
                        }
                        n || (c[m] = C)
                }
                return c
            }
        }
                json: !0
            }, [].slice.call(arguments))
            t(n, "", e(o, {
                expires: -1
            }))
    }
    return n(function() {})
});