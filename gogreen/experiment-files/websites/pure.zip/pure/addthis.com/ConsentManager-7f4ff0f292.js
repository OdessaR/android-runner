// CustomEvent polyfill
// https://developer.mozilla.org/en-US/docs/Web/API/CustomEvent/CustomEvent
(function() {

    function CustomEvent(event, params) {
            bubbles: false,
            cancelable: false,
            detail: undefined
        };
        evt.initCustomEvent(event, params.bubbles, params.cancelable, params.detail);
        return evt;
    }

})();

(function() {
    /**
     * ConsentManager - abstraction wrapper for TRUSTe/TrustArc PrivacyManagerAPI
     *
     * domain: domain that is requesting permission ('.domain.com')
     * siteDomain: current site hostname ('www.domain.com')
     * eventContext: object/element to which we will dispatch events (defaults to window)
     */
    function ConsentManager(domain, siteDomain, eventContext) {

    }


            'required',
            'functional',
            'advertising'
        ];

        // Listen for messages from the API
            try {
                var data = JSON.parse(e.data);
                if (data.PrivacyManagerAPI) {
                    self.handleApiMessage(data.PrivacyManagerAPI);
                }
            } catch (e) {}
        }, false);

        // Required is approved by default, do this as fast as possible

        // Wait for the PrivacyManagerAPI object to initialize
            self.privacyApi = obj;

            for (var i = 0; i < self.consentTypes.length; i++) {
                var type = self.consentTypes[i];
                if (!self.haveConsent(type)) {
                    self.requestConsentMessaging(type);
                    self.handleResponse(type, self.getConsent(type));
                }
            }
        });
    }

    // Approve consent for a type, source can be implied or asserted
        if (source === undefined) {
        }


                detail: {
                    type: type,
                    source: source
                }
            });
        }
    };

    // Call the Privacy Manager API
    };

    // Deny consent for a type, source can be implied or asserted
        if (source === undefined) {
        }


                detail: {
                    type: type,
                    source: source
                }
            });
        }
    };

    // Get consent for the given type directly from the API
    };

    // Get consent for the given type from TrustArc's local storage object instead of the API
        // Get from the API first, this will let us know if we need consent initially based on user's location

        // Override response based on what is in the raw localStorage
            var storage = null
            try {

            if (storage !== null && typeof storage.value === 'string') {
                var level = storage.value.split(':');
                if (level.length > 0) {
                    level = parseInt(level[0]);

                    // Technically it's asserted, but it is useful to know how we got it
                    response.source = 'raw_storage';

                    switch (type) {
                        case 'required':
                            response.consent = 'approved';
                            break;
                        case 'functional':
                            response.consent = (level > 0 ? 'approved' : 'denied');
                            break;
                        default:
                            response.consent = (level > 1 ? 'approved' : 'denied');
                    }
                }
            }
        }

        return response;
    };

    // Handle the messages returned by the API calls
        // CHECK: make sure this response is to YOU. You will actually get the messages to all API callers on this page, not just to you.
            return;
        }

        // Do not proceed unless this is the direct result of user interraction
        if (message.source != 'asserted') {
            return;
        }

        // If type is provided, handle the response; otherwise re-get consent for everything (except required)
        if (message.type) {
        } else {
                if (type != 'required') {
                }
            }
        }
    };

    // Handle a response to an request for consent
        if (response.consent == 'approved') {
        } else if (response.consent == 'denied') {
        } else {
        }
    };

    // Do we have consent for the specific type of functionality?
            return false;
        }

    };

    // Request that the API send messages for consent updates
        var apiObject = {
            PrivacyManagerAPI: {
                action: 'getConsent',
                timestamp: new Date().getTime(),
                type: type
            }
        };

    };

    // Long-poll for a specific object to instantiate
        var poll = setInterval(function() {
            if (parentObj[objName] !== undefined) {
                    detail: {
                        parentObj: parentObj,
                        objName: objName,
                        obj: parentObj[objName]
                    }
                });

                clearInterval(poll);

                if (typeof callback === 'function') {
                    callback(parentObj[objName]);
                }

                parentObj.dispatchEvent(evt);
            }
        }, interval);
    };

    }
})();