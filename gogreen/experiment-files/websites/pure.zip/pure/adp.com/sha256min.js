! function(e, r) {
}(this, function(e) {
    return function(r) {
        var t = e,
            o = t.lib,
            n = o.WordArray,
            i = o.Hasher,
            s = t.algo,
            a = [],
            c = [];
        ! function() {
            function e(e) {
                for (var t = r.sqrt(e), o = 2; o <= t; o++)
                    if (!(e % o)) return !1;
                return !0
            }

            function t(e) {
                return 4294967296 * (e - (0 | e)) | 0
            }
            for (var o = 2, n = 0; n < 64;) e(o) && (n < 8 && (a[n] = t(r.pow(o, .5))), c[n] = t(r.pow(o, 1 / 3)), n++), o++
        }();
        var f = [],
            h = s.SHA256 = i.extend({
                _doReset: function() {
                },
                _doProcessBlock: function(e, r) {
                        if (d < 16) f[d] = 0 | e[r + d];
                        else {
                            var _ = f[d - 15],
                                p = (_ << 25 | _ >>> 7) ^ (_ << 14 | _ >>> 18) ^ _ >>> 3,
                                v = f[d - 2],
                                H = (v << 15 | v >>> 17) ^ (v << 13 | v >>> 19) ^ v >>> 10;
                            f[d] = p + f[d - 7] + H + f[d - 16]
                        }
                        var y = a & h ^ ~a & u,
                            w = o & n ^ o & i ^ n & i,
                            A = (o << 30 | o >>> 2) ^ (o << 19 | o >>> 13) ^ (o << 10 | o >>> 22),
                            S = (a << 26 | a >>> 6) ^ (a << 21 | a >>> 11) ^ (a << 7 | a >>> 25),
                            g = l + S + y + c[d] + f[d],
                            m = A + w;
                        l = u, u = h, h = a, a = s + g | 0, s = i, i = n, n = o, o = g + m | 0
                    }
                    t[0] = t[0] + o | 0, t[1] = t[1] + n | 0, t[2] = t[2] + i | 0, t[3] = t[3] + s | 0, t[4] = t[4] + a | 0, t[5] = t[5] + h | 0, t[6] = t[6] + u | 0, t[7] = t[7] + l | 0
                },
                _doFinalize: function() {
                        t = e.words,
                        n = 8 * e.sigBytes;
                },
                clone: function() {
                    var e = i.clone.call(this);
                }
            });
        t.SHA256 = i._createHelper(h), t.HmacSHA256 = i._createHmacHelper(h)
    }(Math), e.SHA256
});
//# sourceMappingURL=sha256.min.js.map