! function(o) {
    var e = !1;
        i.noConflict = function() {
        }
    }
}(function() {
    function o() {
        for (var o = 0, c = {}; o < arguments.length; o++) {
            var i = arguments[o];
            for (var e in i) c[e] = i[e]
        };
        return c
    };
    return function e(i) {
        function c(e, n, t) {
            var s;
                if (1 < arguments.length) {
                            path: '/'
                        var l = new Date;
                    };
                    try {
                    var u = '';
                    for (var d in t) t[d] && (u += '; ' + d, !0 !== t[d] && (u += '=' + t[d]));
                };
                e || (s = {});
                    var f = S[k].split('='),
                        r = f.slice(1).join('=');
                    try {
                        var a = f[0].replace(h, decodeURIComponent);
                            r = JSON.parse(r)
                        if (e === a) {
                            s = r;
                            break
                        };
                        e || (s[a] = r)
                };
                return s
            }
        };
                json: !0
            }, [].slice.call(arguments))
            c(e, '', o(i, {
                expires: -1
            }))
    }(function() {})
});
var csCookies = Cookies.noConflict(),
    cookieScriptWindow = window.document,
    cookieScripts = document.getElementsByTagName('script'),
    cookieScriptSrc = cookieScripts[cookieScripts.length - 1].src,
    cookieQuery = null,
    cookieScriptPosition = 'top',
    cookieScriptSide = 'left',
    cookieScriptSource = 'cookie-script.com',
    cookieScriptDomain = '',
    cookieScriptReadMore = 'privacy-policy.htm',
    cookieId = 'a89dda72cbceef9958e523b1eadc4cb0',
    cookieScriptDebug = 0,
    cookieScriptShowBadge = !0,
    cookieScriptCurrentUrl = window.location.href,
    cookieScriptTitle = '<h4 id="cookiescript_header">Our website uses cookies</h4>',
    cookieScriptDesc = 'AllAboutCookies.org uses cookies to improve user experience. We also show safe,   secure and non personal advertising to support this site.By using our website you consent to our cookies in accordance with our Cookie Policy.<br \/>',
    cookieScriptAccept = 'I agree',
    cookieScriptMore = 'Read more',
    cookieScriptReject = '<div id="cookiescript_reject">I disagree</div>',
    cookieScriptCopyrights = 'I agree',
    cookieScriptLoadJavaScript = function(e, i) {
        o.type = 'text/javascript', o.src = e, i != undefined && (o.onload = o.onreadystatechange = function() {
            (!o.readyState || /loaded|complete/.test(o.readyState)) && (o.onload = o.onreadystatechange = null, c && o.parentNode && c.removeChild(o), o = undefined, i())
        }), c.insertBefore(o, c.firstChild)
    },
    InjectCookieScript = function() {
            else var n = '';
            var r = '',
                i, t;
                for (e = t[i]; e.charAt(0) == ' ';) e = e.substring(1, e.length);
                if (e.indexOf(c) == 0) return e.substring(c.length, e.length)
            };
            return null
        };
        cookieQuery(function() {
            cookieQuery('#cookiescript_injected', cookieScriptWindow).remove();
                    cookieQuery('#cookiescript_injected', cookieScriptWindow).css('top', 20)
                } else {
                    cookieQuery('#cookiescript_injected', cookieScriptWindow).css('bottom', 20)
                };
                    cookieQuery('#cookiescript_injected', cookieScriptWindow).css('left', 20)
                } else {
                    cookieQuery('#cookiescript_injected', cookieScriptWindow).css('right', 20)
                };
                cookieQuery('#cookiescript_injected', cookieScriptWindow).css({
                    'background-color': '#db6f34',
                    'z-index': '999999',
                    'opacity': '0.6',
                    'position': 'fixed',
                    'padding': '15px',
                    'width': '300px',
                    'font-size': '13px',
                    'font-weight': 'normal',
                    'text-align': 'left',
                    'color': '#FFFFFF',
                    'font-family': 'Arial, sans-serif',
                    'display': 'none',
                    'line-height': '20px',
                    'letter-spacing': 'normal',
                    '-moz-box-shadow': '0px 0px 8px #000000',
                    '-webkit-box-shadow': '0px 0px 8px #000000',
                    'box-shadow': '0px 0px 8px #000000',
                    '-moz-border-radius': '5px',
                    '-webkit-border-radius': '5px',
                    'border-radius': '5px'
                });
                cookieQuery('#cookiescript_injected h4#cookiescript_header', cookieScriptWindow).css({
                    'background-color': '#db6f34',
                    'z-index': '999999',
                    'padding': '0 0 7px 0',
                    'text-align': 'center',
                    'color': '#FFFFFF',
                    'font-family': 'Arial, sans-serif',
                    'display': 'block',
                    'font-size': '15px',
                    'font-weight': 'bold',
                    'margin': '0'
                });
                cookieQuery('#cookiescript_injected span', cookieScriptWindow).css({
                    'display': 'block',
                    'font-size': '100%',
                    'margin': '5px 0'
                });
                cookieQuery('#cookiescript_injected a', cookieScriptWindow).css({
                    'text-decoration': 'underline',
                    'color': '#FFFFFF'
                });
                cookieQuery('#cookiescript_injected a#cookiescript_link', cookieScriptWindow).css({
                    'display': 'none',
                    'text-decoration': 'none',
                    'color': '#FFFFFF',
                    'float': 'right',
                    'font-size': '90%'
                });
                cookieQuery('#cookiescript_injected div#cookiescript_accept,#cookiescript_injected div#cookiescript_readmore, #cookiescript_injected div#cookiescript_reject', cookieScriptWindow).css({
                    '-webkit-border-radius': '5px',
                    '-khtml-border-radius': '5px',
                    '-moz-border-radius': '5px',
                    'border-radius': '5px',
                    'border': '0',
                    'padding': '6px 10px',
                    'font-weight': 'bold',
                    'cursor': 'pointer',
                    'margin': '5px 0',
                    '-webkit-transition': '0.25s',
                    '-moz-transition': '0.25s',
                    'transition': '0.25s',
                    'text-shadow': 'rgb(0, 0, 0) 0px 0px 2px'
                });
                cookieQuery('#cookiescript_injected div#cookiescript_readmore', cookieScriptWindow).css({
                    'background-color': '#5ab750',
                    'color': '#ffffff',
                    'display': 'block',
                    'text-align': 'center',
                    'clear': 'both'
                });
                cookieQuery('#cookiescript_injected div#cookiescript_reject', cookieScriptWindow).css({
                    'background-color': '#B75B5B',
                    'color': '#FFFFFF',
                    'display': 'inline-block',
                    'float': 'right'
                });
                cookieQuery('#cookiescript_injected div#cookiescript_accept', cookieScriptWindow).css({
                    'background-color': '#5BB75B',
                    'color': '#FFFFFF',
                    'display': 'inline-block',
                    'margin-right': '5px'
                });
                cookieQuery('#cookiescript_injected div#cookiescript_pixel', cookieScriptWindow).css({
                    'width': '1px',
                    'height': '1px',
                    'float': 'left'
                });
                cookieQuery('#cookiescript_injected', cookieScriptWindow).fadeIn(1000);
                cookieQuery('#cookiescript_injected div#cookiescript_accept', cookieScriptWindow).click(function() {
                    o()
                });
                cookieQuery('#cookiescript_injected div#cookiescript_reject', cookieScriptWindow).click(function() {
                    r()
                });
                cookieQuery('#cookiescript_injected div#cookiescript_readmore', cookieScriptWindow).click(function() {
                    return !1
                })
            };
                c();
                return !1
            };
                cookieQuery(window).scroll(function() {
                    o();
                })
            };
            var n = i('firstpage');
                e('action', 'accept');
                t();
                return !1
            } else {
                e('firstpage', cookieScriptCurrentUrl)
            };
            cookieScriptAddBox();
            a();
                cookieQuery('#cookiescript_injected').fadeOut(400)
            }, 60000);
        });

        function a() {
            cookieQuery('iframe[data-cookiescript="accepted"]').not(':has([src])').each(function() {
                o = (o.contentWindow) ? o.contentWindow : (o.contentDocument.document) ? o.contentDocument.document : o.contentDocument;
                o.document.open();
                o.document.write(cookieQuery(this).attr('alt'));
                o.document.close()
            })
        };

        function o() {
            cookieQuery('#cookiescript_injected', cookieScriptWindow).fadeOut(200);
            e('action', 'accept');
            t();
            cookieQuery('#csconsentcheckbox').prop('checked', !0);
            c()
        };

        function r() {
            e('action', 'reject');
            p();
            cookieQuery('#cookiescript_injected', cookieScriptWindow).fadeOut(200);
            cookieQuery('#csconsentcheckbox').prop('checked', !1);
            c()
        };

        function e(o, i) {
            var t = 'CookieScriptConsent';
            try {
                var c = JSON.parse(cookieScriptReadCookie(t))
                return !1
            };
                var c = {};
                c[o] = i
            } else {
            };
            try {
                var r = JSON.stringify(c)
                return !1
            };
            cookieScriptCreateCookie(t, r, 30)
        };

        function i(o) {
            var c = 'CookieScriptConsent';
            try {
                var i = JSON.parse(cookieScriptReadCookie(c))
                return null
            };
                return null
            } else {
            }
        };

        function c() {
            if (cookieQuery('#cookiescript_badge').length) {
                cookieQuery('#cookiescript_badge', cookieScriptWindow).fadeIn(500)
            } else {
                cookieQuery('body', cookieScriptWindow).append('<div id="cookiescript_badge">Cookie settings</div>');
                cookieQuery('#cookiescript_badge', cookieScriptWindow).css({
                    'position': 'fixed',
                    'font': '13px Arial',
                    'line-height': '20px',
                    'color': '#FFFFFF',
                    'display': 'none',
                    'cursor': 'pointer',
                    'z-index': '999',
                    'background': '#db6f34',
                    'padding': '6px 11px 2px',
                    '-moz-box-shadow': '0px 0px 3px #000000',
                    '-webkit-box-shadow': '0px 0px 3px #000000',
                    'box-shadow': '0px 0px 3px #000000',
                    'left': '10px',
                    'top': '0px',
                    '-webkit-border-bottom-right-radius': '5px',
                    '-webkit-border-bottom-left-radius': '5px',
                    '-moz-border-radius-bottomright': '5px',
                    '-moz-border-radius-bottomleft': '5px',
                    'border-bottom-right-radius': '5px',
                    'border-bottom-left-radius': '5px'
                });
                cookieQuery('#cookiescript_badgeimage', cookieScriptWindow).css({
                    'width': '100%',
                    'height': '100%'
                });
                cookieQuery('#cookiescript_badge', cookieScriptWindow).fadeIn(500);
                cookieQuery('#cookiescript_badge').click(n)
            }
        };

        function n() {
            if (cookieQuery('#cookiescript_badge').length) {
                cookieQuery('#cookiescript_badge', cookieScriptWindow).fadeOut(200)
            };
            if (cookieQuery('#cookiescript_injected').length) {
                cookieQuery('#cookiescript_injected', cookieScriptWindow).fadeIn(200)
            } else {
                cookieScriptAddBox()
            }
        };

        function s(o) {
        };

        function d() {
            if (i('action') == 'accept') {
                cookieQuery('#csconsentcheckbox').prop('checked', !0)
            };
            cookieQuery('#csconsentcheckbox').change(function() {
                    o()
                } else {
                    r()
                }
            });
            cookieQuery('#csconsentlink').click(function() {
                n()
            })
        };
        d();

        function p() {
            for (var o in r) {
                if (o == 'CookieScriptConsent') {
                    continue
                };
                    var c = new RegExp('[a-z\-0-9]{2,63}\.[a-z\.]{2,5}$'),
                                path: '/',
                    }
                }
            }
        };
        if (i('action') != 'accept') setTimeout(p, 500);

        function t() {
            cookieQuery('img[data-cookiescript="accepted"]').each(function() {
                cookieQuery(this).attr('src', cookieQuery(this).attr('data-src'))
            });
            cookieQuery('script[type="text/plain"][data-cookiescript="accepted"]').each(function() {
                if (cookieQuery(this).attr('src')) {
                    cookieQuery(this).after('<script type="text/javascript" src="' + cookieQuery(this).attr('src') + '"><\/script>')
                } else {
                    cookieQuery(this).after('<script type="text/javascript">' + cookieQuery(this).html() + '<\/script>')
                };
                cookieQuery(this).empty()
            });
            cookieQuery('iframe[data-cookiescript="accepted"]').each(function() {
                cookieQuery(this).attr('src', cookieQuery(this).attr('data-src'))
            });
            cookieQuery('embed[data-cookiescript="accepted"]').each(function() {
                cookieQuery(this).replaceWith(cookieQuery(this).attr('src', cookieQuery(this).attr('data-src'))[0].outerHTML)
            });
            cookieQuery('object[data-cookiescript="accepted"]').each(function() {
                cookieQuery(this).replaceWith(cookieQuery(this).attr('data', cookieQuery(this).attr('data-data'))[0].outerHTML)
            });
            cookieQuery('link[data-cookiescript="accepted"]').each(function() {
                cookieQuery(this).attr('href', cookieQuery(this).attr('data-href'))
            })
        }
    };
window.jQuery && jQuery.fn && /^(1\.[8-9]|2\.[0-9]|1\.1[0-2]|3\.[0-9])/.test(jQuery.fn.jquery) ? (cookieScriptDebug && window.console && console.log('Using existing jQuery version ' + jQuery.fn.jquery), cookieQuery = window.jQuery, InjectCookieScript()) : (cookieScriptDebug && window.console && console.log('Loading jQuery 1.8.1 from ajax.googleapis.com'), cookieScriptLoadJavaScript(('https:' == document.location.protocol ? 'https://' : 'http://') + 'ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js', function() {
}));