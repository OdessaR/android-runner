"use strict";
! function(e) {
    var t = {
            apiUrl: "/api/accorhotels/searchapi/searchNews",
            requestModel: {
                Page: 1,
                PageSize: 10,
                Query: "",
                ContentTypeName: "",
                CategoryId: "",
                StartDate: "",
                EndDate: "",
                Sort: "Date"
            }
        },
        a = function() {
            e.ajax({
                type: "POST",
                url: t.apiUrl,
                data: t.requestModel,
                dataType: "json",
                success: function(e) {
                    s(e), l(e)
                },
                error: function(e) {
                }
            })
        },
        s = function(t) {
            var a, s = t.results,
                l = e(".results-container"),
                r = [];
            if (l.empty(), s.length > 0) {
                for (var n = 0; n < s.length; n++)
                    if (null !== (a = s[n]).searchResultDetails) {
                        var o = "";
                        a.searchResultDetails.documentType && "pdf" === a.searchResultDetails.documentType.toLowerCase() && (o = " onclick =\"return trackStatsPDF(this, '11')\""), r.push('<div class="module-result"><a href="' + a.articleUrl + '" class="trigger"' + o + '><img src="' + a.imageUrl + '" alt="' + a.title + '" class="picture" style="barckground-color:grey"><div class="content"><h2 class="title">' + a.title + '</h2><p class="text-description">' + a.abstract + '</p><p class="text">' + a.formattedDate + " - " + a.contentTypeNameTranslated + '</p><ul class="details"><li><span class="icon icon-' + a.searchResultDetails.documentType + '"></span><span class="accessibility">' + a.searchResultDetails.documentTitle + '</span></li><li class="weight">' + a.searchResultDetails.documentWeight + '</li><li class="lang">' + a.searchResultDetails.documentLang + '</li></ul><span class="icon icon-arrow"></span></div></a></div>')
                    } else r.push('<div class="module-result"><a href="' + a.articleUrl + '" class="trigger"><img src="' + a.imageUrl + '" alt="' + a.title + '" class="picture" style="barckground-color:grey"><div class="content"><h2 class="title">' + a.title + '</h2><p class="text-description">' + a.abstract + '</p><p class="text">' + a.formattedDate + " - " + a.contentTypeNameTranslated + '</p><span class="icon icon-arrow"></span></div></a></div>');
                l.append(r.join(""))
            }
        },
        l = function(a) {
            var s, l, n, o = a.totalResults,
                i = Number(t.requestModel.Page),
                u = (e("#pager-news-top"), e("#pager-news-top"), Math.ceil(o / t.requestModel.PageSize));
            if (s = o, l = e("div.all-news").find("p.results"), (n = l.text().split(" "))[0] = s.toString(), l.text(n.join(" ")), 0 != o) {
                if (u && "number" == typeof u) {
                    if (1 == u) var c = e('<li class="pager-item-news active"><button title=" ' + i + ' ">' + i + "</button></li>");
                    else {
                        var p = 1 != Number(i) ? '<li class="pager-item-news" id="pager-item-news"><button data-role="prev" onclick="gotoPagerNewsTop();" ><span class="icon icon-arrow-left"></span><span class="accessibility">Page pr�c�dente</span></button></li>' : "",
                            d = Number(i) < u ? '<li class="pager-item-news" id="pager-item-news"><button onclick="gotoPagerNewsTop();" data-role="next"><span class="icon icon-arrow"></span><span class="accessibility">Page suivante</span></button></li>' : "";
                        c = e(p + (Number(i - 1) > 1 ? '<li class="pager-item-news" id="pager-item-news"><button onclick="gotoPagerNewsTop();" title="1">1</button></li>' : "") + (Number(i - 2) > 1 ? "<li>...</li>" : "") + (Number(i) > 1 ? '<li class="pager-item-news" id="pager-item-news"><button onclick="gotoPagerNewsTop();" title="' + Number(i - 1) + '">' + Number(i - 1) + "</button></li>" : "") + '<li class="pager-item-news active" id="pager-item-news"><button onclick="gotoPagerNewsTop();" title="' + i + '">' + i + "</button></li>" + (Number(i) + 1 < u ? '<li class="pager-item-news" id="pager-item-news"><button onclick="gotoPagerNewsTop();" title="' + Number(i + 1) + '">' + Number(i + 1) + "</button></li>" : "") + (Number(i) + 2 < u ? '<li class="pager-item-news" id="pager-item-news"><button onclick="gotoPagerNewsTop();" title="' + Number(i + 2) + '">' + Number(i + 2) + "</button></li>" : "") + (Number(i) + 3 < u ? "<li>...</li>" : "") + (Number(i) != u ? '<li class="pager-item-news" id="pager-item-news"><button onclick="gotoPagerNewsTop();" title="' + u + '">' + u + "</button></li>" : "") + d)
                    }
                    e("ul.pagination").empty().append(c)
                }
                e("#pager-news .pager-item-news").on("click", function(t) {
                    t.preventDefault(), r(e(t.target)), gotoPagerNewsTop()
                })
            } else e("ul.pagination").empty()
        },
        r = function(s) {
            var l = Number(s.text());
            "" == s.text() || isNaN(l) ? "next" === e(s).parent().attr("data-role") || "next" === e(s).attr("data-role") ? (t.requestModel.Page = Number(t.requestModel.Page) + 1, a()) : "prev" !== e(s).parent().attr("data-role") && "prev" !== e(s).attr("data-role") || (Number(t.requestModel.Page) > 1 ? (t.requestModel.Page = Number(t.requestModel.Page) - 1, a()) : (t.requestModel.Page = 1, a())) : t.requestModel.Page = l, a()
        },
        n = function(e) {
            if (!(null == e || e.indexOf("/") < 0)) {
                var t = e.split("/");
                return t[1] + "/" + t[0] + "/" + t[2]
            }
        };
    ! function() {
        var s, o = e("input#keyword"),
            i = e("button#Valider"),
            u = e("#pager-news .pager-item-news"),
            c = e("div.all-news").find("p.results").text(),
            p = e("select#sections"),
            d = e("select#type");
        if (t.requestModel.CategoryId = p.val(), t.requestModel.ContentTypeName = d.val(), t.requestModel.publishAfter = n(e("input#calendar-after").val()), t.requestModel.publishBefore = n(e("input#calendar-before").val()), t.requestModel.ContentTypeName = d.val(), o.on("keyup", function(l) {
            }), i.on("click", function() {
            }), u.on("click", function(t) {
                t.preventDefault(), r(e(t.target)), gotoPagerNewsTop()
            }), null != e("input#keyword").val() && (t.requestModel.Query = e("input#keyword").val()), c) {
            var g = Number(c.split(" ")[0]);
            isNaN(g) || l({
                totalResults: g
            })
        }
    }()
}(jQuery);
var findPos = function(e) {
        var t = 0;
        if (e.offsetParent) {
            do {
                t += e.offsetTop
            return [t]
        }
    },
    gotoPagerNewsTop = function() {
    };