function forceSidebarImgToload() {
    $(".sideNavPicture").find("img").each(function() {
    })
}

function addClassToBody(e) {
}

function tailleTexteTitleLevel3() {
        var e = $(".is-current-level2").find(".wrapper-label")[0],
            a = $(e).find(".level-3-title")[0],
            t = $(a).height(),
            n = parseFloat($(e).css("line-height")),
            r = Math.ceil(t / n);
        if (r > 1 && r < 5) {
            var i = parseInt($(a).css("padding-top")) - 10 * (r - 1),
                s = parseInt($(a).css("padding-bottom")) - 10 * (r - 1);
            $(a).css("padding-top", i + "px"), $(a).css("padding-bottom", s + "px")
        }
    }
}

function PostFrom(e, a, t, n, r, i, s, o, c, d, l) {
    $("#list-date-" + e + " li:not(.on)").click(function() {
        $(this).siblings().removeClass("on"), $(this).addClass("on")
    }), $("#hiddenPager-" + e).val(t);
    var u = {};
        type: "POST",
        url: a,
        data: u,
        success: function(a) {
            $("#list-docs-" + e).html(""), $("#list-docs-" + e).html(a.PressStr), $("#pager-" + e).html(""), $("#pager-" + e).html(a.PagersStr)
        }
    })
}

function PostFromPager(e, a, t, n, r, i, s, o, c, d) {
    var l = $("#hiddenPager-" + e).val(),
        u = {};
        type: "POST",
        url: a,
        data: u,
        success: function(a) {
            $("#list-docs-" + e).html(""), $("#list-docs-" + e).html(a.PressStr), $("#pager-" + e).html(""), $("#pager-" + e).html(a.PagersStr)
        }
    })
}

function AccorHotelsBourse(e, a, t, n, r, i) {
    var s = e,
        o = a,
        c = t,
        d = n,
        l = r,
        u = i,
        v = function(e) {
            return isNaN(e) ? e : e.replace(/(?!^)(?=(?:\d{3})+(?:\.|$))/gm, " ")
        },
        g = function(e, a) {
            var t = e.split("-");
            return "en" == a.toLowerCase() ? parseInt(t[1]) + "." + parseInt(t[2]) + "." + parseInt(t[0]) : t[2] + "." + t[1] + "." + t[0]
        },
        p = function(e, a, t, n, r) {
            var i = function(e, a, t, n) {
                var r = "",
                    i = "",
                    s = 0,
                    o = "",
                    c = "",
                    d = "",
                    l = "",
                    u = "";
                if (void 0 !== t && void 0 !== t[a]) {
                    var v = t[a],
                        p = v.date,
                        f = p.indexOf(" ");
                    r = g(p.substring(0, f), e), i = p.substring(f + 1, f + 6), o = (s = parseFloat(v.change.replace(",", "."))).toFixed(2), c = s > 0 ? "data-up" : s < 0 ? "data-down" : "", d = s > 0 ? "+ " : "", l = s > 0 ? "icon-arrow-up" : s < 0 ? "icon-arrow-down" : "", u = parseFloat(v.last).toFixed(2)
                }
                return {
                    dateInfo: r,
                    heureInfo: i,
                    variance: s,
                    svariance: o,
                    varianceClass: c,
                    varianceSign: d,
                    varianceIconClass: l,
                    valeur: u,
                    currency: n
                }
            }(e, a, n, r);
            $("#" + t + " > p.text-information").prepend(i.dateInfo), $("#" + t + " > p.text-information > span.hour").html(i.heureInfo), $("#" + t + " > p.brs-valeur").addClass(i.varianceClass), $("#" + t + " > p.brs-valeur > span").addClass(i.varianceIconClass), $("#" + t + " > p.brs-valeur").append(i.valeur + " " + i.currency), $("#" + t + " > p.brs-variance").addClass(i.varianceClass), $("#" + t + " > p.brs-variance").html(i.varianceSign + i.svariance + " %")
        },
        f = function(e, a, t, n, r) {
            var i = function(e, a, t, n) {
                var r = "",
                    i = "",
                    s = "",
                    o = "",
                    c = 0,
                    d = "",
                    l = "",
                    u = "",
                    p = "",
                    f = "",
                    h = "",
                    m = "",
                    $ = "",
                    x = "",
                    w = "",
                    y = "";
                if (void 0 !== t && void 0 !== t[a]) {
                    var b = t[a],
                        C = b.date,
                        I = C.indexOf(" ");
                    r = g(C.substring(0, I), e), i = C.substring(I + 1, I + 6), s = b.last, o = b.close, d = (c = parseFloat(b.change.replace(",", "."))) > 0 ? "data-up" : c < 0 ? "data-down" : "", l = c > 0 ? "+" : "", u = c.toFixed(2), p = b.high, f = b.low, h = v(b.volume), m = v(b.capitalisation), $ = b.max_january, w = (x = (x = 100 * parseFloat(b.last) / parseFloat(b.max_january) - 100).toFixed(2)) > 0 ? "data-up" : x < 0 ? "data-down" : "", y = x > 0 ? "+" : ""
                }
                return {
                    dateInfo: r,
                    heureInfo: i,
                    last: s,
                    close: o,
                    variance: c,
                    svariance: u,
                    varianceClass: d,
                    varianceSign: l,
                    high: p,
                    low: f,
                    svol: h,
                    scap: m,
                    max_january: $,
                    performance: x,
                    performanceClass: w,
                    performanceSign: y,
                    currency: n
                }
            }(e, a, n, r);
            $("#dateHeure_" + t).text(i.dateInfo + " | " + i.heureInfo), $("#last_" + t).text(i.last), $("#close_" + t).text(i.close), $("#variance_" + t).text(i.varianceSign + i.svariance + "%"), $("#variance_" + t).addClass(i.varianceClass), $("#high_" + t).text(i.high), $("#low_" + t).text(i.low), $("#vol_" + t).text(i.svol), $("#maxJanuary_" + t).text(i.max_january), $("#performance_" + t).text(i.performanceSign + i.performance + "%"), $("#performance_" + t).addClass(i.performanceClass), $("#cap_" + t).text(i.scap + " " + i.currency)
        };
    return {
        configure: function() {
            e.onreadystatechange = function() {
                    var a = e.status;
                    if ("200" == a || "404" == a) {
                        var t = JSON.parse(e.responseText);
                        r = o, i = c, l = d, v = t, g = u, "BourseJson" == (n = s) && p(r, i, l, v, g), "ContentBourse" == n && f(r, i, l, v, g)
                    }
                }
                var n, r, i, l, v, g
            }, e.open("GET", l, !0), e.send(null)
        }
    }
}

function trackCompare(e, a) {
    var t;
}

function trackStatsLanguette(e, a, t) {
    var n, r = jQuery(e).attr("href");
    if (r) {
        var i = String(r).replace(/^.*[\\\/]/, "");
            event_category: "Languette",
            event_label: t
        })
    }
}

function trackStatsPDF(e, a) {
    var t = jQuery(e).attr("href");
    if (t && ("-1" != t.indexOf("?") && (t = t.substring(0, t.indexOf("?"))), t.match(/\.(pdf)$/i))) {
        String(/[.]/.exec(t) ? /[^.]+$/.exec(t) : void 0);
        var n = String(t).replace(/^.*[\\\/]/, "");
            event_category: "PDF-Downloads",
        });
        var r = !0;
    }
}

function disableOverlay(e) {
    $(".vjs-overlay.vjs-overlay-top-left.vjs-overlay-background").addClass("vjs-hidden")
}

function hideSidenav() {
    $("#content").addClass(".without-after-element"), $(".sidenav").css("z-index", "90")
}

function showSidenav() {
}

function searchSpinToggle() {
    $(".search-spin").each(function() {
        $(this).toggle()
    }), $("p.results").each(function() {
        $(this).toggle()
    }), $("nav.pagination-wrapper-top").each(function() {
        $(this).toggle()
    }), $("div.results-container").each(function() {
        $(this).toggle()
    }), $("nav.pagination-wrapper").each(function() {
        $(this).toggle()
    })
}
document.addEventListener("DOMContentLoaded", e => {
        n = function() {
            var e = t.getElementsByTagName("img");
            if (e)
                for (let a = 0; a < e.length; a++) {
                    const t = e[a],
                        n = t.attributes;
                    for (let e = 0; e < n.length; e++) {
                        const a = n[e];
                        "data-customlazyload" === a.name && a.value && t.setAttribute("src", a.value)
                    }
                }
            removeEventListener("click", n)
        };
    a.addEventListener("click", () => {
        setTimeout(() => {
            (function(e, a) {
                return (" " + e.className + " ").indexOf(" " + a + " ") > -1
        }, 100)
        n()
    }, 3e3)
});