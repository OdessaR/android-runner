"use strict";
! function(e) {
    var t = {
            apiUrl: "/api/accorhotels/searchapi/search",
            requestModel: {
                Page: 1,
                PageSize: 10,
                Query: "",
                ContentTypeName: "",
                Sort: e("ul.sort-list").find("li.active").find("button").attr("data-search-order")
            }
        },
        a = function() {
            e.ajax({
                type: "POST",
                url: t.apiUrl,
                data: t.requestModel,
                dataType: "json",
                success: function(t) {
                    i(t), e(".search-spin").each(function() {
                        e(this).hide()
                    }), e("p.results").each(function() {
                        e(this).show()
                    }), e("nav.pagination-wrapper-top").each(function() {
                        e(this).show()
                    }), e("div.results-container").each(function() {
                        e(this).show()
                    }), e("nav.pagination-wrapper").each(function() {
                        e(this).show()
                    }), o(t)
                },
                error: function(e) {
                }
            })
        },
        i = function(t) {
            var a, i = t.results,
                o = e(".results-container"),
                l = [];
            if (o.empty(), i.length > 0) {
                l.push('<script src="//players.brightcove.net/2432590742001/rJvwYPinG_default/index.min.js"><\/script>');
                for (var s = 0; s < i.length; s++) {
                    var n = " - " + (a = i[s]).contentTypeNameTranslated;
                    if ("Other" === a.contentTypeName && (n = ""), a.isVideo) l.push('<div class="module-result"><button class="JS_toggler trigger" data-toggler-id="popin-video-' + a.videoInfo.videoID + '" data-toggler-group="popin" onclick="document.getElementById(\'popvideo-' + a.videoInfo.videoID + '_html5_api\').play()"><img src="' + a.imageUrl + '" alt="' + a.title + '" class="picture" style="barckground-color:grey"><span class="play module-result-video-popin" aria-hidden="true" ><span class="icon icon-play"></span></span><div class="content"><h2 class="title">' + a.title + '</h2><p class="text-description">' + a.abstract + '</p><p class="text">' + a.formattedDate + n + '</p><span class="icon icon-arrow"></span></div></button><style>.module-result .module-video {background-color: none;}.module-result .module-video .video-js {display: block;}</style><div class="module-video js-module" data-module="module-video"><div class="popin popin-video-' + a.videoInfo.videoID + ' JS_item_toggler js-module"data-module="module-popin-manager"data-toggler-itemid="popin-video-' + a.videoInfo.videoID + '"data-toggler-group="popin"role="dialog" aria-label="' + a.title + '" tabindex="-1"><div class="mask"></div><div class="content-scroll"><div class="content-wrapper"><div class="popin-content"><div class="popin-ground" style="background:#13202e"><button class="popin-close JS_toggler"data-toggler-id="popin-video-' + a.videoInfo.videoID + '"data-toggler-group="popin"data-toggler-action="close"onclick="document.getElementById(\'popvideo-' + a.videoInfo.videoID + '_html5_api\').pause()"><span class="accessibility">' + a.videoInfo.closeLabel + '</span><span style="color:#fff;"><i class="fa fa-times-thin fa-2x" aria-hidden="true"></i></span></button><div class="in-content"  role="document"><div class="popin-title">' + a.title + '</div><video id="popvideo-' + a.videoInfo.videoID + '" data-video-id="' + a.videoInfo.videoID + '" data-account="' + a.videoInfo.videoAccount + '" data-player="' + a.videoInfo.videoPlayer + '" data-embed="default" data-application-id class="video-js" controls onplay="videojs(\'popvideo-' + a.videoInfo.videoID + "_html5_api');setTimeout(function(){disableOverlay()}, 100 );\"></video></div></div></div></div></div></div></div></div>");
                    else if (null !== a.searchResultDetails) {
                        var r = "";
                        a.searchResultDetails.documentType && "pdf" === a.searchResultDetails.documentType.toLowerCase() && (r = " onclick =\"return trackStatsPDF(this, '11')\""), l.push('<div class="module-result"><a href="' + a.articleUrl + '" class="trigger"' + r + '><div class="imgContainer"><img src="' + a.imageUrl + '" alt="' + a.title + '" class="picture" style="barckground-color:grey"></div><div class="content"><h2 class="title">' + a.title + '</h2><p class="text-description">' + a.abstract + '</p><p class="text">' + a.formattedDate + n + '</p><ul class="details"><li><span class="icon icon-' + a.searchResultDetails.documentType + '"></span><span class="accessibility">' + a.searchResultDetails.documentTitle + '</span></li><li class="weight">' + a.searchResultDetails.documentWeight + '</li><li class="lang">' + a.searchResultDetails.documentLang + '</li></ul><span class="icon icon-arrow"></span></div></a></div>')
                    } else l.push('<div class="module-result"><a href="' + a.articleUrl + '" class="trigger"><div class="imgContainer"><img src="' + a.imageUrl + '" alt="' + a.title + '" class="picture" style="barckground-color:grey"></div><div class="content"><h2 class="title">' + a.title + '</h2><p class="text-description">' + a.abstract + '</p><p class="text">' + a.formattedDate + n + '</p><span class="icon icon-arrow"></span></div></a></div>')
                }
                o.append(l.join(""))
            }
        },
        o = function(a) {
            var i, o, s, n = a.totalResults,
                r = Number(t.requestModel.Page),
                d = (e(".pagination-wrapper-top"), e(".pagination-wrapper-bottom"), Math.ceil(n / t.requestModel.PageSize));
            if (i = n, o = e("div.search").find("p.results"), (s = o.text().split(" "))[0] = i.toString(), o.text(s.join(" ")), 0 !== n) {
                if (d && "number" == typeof d) {
                    if (1 === d) var u = e('<li class="pager-item active"><button title=" ' + r + ' pagination active">' + r + "</button></li>");
                    else {
                        var p = 1 !== Number(r) ? '<li class="pager-item"><button data-role="prev"><span class="icon icon-arrow-left"></span><span class="accessibility">Page pr�c�dente</span></button></li>' : "",
                            v = Number(r) < d ? '<li class="pager-item"><button data-role="next"><span class="icon icon-arrow"></span><span class="accessibility">Page suivante</span></button></li>' : "";
                        u = e(p + (Number(r - 1) > 1 ? '<li class="pager-item"><button title="1">1</button></li>' : "") + (Number(r - 2) > 1 ? "<li>...</li>" : "") + (Number(r) > 1 ? '<li class="pager-item"><button title="' + Number(r - 1) + '">' + Number(r - 1) + "</button></li>" : "") + '<li class="pager-item active"><button title="' + r + ' pagination active">' + r + "</button></li>" + (Number(r) + 1 < d ? '<li class="pager-item"><button title="' + Number(r + 1) + '">' + Number(r + 1) + "</button></li>" : "") + (Number(r) + 2 < d ? '<li class="pager-item"><button title="' + Number(r + 2) + '">' + Number(r + 2) + "</button></li>" : "") + (Number(r) + 3 < d ? "<li>...</li>" : "") + (Number(r) !== d ? '<li class="pager-item"><button title="' + d + '">' + d + "</button></li>" : "") + v)
                    }
                    e("ul.pagination").empty().append(u)
                }
                e("li.pager-item").on("click", function(t) {
                    t.preventDefault(), l(e(t.target)), c()
                })
            } else e("ul.pagination").empty()
        },
        l = function(i) {
            var o = Number(i.text());
            "" === i.text() || isNaN(o) ? "next" === e(i).parent().attr("data-role") || "next" === e(i).attr("data-role") ? (t.requestModel.Page = Number(t.requestModel.Page) + 1, a()) : "prev" !== e(i).parent().attr("data-role") && "prev" !== e(i).attr("data-role") || (Number(t.requestModel.Page) > 1 ? (t.requestModel.Page = Number(t.requestModel.Page) - 1, a()) : (t.requestModel.Page = 1, a())) : t.requestModel.Page = o, a()
        },
        s = function(e) {
            var i = e.first().attr("id");
            t.requestModel.ContentTypeName = i.replace(/\s/g, ""), t.requestModel.Page = 1, a()
        },
        n = function(e) {
            var i = e.attr("data-search-order");
            t.requestModel.Sort = i, t.requestModel.Page = 1, a()
        },
        r = function(t) {
            t.parents("ul").find("li").removeClass("active"), t.parent().addClass("active");
            var a = t.parents("ul").find("li").find("button"),
                i = "";
            a.each(function() {
                if (e(this).attr("title").split(" | ").length > 1) return i = e(this).attr("title").split(" | ")[1], e(this).attr("title", e(this).attr("title").split(" | ")[0]), !1
            }), t.attr("title", t.attr("title") + " | " + i)
        },
        c = function() {
                var t = 0;
                if (e.offsetParent) {
                    do {
                        t += e.offsetTop
                    return [t]
                }
        };
    ! function() {
        var a, i = e("input#search"),
            d = i.next("button"),
            u = e("li.pager-item"),
            p = e("ul.filters"),
            v = e("ul.sort-list"),
            g = e("div.search").find("p.results").text();
        if (void 0 !== e("input#search").val() && (t.requestModel.Query = e("input#search").val()), i.on("keyup", function(o) {
            }), d.on("click", function() {
            }), u.on("click", function(t) {
                t.preventDefault(), l(e(t.target)), c()
            }), p.on("click", function(t) {
                t.preventDefault(), s(e(t.target)), r(e(t.target))
            }), v.on("click", function(t) {
                t.preventDefault(), n(e(t.target)), r(e(t.target))
            }), g) {
            var m = Number(g.split(" ")[0]);
            isNaN(m) || o({
                totalResults: m
            })
        }
    }()
}(jQuery);