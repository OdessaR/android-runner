var picturePolyfill = function(a) {
    "use strict";
    var b, c, d, e = 100,
        f = !1;
    return {
        _getAttrs: function(a, b) {
            for (var c, d, e = {}, f = 0, g = b.length; f < g; f += 1) c = b[f], d = a.getAttribute(c), d && (e[c] = d);
            return e
        },
        _getAttrsList: function(a) {
            for (var b = [], c = 0, d = a.attributes, e = d.length; c < e; c++) b.push(d.item(c).nodeName);
            return b
        },
        _getSrcsetArray: function(a) {
            var b, c, d, e, f = [];
            if (null === a || "" === a || "undefined" == typeof a) return f;
            e = a.split(",");
            for (var g = 0, h = e.length; g < h; g += 1) b = e[g].trim().split(" "), d = 1 === b.length ? 1 : parseFloat(b[b.length - 1], 10), c = b[0], f.push({
                pxr: d,
                src: c
            });
            return f.sort(function(a, b) {
                var c = a.pxr,
                    d = b.pxr;
                return c < d ? -1 : c > d ? 1 : 0
            })
        },
        _getSrcFromSrcset: function(a, b) {
            var c, d, e = 0,
                f = -1;
            if (null === a || "" === a || "undefined" == typeof a) return "";
            do(c[e].pxr >= b || e === d - 1) && (f = e), e += 1; while (!(f > -1 || e >= d));
            return c[f].src
        },
        _getSrcsetFromData: function(b) {
            for (var c, d, e, f, g = 0, h = b.length; g < h; g += 1)
                if (c = b[g], d = c.media, f = c.srcset, e = c.src, !d || a.matchMedia(d).matches) return f ? f : e ? e : "";
            return ""
        },
        _getImgTagsInPicture: function(a) {
            var b, c = a;
            if (b = a.getElementsByTagName("img"), b.length > 0) return b;
            do
                if (c = c.nextSibling, null === c) return []; while ("IMG" !== c.tagName);
            return [c]
        },
        _setImgAttributes: function(a, b) {
            function c(a, b, c) {
                a.getAttribute(b) !== c && a.setAttribute(b, c)
            }
            return 0 !== i.length && (d = i[0], d.getAttribute("data-original-src") || (c(d, "data-original-src", d.getAttribute("src")), c(d, "data-original-srcset", d.getAttribute("srcset"))), e = b.src, f = b.srcset, e || f ? (g = e, h = f) : (g = d.getAttribute("data-original-src"), h = d.getAttribute("data-original-srcset")), c(d, "src", g), void c(d, "srcset", h))
        },
        _getSourcesData: function(a) {
            return d
        },
        _addListeners: function() {
            function b() {
            }

            function c() {
                clearTimeout(d), d = setTimeout(b, e)
            }
                b(), a.removeEventListener("load", b)
            }), a.addEventListener("load", b)) : a.attachEvent && (a.attachEvent("onload", b), a.attachEvent("onresize", c)), void(f = !0))
        },
        initialize: function() {
        },
        parse: function(a, d) {
            var e, f, g, h, i, j;
                src: h,
                srcset: i,
                alt: f.getAttribute("data-alt")
            });
            return k
        }
    }
}(window);
picturePolyfill.initialize(), picturePolyfill.parse();