$(function() {
    var e = $(".acting-here .circle-sections"),
        n = $(".acting-here .mobile-content-container"),
        i = n.find(".mobile-content"),
        t = $(".acting-here .intro-global");
    e.find(".section:not(.hospitalite)").on("click", function() {
        "none" !== n.css("display") && (i.html($(this).find(".content").html()), e.addClass("fadeOut"), n.addClass("active"))
    }), e.find(".section").on("click", function() {
    }), n.find(".close-mobile").on("click", function() {
        n.removeClass("active"), e.removeClass("fadeOut")
    });
    var o = setTimeout(function() {
        t.removeClass("active"), clearTimeout(o)
    }, 1500);
    t.on("mouseenter", function() {
        "none" === n.css("display") && t.addClass("active")
    }).on("mouseleave", function() {
        t.removeClass("active")
    }).trigger("mouseenter").find(".arrow-container").on("click", function() {
        t.hasClass("active") ? t.removeClass("active") : t.addClass("active")
    })
});