WebFontConfig = {
    google: {
        families: ['Roboto+Condensed:400,300,700,300italic,400italic,700italic:latin', 'Roboto:400,500:latin']
    }
};
(function() {
        '://ajax.googleapis.com/ajax/libs/webfont/1/webfont.js';
    wf.type = 'text/javascript';
    wf.async = 'true';
    s.parentNode.insertBefore(wf, s);
})();