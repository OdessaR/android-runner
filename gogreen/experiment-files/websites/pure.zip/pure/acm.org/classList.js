(function() {


    var prototype = Array.prototype,
        push = prototype.push,
        splice = prototype.splice,
        join = prototype.join;

    function DOMTokenList(el) {
        // The className needs to be trimmed and split on whitespace
        // to retrieve a list of classes.
        var classes = el.className.replace(/^\s+|\s+$/g, '').split(/\s+/);
        for (var i = 0; i < classes.length; i++) {
            push.call(this, classes[i]);
        }
    };

        add: function(token) {
            push.call(this, token);
        },
        contains: function(token) {
        },
        item: function(index) {
        },
        remove: function(token) {
            }
            splice.call(this, i, 1);
        },
        toString: function() {
            return join.call(this, ' ');
        },
        toggle: function(token) {
            } else {
            }

        }
    };


    function defineElementGetter(obj, prop, getter) {
        if (Object.defineProperty) {
            Object.defineProperty(obj, prop, {
                get: getter
            });
        } else {
            obj.__defineGetter__(prop, getter);
        }
    }

    });

})();