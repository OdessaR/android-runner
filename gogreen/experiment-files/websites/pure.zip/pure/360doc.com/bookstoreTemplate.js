/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_1445 = ["type", "", "<div class=\"content5\">", "\x09<div class=\"zcomdiv\" id=\"contentnew\">", "\x09\x09<ul class=\"c5_list\">", "\x09\x09</ul>", "     <div id=\"contentoffside\" class=\"c5_d1 f_right\">", "     </div>", "\x09</div>", "</div>", "html", "#content_index", "<div class=\"bookstore\">", "\x09<ul class=\"c5_list\">", "\x09</ul>", "\x09<div class=\"bookstore_r\">", " \x09<div class=\"c5_slider\" id=\"c5_slider\">", " \x09</div>", " \x09<div class=\"rtips_join\" style=\"margin-top: 8px;\">", " </div>", ".rcontent", "getBookCityClass", "classid", "subclassid", "bookClassSwitch", "<div class=\"c5_slider\" id=\"c5_slider\" ></div><div class=\"rtips_join\"></div>", "#contentoffside", "c5_d1", "addClass", "removeClass", "c6_right", "cur", ".c5_list a", "#bookclass_", "#booksubclass_", "<div class=\"rtips_join\"></div>", "    <div class=\"c6_3d\">", "    </div>", "    <div class=\"c5_booktitle\" style=\"margin-top: 10;\"><p class=\"f_left\" id=\"titele_classid\">--</p><ul class=\"f_left\" id=\"switch_order\"><li class=\"cur\">\u6700\u65b0</li><li class=\"p1 no\">\u4ef7\u683c</li><li>\u4eba\u6c14</li></ul><b></b></div>", "<p class=\"z1d1text\">\u8d60\u4e66\u7ed9\u670b\u53cb\uff0c\u670b\u53cb\u9886\u53d6\u540e\u4f60\u4e5f\u83b7\u8d60\u6b64\u4e66\u3002\u6bcf\u671f20\u672c\u90fd\u6709\u673a\u4f1a\u83b7\u5f97\u3002</p>", "    <ul class=\"c6_ul\" id=\"ullist\">", "    </ul>", "    <div id=\"loadMore\" class=\"bottompager\" style=\"display: block;\"></div>", "    <div id=\"mesages\" style=\"text-align: center;/*! size: 14; */font-size: 14px;color: #3e3e3e;display: none;\">\u8be5\u5206\u7c7b\u6b63\u5728\u8865\u5145\u4e66\u7c4d\uff0c\u656c\u8bf7\u671f\u5f85\uff01</div>", "text", "#titele_classid", "--", "index", "ordertype", "no", "eq", "li", "children", "#switch_order", "hasClass", "pdown", "toggleClass", "siblings", "getBookList", "click", "<div class=\"c5_slider\" id=\"c5_slider\"></div><div class=\"rtips_join\" style=\"margin-top: 8px;\"></div>", ".bookstore_r", "    <div class=\"c5_booktitle\"><p class=\"f_left\" id=\"titele_classid\">--</p><ul class=\"f_left\" id=\"switch_order\"><li class=\"cur\">\u6700\u65b0</li><li class=\"p1 no\">\u4ef7\u683c</li><li>\u4eba\u6c14</li></ul><b></b></div>", "getClassLoading", "http://product.360doc.com/ajax/eproduct.ashx?op=GetBookStoreClass", "post", "jsonp", "GetBookStoreClass", "xfejh", "status", "classitem", "bandBookCityClass", "\u8bbf\u95ee\u51fa\u9519\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5", "error", "ajax", "<li class=\"odd\">", "\x09<p class=\"p1\">", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(0,0);imgLog(1, \'code=44-1-4\');\" id=\"bookclass_0\">\u597d\u4e66\u9996\u9875</a>", "\x09</p>", "\x09<p class=\"p2\">", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(-2,0);imgLog(1, \'code=44-1-5\');\" id=\"bookclass_-2\">\u9650\u65f6\u7279\u4ef7</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(-1,0);imgLog(1, \'code=44-1-6\');\" id=\"bookclass_-1\">\u70ed\u95e8\u63a8\u8350</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(1000,0);imgLog(1, \'code=44-1-7\');\" id=\"bookclass_1000\">VIP\u4e13\u533a</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(-3,0);imgLog(1, \'code=44-1-8\');\" id=\"bookclass_-3\">\u65b0\u4e66\u4e0a\u67b6</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(2000,0);imgLog(1, \'code=65-1-2\');\" id=\"bookclass_2000\">\u8d60\u4e00\u5f97\u4e00</a>", "</li>", "parentclassid", "classname", "<li ", "class=\"odd\"", ">", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(", ",0);", "imgLog(1, \'code=44-1-", "\');", "\"  id=\"bookclass_", "\">", "<span class=\"indexallbg\"></span>", "</a></p>", "<a href=\"javascript:bookstoreTemplate.bookClassSwitch(", ",", ");imgLog(1, \'code=44-1-", "\');\" id=\"booksubclass_", "</a>", "each", ".c5_list", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(0,0);\" id=\"bookclass_0\">\u597d\u4e66\u9996\u9875</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(-2,0);\" id=\"bookclass_-2\">\u9650\u65f6\u7279\u4ef7</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(-1,0);\" id=\"bookclass_-1\">\u70ed\u95e8\u63a8\u8350</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(1000,0);\" id=\"bookclass_1000\">VIP\u4e13\u533a</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(-3,0);\" id=\"bookclass_-3\">\u65b0\u4e66\u4e0a\u67b6</a>", "\x09\x09<a href=\"javascript:bookstoreTemplate.bookClassSwitch(2000,0);imgLog(1, \'code=65-1-4\');\" id=\"bookclass_2000\">\u8d60\u4e00\u5f97\u4e00</a>", ",0);\"  id=\"bookclass_", ");\" id=\"booksubclass_", "top_animate", "\u597d\u4e66\u4e66\u7c4d\u7c7b\u578b\u5207\u6362", "log", "remove", "#contentnew", "bandIndexHtmlStructure", "getHomePage", "code=43-4-3", "code=43-4-4", "code=43-4-5", "code=43-4-6", "code=43-4-7", "code=43-4-8", "code=43-4-9", "code=43-4-10", "code=43-4-11", "code=43-4-12", "code=43-4-13", "code=43-4-14", "code=43-4-15", "code=43-4-16", "code=43-4-17", "getBookListLoading", "bandHomePageVipInfo", "pageNum", "\u597d\u4e66getBookList", "http://product.360doc.com/ajax/eproduct.ashx?op=GetListByClassIdToPc", "dn", "recommendmindn", "recommendmaxdn", "GetListByClassIdToPc", "1", "count", "recommenditem", "setRecommendItemHtml", "listitem", "setListItemHtml", "show", "#mesages", "bookstoreTemplate.getBookList", "#loadMore", "length", "destroy", "roundabout", "#c6_3d_1", "hide", ".c6_3d", "<a href=\"#\" id=\"c6_3d_prev\" class=\"a1\"></a><a href=\"#\" id=\"c6_3d_next\" class=\"a2\"></a><div class=\"c6_3d_1\" id=\"c6_3d_1\">", "<div class=\"d1\">", "<img src=\"http://pubimage.360doc.com/index7/c6_fire.jpg\" class=\"c6_fire\" />", "<div class=\"pic\"><a target=\"_blank\" href=\"http://www.360doc.com/book/index.html?productid=", "productid", "getunionid", "\"><img src=\"", "productphotolist", "\" class=\"cover\" />", "islimitprice", "<img src=\"http://pubimage.360doc.com/index7/c5_xs.png\" class=\"xs\"/>", "<div class=\"dinfo f_left\"><p class=\"p1 nobreak_\"><a style=\"color: #000;\"  target=\"_blank\" title=\"", "productname", "\" href=\"http://www.360doc.com/book/index.html?productid=", "<p class=\"p2 nobreak_\">", "productauthor", "</p>", "isfree", "<p class=\"p3 nobreak_\">\u514d\u8d39</p>", "<p class=\"p3 nobreak_\">\uffe5", "limitpcprice", "&nbsp;&nbsp;<span>\uffe5", "pcprice", "</span></p>", "</div></div>", ".d1", "#c6_3d_next", "#c6_3d_prev", "<li><div class=\"pic f_left\">", "<a href=\"http://www.360doc.com/book/index.html?productid=", "\" target=\"_blank\">", "<img src=\"", "\" />", "<i></i>", "</div><div class=\"f_right\">", "<p class=\"p1 nobreak_\"><a style=\"color: #000;\"  target=\"_blank\" href=\"http://www.360doc.com/book/index.html?productid=", "<p class=\"p3\">", "pcintroduction", "<p class=\"p4\">\u514d\u8d39</p>", "<p class=\"p4\">\uffe5", "</span>", "<a class=\"z\" href=\"http://www.360doc.com/book/index.html?productid=", "\">\u8d60\u4e00\u5f97\u4e00</a>", "</div></li>", "c6_ul", "zcomdiv", "c6_cardlist", "#ullist", "getHomePageLoading", "http://product.360doc.com/ajax/eproduct.ashx?op=GetHomePage", "GetHomePage", "homepagebanner", "bandHomePageBanner", "homepagelist", "bandHomePageList", "https://account.360doc.com/Ajax/vip.ashx?op=getmyvipinfo", "getmyvipinfo", "onclick =\"imgLog(1, \'code=46-1-2\');\"", "onclick =\"imgLog(1, \'code=46-1-1\');\"", "isVip", "isvip", "<div class=\"f_left d1\"><i class=\"ricons\"></i><span>\u5f00\u901a\u4e2a\u56feVIP \xB7 </span>\u6d77\u91cf\u597d\u4e66\u514d\u8d39\u7545\u8bfb</div><a href=\"http://www.360doc.com/member/index.html?imgcode=46-8\" class=\"f_right\" target=\"_blank\" ", "> \u7acb\u5373\u5f00\u901a&nbsp;&gt;</a>", ".rtips_join", "isexpired", "<div class=\"f_left d1\"><i class=\"ricons\"></i><span>\u91cd\u65b0\u5f00\u901a\u4e2a\u56feVIP \xB7 </span>\u7acb\u5373\u6062\u590dVIP\u4e13\u4eab\u6743\u76ca</div><a href=\"http://www.360doc.com/member/index.html?imgcode=46-8\" class=\"f_right\" target=\"_blank\" ", "> \u7acb\u5373\u6062\u590d&nbsp;&gt;</a>", "<div class=\"f_left d1\"><i class=\"ricons\"></i><span>\u4e2a\u56feVIP \xB7 </span>\u8fd8\u5dee", "NextEmpiricValue", "\u70b9\u5347\u7ea7LV ", "NextvipLevel", "</div><a href=\"http://www.360doc.com/member/index.html?imgcode=46-8\" class=\"f_right\" target=\"_blank\" ", "> ", "EndTime", "\u5230\u671f&nbsp;&gt;</a>", "onclick =\"imgLog(1, \'code=44-1-2\');\"", "onclick =\"imgLog(1, \'code=43-4-18\');\"", "onclick =\"imgLog(1, \'code=65-1-1-", "\');\"", "onclick =\"imgLog(1, \'code=65-1-3-", "<div class=\"easyCycle-page\"><a href=\"", "url", "\" ", " target=\"_blank\"><img src=\"", "image", "width=\"100%\" height=\"100%\"", " /></a></div>", "#c5_slider", "zySlider", "<div class=\"easyCycle-page\"><a href=\"http://pubimage.360doc.com/book/banner1.jpg\" ", " target=\"_blank\"><img src=\"http://pubimage.360doc.com/book/banner1.jpg\"  ", "/></a></div>", "<div class=\"easyCycle-page\"><a href=\"http://pubimage.360doc.com/book/banner2.jpg\" ", " target=\"_blank\"><img src=\"http://pubimage.360doc.com/book/banner2.jpg\"  ", "data", "<li class=\"", "nbd", "\"><div class=\"pic\"><a  target=\"_blank\" href=\"http://www.360doc.com/book/index.html?productid=", "\"/>", "<p class=\"p1\"><a style=\"color: #000;\" target=\"_blank\" href=\"http://www.360doc.com/book/index.html?productid=", "\" title=\"", "<p class=\"p2\"><a style=\"color: #8a8a8a; cursor: pointer; cursor: auto;\" href=\"javascript:return false;\" title=\"", "<p class=\"p1\"><a style=\"color: #000;\"  target=\"_blank\" href=\"http://www.360doc.com/book/index.html?productid=", "<p class=\"p3\">\uffe5", "<ul class=\"c5_ul3 ", "</ul><ul class=\"c5_ul3 nbd\">", "\"><div class=\"pic f_left\"><a  target=\"_blank\" href=\"http://www.360doc.com/book/index.html?productid=", "<p class=\"p2 nobreak_\"><a style=\"color: #8a8a8a; cursor: pointer; cursor: auto;\" href=\"javascript:return false;\" title=\"", "<div class=\"c5_booktitle\"><p class=\"f_left\">\u70ed\u95e8\u63a8\u8350</p>", ",0);\" class=\"f_right\">\u67e5\u770b\u66f4\u591a</a>", "<b></b></div><ul class=\"c5_ul1 c5_ul2 zcomdiv\">", "</ul>", "append", ".c5_d1", "<div class=\"c5_booktitle\"><p class=\"f_left\">VIP\u4e13\u533a</p>", "<div class=\"c5_booktitle\"><p class=\"f_left\">\u9650\u65f6\u7279\u4ef7</p>", "<b></b></div><ul class=\"c5_ul1\">", "\u8d60\u4e00\u5f97\u4e00\uff08\u514d\u8d39\u8d60\uff0c\u514d\u8d39\u5f97\uff09", "<div class=\"c5_booktitle\"><p class=\"f_left\">", "<b></b></div>", "<b></b></div><ul class=\"c5_ul1 c5_ul2\">", "(^|&)unionid=([^&]*)(&|$)", "match", "substr", "referrer", "unionID", "search", "location", "&unionid=", "scrollTop", "animate", "body,html", "\u7f51\u7edc\u9519\u8bef\uff0c\u8bf7\u7a0d\u540e\u518d\u8bd5\u3002"];
var bookstoreTemplate = {
    getHomePageLoading: false,
    getClassLoading: false,
    getBookListLoading: false,
    type: 1,
    classid: 0,
    subclassid: 0,
    pageNum: 1,
    dn: 20,
    recommendmindn: 3,
    recommendmaxdn: 9,
    ordertype: 1,
    count: 1,
    isVip: false,
    unionid: 0,
    Init: function(_0x18132) {
            case 1:
                break;
            case 2:
                scrollToFixBar(1);
                break
        };
    },
    bandIndexHtmlStructure: function(_0x18132) {
        switch (_0x18132) {
            case 1:
                } else {
                };
                break;
            case 2:
                };
                } else {
                };
                    switch (_0x1818E) {
                        case 0:
                            break;
                        case 1:
                            };
                            };
                            } else {
                            };
                            break;
                        case 2:
                            break
                    };
                });
                break;
            case 3:
                } else {
                };
                break;
            case 4:
                };
                } else {
                };
                    switch (_0x1818E) {
                        case 0:
                            break;
                        case 1:
                            };
                            };
                            } else {
                            };
                            break;
                        case 2:
                            break
                    };
                });
                break
        }
    },
    getBookCityClass: function() {
                data: {
                    })
                },
                success: function(_0x181EA) {
                    } else {
                    }
                },
            })
        }
    },
    bandBookCityClass: function(_0x182FE) {
            case 1:
                var _0x183B6 = 8;
                        _0x183B6++;
                            }
                        });
                    }
                });
                } else {
                };
                break;
            case 2:
                            }
                        });
                    }
                });
                break
        }
    },
    bookClassSwitch: function(_0x18582, _0x185DE) {
        };
            case 1:
                } else {
                };
                break;
            case 2:
                } else {
                };
                switch (parseInt(_0x18582)) {
                    case -2:
                        break;
                    case -1:
                        break;
                    case 1000:
                        break;
                    case -3:
                        break;
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    case 4:
                        break;
                    case 5:
                        break;
                    case 8:
                        break;
                    case 9:
                        break;
                    case 11:
                        break;
                    case 15:
                        break;
                    case 19:
                        break;
                    case 21:
                        break
                };
                break
        }
    },
    getBookList: function(_0x1863A, _0x18132) {
            if (_0x1863A != null) {
            } else {
                }
            };
                data: {
                    })
                },
                success: function(_0x181EA) {
                            } else {
                            };
                        };
                        };
                    } else {
                    }
                },
            })
        }
    },
    setRecommendItemHtml: function(_0x186F2) {
        } else {
                } else {
                    } else {
                    }
                };
            });
                minOpacity: 1,
                autoplay: true,
                autoplayDuration: 4000,
                autoplayPauseOnHover: true
            })
        }
    },
    setListItemHtml: function(_0x18806) {
            } else {
                } else {
                }
            };
        });
    },
    getHomePage: function() {
                data: {
                    })
                },
                success: function(_0x181EA) {
                    } else {
                    }
                },
            })
        }
    },
    bandHomePageVipInfo: function() {
            data: {
                })
            },
            success: function(_0x181EA) {
                    } else {
                    };
                    } else {
                        } else {
                        }
                    }
                } else {
                }
            },
        })
    },
    bandHomePageBanner: function(_0x189D2) {
        var _0x1891A = 0;
            _0x1891A = 0;
        } else {
            _0x1891A = 18;
        };
                } else {
                };
            };
                speed: 800,
                round: 1,
                autoplay: 4000,
                pager: true
            })
        } else {
                speed: 800,
                round: 1,
                autoplay: 4000,
                pager: true
            })
        }
    },
    bandHomePageList: function(_0x18A8A) {
            var _0x18582 = 0;
            var _0x18A2E;
                case 1:
                                switch (_0x18582) {
                                    case -1:
                                        ;
                                    case 1000:
                                        break;
                                    case -2:
                                        } else {
                                        };
                                        break;
                                    default:
                                        if (_0x18B9E == 0) {
                                        };
                                        if (_0x18B9E == 2) {
                                        };
                                        break
                                }
                            });
                            switch (_0x18582) {
                                case -1:
                                    break;
                                case 1000:
                                    break;
                                case -2:
                                    break;
                                default:
                                    };
                                    break
                            }
                        }
                    });
                    break;
                case 2:
                                switch (_0x18582) {
                                    case -1:
                                        ;
                                    case 1000:
                                        break;
                                    case -2:
                                        } else {
                                        };
                                        break;
                                    default:
                                        if (_0x18B9E == 0) {
                                        };
                                        if (_0x18B9E == 2) {
                                        };
                                        break
                                }
                            });
                            switch (_0x18582) {
                                case -2:
                                    break;
                                case -1:
                                    break;
                                case 1000:
                                    break;
                                default:
                                    };
                                    break
                            }
                        }
                    });
                    break
            }
        }
    },
    getunionid: function(_0x18C56) {
        if (_0x18C56) {
            } else {
                }
            }
        } else {
            };
        }
    },
    top_animate: function(_0x18D6A) {
        var _0x18E22 = 286;
            _0x18E22 = 348
        };
            scrollTop: _0x18DC6 < _0x18E22 ? _0x18DC6 : _0x18E22
        }, 200, function() {
            _0x18D6A && _0x18D6A()
        })
    },
    error: function() {
    }
}