/***************************************************************************/
/*                                                                         */
/*  This obfuscated code was created by Javascript Obfuscator Free Version.*/
/*  Javascript Obfuscator Free Version can be downloaded here              */
/*  http://javascriptobfuscator.com                                        */
/*                                                                         */
/***************************************************************************/
var _$_58bb = ["bandNewCouponsLoading", "http://product.360doc.com/ajax/myeproduct.ashx?op=receivecoupon", "post", "jsonp", "receivecoupon", "2", "xfejh", "status", "couponitem", "length", "\u6211\u77e5\u9053\u4e86", "360doc1", "", "index.html", "indexOf", "href", "\u9a6c\u4e0a\u9886\u53d6", "<div class=\"mb_hongbao mb_hongbao_db11\"><a href=\"javascript:void(0);\" onclick=\"fixedDiv.close();$(\'.mb_hongbao\').remove();\" class=\"mbhb_close\">\xD7</a><p class=\"pstr\">\u597d\u4e66\u4e0a\u7ebf\uff0c\u597d\u793c\u76f8\u9001</p><div class=\"pay_couponbox\"></div><p class=\"hbtext\">\u6ce8\uff1a\u4f18\u60e0\u5238\u5df2\u53d1\u653e\uff0c\u8bf7\u5728\u201c\u6211\u7684\u94b1\u5305\u201d\u4e2d\u67e5\u770b</p></a><a href=\"javascript:void(0);\" onclick=\"couponReceive.gotosc();\" class=\"go\">", "</a>", "append", "body", "setNewCouponsHtml", ".mb_hongbao", "open", ".pay_couponbox .c", "6px", "none", "4px", "#c64b2b", "niceScroll", ".pay_couponbox", "commonlayer", "\u4f60\u5df2\u7ecf\u9886\u53d6\u8fc7\u8be5\u4f18\u60e0\u5238\uff01", "error", "ajax", "<div class=\"commonlayer\" style=\"width: 362px;height: 200px;display: none;\"><div class=\"d1\"><p>\u6e29\u99a8\u63d0\u793a</p><a href=\"javascript:void(0);\" onclick=\"fixedDiv.close();$(\'.commonlayer\').remove();\" class=\"closer\">\xD7</a></div><p style=\"text-align:center;font-size: 14px;padding: 43px 0;\">\u4f18\u60e0\u5238\u5df2\u7ecf\u53d1\u653e\u5230\u4f60\u7684\u8d26\u6237 </p><div style=\"text-align: center;\"><a href=\"http://www.360doc.com/myaccount.aspx?app=14\" class=\"rbtn_confirm_s\" style=\"width: 128px;\">\u67e5\u770b\u6211\u7684\u4f18\u60e0\u5238</a>&nbsp;&nbsp;<a href=\"javascript:void(0);\" onclick=\"fixedDiv.close();$(\'.commonlayer\').remove();\" class=\"rbtn_cancel_s\">\u53d6\u6d88</a></div></div>", ".commonlayer", "location", "http://www.360doc.com/mybook.aspx", "close", "remove", "http://www.360doc.com/clippertool/getnoteclipperASHX.ashx?type=10&jsoncallback=?", "isFocus", "http://www.360doc.com/userhome/", "<div class=\"c\">", "<div class=\"zcomdiv\">", "<div class=\"f_left\">", "<p class=\"p1 nbr_\">", "name", "</p>", "<p class=\"p2 nbr_\">", "validtime", "<p class=\"p5\">", "useconditioninfo", "</div>", "<p class=\"f_right p3\">\uffe5<span>", "amount", "</span></p>", "1", "<p class=\"f_right p3\"><span>", "</span> \u6298</p>", "<p class=\"f_right p3\"><span>0</span> \u5143\u8d2d</p>", "3", "<div class=\"d1\"><p class=\"d1_p1\">\uffe5<span>", "</span></p><p class=\"d1_p2\">\u6ee1", "reachamount", "\u5143\u53ef\u7528</p></div>", "4", "type", "<p class=\"p4\">", "info", "XMLHttpRequest", "withCredentials", "\u7f51\u7edc\u9519\u8bef\uff0c\u8bf7\u7a0d\u5fae\u518d\u8bd5\u3002", "toLocaleString", "prototype", "getFullYear", "-", "getMonth", "0", "getDate", "#isguide", "val", "bandNewCoupons"];
var couponReceive = {
    bandNewCouponsLoading: false,
    isFocus: 0,
    bandNewCoupons: function(_0x1A586) {
                data: {
                    type: 2,
                    })
                },
                success: function(_0x1A5A9) {
                            if (_0x1A586 == null || !_0x1A586) {
                                };
                                    zindex: 999,
                                });
                                        autohidemode: false,
                                    })
                                }
                            } else {
                            }
                        } else {
                            if (_0x1A586) {
                            }
                        }
                    }
                },
            })
        }
    },
    commonlayer: function() {
            zindex: 999,
        });
    },
    gotosc: function() {
        } else {
                dlBandClick(2);
                return
            }
        }
    },
    setNewCouponsHtml: function(_0x1A612, _0x1A658) {
        var _0x1A5EF = _0x1A658 || 0;
            return
        };
        var _0x1A67B = _0x1A612[_0x1A5EF];
                break;
                break;
                break;
                break
        };
        _0x1A5EF++;
    },
    createCORSRequest: function() {
            return false
        };
            _0x1A6C1 = true
        } else {
            _0x1A6C1 = false
        };
        return _0x1A6C1
    },
    error: function() {
    },
    getLocalTime: function(_0x1A6E4) {
        };
    }
};
$(function() {
        }
    }
})