(function() {
    var h = function(a) {
    };

    function j() {
        return +new Date()
    }

    function g(a) {
        return isFinite(a) ? a : 0
    }
    var i = function(a) {
    };
    i.prototype = {
        constructor: i,
        initialize: function(b) {
                return
            }
            if (a.targetEl) {
            } else {
            }
            if (a.autostart) {
            }
        },
        getOptions: function(a) {
            if (typeof a !== "object") {
            }
            return a
        },
        domove: function(b, a) {
                position: "absolute",
            });
        },
        step: function(c) {
            var d, a;
                if (typeof b.callback === "function") {
                    b.callback.call(this)
                }
            } else {
                if (typeof b.stepCallback === "function") {
                    b.stepCallback.call(this, d, a)
                }
            }
        },
        setOptions: function(a) {
            if (typeof a !== "object") {
            }
        },
        start: function() {
                return
            }
            }
                var b = j();
                a.step(b)
            }, 13);
        },
        reset: function(b, a) {
        },
        stop: function() {
            }
        }
    };
    var f = {
        el: null,
        offset: [0, 0],
        targetEl: null,
        duration: 500,
        curvature: 0.001,
        callback: null,
        autostart: false,
        stepCallback: null
    };
})();
(function() {
    var o = getCookie("yuanChuang_banner");
            n = ".tab li span.s1{visibility:visible !important;}";
        if ("styleSheet" in i) {
            i.setAttribute("type", "text/css");
            i.styleSheet.cssText = n
        } else {
            i.innerHTML = n
        }
        return
    } else {
        setCookie("yuanChuang_banner", "1", 720)
    }
    var l, j, m = 400;
    var p = "http://pubimage.360doc.com/index7/jiang_index2.png";
    k.onload = function() {
        setTimeout(function() {
            $("html,body").css({
                height: "100%",
                overflow: "hidden"
            });
            $("body").css("margin-right", "17px");
            l = $("<div/>").css({
                position: "absolute",
                left: 0,
                top: 0,
                zIndex: 999,
                backgroundColor: "#000",
                opacity: 0.5,
                width: "100%",
                height: "100%"
            }).appendTo("body");
            var a = ($(window).width() - 722) / 2,
                b = ($(window).height() - 595) / 2,
                popout = $("<div/>").css({
                    width: 722,
                    height: 595,
                    position: "absolute",
                    zIndex: 1000,
                    left: a,
                    top: b,
                    webkitTransformOrigin: "left top",
                    overflow: "hidden"
                }).html('<a href="javascript:void(0);"><img src=' + p + ' style="width:100%;height:100%"></a>').appendTo("body");
            j = $("<img/>").attr("src", "http://pubimage.360doc.com/index7/jiangindex_close.gif").css({
                position: "absolute",
                right: 60,
                top: 147,
                cursor: "pointer"
            }).appendTo(popout);
            j.click(function(c) {
                c.stopPropagation();
                $(this).remove();
                var d = $(".tabn2 li span.s1").eq(0),
                    f = [d.offset().left + 50 - a, d.offset().top - b];
                    curvature: -0.001,
                    duration: m,
                    el: popout,
                    offset: f,
                    callback: function() {
                        d.css("visibility", "visible");
                        l.remove();
                        popout.remove();
                        $("html,body").removeAttr("style");
                    },
                    stepCallback: function(t, g) {
                            h = Math.round(100 - (t / s * 100)) / 100;
                        popout.css({
                            width: 722 * h,
                            height: 595 * h
                        });
                        l.css("opacity", h > 0.5 ? 0.5 : h)
                    }
                });
                e.start()
            });
            popout.click(function() {
                index_new(17);
                j.trigger("click")
            });
            l.click(function() {
                j.trigger("click")
            })
        }, 100)
    };
    k.src = p
})();