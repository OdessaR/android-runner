var _$_d918 = ["", "str2rstr_utf8", "rstr_sha1", "rstr2hex", "rstr2b64", "rstr2any", "rstr_hmac_sha1", "rstr2binb", "length", "binb_sha1", "binb2rstr", "concat", "hexcase", "0123456789ABCDEF", "0123456789abcdef", "charCodeAt", "charAt", "b64pad", "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/", "ceil", "floor", "log", "fromCharCode", "bit_rol", "sha1_ft", "safe_add", "sha1_kt", "gs", "sort", "toUpperCase", "hex_sha1", "&", "split", "string", "=", "substr"];
var doccgjio = {
    hexcase: 0,
    b64pad: _$_d918[0],
    hex_sha1: function(_0x7815) {
    },
    b64_sha1: function(_0x7815) {
    },
    any_sha1: function(_0x7815, _0x785C) {
    },
    hex_hmac_sha1: function(_0x78EA, _0x78A3) {
    },
    b64_hmac_sha1: function(_0x78EA, _0x78A3) {
    },
    any_hmac_sha1: function(_0x78EA, _0x78A3, _0x785C) {
    },
    rstr_sha1: function(_0x7815) {
    },
    rstr_hmac_sha1: function(_0x7A94, _0x7978) {
        };
        var _0x7A4D = Array(16),
            _0x7ADB = Array(16);
        for (var _0x7A06 = 0; _0x7A06 < 16; _0x7A06++) {
            _0x7A4D[_0x7A06] = _0x7931[_0x7A06] ^ 0x36363636;
            _0x7ADB[_0x7A06] = _0x7931[_0x7A06] ^ 0x5C5C5C5C
        };
    },
    rstr2hex: function(_0x7B69) {
        try {
        };
        var _0x7BF7;
        };
        return _0x7BB0
    },
    rstr2b64: function(_0x7B69) {
        try {
        };
        for (var _0x7A06 = 0; _0x7A06 < _0x7C85; _0x7A06 += 3) {
            for (var _0x7C3E = 0; _0x7C3E < 4; _0x7C3E++) {
                } else {
                }
            }
        };
        return _0x7BB0
    },
    rstr2any: function(_0x7B69, _0x7DE8) {
        var _0x7F04 = Array();
        var _0x7A06, _0x7E76, _0x7BF7, _0x7EBD;
        };
            _0x7EBD = Array();
            _0x7BF7 = 0;
                _0x7BF7 = (_0x7BF7 << 16) + _0x7D5A[_0x7A06];
                _0x7BF7 -= _0x7E76 * _0x7DA1;
                }
            };
            _0x7D5A = _0x7EBD
        };
        };
            _0x7BB0 = _0x7DE8[0] + _0x7BB0
        };
        return _0x7BB0
    },
    str2rstr_utf8: function(_0x7B69) {
        var _0x7A06 = -1;
        var _0x7BF7, _0x7F4B;
            if (0xD800 <= _0x7BF7 && _0x7BF7 <= 0xDBFF && 0xDC00 <= _0x7F4B && _0x7F4B <= 0xDFFF) {
                _0x7BF7 = 0x10000 + ((_0x7BF7 & 0x03FF) << 10) + (_0x7F4B & 0x03FF);
                _0x7A06++
            };
            if (_0x7BF7 <= 0x7F) {
            } else {
                if (_0x7BF7 <= 0x7FF) {
                } else {
                    if (_0x7BF7 <= 0xFFFF) {
                    } else {
                        if (_0x7BF7 <= 0x1FFFFF) {
                        }
                    }
                }
            }
        };
        return _0x7BB0
    },
    str2rstr_utf16le: function(_0x7B69) {
        };
        return _0x7BB0
    },
    str2rstr_utf16be: function(_0x7B69) {
        };
        return _0x7BB0
    },
    rstr2binb: function(_0x7B69) {
            _0x7BB0[_0x7A06] = 0
        };
        };
        return _0x7BB0
    },
    binb2rstr: function(_0x7B69) {
        };
        return _0x7BB0
    },
    binb_sha1: function(_0x7BF7, _0x7C85) {
        var _0x8211 = Array(80);
        var _0x7F92 = 1732584193;
        var _0x7FD9 = -271733879;
        var _0x8020 = -1732584194;
        var _0x78A3 = 271733878;
        var _0x785C = -1009589776;
            var _0x8067 = _0x7F92;
            var _0x80AE = _0x7FD9;
            var _0x80F5 = _0x8020;
            var _0x813C = _0x78A3;
            var _0x8183 = _0x785C;
            for (var _0x7C3E = 0; _0x7C3E < 80; _0x7C3E++) {
                if (_0x7C3E < 16) {
                    _0x8211[_0x7C3E] = _0x7BF7[_0x7A06 + _0x7C3E]
                } else {
                };
                _0x785C = _0x78A3;
                _0x78A3 = _0x8020;
                _0x7FD9 = _0x7F92;
                _0x7F92 = _0x81CA
            };
        };
        return Array(_0x7F92, _0x7FD9, _0x8020, _0x78A3, _0x785C)
    },
    sha1_ft: function(_0x81CA, _0x7FD9, _0x8020, _0x78A3) {
        if (_0x81CA < 20) {
            return (_0x7FD9 & _0x8020) | ((~_0x7FD9) & _0x78A3)
        };
        if (_0x81CA < 40) {
            return _0x7FD9 ^ _0x8020 ^ _0x78A3
        };
        if (_0x81CA < 60) {
            return (_0x7FD9 & _0x8020) | (_0x7FD9 & _0x78A3) | (_0x8020 & _0x78A3)
        };
        return _0x7FD9 ^ _0x8020 ^ _0x78A3
    },
    sha1_kt: function(_0x81CA) {
        return (_0x81CA < 20) ? 1518500249 : (_0x81CA < 40) ? 1859775393 : (_0x81CA < 60) ? -1894007588 : -899497514
    },
    safe_add: function(_0x7BF7, _0x7F4B) {
        var _0x8258 = (_0x7BF7 & 0xFFFF) + (_0x7F4B & 0xFFFF);
        var _0x829F = (_0x7BF7 >> 16) + (_0x7F4B >> 16) + (_0x8258 >> 16);
        return (_0x829F << 16) | (_0x8258 & 0xFFFF)
    },
    bit_rol: function(_0x832D, _0x82E6) {
        return (_0x832D << _0x82E6) | (_0x832D >>> (32 - _0x82E6))
    },
    xfejh: function(_0x7815) {
    },
    sort: function(_0x8402) {
        };
        return _0x83BB
    },
    gs: function(_0x8449) {
        for (var _0x7A94 in _0x8449) {
            }
        };
        };
        return _0x8490
    }
}