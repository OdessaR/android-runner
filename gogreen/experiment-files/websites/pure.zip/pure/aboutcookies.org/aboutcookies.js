// revised cookie solution
var _gaq = _gaq || [];
_gaq.push(['_setAccount', 'UA-116363-1']);
_gaq.push(['_trackPageview']);

$(document).ready(
    function() {
        selection('.smA0', 'smsel0');
        selection('.smA1', 'smsel1');

        function selection(cssclass, selclass) {
            $(cssclass).each(function() {
                var child = $(this).children('a').filter(':first');
                    $(this).addClass(selclass);
                    $(this).text(child.text());
                    child.remove();
                }
            });

        }

    });