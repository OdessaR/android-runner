! function(e) {
    var t = {};

    function n(r) {
        if (t[r]) return t[r].exports;
        var o = t[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
            enumerable: !0,
            get: r
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
                return e[t]
            }.bind(null, o));
        return r
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return Object.prototype.hasOwnProperty.call(e, t)
}([function(e, t, n) {
    n(1)
}, function(e, t, n) {
    "use strict";
    ! function() {
        var e, t = "https://gcd.mmstat.com/detector/getDetector.htm",
            n = "https://gcd.mmstat.com/detector/recordData.htm",
            r = /googlebot|bingbot|yahoo|baidu/,
            o = {
                request: function(e, t) {
                    n.open(e.method || "GET", e.url, !0), n.onreadystatechange = function() {
                        if (4 === n.readyState && 200 === n.status && n.responseText && t) {
                            var e = void 0;
                            try {
                                e = JSON.parse(n.responseText)
                            } catch (e) {}
                            t(e)
                        }
                    }, n.send(e.data)
                },
                getImage: function(e, t) {
                    if (e) {
                        n.src = e, n.onload = function() {
                            t && t(e)
                        }
                    }
                },
                formatMillSecond: function(e) {
                    return null == e || 0 == e ? 0 : Math.floor(e)
                },
                serial: function(e) {
                    var t = [];
                    for (var n in e) t.push(n + "=" + encodeURIComponent(e[n]));
                    return t.join("&")
                }
            };

        function a() {
            o.request({
                url: t
            }, function(e) {
                var t = e.detectorUrl;
                o.getImage(t, c)
            })
        }

        function c(e) {
                return t.name === e
            });
            if (r && r.length > 0) {
                var a = r[0],
                    c = o.formatMillSecond;
                t = {
                    rs: c(a.redirectStart),
                    re: c(a.redirectEnd),
                    fs: c(a.fetchStart),
                    st: c(a.startTime),
                    dls: c(a.domainLookupStart),
                    dle: c(a.domainLookupEnd),
                    cs: c(a.connectStart),
                    ce: c(a.connectEnd),
                    scs: c(a.secureConnectionStart),
                    resqs: c(a.requestStart),
                    resps: c(a.responseStart),
                    respe: c(a.responseEnd),
                    restype: a.initiatorType,
                    n: a.name
                }, o.getImage(n + "?" + o.serial(t))
            }
    }()
}]);