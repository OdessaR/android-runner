(function() {
    var e = function() {
        var e = {},
            t = {
                exports: e
            };
        (function() {
            if (!(e && e.length)) return;
            var t = e[0];
            r.src = "https://assets.alicdn.com/g/big-brother/sentry/2.x/index.js";
            r.crossOrigin = "anonymous";
            r.addEventListener("load", function() {
                if (e) {
                    e.performance.autoReport();
                    e.api.autoReport()
                }
            });
            t.appendChild(r)
        })();
        return t.exports
    }()
})();;