'use strict';

~ function() {
        cb && cb();
    };

    function report() {

        if (shouldReport) {
                return;
                return;
            }

            var data = {
                begin: timing.fetchStart,
                dom: timing.domInteractive - timing.responseEnd,
                load: timing.loadEventStart - timing.fetchStart,
            };

        }
    }
}();