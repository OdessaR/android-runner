! function(e) {
    function t(n) {
        if (o[n]) return o[n].exports;
        var i = o[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(i.exports, i, i.exports, t), i.l = !0, i.exports
    }
    var o = {};
            configurable: !1,
            enumerable: !0,
            get: n
        })
        var o = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return Object.prototype.hasOwnProperty.call(e, t)
}([function(e, t, o) {
    "use strict";

    function n() {
    }

    function i(e) {
    }

    function c(e, t) {
    }

    function a(e, t) {
        var o = s(t);
        else {
        }
    }

    function r(e) {
        var t = e.gdprNotice,
    }

    function l(e, t, o) {
    }
    Object.defineProperty(t, "__esModule", {
        value: !0
    });
    var s = function(e) {
            return "\n    .GDPR-cookies-notice-wrap {position: fixed;font-size:0;left:0; right:0;bottom:".concat(e.bottom, "; z-index: ").concat(e.zIndex, "; line-height:16px;color:#666;box-sizing: border-box; padding-left: 12px;}\n    .GDPR-cookies-notice-link {text-decoration: underline; color: #666;}\n    .GDPR-cookies-notice {display: inline-block;vertical-align: top;font-size:12px; padding: 12px 0}\n    .GDPR-cookies-notice-close-wrap {cursor: pointer}\n    .GDPR-cookies-notice-close {\n      position: relative; display: inline-block; width: 18px; height:1px; background: #333;line-height: 0;font-size:0;vertical-align: middle;\n      transform: rotate(45deg);\n      -ms-transform: rotate(45deg);\n      -o-transform: rotate(45deg);\n      -webkit-transform: rotate(45deg);\n    }\n    .GDPR-cookies-notice-close:after {content:'/';display:block; width: 18px; height:1px; background: #333;\n      transform: rotate(-90deg);\n      -ms-transform: rotate(-90deg);\n      -o-transform: rotate(-90deg);\n      -webkit-transform: rotate(-90deg);\n    }\n  ")
        },
        d = function() {
        },
        p = function() {
            return "\n    .GDPR-cookies-notice-wrap {display: flex; background: #F2F3F7;}\n    .GDPR-cookies-notice-close-wrap {text-align: center; padding: 0 5px;}\n    .GDPR-cookies-notice {flex: 1}\n    .GDPR-cookies-notice-close-wrap {display: flex; align-items: center; justify-content: center; flex: 0 0 40px; width: 40px;}\n  "
        },
    try {
        ! function() {
            var e = {
                needShow: !0,
                zIndex: 30001,
                bottom: 0
            };
                var t = !0,
                    o = i("GDPR_NOTICE_NEED_SHOW");
                if (o && (new Date).getTime() - Number(o) < 864e5 && (t = !1), t) {
                    var n = (new Date).getTime();
                    l("//buyercentral.alibaba.com/buyer/privacy/need_show_cookie_setting.do?terminal=".concat(m), "GDPR_NOTICE_GET_INFO_FUN_".concat(n), function(t) {
                        200 === t.code && (t = t.data, t.needShow && (a(m, e), r(t), l("//buyercentral.alibaba.com/buyer/privacy/show_cookie_setting_notice_ack.do?", "GDPR_NOTICE_DISPLAY_SUCCESS_FUN_".concat(n), function(e) {
                            200 === e.code && c("GDPR_NOTICE_NEED_SHOW", (new Date).getTime())
                        })))
                        var t = e.target;
                        "GDPR-cookies-notice-close-wrap" != t.className && "GDPR-cookies-notice-close" != t.className || (("GDPR-cookies-notice-wrap" == t.parentElement.className ? t.parentElement : t.parentElement.parentElement).style.display = "none")
                    })
                }
            }
        }()
    } catch (e) {
    }
}]);