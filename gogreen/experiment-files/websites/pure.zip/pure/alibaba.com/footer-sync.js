(function() {
    var e = function() {
        var e = {},
            o = {
                exports: e
            };
            if (e && e.countryCode === "CN") {
                o && o.classList.remove("hide")
            }
        };
        var t = function() {
        };
        if (a && a.contentWindow && a.contentWindow.postMessage) {
            var n = "store-proxy",
                i = n + "get-_-cookie-info-storeproxy-ipdata-_-0";

            function r(e) {
                var o = e.data;
                if (typeof o === "string" && o.slice(0, i.length) === i) {
                    var a = o.split("T_T");
                    if (a[2]) {
                        jsonpFooterCallback({
                            countryCode: a[2].split("|")[1] || ""
                        })
                    } else {
                        t()
                    }
                }
            }
            }
            a.contentWindow.postMessage(i, "*")
        } else {
            t()
        }
        return o.exports
    }()
})();