! function(t) {
    var e = {};

    function o(a) {
        if (e[a]) return e[a].exports;
        var n = e[a] = {
            i: a,
            l: !1,
            exports: {}
        };
        return t[a].call(n.exports, n, n.exports, o), n.l = !0, n.exports
    }
            enumerable: !0,
            get: a
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var a = Object.create(null);
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
                return t[e]
            }.bind(null, n));
        return a
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return Object.prototype.hasOwnProperty.call(t, e)
}([function(t, e, o) {
    "use strict";
        var o = function(t) {
                if (e) return e[2]
            }("cna"),
            a = "".concat(t, "-").concat(e),
            n = "ife-bucket-".concat(a),
            r = !1;
        return "true" === (i && i.getItem(n)) ? r = !0 : (o && function(t, e, o) {
            var a, n, i = void 0 === o ? 2166136261 : o;
            for (a = 0, n = t.length; a < n; a++) i ^= t.charCodeAt(a), i += (i << 1) + (i << 4) + (i << 7) + (i << 8) + (i << 24);
            return e ? "0000000".concat((i >>> 0).toString(16)).substr(-8) : i >>> 0
        }(o + t) % 1e3 < 10 * e && (r = !0), !o && Math.floor(1e3 * Math.random()) % 1e3 < 10 * e && (r = !0), i && i.setItem("ife-bucket-".concat(a), r ? "true" : "false")), r
    }
}, function(t, e, o) {
    "use strict";
    o.r(e);
    var a = o(0),
        n = o.n(a);
    ! function() {
        try {
                e = ["activity.alibaba.com", "www.alibaba.com", "i.alibaba.com", "passport.alibaba.com", "sale.alibaba.com", "russian.alibaba.com", "us-productposting.alibaba.com", "hz-productposting.alibaba.com", "post.alibaba.com"];
            e = e.concat(["spanish", "hindi", "japanese", "korean", "dutch", "italian", "hebrew", "german", "french", "arabic", "vietnamese", "thai", "turkish", "portuguese", "indonesian", "russian"].map((function(t) {
                return "".concat(t, ".alibaba.com")
            })));
            if (-1 !== a.indexOf("/f/") || -1 !== a.indexOf("/Favorite/") || -1 !== a.indexOf("/goods/")) return;
            var i = "https://s.alicdn.com/@g/flasher/sw/".concat(t, "/client/index.js"),
                r = "https://s.alicdn.com/@g/flasher/sw/".concat(t, "/client/revoke.js");
                asset: r,
                callback: function() {}
            });
                asset: i,
                callback: function() {
                    var t = function(t) {
                            return function() {
                            }
                        },
                        e = function(t) {
                            return function() {
                            }
                        };

                    function a() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "https://www.alibaba.com/product-detail/!";
                        setTimeout(t(e), 500), setTimeout(t(e), 1e3), setTimeout(t(e), 3e3), setTimeout(t(e), 5e3)
                    }
                    o && a();
                    var i = !1,
                        r = function t() {
                                namespace: "detail",
                                id: "detail"
                            }]), i = !0) : setTimeout(t, 1e3))
                        };
                        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "https://www.alibaba.com/product-detail/!";
                        setTimeout(e(t), 500), setTimeout(e(t), 1e3), setTimeout(e(t), 3e3), setTimeout(e(t), 5e3)
                    }());
                }
            }
        } catch (t) {
        }
        var c, s
    }(window)
}]);
! function() {
    "use strict";

    function t() {}

    function e(t) {
        return function(e) {
            return {}.toString.call(e) === "[object " + t + "]"
        }
    }
    var n = {
        isObject: e("Object"),
        isString: e("String"),
        isArray: Array.isArray || e("Array"),
        isFunction: e("Function"),
        isUndefined: e("Undefined"),
        each: function(t, e) {
            for (var n = -1, s = t ? t.length : 0; ++n < s && !1 !== e(t[n], n, t););
            return t
        },
        one: function(e) {
            var n = [].slice.call(arguments, 1);
        }
    };

    function s() {}
        var e, s, i, o = [];
        for (var r = 1; r < arguments.length; r++) o[r - 1] = arguments[r];
        for (var a = 0; a < s; a++) i = e[a], n.isFunction(i) && i.apply(this, o);
        return !0
            i = function() {
                s.removeListener(t, i), e.apply(this, arguments)
            };
        var s;
            if (s[i] === e) {
                s.splice(i, 1);
                break
    };
        o = i.document,
            LOADING: 1,
            LOADED: 2,
            ERROR: 3
        };

    function a(t) {
    }
        ! function(t) {
            function e() {
                o.addEventListener ? (o.removeEventListener("DOMContentLoaded", e, !1), t()) : "complete" === o.readyState && (o.detachEvent("onreadystatechange", e), t())
            }
            "complete" === o.readyState ? t() : o.addEventListener ? (o.addEventListener("DOMContentLoaded", e, !1), i.addEventListener("load", t, !1)) : (o.attachEvent("onreadystatechange", e), i.attachEvent("onload", t))
        }(function() {
            t.isDomReady = !0, t.emit("domready"), t.initLoad()
        })
        var e = {};
        if (n.isObject(t))
            for (var s in t) t[s] && (e = {
                name: s,
                url: t[s]
            });
        else e = {
            url: t
        };
            if (!t.hasOwnProperty(e) || !t[e] || t[e].state !== r.LOADED) return !1;
        return !0
            e = arguments,
            s = e[e.length - 1],
            i = {};
            e !== s && (e = t.getAsset(e), i[e.name] = e)
        }), n.each(e, function(e) {
            e !== s && (e = t.getAsset(e), t.loadAsset(e, function() {
                t.allLoaded(i) && n.one(s, i)
            }))
        var s;
        }, s.onerror = function() {
        }, s.async = !1, s.defer = !1;
        var a = o.head || o.getElementsByTagName("head")[0];
        a.insertBefore(s, a.lastChild)
        if (n.isArray(t)) {
            var i = {};
            return n.each(t, function(t) {
                i[t] = s.assets[t], s.ready(t, function(o) {
                    i[t] = o, s.allLoaded(i) && n.one(e, i)
                })
        }
        var c = s.assets[t] || {};
        if (n.isObject(t))
            for (var e in t)
                if (t.hasOwnProperty(e)) {
                    var s = t[e],
                        i = [];
                    if (!s || s.loaded) continue;
                    var o = s.asset;
                    if (n.isString(o)) {
                        var r = {};
                        r[e] = o, i.push(r)
                    } else i = i.concat(o);
                }
        var e = t.split("/"),
            n = e[e.length - 2] + "_" + e[e.length - 1],
            s = n.indexOf("?");
        return -1 !== s ? n.substring(0, s) : n
    };
    }
    c.version = "0.1.4"
}();