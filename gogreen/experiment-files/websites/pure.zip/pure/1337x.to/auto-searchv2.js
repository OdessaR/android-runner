$(function() {
    var cache = {};
    $("#autocomplete").autocomplete({
        minLength: 3,
        appendTo: '.search-box',
        source: function(request, response) {
            var term = request.term;
            if (term in cache) {
                response(cache[term]);
                return;
            }
                cache[term] = data.data;
                response(data.data);
            });
        },
        select: function(event, ui) {}
    }).data('uiAutocomplete')._renderItem = function(ul, item) {
        var strNewLabel = item.label;
        var strNewLabel = strNewLabel.replace(regexp, "<span class='highlight-class'>$1</span>");
        return $("<li></li>").data("item.autocomplete", item).append("<a>" + strNewLabel + "</a>").appendTo(ul);
    };
});