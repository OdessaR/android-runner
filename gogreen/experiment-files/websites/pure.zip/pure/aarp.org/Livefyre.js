function get(n, e, t) {
    var i = n;
    try {
        e.split(".").forEach(function(n) {
            i = i[n]
        })
    } catch (n) {
        return t
    }
    return i
}! function(n) {
        t = ["analytics.addHandler", "analytics.setBatchInterval", "on", "require"];
    if (e.pending = e.pending || {}, t.forEach(function(n) {
            e.pending[n] = e.pending[n] || []
        }), !e.initialized) {
        e.analytics = {
            addHandler: function() {
                e.pending["analytics.addHandler"].push(arguments)
            },
            setBatchInterval: function() {
                e.pending["analytics.setBatchInterval"].push(arguments)
            }
        }, e.on = function() {
            e.pending.on.push(arguments)
        }, e.require = function(n, t) {
            e.pending.require.push(arguments)
        }, e.require.amd = !0, e.fulfillPending = function(t) {
            var i, a = n.Livefyre,
                r = e.pending[t] || [];
            try {
                var o = a,
                    d = t.split(".");
                for (d.length > 1 && (d.pop(), o = get(a, d.join("."))); i = r.shift();) get(a, t).apply(o, i)
            } catch (n) {
            }
        };
        var i = n.location.protocol;
        0 !== i.indexOf("http") && (i = "https:");
        var a = i + "//cdn.livefyre.com/libs/Livefyre/v1.1.16/builds/1579772404689/Livefyre.min.js";
        ! function(n, e) {
                a = !1;
            i.src = n, i.onload = i.onreadystatechange = function() {
            }, t.insertBefore(i, t.firstChild)
        }(a, function() {
            for (var n = t.length - 1; n >= 0; n--) e.fulfillPending(t[n])
        }), e.initialized = !0
    }
}(window);