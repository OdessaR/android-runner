(function() {
    /*
     Copyright 2019 Glance Networks, Inc.
    */
    var aa = ["4", "9", "2", "0"].slice(0, 3).join(".");

    function g(a) {
        return a
    }
    });
        if (0 >= b - a) return new ArrayBuffer(0);
        var c = new ArrayBuffer(b - a),
            d = new Uint8Array(c),
        d.set(f);
        return c
    });
        m = h.match(/(edge)[\s\/:]([\w\d\.]+)?/) || h.match(/(opera|ie|firefox|chrome|version)[\s\/:]([\w\d\.]+)?.*?(safari|version[\s\/:]([\w\d\.]+)|$)/) || h.match(/(rv):([\w\d\.]+)/) || [null, "unknown", 0];
    "rv" === m[1] && (m[1] = "ie");
    /*
     Copyright 2017 Glance Networks, Inc.
    */
    function ba(a) {
        for (var b = new Date, b = b.getUTCFullYear() + "/" + (b.getUTCMonth() + 1) + "/" + b.getUTCDate() + " " + g(b.getUTCHours()) + ":" + g(b.getUTCMinutes()) + ":" + g(b.getUTCSeconds()) + " ", c = 0; c < a.length; c++) b += ("object" === typeof a[c] ? JSON.stringify(a[c]) : a[c]) + " ";
        return b
    }

    function n(a) {
    };
    /*
     Copyright (c) 2018 Glance Networks, Inc.
    */
    var p = p || {};
        r = q.match(/(edge)[\s\/:]([\w\d\.]+)?/) || q.match(/(opera|ie|firefox|chrome|version)[\s\/:]([\w\d\.]+)?.*?(safari|version[\s\/:]([\w\d\.]+)|$)/) || q.match(/(rv):([\w\d\.]+)/) || [null, "unknown", 0];
    "rv" === r[1] && (r[1] = "ie");
    var t = {
        extend: Function.prototype.extend,
        name: "version" == r[1] ? r[3] : r[1],
        u: {
            name: q.match(/ip(?:ad|od|hone)/) ? "ios" : (q.match(/(?:webos|android)/) || ca.match(/mac|win|linux/) || ["other"])[0]
        },
        S: {
        },
        T: {}
    };
    t[t.name] = !0;
    t[t.name + parseInt(t.version, 10)] = !0;
    t.u[t.u.name] = !0;
        var b = Array.prototype.toJSON;
        delete Array.prototype.toJSON;
        return a
    };
    void 0 === v && (v = function(a) {
        return JSON.stringify(a)
    });

    function w(a) {
            a.C && a.C(b)
        };
            a.send(b)
        };
            return a && a.code || 0
        };
            return a && a.reason || ""
        }
    }

    function da(a) {
        var b = {},
            c;
        c.l = 0;
        c.F = function() {
            c.w();
                c.l++;
                c.M && c.M({
                    l: c.l
                })
            }, 15E3))
        };
        c.w = function() {
        };
        w(c);
        c.onclose = function(a) {
            c.w();
            c.K && c.K(a)
        };
        c.onheartbeat = function() {
            c.l = 0;
            c.F();
            c.L && c.L()
        };
        return c
    }

    function y(a, b) {
            y(a, b)
        }, 100)
    }

    function x(a) {
        z = z || {};
        y({
            from: "GSockJSProxy",
            cmd: "open",
            url: a
        })
    }
    var z;
        y({
            from: "GSockJSProxy",
            cmd: "send",
            data: a
        })
    };
        y({
            from: "GSockJSProxy",
            cmd: "close"
        })
    };

    function A(a, b, c) {
        }))
    }

    function ea(a) {
        var b = a.func.split(".");
        if ("GLANCE" !== b[0]) B("ERR_BADINVOKE:" + b[0]);
        else {
                if (c = c[b[d]], !c) {
                    B("ERR_UNDEFINVOKE:" + b[d]);
                    return
            c(a.args)
        }
    }

    function C(a) {
    }
    };
        E("Sarissa");
    });
    };
            var a = "error";
            } else {
                        })
                        return
                    }
                        return
                    }
                }
            }
        }
    };

    function F(a) {
        var b = null;
        try {
            b = JSON.parse(a)
        }
        return b
    }
    };
        G(this, a, null, b, c, d, f)
    };

    function G(a, b, c, d, f, l, e) {
        if (a.f) fa(a.f, b, c, d, f, l, e);
        else {
            var u;
                }.bind(a),
                a.j));
                a.onreadystatechange()
            };
            try {
            }
        }
    }

    function D(a) {
    }

    function fa(a, b, c, d, f, l, e) {
        y({
            from: "IFrameProxyRequest",
            type: a.type,
            url: b,
            obj: c,
            async: d,
            withcred: f
        })
    }
            from: "IFrameProxyRequest",
            abort: !0
        })
    };

    function H(a) {
    }

    function I(a, b) {
        var c = new Date;
        c.setUTCHours(c.getUTCHours() + 8);
    }

    function J(a) {
        if (!K(a)) return null;
        return JSON.parse(a)
    }

    function ga(a, b) {
        var c = new Date;
        c.setUTCMinutes(c.getUTCMinutes() + b);
    }
    };

    function K(a) {
        if (!b) return !1;
        b = new Date(b);
    }

    function L(a) {
        var b = [
            ["hidden", "visibilitychange"],
            ["mozHidden", "mozvisibilitychange"],
            ["webkitHidden", "webkitvisibilitychange"],
            ["msHidden", "msvisibilitychange"],
            ["oHidden", "ovisibilitychange"]
        ];
                break
            }
    }
    };

    function ha(a, b) {
        var c = [
                ["src", "//www.glancecdn.net/cobrowse/js/sockjs1.0.2.min.js"]
            ],
            d = a.a.createElement("script");
        b && d.addEventListener("load", b);
        d.setAttribute("type", "text/javascript");
        d.setAttribute("charset", "UTF-8");
        for (var f = 0; f < c.length; f++) d.setAttribute(c[f][0], c[f][1]);
        a.a.head.appendChild(d)
    }

    function M(a) {
        return void 0 === a.b ? !1 : a.a[a.b]
    }

    function ia(a, b) {
        a.addEventListener(a.f, b)
    }
    };
    };
    };

    function B(a) {
    }

    function E(a) {
    };

    function ja(a, b) {
        var c;
        a && (c = c || Object.keys(a), c.forEach(function(c) {
        }))
    }

    function ka(a) {
        var b = {};
        if (!a) return b;
        var c = 0;
            var d = a[c].nodeName.match(/data-(.*)/);
            d && 2 === d.length && (b[d[1]] = a[c].nodeValue)
        }
        return b
    }

    function la() {
            b = ka(b);
        ja(c, a);
        ja(b, a);
        return a
    };

    function N() {}

    function ma(a, b) {
        A(la(), a.a);
        A(b, a.a);
        delete a.a.presenceserver;
        var c = J(a.o);
    }
    var O = 1;

    function P(a, b, c, d, f) {
        if (b && !a.c) n("ERR_NODIRECTSERVER");
        else {
            var l = (f || "https") + "://" + (b ? a.c : a.a.presenceserver) + "/" + c;
            d && (l += "?", ["groupid", "visitorid"].forEach(function(b) {
                l += b + "=" + a.a[b] + "&"
            }));
            return l
        }
    }
        na(this, "findvisitor", "GET", a)
    };

    function Q(a) {
        n("connecting to " + a.c);
        var b = !1;
            a.b.s({
                type: "connect",
                authorization: void 0,
                groupid: a.a.groupid,
                visitorid: a.a.visitorid,
                version: aa
            });
            a.j.forEach(function(b) {
                a.b.s(b)
            });
            n("received:" + v(b));
            if (a.b) {
                var c = b.mtype || b.type,
                    f = b.data;
                switch (c) {
                    case "connected":
                        if (a.a.nokeepalive) break;
                                a.b.s({
                                    type: "k"
                                })
                            },
                            1E3 * b.keepalive));
                        break;
                    case "invoke":
                        "visitor" === a.R && ea(f);
                        break;
                    default:
                        if (a["on" + c]) a["on" + c](f)
                }
            }
                a.connect()
            }, 2E3))
        })
    }

    function na(a, b, c, d) {
        function f(a) {
            var b = a && (a.directserver || a.direct);
            b && (e.c = b, a.httpsport && (e.c += ":" + a.httpsport), e.B());
            e.b && e.c != e.b.N && Q(e);
            if (d && d.onsuccess) d.onsuccess(a)
        }

        function l(a, c) {
            n(b, "failed");
            if (d.onfail) d.onfail(c);
            else qa(e, {
                error: "connfail",
                detail: c
            })
        }
        var e = a,
        u.c = void 0;
        u.method = c;
        n(b, JSON.stringify(d));
        (function(a) {
            if (e.a.presenceserver) return a();
                c = J(b);
            if (c) return e.a.presenceserver = c.presenceserver,
                e.a.presenceserver || n("PRES_DISABLED (from cache)"), a();
                d = "https://" + e.a.ws + "/services/authorizationservice/GetVisitorSettings3?groupid=" + e.a.groupid + "&site=" + e.a.site + "&service=presence";
            c.method = "GET";
            G(c, d, null, !0, !1, function(c) {
                e.a.presenceserver = c.presenceUrl;
                e.a.presenceserver || n("PRES_DISABLED");
                var d = {};
                d.presenceserver = e.a.presenceserver;
                d.presencesettings = c;
                I(b, d);
                ga(b, 1440);
                return a()
            }, function(b, c) {
                n("PRES_UNAVAILABLE " + c);
                a()
            })
        })(function() {
            e.a.presenceserver && G(u,
                P(e, !1, b, !0), d.data ? d.data : {}, !0, !0, f, l)
        })
    }

    function R(a) {
        a.b && a.b.close();
        pa(a)
    }

    function pa(a) {
        delete a.b;
        delete a.c
    }

    function S(a, b) {
        n("sending", b.type, a.f);
        3 === a.f ? a.b.s(b) : (a.j.push(b), a.connect())
    }
                a.disconnect();
                a.connect()
            };
                onsuccess: function() {
                    n("found visitor, connect");
                    Q(a)
                },
                onfail: function(b) {
                    qa(a, {
                        error: "connfail",
                        detail: b
                    });
                    a.f = O
                }
            })
        }
    };
        R(this)
    };

    function qa(a, b) {
        n("Error: ", JSON.stringify(b));
        if (a.onerror) a.onerror(b)
    }
        S(this, {
            type: a,
            data: b
        })
    };

    function T(a) {
        ma(this, a);
            b.i = !1;
            b.O && b.v()
        }, void 0);
            n("visibility:", M(b.g) ? "hidden" : "visible");
            if (3 === b.f && !b.i) {
                var a = {
                    type: "visibility"
                };
                a.data = {
                    visibility: M(b.g) ? "hidden" : "visible"
                };
                S(b, a);
                M(b.g) && R(b)
            }
        });
    }
        U = ["GLANCE", "Presence", "Visitor"],
    U[0] in V || !V.execScript || V.execScript("var " + U[0]);
    for (var X; U.length && (X = U.shift());) U.length || void 0 === ra ? V[X] ? V = V[X] : V = V[X] = {} : V[X] = ra;
        var a = {};
    };
            var b = {};
            var c = {},
                d;
            c.browser = t.name;
            c.browserver = t.version;
            c.platform = t.u.name;
            b.data = c;
                type: "presence"
        } else n("PRES_NOVISITORID")
    };

    function oa(a) {
        return a
    }
        na(this, "presence", "POST", a)
    };
        n("BLURRED");
        R(this)
    };
    var sa = !1;

    function Y() {
        if (!sa) {
            sa = !0;
            var a = la();
            if (a.presence && "api" !== a.presence) {
                b.onerror = function(a) {
                        b.connect()
                    }, 5E3)
                };
                b.v()
            }
        }
    }
}).call(window);