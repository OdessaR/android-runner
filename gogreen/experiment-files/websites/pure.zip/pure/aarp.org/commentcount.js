window.LF_HOST = 'prod.livefyre.com';
"undefined" === typeof LF && (LF = {});
"undefined" === typeof LF.modules && (LF.modules = {});
LF.modules.CommentCount = function(q) {
        s = /[^.\/]+\.fyre\.co|(\w+\.)?livefyre\.com/,
        t = /(CommentCount|ncomments)\.js/i,
        a = function(b) {
            var e = b.articles || a.defaults.get_articles();
            a.fetch(e, b)
        };
    a.helpers = {};
    a.helpers.Base64 = function() {
        var b = {
            _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
            encode: function(e) {
                var c = "",
                    d, f, a, h, g, l, m = 0;
                return c
            },
            decode: function(e) {
                var c = "",
                    d, a, k, h, g, l = 0;
                    d = d << 2 | a >> 4, a = (a & 15) << 4 | h >> 2, k = (h & 3) << 6 | g, c += String.fromCharCode(d), 64 != h && (c += String.fromCharCode(a)), 64 != g && (c += String.fromCharCode(k));
                return c = b._utf8_decode(c)
            },
            _utf8_encode: function(b) {
                b = b.replace(/\r\n/g, "\n");
                for (var c = "", d = 0; d < b.length; d++) {
                    var a = b.charCodeAt(d);
                    128 > a ? c += String.fromCharCode(a) : (127 < a && 2048 > a ? c += String.fromCharCode(a >> 6 | 192) : (c += String.fromCharCode(a >> 12 | 224), c += String.fromCharCode(a >> 6 & 63 | 128)), c += String.fromCharCode(a & 63 | 128))
                }
                return c
            },
            _utf8_decode: function(b) {
                for (var a =
                        "", d = 0, f = 0, k = 0, h = 0; d < b.length;) f = b.charCodeAt(d), 128 > f ? (a += String.fromCharCode(f), d++) : 191 < f && 224 > f ? (k = b.charCodeAt(d + 1), a += String.fromCharCode((f & 31) << 6 | k & 63), d += 2) : (k = b.charCodeAt(d + 1), h = b.charCodeAt(d + 2), a += String.fromCharCode((f & 15) << 12 | (k & 63) << 6 | h & 63), d += 3);
                return a
            }
        };
        return b
    }();
    a.helpers.isArray = function(b) {
        return b ? b.isArray ? b.isArray() : "[object Array]" === Object.prototype.toString.call(b) : !1
    };
    a.helpers.isRegExp = function(b) {
        return b ? "[object RegExp]" === Object.prototype.toString.call(b) : !1
    };
    a.helpers.contains = function(b, a) {
        for (var c = b.length; c--;)
            if (b[c] === a) return !0;
        return !1
    };
    a.helpers.hash_articles = function(b) {
        var e = [],
            c, d = {};
        if (0 == b.length) return null;
        for (var f = 0, k = b.length, h, g; f < k; f++) g = b[f], h = d[g.site_id] || [], a.helpers.contains(h, g.article_id) || h.push(g.article_id), d[g.site_id] = h;
        for (c in d) d.hasOwnProperty(c) && e.push(c + ":" + d[c].join(","));
        return a.helpers.Base64.encode(e.join("|"))
    };
    a.helpers.unhash_articles = function(b) {
            a.helpers.Base64.decode(b).split("|");
        for (var e = [], c = 0, d = b.length, f; c < d; c++) f = b[c].split(","), e.push({
            site_id: f[0],
            article_id: f[1]
        });
        return e
    };
    a.helpers.merge_articles_objects = function() {
        for (var b = Array.prototype.slice.call(arguments), e, c, d, f, k = {}, h = 0, g = b.length; h < g; h++) {
            e = b[h];
            for (var l in e)
                if (e.hasOwnProperty(l)) {
                    l in k || (k[l] = {});
                    c = e[l];
                    d = k[l];
                    for (var m in c) c.hasOwnProperty(m) && (m in d || (d[m] = {}), f = c[m], d[m] = a.helpers.merge_simple_objects(d[m], f))
                }
        }
        return k
    };
    a.helpers.articles_list_to_object =
        function(b) {
            for (var e = {}, c, d, f, k, h = 0, g = b.length; h < g; h++) c = b[h], d = c.site_id, k = c.article_id, d in e || (e[d] = {}), f = e[d], e[d][k] = a.helpers.merge_simple_objects(f[k] || {}, a.helpers.remove_ids_from_article_object(c));
            return e
        };
    a.helpers.articles_object_to_list = function(b) {
        var e = [],
            c, d, f;
        for (f in b)
            if (b.hasOwnProperty(f)) {
                c = b[f];
                for (var k in c) c.hasOwnProperty(k) && (d = c[k], d = a.helpers.merge_simple_objects({
                    article_id: k,
                    site_id: f
                }, d), e.push(d))
            } return e
    };
    a.helpers.jsonp = function(b, a, c) {
        "undefined" === typeof a &&
            (a = {});
        var d;
        d = "LFCommentCount" + Math.floor(1E5 * Math.random());
        a.callback = d;
        a.appendChild(c)
    };
    a.helpers.on_window_load = function(b) {
        var e = b;
            e.call(window);
            a.loaded = !0
        };
    };
    a.helpers.get_script_element = function() {
            if (a = b[d], (c = a.src) && c.match(t)) return a
    };
    a.helpers.get_domain = function() {
        var b = a.helpers.get_script_element();
        if (b) {
            var e = b.getAttribute("data-lf-domain");
            if (e) return e;
            if (b = b.src.match(s))
                if (b = b[0], !b.match(/zor\.livefyre\.com|zor\.fyre\.co/)) return b
        }
    };
    a.helpers.memoize = function(b) {
        var a = "first-time";
        return function() {
            return "first-time" !== a ? a : a = b.apply(this,
                arguments)
        }
    };
    a.helpers.getElementsByClassName = function(a, e, c) {
            a = c.getElementsByClassName(a);
            for (var e, g = 0, l = a.length; g < l; g += 1) e = a[g], b && !b.test(e.nodeName) || c.push(e);
            return c
            var e = a.split(" "),
                g = "",
            a = [];
            for (var m, n = 0, p =
                    e.length; n < p; n += 1) g += "[contains(concat(' ', @class, ' '), ' " + e[n] + " ')]";
            try {
            } catch (q) {
            }
            return a
        } : function(a, b, c) {
            var e = a.split(" ");
            a = [];
            var g;
            g = 0;
            for (var l = e.length; g < l; g += 1) a.push(new RegExp("(^|\\s)" + e[g] + "(\\s|$)"));
            for (var l = 0, m = b.length; l < m; l += 1) {
                e = b[l];
                g = !1;
                for (var n = 0, p = a.length; n < p && (g = a[n].test(e.className),
                        g); n += 1);
                g && c.push(e)
            }
            return c
        })(a, e, c)
    };
    a.helpers.replace_innerHTML = function(a, e, c) {
        a.innerHTML = a.innerHTML.replace(e, c)
    };
    a.helpers.make_replacer = function(b) {
        var e = b;
        a.helpers.isRegExp(b) && (e = function(c, d) {
            a.helpers.replace_innerHTML(c, b, d)
        });
        return function(a) {
            var b, f, k, h;
            for (h in a)
                if (a.hasOwnProperty(h)) {
                    b = a[h];
                    for (var g in b)
                        if (b.hasOwnProperty(g)) {
                            f = b[g];
                            k = f.elements;
                            f = f.total || 0;
                            for (var l = 0, m = k.length; l < m; l++) e(k[l], f)
                        }
                }
        }
    };
    a.helpers.remove_ids_from_article_object = function(a) {
        var e = {},
            c;
        for (c in a) a.hasOwnProperty(c) &&
            "site_id" !== c && "article_id" !== c && (e[c] = a[c]);
        return e
    };
    a.helpers.merge_simple_objects = function(b, e) {
        var c = {},
            d;
        for (d in b) b.hasOwnProperty(d) && (c[d] = b[d]);
        for (d in e) e.hasOwnProperty(d) && (a.helpers.isArray(e[d]) && a.helpers.isArray(c[d]) ? c[d] = c[d].concat(e[d]) : c[d] = e[d]);
        return c
    };
    a.helpers.ensure_correct_articles_object = function(a) {
        for (var e in a)
            if (a.hasOwnProperty(e)) {
                var c = a[e],
                    d;
                for (d in c) c.hasOwnProperty(d) && "object" !== typeof c[d] && (c[d] = {
                    count: c[d]
                })
            } return a
    };
    a.defaults = {};
    a.defaults.find_elements =
        function(b) {
            return a.helpers.getElementsByClassName(b || "livefyre-commentcount")
        };
    a.defaults.get_article_id = function(a) {
        return a.getAttribute("data-lf-article-id")
    };
    a.defaults.get_article_id_legacy = function(a) {
        return a.getAttribute("article_id")
    };
    a.defaults.get_site_id_from_script_src = a.helpers.memoize(function(b) {
    });
    a.defaults.get_site_id_from_attribute = function(a) {
        return a.getAttribute("data-lf-site-id")
    };
    a.defaults.get_articles = function() {
        for (var b = a.defaults.find_elements(), e, c = {}, d, f, k = 0, h = b.length; k < h; k++) e = b[k], d = a.defaults.get_site_id_from_attribute(e) || a.defaults.get_site_id_from_script_src(e), d in c || (c[d] = {}), d = c[d], f = a.defaults.get_article_id(e), f in d || (d[f] = {
            elements: []
        }), d[f].elements.push(e);
        return c
    };
    a.defaults.get_articles_legacy = function() {
        for (var b = a.defaults.find_elements("livefyre-ncomments"), e, c = {}, d, f, k = 0, h = b.length; k < h; k++) e = b[k], d = a.defaults.get_site_id_from_script_src(e), d in
            c || (c[d] = {}), d = c[d], f = a.defaults.get_article_id_legacy(e), f in d || (d[f] = {
                elements: []
            }), d[f].elements.push(e);
        return c
    };
    a.defaults.replace_all = a.helpers.make_replacer(/(\d+,?\d*|none|no|zero|nada|leave a)/ig);
    a.fetch = function(b, e, c) {
        var d = Array.prototype.slice.call(arguments),
            f = 0;
        a.loaded = !0;
        d = a.helpers.hash_articles(b);
        if (null === d) "function" === typeof c &&
            c();
        else {
            var k = a.helpers.get_domain(),
                h;
            h = k && "livefyre.com" !== k ? "//" + k.split(".")[0] + ".bootstrap.fyre.co{path}" : "//bootstrap." + r + "{path}";
            h = "https:" + h;
            h = h.replace("{path}", "/api/v1.1/public/comments/ncomments/{hash}.json").replace("{hash}", d);
            var g = function(c) {
                f += 1;
                if ("ok" === c.status) {
                    var d = a.helpers.articles_list_to_object(b);
                    e.call(null, c)
                } else 503 == c.code && 5 > f && setTimeout(function() {
                    a.helpers.jsonp(h, {},
                        g)
                }, c.data.wait || 500)
            };
            a.helpers.jsonp(h, {}, g)
        }
    };
    a.auto_legacy = function() {
        a.fetch(a.defaults.get_articles_legacy(), a.defaults.replace_all)
    };
    a.auto = function() {
        a.fetch(a.defaults.get_articles(), a.defaults.replace_all)
    };
    a.helpers.on_window_load(function() {
        a.loaded || (a.defaults.get_site_id_from_script_src() ? a.auto_legacy() : a.auto())
    });
    a.loaded = !1;
    a.run = function() {
        a.loaded || a.auto()
    };
};
LF.modules.CommentCount(LF);