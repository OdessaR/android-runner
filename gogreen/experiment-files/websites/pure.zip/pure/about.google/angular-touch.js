/*
 AngularJS v1.6.6
 (c) 2010-2017 Google, Inc. http://angularjs.org
 License: MIT
*/
(function(x, p) {
    'use strict';

    function s(f, k) {
        var e = !1,
            a = !1;
            return p.isDefined(b) ? (b && !a && (a = !0, t.$$moduleName = "ngTouch", k.directive("ngClick", t), f.decorator("ngClickDirective", ["$delegate", function(a) {
                if (e) a.shift();
                else
                    for (var b = a.length - 1; 0 <= b;) {
                        if ("ngTouch" === a[b].$$moduleName) {
                            a.splice(b, 1);
                            break
                        }
                        b--
                    }
                return a
        };
            return {
                ngClickOverrideEnabled: function() {
                    return e
                }
            }
        }
    }

    function v(f, k, e) {
        n.directive(f, ["$parse", "$swipe", function(a,
            b) {
            return function(l, u, g) {
                function h(c) {
                    if (!d) return !1;
                    var a = Math.abs(c.y - d.y);
                    c = (c.x - d.x) * k;
                    return r && 75 > a && 0 < c && 30 < c && .3 > a / c
                }
                var m = a(g[f]),
                    d, r, c = ["touch"];
                p.isDefined(g.ngSwipeDisableMouse) || c.push("mouse");
                b.bind(u, {
                    start: function(c, a) {
                        d = c;
                        r = !0
                    },
                    cancel: function(c) {
                        r = !1
                    },
                    end: function(c, d) {
                        h(c) && l.$apply(function() {
                            u.triggerHandler(e);
                            m(l, {
                                $event: d
                            })
                        })
                    }
                }, c)
            }
        }])
    }
    var n = p.module("ngTouch", []);
    n.info({
        angularVersion: "1.6.6"
    });
    n.provider("$touch", s);
    n.factory("$swipe",
        [function() {
            function f(a) {
                var b = a.touches && a.touches.length ? a.touches : [a];
                return {
                    x: a.clientX,
                    y: a.clientY
                }
            }

            function k(a, b) {
                var l = [];
                p.forEach(a, function(a) {
                });
                return l.join(" ")
            }
            var e = {
                mouse: {
                    start: "mousedown",
                    move: "mousemove",
                    end: "mouseup"
                },
                touch: {
                    start: "touchstart",
                    move: "touchmove",
                    end: "touchend",
                    cancel: "touchcancel"
                },
                pointer: {
                    start: "pointerdown",
                    move: "pointermove",
                    end: "pointerup",
                    cancel: "pointercancel"
                }
            };
            return {
                bind: function(a,
                    b, l) {
                    var e, g, h, m, d = !1;
                    a.on(k(l, "start"), function(c) {
                        h = f(c);
                        d = !0;
                        g = e = 0;
                        m = h;
                        b.start && b.start(h, c)
                    });
                    var r = k(l, "cancel");
                    if (r) a.on(r, function(c) {
                        d = !1;
                        b.cancel && b.cancel(c)
                    });
                    a.on(k(l, "move"), function(c) {
                        if (d && h) {
                            var a = f(c);
                            e += Math.abs(a.x - m.x);
                            g += Math.abs(a.y - m.y);
                            m = a;
                            10 > e && 10 > g || (g > e ? (d = !1, b.cancel && b.cancel(c)) : (c.preventDefault(), b.move && b.move(a, c)))
                        }
                    });
                    a.on(k(l, "end"), function(c) {
                        d && (d = !1, b.end && b.end(f(c), c))
                    })
                }
            }
        }]);
    var t = ["$parse", "$timeout", "$rootElement", function(f,
        k, e) {
        function a(a, d, b) {
            for (var c = 0; c < a.length; c += 2) {
                var g = a[c + 1],
                    e = b;
                if (25 > Math.abs(a[c] - d) && 25 > Math.abs(g - e)) return a.splice(c, c + 2), !0
            }
            return !1
        }

        function b(b) {
            if (!(2500 < Date.now() - u)) {
                var d = b.touches && b.touches.length ? b.touches : [b],
                    e = d[0].clientX,
                    d = d[0].clientY;
                if (!(1 > e && 1 > d || h && h[0] === e && h[1] === d)) {
                    h && (h = null);
                    var c = b.target;
                    "label" === p.lowercase(c.nodeName || c[0] && c[0].nodeName) && (h = [e, d]);
                    a(g, e, d) || (b.stopPropagation(), b.preventDefault(), b.target && b.target.blur && b.target.blur())
                }
            }
        }

        function l(a) {
                a.touches && a.touches.length ? a.touches : [a];
            var b = a[0].clientX,
                e = a[0].clientY;
            g.push(b, e);
            k(function() {
                for (var a = 0; a < g.length; a += 2)
                    if (g[a] === b && g[a + 1] === e) {
                        g.splice(a, a + 2);
                        break
                    }
            }, 2500, !1)
        }
        var u, g, h;
        return function(h, d, k) {
            var c = f(k.ngClick),
                n = !1,
                q, s, t, v;
            d.on("touchstart", function(a) {
                n = !0;
                q = a.target ? a.target : a.srcElement;
                3 === q.nodeType && (q = q.parentNode);
                d.addClass("ng-click-active");
                s = Date.now();
                t = a.clientX;
                v = a.clientY
            });
            d.on("touchcancel",
                function(a) {
                    n = !1;
                    d.removeClass("ng-click-active")
                });
            d.on("touchend", function(c) {
                var h = Date.now() - s,
                    f = c.originalEvent || c,
                    m = (f.changedTouches && f.changedTouches.length ? f.changedTouches : f.touches && f.touches.length ? f.touches : [f])[0],
                    f = m.clientX,
                    m = m.clientY,
                    w = Math.sqrt(Math.pow(f - t, 2) + Math.pow(m - v, 2));
                n && 750 > h && 12 > w && (g || (e[0].addEventListener("click", b, !0), e[0].addEventListener("touchstart", l, !0), g = []), u = Date.now(), a(g, f, m), q && q.blur(), p.isDefined(k.disabled) && !1 !== k.disabled || d.triggerHandler("click",
                    [c]));
                n = !1;
                d.removeClass("ng-click-active")
            });
            d.on("click", function(a, b) {
                h.$apply(function() {
                    c(h, {
                        $event: b || a
                    })
                })
            });
            d.on("mousedown", function(a) {
                d.addClass("ng-click-active")
            });
            d.on("mousemove mouseup", function(a) {
                d.removeClass("ng-click-active")
            })
        }
    }];
    v("ngSwipeLeft", -1, "swipeleft");
    v("ngSwipeRight", 1, "swiperight")
})(window, window.angular);
//# sourceMappingURL=angular-touch.min.js.map