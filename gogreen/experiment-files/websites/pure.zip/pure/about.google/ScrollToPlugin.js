/*!
 * VERSION: 1.7.5
 * DATE: 2015-02-26
 * UPDATES AND DOCS AT: http://greensock.com
 *
 * @license Copyright (c) 2008-2015, GreenSock. All rights reserved.
 * This work is subject to the terms at http://greensock.com/standard-license or for
 * Club GreenSock members, the software agreement that was issued with your membership.
 * 
 * @author: Jack Doyle, jack@greensock.com
 **/
var _gsScope = "undefined" != typeof module && module.exports && "undefined" != typeof global ? global : this || window;
(_gsScope._gsQueue || (_gsScope._gsQueue = [])).push(function() {
    "use strict";
        i = function(i, r) {
            var s = "x" === r ? "Width" : "Height",
                n = "scroll" + s,
                a = "client" + s,
            return i === e || i === t || i === o ? Math.max(t[n], o[n]) - (e["inner" + s] || t[a] || o[a]) : i[n] - i["offset" + s]
        },
            propName: "scrollTo",
            API: 2,
            version: "1.7.5",
            init: function(t, r, s) {
                    y: r
            },
            set: function(t) {
            }
        }),
        s = r.prototype;
    r.max = i, s.getX = function() {
    }, s.getY = function() {
    }, s._kill = function(t) {
    }
}), _gsScope._gsDefine && _gsScope._gsQueue.pop()();