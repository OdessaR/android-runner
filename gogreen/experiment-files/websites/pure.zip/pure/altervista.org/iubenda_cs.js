! function() {
    "use strict";
    e.src = "//cdn.iubenda.com/cookie_solution/iubenda_cs/core-4f447fcd97783865e71939f697e3b28c.js", c.parentNode.insertBefore(e, c)
}();