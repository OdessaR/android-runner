var swiperHome;
$(function() {
});

function swiperHome() {

    me.init = function() {
        me.checkSwiper = 0;
        me.initSwiper();
        $(window).resize(function() {
            me.initSwiper();
        });

    };

    me.initSwiper = function() {
            me.checkSwiper = 1;
                loop: true,
                pagination: {
                    el: '.swiper-pagination',
                    type: 'bullets',
                    clickable: true,
                },
                paginationClickable: true,
                autoplay: 3000,
                autoplayDisableOnInteraction: false
            });


            me.swiper.destroy(1, 1);
            me.checkSwiper = 0;
        }
    };
}