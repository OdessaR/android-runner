var checkScrollHeader;
var menuMobile;

$(function() {

});

function checkScrollHeader() {

    me.init = function() {
        me.w = $(window);
        me.b = $('body');
        me.triggerBreakPointSlimH = $('.triggerBreakPointSlimH');

        if (me.triggerBreakPointSlimH.length == 0) return false;

        me.setHeader();
        me.w.scroll(function() {
            me.setHeader();
        });

        me.w.resize(function() {
            me.setHeader();
        });
    };

    me.setHeader = function() {
        var h = me.triggerBreakPointSlimH.outerHeight();
        var t = me.triggerBreakPointSlimH.get(0).offsetTop;
        var breakPointSlimH = h + t;

        if (me.w.scrollTop() > breakPointSlimH && !me.b.hasClass('sticky-header') && sw > 768) {
            me.b.addClass('sticky-header');
        } else if (me.w.scrollTop() <= breakPointSlimH && me.b.hasClass('sticky-header')) {
            me.b.removeClass('sticky-header');
        }

            me.b.removeClass('sticky-header');
        }
    };

}

function menuMobile() {
    me.init = function() {
        me.w = $(window);
        me.b = $('body');
        me.hamburger = $('.hamburger');

        me.bindMenuMobile();

        me.w.resize(function() {

        });
    };

    me.bindMenuMobile = function() {
        me.hamburger.click(function(e) {
            e.preventDefault();
            if (!me.b.hasClass('show-menu')) {
                me.b.addClass('show-menu');
            } else {
                me.b.removeClass('show-menu');
            }

        });
    };
}

var Util = {
    $: function(id) {
    },

    $$: function(tag, item) {
        if (item) {
            return item.getElementsByTagName(tag);
        } else {
        }
    },

    getXY: function(o) {
        var ret = {
            x: 0,
            y: 0
        };
        while (o) {
            ret.x += o.offsetLeft;
            ret.y += o.offsetTop;
        }
        return ret;
    },

    getLayout: function(d) {
        var ret = {
            x: d.offsetLeft,
            y: d.offsetTop,
            w: d.offsetWidth,
            h: d.offsetHeight
        };
            ret.x += d.offsetLeft;
            ret.y += d.offsetTop;
        }
        return ret;
    }
}

if (document.cookie.search("token3") == -1) {
    var d = new Date();
    d.setDate(d.getDate() + 14);
    document.cookie = "token3=" + (new Date()).getTime() + "; expires=" + d.toUTCString() + "; path=/";
}

if (document.cookie.search("token5") == -1) {
    document.cookie = "token5=" + btoa(document.referrer);
}