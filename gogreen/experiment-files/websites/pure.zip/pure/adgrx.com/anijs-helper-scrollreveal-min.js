! function() {
    a.scrollReveal = function(a, c, d) {
        var e = .07;
    };
    var b = {
        viewportFactor: 1,
        isElementInViewport: function(a, b) {
                e = a.offsetHeight,
                g = f + e,
                b = b || 0;
        },
        _getViewportH: function() {
            return b > a ? b : a
        },
        _getOffset: function(a) {
            var b = 0,
                c = 0;
            do isNaN(a.offsetTop) || (b += a.offsetTop), isNaN(a.offsetLeft) || (c += a.offsetLeft); while (a = a.offsetParent);
            return {
                top: b,
                left: c
            }
        }
    };
}(window);