! function() {
    "use strict";
    var a, r, o, c, n, s;
    try {
            m = i && i[1];
            var a = [];
            for (var r in e) a.push(r + "=" + encodeURIComponent(e[r]));
        }({
            code: r,
            msg: a + "",
            pid: "spl",
            page: e.href.split(/[#?]/)[0],
            query: e.search.substr(1),
            hash: e.hash,
            referrer: t.referrer,
            title: t.title,
        }, "//gm.mmstat.com/fsp.1.1?")
    }
}();