/* 2018-10-09 14:12:23 */ ! function(e, n) {
    function i(e) {
        var i = n.createElement("iframe");
    }

    function t(e) {
        var i = new RegExp("(^| )" + e + "=([^;]*)(;|$)"),
            t = n.cookie.match(i);
        return t ? t[2] || "" : ""
    }

    function o() {
    }

    function a() {
        return e.indexOf("android") >= 0 || e.indexOf("iphone") >= 0 || e.indexOf("ipad") >= 0 || e.indexOf("ipod") >= 0 || e.indexOf("mobile") >= 0
    }

    function r() {
        var n = (new Date).getTime();
            var o = t("cna"),
                a = t("nickname");
            if (o || a) {
                i("//g.alicdn.com/alilog/oneplus/blk.html#coid=" + encodeURIComponent(o) + "&noid=" + encodeURIComponent(a))
            } else e.setTimeout(function() {
                r()
            }, 300)
        }
    }
    try {
        var d = "_oid_ifr_",
            c = (new Date).getTime();
        o() || a() || r()
}(window, document);