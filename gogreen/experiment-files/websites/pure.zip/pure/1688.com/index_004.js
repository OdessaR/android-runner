(function(p, h, a, e, o, u, i) {
    if (p.__sec_entry_loaded || h.__no_sec_entry) {
        return
    }
    var t = e.userAgent;
    var r = i("%58%75%65%58%69");
    var n = r.toLowerCase();
        return
    }
    var c = h.getElementsByTagName("head")[0];

    function g(a) {
        var e = h.createElement("script");
        e.src = a;
        return c.appendChild(e)
    }
    var l = "//g.alicdn.com";
    if (m && m.getCdnPath) {
        l = m.getCdnPath()
    }
    l += "/secdev/";
    var s = t.match(/Chrome\/(\d*)/);
    if (s) {
        s = +s[1]
    }
    if (!h._sufei_data2) {
        var d = "3.9.0";
        var f = g(l + "sufei_data/" + d + "/index.js");
        f.async = h.cookie.indexOf("isg=") < 0;
        f.id = "aplus-sufei"
    }
    var v = .001;
    if (a() < v) {
        g(l + "linkstat/index.js?v=1201")
    }
    var y = 0;
    var _ = ["taobao.com", "alibaba.com", "alipay.com", "tmall.com", "lazada", "aliexpress.com", "1688.com", "alimama.com", "tb.cn", "xiami.com", "amap.com", "cainiao.com", "aliyun.com", "etao.com", "fliggy.com", "liangxinyao.com", "damai.cn", "daraz.lk", "tmall.hk", "jiyoujia.com", "taopiaopiao.com", "alitrip.com", "fliggy.hk", "alihealth.cn", "alitrip.hk", "ele.me", "gaode.cn", "mp.dfkhgj.com", "mp.bcvbw.com", "m.dfkhgj.com", "pailitao.com"];
    if (Math.random() < .3) _ = ["taobao", "alibaba.com", "alipay.com", "tmall.com", "lazada", "aliexpress", "1688.com", "alimama.com", "tb.cn", "xiami.com", "amap.com", "cainiao.com", "aliyun.com", "etao.com", "fliggy.com", "liangxinyao.com", "damai.cn", "daraz", "tmall.hk", "jiyoujia.com", "taopiaopiao.com", "alitrip.com", "fliggy.hk", "alihealth.cn", "alitrip.hk", "ele.me", "gaode", "mp.dfkhgj.com", "mp.bcvbw.com", "m.dfkhgj.com", "pailitao.com", "youku.com", "jiaoyimao", "sm.cn", "dingtalk.com", "alibaba-inc", "guoguo-app", "kaola", "alicdn", "soku"];
    for (var x = 0; x < _.length; x++) {
        if (~o.host.indexOf(_[x])) {
            y = 1;
            break
        }
    }
    if (y) {
        var b = ["1.0.78", "e", 88];
        var k = ["1.0.79", "e", 89];
        var j = 0;
        var M = b;
        if (o.href == "https://search.1688.com/company/wap/company_search.html") {
            j = 1e4
        }
        if ((a() * 1e4 | 0) < j) {
            M = k
        }
        if (!M) {
            return
        }
        var C = l;
        var w = true;
        if (o.hostname.indexOf("buyertrade.taobao.com") > -1 || /refund2\.taobao\.com$|refund2\.tmall\.com$/.test(o.hostname) && o.pathname === "/dispute/apply.htm") {
            if (!w) {
                C = C.replace("/secdev/", "??xlly/spl/index.js,secdev/")
            } else {
                C = C.replace("/secdev/", "??xlly/spl/index.js,xlly/spl/rp.js,secdev/")
            }
        } else if (w) {
            C = C.replace("/secdev/", "??xlly/spl/rp.js,secdev/")
        }
        var E = C + "nsv/" + M[0] + "/";
        var S = E + "ns_" + M[1] + "_" + M[2] + "_3_f.js";
        var I = E + "ns_" + M[1] + "_" + M[2] + "_3_n.js";

        function L() {
            var a = "function%20javaEnabled%28%29%20%7B%20%5Bnative%20code%5D%20%7D";
            if ("WebkitAppearance" in h.documentElement.style) {
                if (escape(e.javaEnabled.toString()) === a) {
                    return true
                }
            }
            return false
        }
        var O = t.match(/Edge\/([\d]*)/);
        var A = t.match(/Safari\/([\d]*)/);
        var D = t.match(/Firefox\/([\d]*)/);
        var T = t.match(/MSIE|Trident/);
        if (O) {
            g(S)
        } else if (s) {
            g(S)
        } else if (A || D || T) {
            g(I)
        } else {
            if (L()) {
                g(S)
            } else {
                g(I)
            }
        }
    } else {
        g(l.replace("/secdev/", "/xlly/spl/rp.js"))
    }

    function W() {
        var a = p.atob;
        if (!a) {
            return
        }

        function o(a, e) {
            var o = [];
            for (var i in a) {
                o.push(i + "=" + u(a[i]))
        }
        var e = 0;
        var i = "";

        function t() {
            if (++e == 3) {
                clearInterval(s)
            }
            c()
        }
        var r;
        var n = Math.random() * 1e8 | 0;

        function c() {
            var a = r.getUA({
                MaxMTLog: 500,
                MTInterval: 7
            });
            a = n + "|" + a;
            var e = {
                token: a,
                cna: i,
                ext: 7
            };
            o(e, "https://fourier.taobao.com/ts?")
        }
        if (!l && /xlly=1/.test(h.cookie)) {
            l = +new Date;
        }
        if (l) {
            var m = new Date - l;
            if (m > 1e3 * 3600 * 24) {
                m = 0;
            }
            if (m < 1e3 * 60 * 20) {
                var s = setInterval(t, 1e3 * 60);
                if (p.addEventListener) {
                    p.addEventListener("unload", c)
                }
                var d = h.cookie.match(/cna=([^;]+)/);
                if (d) {
                    i = d[1]
                }
                var f = g(a("aHR0cHM6Ly9nLmFsaWNkbi5jb20vQVdTQy9BV1NDL2F3c2MuanM="));
                var v = unescape("%75%61%62");
                f.onload = function() {
                        if (a === "loaded") {
                            r = e
                        }
                    })
                }
            }
        }
    }
    try {
        W()
    } catch (a) {}
    try {
        var z = 0;
        for (var x = 0; x < _.length; x++) {
            if (o.host && ~o.host.indexOf(_[x])) {
                z = 1;
                break
            }
        }
        if (z) {
            var B = "1.61.1";
            var F = "1.62.1";
            var N = 1;
            var R = B;
            if (Math.random() < N) {
                R = F
            }
            if (!R) {
                return
            }
            var U = "//g.alicdn.com/AWSC/et/" + R + "/";
            var H = U + "et_f.js";
            var P = U + "et_n.js";
                g(H)
            } else if (s) {
                g(H)
                g(P)
            } else {
                if (L()) {
                    g(H)
                } else {
                    g(P)
                }
            }
        }
    } catch (a) {}
})(window, document, Math.random, navigator, location, encodeURIComponent, decodeURIComponent);