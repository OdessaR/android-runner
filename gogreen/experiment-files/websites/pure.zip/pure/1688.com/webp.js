! function() {
    var o = {
        isSupport: function() {
            var o, t = function(t) {
                o = t
            };
        },
        _isSupport: function(o) {
            var t = "webpsupport_lossy";
                return void o("true" === e)
            }
            a.onload = function() {
                var e = a.width > 0 && a.height > 0;
            }, a.onerror = function() {
            }, a.src = "data:image/webp;base64,UklGRhoAAABXRUJQVlA4TA0AAAAvAAAAEAcQERGIiP4HAA=="
        }
    };
    if (o.isSupport()) {
            e = t.className || "",
            a = e + " common_webp_support";
        t.className = a
    }
}();;