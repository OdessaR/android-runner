/*! privacy - v1.0.10 - 08-26-2020, 5:51:33 AM

ADOBE CONFIDENTIAL
==================
Copyright 2020 Adobe Systems Incorporated
All Rights Reserved.

NOTICE: All information contained herein is, and remains
the property of Adobe Systems Incorporated and its suppliers,
if any. The intellectual and technical concepts contained
herein are proprietary to Adobe Systems Incorporated and its
suppliers and are protected by trade secret or copyright law.
Dissemination of this information or reproduction of this material
is strictly forbidden unless prior written permission is obtained
from Adobe Systems Incorporated.
*/

! function() {
    var e, t, n, o, i, s;
    e = function() {
        var e = {};
        return e.isObject = function(e) {
            return null !== e && "object" == typeof e
        }, e.isEmptyObject = function(e) {
            var t;
                for (t in e)
                    if (e.hasOwnProperty(t)) return !1;
            return !0
        }, e.isFunction = function(e) {
            return "function" == typeof e
        }, e.isArray = function(e) {
        }, e.formatString = function(e, t) {
            if ("string" == typeof e && Array.isArray(t) && t.length) return e.replace(/{(\d+)}/g, function(e, n) {
                return "undefined" != typeof t[n] ? t[n] : e
            })
        }, e.getPropertySafely = function(e, t) {
            var n, o, i;
            if (e && "object" == typeof e && !Array.isArray(e) && "string" == typeof t && Object.keys(e).length && t.length) {
                for (t = t.split("."), o = t.length, i = e, n = 0; n < o; n++) {
                    if (!i.hasOwnProperty(t[n])) return;
                    i = i[t[n]]
                }
                return i
            }
        }, e.isValidHex = function(e) {
            return "string" == typeof e && /(^#[0-9A-F]{6}$)|(^#[0-9A-F]{3}$)/i.test(e)
        }, e.removeSelectorIdentifier = function(e) {
            return "string" == typeof e ? e.replace(/^[\.#]/, "") : void 0
        }, e.mergeObjects = function(e, t) {
            return e = n ? e : {}, t = o ? t : {}, Object.keys(e).forEach(function(n) {
                t[n] = e[n]
            }), t
        }, e
    }(), t = function(e) {
        var t, n, o = {},
            i = "adobePrivacy";
            id: i,
            debug: i + "Debug",
            testNotice: "testNotice",
            bypassConsent: "autoConsent"
        }, o.events = Object.freeze({
            privacyConsentPublic: i + ":PrivacyConsent",
            privacyRejectPublic: i + ":PrivacyReject",
            privacyCustomPublic: i + ":PrivacyCustom",
            oneTrustReady: "feds.events.oneTrustReady"
        }), o.privacy = {
            oneTrustDomainId: t,
            footerLinkSelector: n,
            privacyFilesCDN: "https://cdn.cookielaw.org/scripttemplates/otSDKStub.js",
            cookieTime: 13,
            productionDomain: "adobe.com"
        }, o.cookieNames = {
            fedsPrivacyCookieName: "feds_privacy_consent",
            oneTrustBannerCookieName: "OptanonAlertBoxClosed"
        }, o.cookieDomains = {
            allAdobe: ".adobe.com"
        }, o
    }(e), n = function(e) {
        var t = {};
        return t.closest = function(e, t) {
            if (!e || !t) return null;
                for (; e && 1 === e.nodeType;) {
                    e = e.parentNode
                }
                return null
            }
            return e.closest(t)
        }, t.matches = function(e, t) {
            var n, o, i;
                return i > -1
            }, n.apply(e, [t])) : e.matches(t) : null
        }, t.forEach = function(e, t, n) {
            var o, i;
            if (e && t)
                for (o = 0, i = e.length, o; o < i; o++) t.call(n, e[o], o, e)
        }, t.Events = function() {
            var t = {};
                var o = t[e] || [];
                o.push(n), t[e] = o
                var i, s, r = t[n];
                if (r)
                    for (s = 0, i = r.length; s < i; ++s) e.isFunction(r[s]) && r[s].apply(null, [o, n])
            }
        }, t.addPassiveEventListener = function(t, n, o) {
            var i, s = !1;
            if (t && "object" == typeof t && "string" == typeof n && n.length > 0 && e.isFunction(o)) {
                try {
                    i = Object.defineProperty({}, "passive", {
                        get: function() {
                            s = !0
                        }
                } catch (e) {}
                t.addEventListener(n, o, !!s && {
                    passive: !0
                })
            }
        }, t.isInteger = function(e) {
            var t;
            return t = "function" == typeof Number.isInteger ? Number.isInteger : function(e) {
            }, t.apply(null, [e])
        }, t.isRTL = function() {
        }, t.isElementVisible = function(e) {
        }, t.findItems = function(t, n) {
            var o, i, s;
            if (t && t.length > 0 && e.isFunction(n))
                for (o = [], s = t.length, i = 0; i < s; i++) n(t[i]) && o.push(t[i]);
            return o
        }, t.loadResource = function(t) {
            var n, o, i = e.getPropertySafely(t, "path"),
                s = e.getPropertySafely(t, "type"),
                r = e.getPropertySafely(t, "async"),
                a = e.getPropertySafely(t, "callback"),
                c = e.getPropertySafely(t, "id");
                o || (o = !0, a())
        }, t
    }(e), o = function(e, t) {
        function n() {
        }
        var o;
        return n.prototype.message = function() {
                var t, n = [e.strings.debug + ":"],
                    o = arguments.length;
                for (t = 0; t < o; t++) n.push(arguments[t]);
                return n.concat()
            }, n.prototype.log = function() {
            }, n.prototype.warn = function() {
            }, n.prototype.error = function() {
            },
            function() {
                return o = o || new n
            }
    }(t, e), i = function(e, t) {
        var n = {};
        return n.isSet = function(e) {
            var t, n = !1;
                if (n.length) return t = n.split("="), t = t[0], t = t.trim(), t === e
            }).length)), n
        }, n.getValue = function(e, t) {
            var n, o, i, s;
        }, n.setValue = function(t, n, o, i) {
            var s, r, a, c = "";
        }, n
    }(e, n), s = function(e, t, n, o, i) {
        function s(e, t) {
            for (t = e = ""; e++ < 36; t += 51 * e & 52 ? (15 ^ e ? 8 ^ Math.random() * (20 ^ e ? 16 : 4) : 4).toString(16) : "-");
            return t
        }
        var r, a, c, d, u, l, p = {
                event: new n.Events,
                userProvidedConsent: !1
            },
            y = {},
            v = o(),
            f = "OptanonConsent",
            m = "#onetrust-consent-sdk",
            g = "#onetrust-banner-sdk",
            h = g + " #onetrust-accept-btn-handler",
            w = g + " #onetrust-pc-btn-handler",
            C = "#onetrust-pc-sdk",
            b = C + " .enable-all-btn",
            k = C + " .disable-all-btn",
            P = C + " .category-switch-handler",
            E = C + " .ot-group-option-box",
            T = C + " .ot-general-question",
            S = C + " .pc-save-and-close",
            O = ".ot-sdk-show-settings",
            L = ".ot-cookie-settings",
            D = "#ot-cookie-button",
            j = "#ot-banner-close",
            A = ".category-switch-handler",
            F = C + " #first-party-cookies-domain",
            M = ".cs-close",
            I = "ot-cookie-settings",
            q = "#ot-cookie-settings",
            x = "ot-cookie-description",
            N = !1,
            R = [],
            U = ["C0001", "C0002", "C0003", "C0004"];
        return p.dispatchEvent = function(e) {
            var t;
        }, p.overrideEndpointsConfig = function(n) {
            e.privacy.privacyFilesCDN = t.getPropertySafely(n, "privacyFilesPath") || e.privacy.privacyFilesCDN, e.privacy.oneTrustDomainId = t.getPropertySafely(n, "oneTrustDomainId") || e.privacy.oneTrustDomainId, e.privacy.footerLinkSelector = t.getPropertySafely(n, "footerLinkSelector") || e.privacy.footerLinkSelector
        }, p.bypassConsent = function() {
                n = new Date;
            t && "undefined" == typeof i.getValue(e.cookieNames.oneTrustBannerCookieName) && (n.setMonth(n.getMonth() + e.privacy.cookieTime), i.setValue(e.cookieNames.oneTrustBannerCookieName, (new Date).toISOString(), {
                expiration: n,
                domain: e.cookieDomains.allAdobe,
                path: "/"
            }, !0))
        }, p.dispatchConsentEvents = function() {
            p.event.dispatchEvent(e.events.privacyConsentPublic), p.dispatchEvent(e.events.privacyConsentPublic), p.userProvidedConsent = !0
        }, p.loadOneTrustAssets = function(o) {
            var i;
            n.loadResource({
                id: "oneTrust-bootstrap",
                path: e.privacy.privacyFilesCDN,
                type: "script",
                async: !0,
                callback: function() {
                    p.event.dispatchEvent(e.events.oneTrustReady), p.dispatchEvent(e.events.oneTrustReady), t.isFunction(o) && o()
                }
        }, p.isOtDomainDataLoaded = function() {
        }, p.isOtBannerLoaded = function() {
        }, p.isOtCookiePopulated = function() {
            var e = i.getValue(f);
            return "string" == typeof e && e.length && e.indexOf("groups=") !== -1 && e.indexOf("hosts=") !== -1
        }, p.firePageLoadPrivacyEvents = function() {
            var n, o, i;
            if (p.isOtDomainDataLoaded() && p.isOtCookiePopulated() || p.isOtBannerLoaded()) {
                        hasUserProvidedConsent: !0
                    }), i = p.getFedsPrivacyCookie())), t.isObject(i) && i.hasUserProvidedConsent) return void p.dispatchConsentEvents();
                if (t.isObject(i) && i.userHasCustomConsent) return p.event.dispatchEvent(e.events.privacyCustomPublic), void p.dispatchEvent(e.events.privacyCustomPublic);
                if (t.isObject(i) && !i.hasUserProvidedConsent && !i.userHasCustomConsent) return p.event.dispatchEvent(e.events.privacyRejectPublic), void p.dispatchEvent(e.events.privacyRejectPublic)
            } else n = setTimeout(p.firePageLoadPrivacyEvents, 200)
        }, p.injectToDomForOneTrust = function() {
        }, p.bindToOneTrustEvents = function() {
                var o, i, s, v, f, C, A, F, I, q, x = t.target.getAttribute("hostid") || t.target.id,
                    B = R.indexOf(x);
                        hasUserProvidedConsent: !0
                    for (o = 0; o < q.length; o++) try {
                    } catch (e) {
                        return
                    }(n.closest(t.target, E) || n.closest(t.target, P)) && (B !== -1 ? R.splice(B, 1) : R.push(x), c && R.length > 0 ? c.style.display = "inline-block" : c && (c.style.display = "none"), p.addClassChecked()), n.closest(t.target, S) && (d = !1, u = !1, l = y.activeCookieGroups(), l.length > 1 && (d = !0, u = U.every(function(e) {
                        return y.activeCookieGroups().indexOf(e) !== -1
                    }), p.userProvidedConsent = u), p.setFedsPrivacyCookie({
                        hasUserProvidedConsent: u,
                        userHasCustomConsent: d
                        a.classList.remove("show")
                        hasUserProvidedConsent: !1
                    }), p.event.dispatchEvent(e.events.privacyRejectPublic), p.dispatchEvent(e.events.privacyRejectPublic), p.userProvidedConsent = !1, N = !1, p.trackConsent("disable"), p.addClassChecked())
            })
        }, p.isOtPopupVisible = function() {
            return !!e && (!e.classList.contains("hide") && (!e.style || "none" !== e.style.display))
        }, p.injectMissingText = function(e) {
                c = n.closest(e.target, ".category-item");
        }, p.addBannerButtonMinimized = function() {
        }, p.addClassChecked = function() {
            for (e = 0; e < t.length; e += 1) t[e].checked === !0 ? t[e].parentElement.classList.add("checked") : t[e].parentElement.classList.remove("checked")
        }, p.toggleToastCookieSettings = function() {
            var e;
        }, p.setFedsPrivacyCookie = function(t) {
            var n, o = new Date;
            t = t || {}, "boolean" != typeof t.hasUserProvidedConsent && (t.hasUserProvidedConsent = !1), "boolean" != typeof t.userHasCustomConsent && (t.userHasCustomConsent = !1), n = "." + p.getTopDomain(), o.setMonth(o.getMonth() + e.privacy.cookieTime), i.setValue(e.cookieNames.fedsPrivacyCookieName, JSON.stringify(t), {
                expiration: o,
                domain: n,
                path: "/"
            }, !0)
        }, p.getFedsPrivacyCookie = function() {
            var t, n = i.getValue(e.cookieNames.fedsPrivacyCookieName, !0);
            try {
                t = JSON.parse(n)
            } catch (e) {}
            return t
        }, p.getTopDomain = function() {
            var e, t, n = "tldTest=cookie",
            for (e = o.length - 1; e >= 0; e--)
        }, p.isProduction = function() {
            function t(e) {
            }
        }, p.trackConsent = function(e) {
            var n, o, i, r, a, c, d, u;
                events: [{
                    xdm: {
                        timestamp: (new Date).toISOString(),
                        web: {
                            webPageDetails: {
                                name: a,
                                URL: a
                            }
                        },
                        _adobe_corpnew: {
                            consentTracking: {
                                type: e,
                                activeGroups: y.activeCookieGroups().toString(),
                                activeGroupsArray: y.activeCookieGroups(),
                                domainID: d,
                                continent: c.continent || "",
                                country: c.country || "",
                                state: c.state || "",
                                stateName: c.stateName || "",
                                city: c.city || "",
                                zipcode: c.zipcode || "",
                                timezone: c.timezone || ""
                            }
                        }
                    }
                }]
        }, y.init = function(t) {
            p.overrideEndpointsConfig(t), "string" == typeof e.privacy.privacyFilesCDN && e.privacy.privacyFilesCDN.length && "string" == typeof e.privacy.oneTrustDomainId && e.privacy.oneTrustDomainId.length && (p.bypassConsent(), p.loadOneTrustAssets(function() {
                p.firePageLoadPrivacyEvents(), p.bindToOneTrustEvents(), p.addBannerButtonMinimized(), p.toggleToastCookieSettings()
        }, y.loadResource = function(e) {
            n.loadResource(e)
        }, y.activeCookieGroups = function() {
            function e(e, t) {
                var n;
                return e && t ? (n = e.split(t + "="), n = n.pop(), n = n.split("&"), n = n.shift()) : null
            }

            function t(e, t) {
                var n;
                null !== e && (n = e.split(","), n.forEach(function(e) {
                    e.indexOf(":1") > 0 && t.push(e.replace(":1", ""))
                }))
            }
            var n, o, s = i.getValue(f),
                r = [];
            return "string" == typeof s && s.length && (n = e(s, "groups"), o = e(s, "hosts"), t(n, r), t(o, r)), r
        }, y.showConsentPopup = function() {
        }, y.hasUserProvidedConsent = function() {
            var e = p.getFedsPrivacyCookie();
            return !(!t.isObject(e) || e.hasUserProvidedConsent !== !0)
        }, y.hasUserProvidedCustomConsent = function() {
            var e = p.getFedsPrivacyCookie();
            return !(!t.isObject(e) || e.hasUserProvidedConsent !== !1 || e.userHasCustomConsent !== !0)
        }, y.events = {
            onetrust_ready: e.events.oneTrustReady,
            privacy_consent: e.events.privacyConsentPublic,
            privacy_reject: e.events.privacyRejectPublic,
            privacy_consent_custom: e.events.privacyCustomPublic
        }, y
}();