// For license information, see `https://assets.adobedtm.com/d4d114c60e50/f3fbfbe0e7ca/f34a88b4afbe/RC252f840aaf624dd8a3342f251aa80827-file.js`.
! function() {
    function i(e) {
        var a = 1e13 * (Math.random() + ""),
    }
        var n = d.location,
            t = n.hostname,
            c = n.pathname,
            s = unescape(unescape(unescape(n.href))),
            o = "";
        switch (e) {
            case "host":
                o = t;
                break;
            case "path":
                o = c;
                break;
            case "href":
                o = s;
                break;
            case "referrer":
                o = u;
                break;
            case "dClick":
                i(a);
                break;
            case "substr":
                o = function(e, a) {
                    return -1 !== e.indexOf(a)
                }(a, r);
                break;
            default:
                return !1
        }
        return o
    }
}();