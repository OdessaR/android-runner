// For license information, see `https://assets.adobedtm.com/d4d114c60e50/f3fbfbe0e7ca/f34a88b4afbe/RCd3eaa000897141edb631f380cab307d5-file.js`.
! function() {
    new Promise(function(e) {
            var a;
        }, [function() {
        }], {
            timeout: 2e3,
            interval: 250,
            callOnTimeout: !0
        })
    }).then(function() {
            var e, t, n = l.s_adobe,
                i = n && n.visitor,
                o = i && i.getMarketingCloudVisitorID(),
                d = i && i.getAudienceManagerLocationHint();
                    method: "GET",
                    url: "https://adobeioruntime.net/api/v1/web/14257_51772/abx-connector-0.0.1/ecids.json?ecid=" + o + "&locationHint=" + d + "&countryCode=" + t
                }).then(function(a) {
                })["catch"](function() {})
            }, [function() {
                if (e && o && d && t) return !0
            }], {
                timeout: 3e3,
                interval: 200
                    method: "GET",
                    url: "https://adobeioruntime.net/api/v1/web/14257_51772/abx-connector-0.0.1/sids.json?demandbase_sid=" + e + "&ecid=" + o + "&locationHint=" + d + "&countryCode=" + t
                }).then(function(a) {
                })["catch"](function() {})
            }, [function() {
                if (e && o && d && t) return !0
            }], {
                timeout: 3e3,
                interval: 200
            })
        })
    })
}();