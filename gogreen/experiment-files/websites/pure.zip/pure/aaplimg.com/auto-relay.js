"use strict";
! function() {
    var r;
    try {
        r = require("@marcom/data-relay")
    } catch (r) {}
    if (r) {
        if (t) try {
            e = JSON.parse(t.innerHTML)
        } catch (r) {}
        new r(e)
    }
}();