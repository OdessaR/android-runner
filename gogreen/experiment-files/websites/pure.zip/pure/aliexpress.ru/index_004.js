(function(p, u, a, e, r, h, t) {
    if (p.__sec_entry_loaded || u.__no_sec_entry) {
        return
    }
    var n = e.userAgent;
    var o = t("%58%75%65%58%69");
    var i = o.toLowerCase();
        return
    }
    var c = u.getElementsByTagName("head")[0];

    function g(a) {
        var e = u.createElement("script");
        e.src = a;
        return c.appendChild(e)
    }
    var l = "//g.alicdn.com";
    if (s && s.getCdnPath) {
        l = s.getCdnPath()
    }
    l += "/secdev/";
    var f = n.match(/Chrome\/(\d*)/);
    if (f) {
        f = +f[1]
    }
    if (!u._sufei_data2) {
        var d = "3.9.0";
        var v = g(l + "sufei_data/" + d + "/index.js");
        v.async = u.cookie.indexOf("isg=") < 0;
        v.id = "aplus-sufei"
    }
    var m = .001;
    if (a() < m) {
        g(l + "linkstat/index.js?v=1201")
    }
    var y = 0;
    var _ = ["taobao", "alibaba.com", "alipay.com", "tmall.com", "lazada", "aliexpress", "1688.com", "alimama.com", "tb.cn", "xiami.com", "amap.com", "cainiao.com", "aliyun.com", "etao.com", "fliggy.com", "liangxinyao.com", "damai.cn", "daraz", "tmall.hk", "jiyoujia.com", "taopiaopiao.com", "alitrip.com", "fliggy.hk", "alihealth.cn", "alitrip.hk", "ele.me", "gaode", "mp.dfkhgj.com", "mp.bcvbw.com", "m.dfkhgj.com", "pailitao.com", "youku.com", "jiaoyimao", "sm.cn", "dingtalk.com", "alibaba-inc", "guoguo-app", "kaola", "alicdn", "soku"];
    for (var x = 0; x < _.length; x++) {
        if (~r.host.indexOf(_[x])) {
            y = 1;
            break
        }
    }
    if (y) {
        var b = ["1.0.78", "e", 88];
        var j = ["1.0.79", "e", 89];
        var k = 0;
        var C = b;
        if (r.href == "https://search.1688.com/company/wap/company_search.html") {
            k = 1e4
        }
        if ((a() * 1e4 | 0) < k) {
            C = j
        }
        if (!C) {
            return
        }
        var M = l;
        var E = true;
        if (r.hostname.indexOf("buyertrade.taobao.com") > -1 || /refund2\.taobao\.com$|refund2\.tmall\.com$/.test(r.hostname) && r.pathname === "/dispute/apply.htm") {
            if (!E) {
                M = M.replace("/secdev/", "??xlly/spl/index.js,secdev/")
            } else {
                M = M.replace("/secdev/", "??xlly/spl/index.js,xlly/spl/rp.js,secdev/")
            }
        } else if (E) {
            M = M.replace("/secdev/", "??xlly/spl/rp.js,secdev/")
        }
        var S = M + "nsv/" + C[0] + "/";
        var w = S + "ns_" + C[1] + "_" + C[2] + "_3_f.js";
        var I = S + "ns_" + C[1] + "_" + C[2] + "_3_n.js";

        function L() {
            var a = "function%20javaEnabled%28%29%20%7B%20%5Bnative%20code%5D%20%7D";
            if ("WebkitAppearance" in u.documentElement.style) {
                if (escape(e.javaEnabled.toString()) === a) {
                    return true
                }
            }
            return false
        }
        var O = n.match(/Edge\/([\d]*)/);
        var A = n.match(/Safari\/([\d]*)/);
        var D = n.match(/Firefox\/([\d]*)/);
        var T = n.match(/MSIE|Trident/);
        if (O) {
            g(w)
        } else if (f) {
            g(w)
        } else if (A || D || T) {
            g(I)
        } else {
            if (L()) {
                g(w)
            } else {
                g(I)
            }
        }
    } else {
        g(l.replace("/secdev/", "/xlly/spl/rp.js"))
    }

    function W() {
        var a = p.atob;
        if (!a) {
            return
        }

        function r(a, e) {
            var r = [];
            for (var t in a) {
                r.push(t + "=" + h(a[t]))
        }
        var e = 0;
        var t = "";

        function n() {
            if (++e == 3) {
                clearInterval(f)
            }
            c()
        }
        var o;
        var i = Math.random() * 1e8 | 0;

        function c() {
            var a = o.getUA({
                MaxMTLog: 500,
                MTInterval: 7
            });
            a = i + "|" + a;
            var e = {
                token: a,
                cna: t,
                ext: 7
            };
            r(e, "https://fourier.taobao.com/ts?")
        }
        if (!l && /xlly=1/.test(u.cookie)) {
            l = +new Date;
        }
        if (l) {
            var s = new Date - l;
            if (s > 1e3 * 3600 * 24) {
                s = 0;
            }
            if (s < 1e3 * 60 * 20) {
                var f = setInterval(n, 1e3 * 60);
                if (p.addEventListener) {
                    p.addEventListener("unload", c)
                }
                var d = u.cookie.match(/cna=([^;]+)/);
                if (d) {
                    t = d[1]
                }
                var v = g(a("aHR0cHM6Ly9nLmFsaWNkbi5jb20vQVdTQy9BV1NDL2F3c2MuanM="));
                var m = unescape("%75%61%62");
                v.onload = function() {
                        if (a === "loaded") {
                            o = e
                        }
                    })
                }
            }
        }
    }
    try {
        W()
    } catch (a) {}
    try {
        var B = 0;
        for (var x = 0; x < _.length; x++) {
            if (r.host && ~r.host.indexOf(_[x])) {
                B = 1;
                break
            }
        }
        if (B) {
            var F = "1.61.1";
            var N = "1.62.1";
            var R = 1;
            var U = F;
            if (Math.random() < R) {
                U = N
            }
            if (!U) {
                return
            }
            var z = "//g.alicdn.com/AWSC/et/" + U + "/";
            var H = z + "et_f.js";
            var P = z + "et_n.js";
                g(H)
            } else if (f) {
                g(H)
                g(P)
            } else {
                if (L()) {
                    g(H)
                } else {
                    g(P)
                }
            }
        }
    } catch (a) {}
})(window, document, Math.random, navigator, location, encodeURIComponent, decodeURIComponent);