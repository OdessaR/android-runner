/*! DSPCounter - v0.7.1 - 2019-07-11 */ ! function(a, b, c) {
    function d(a) {
        return (/^\/\//.test(a) ? "https:" : "") + a
    }

    function e() {
        return Math.round(1e6 * Math.random())
    }

    function f(a) {
        try {
            var c = b.getElementsByTagName("head")[0],
                d = b.createElement("script");
            d.setAttribute("type", "text/javascript"), d.setAttribute("charset", "windows-1251"), d.setAttribute("src", a.split("![rnd]").join(e())), d.onreadystatechange = function() {
            }, d.onload = function() {
                c.removeChild(d)
            }, c.insertBefore(d, c.firstChild)
    }

    function g(a, b, c) {
        var d = [];
        for (var e in a) a.hasOwnProperty(e) && d.push(e + c + escape(a[e]));
        return d.join(b)
    }

    function h(a, b, c) {
        for (var d, e = [], f = 0, g = a.length; g > f; f++) d = a[f], e.push(d[0] + c + escape(d[1]));
        return e.join(b)
    }

    function i(a) {
    }

    function j(a) {
        var b = [];
        for (var c in a) a.hasOwnProperty(c) && b.push(c);
        return b
    }

    function k(a, b) {
        function c() {
            var b = {};
            for (var c in a)
                if (a.hasOwnProperty(c)) {
                    var d = c.length;
                    b[d] = b[d] || [], b[d].push(c)
                } return b
        }

        function d(a, b) {
            return b > a ? 1 : a > b ? -1 : 0
        }
        var e = a[b];
        delete a[b];
        for (var f = c(), g = j(f).sort(d), h = [], i = 0, k = g.length; k > i; i++)
            for (var l = f[g[i]], m = l.sort(), n = 0, o = m.length; o > n; n++) {
                var p = m[n];
                h.push([p, a[p]])
            }
        return h.push([b, e]), h
    }

    function l(a) {
        for (var b, c, d, e = ["sid", "bt", "ad", "pid", "bid", "bn", "pz", "sz", "custom", "ph", "rnd", "tail256", "pass"], f = {}, h = 0, i = e.length; i > h; h++) c = e[h], d = a[c], "undefined" != typeof d && (f[c] = d, delete a[c]);
        return b = m({}, f, a), g(b)
    }

    function m() {
        for (var a, b, c = arguments[0], d = 1, e = arguments.length; e > d; d++) {
            a = arguments[d];
            for (b in a) a.hasOwnProperty(b) && (a[b] instanceof Function ? c[b] = a[b] : a[b] instanceof Object ? c[b] ? m(c[b], a[b]) : c[b] = m(a[b] instanceof Array ? [] : {}, a[b]) : c[b] = a[b])
        }
        return c
    }

    function n(a) {
        for (var b in a)
            if (a.hasOwnProperty(b)) return !1;
        return !0
    }

    function o(a) {
        function b(b, c) {
            "undefined" != typeof a[b] && ("" !== a[b] && (d[c] = a[b]), delete a[b])
        }
        var c, d = {};
    }

    function p(a) {
    }

    function q() {
        for (var b, d = a[c], e = d.q ? d.q.length : 0, f = 0; e > f; f++) b = d.q[f], r(b[0], b[1])
    }

    function r(a, b) {
        else switch (a) {
            case "send":
            case "firstSend":
            default:
        }
    }
    var s = "206";
        bt: 62,
        tail256: b.referrer || "unknown",
        custom: {}
}(window, document, "DSPCounter");