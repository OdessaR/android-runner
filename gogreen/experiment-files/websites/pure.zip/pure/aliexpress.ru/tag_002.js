(function() {
    function x(b) {
        return !!b && "[object Array]" === Object.prototype.toString.call(b)
    }

    function g(b, d, c) {
        "undefined" !== typeof d && c.push(b + "=" + encodeURIComponent(d))
    }

    function y(b) {
        var d = 0,
            c = b.length;
            var a = [],
                e = b[d],
                u = m.tag,
                h;
            for (h in e)
                if (e.hasOwnProperty(h)) {
                    if ("event" == h && ("gtm.js" == e[h] || "gtm.dom" == e[h] || "gtm.load" == e[h])) continue a;
                    if ("__location" !== h && "__referrer" !== h && "__title" !== h && "__keywords" !== h && "_usertz" !== h) {
                        var n = h,
                            f = e[h],
                            l = a;
                        if (x(f))
                            for (var p = 0, v = f.length; p < v; p++) {
                                var w =
                                    f[p],
                                    r;
                                for (r in w) w.hasOwnProperty(r) && g(n + "__" + r, w[r], l)
                            } else g(n, f, l)
                    }
                } if (0 < a.length) {
                !1 === k.rtgCheck ? g("check", !1, a) : g("check", !0, a);
                !0 === k.rtgSyncFrame && (g("response", "syncframe", a), u = m.iframe);
                k.rtgSyncWith && g("syncwith", k.rtgSyncWith, a);
                g("__r", n, a);
                (!0 === k.rtgNoSync || t.isTimingRnd(n) && u === m.tag) && g("nosync", !0, a);
                g("__keywords", e, a);
                g("_usertz", -(new Date).getTimezoneOffset(), a);
                e = 8E3 - (q + a.join("&")).length;
                if (0 > e)
                            break
                        } z(a, u, n)
            }
        }
    }

    function z(b, d, c) {
            var a = q + b.join("&");
        } else setTimeout(function() {
                z(b)
            },
            100)
    }

    function A(b, d, c) {
        a.width = 1;
        a.height = 1;
        a.style.display = "none";
        a.src = d;
        c && t.isTimingRnd(c) && (a.onload = function() {
            D(c, b)
        });
        b === m.tag && (a.alt = "");
        return a
    }

    function D(b, d) {
                return a.name.includes(q) && a.name.includes("__r=" + b)
            });
            if (c && c.domainLookupStart) {
                var a = d === m.tag ? B.tag : B.iframe,
                    c = encodeURIComponent(["d_" + (c.domainLookupEnd - c.domainLookupStart),
                        "c_" + (c.connectEnd - c.connectStart), "s_" + (c.secureConnectionStart && c.connectEnd - c.secureConnectionStart || 0), "r_" + (c.responseEnd - c.requestStart), "t_" + (c.responseStart - c.requestStart)
                    ].join()),
                    a = q + "event=addToSegment&name=" + a + "&value=" + c + "&nosync=true&__r=" + t.getRandomId(),
                    a = A(m.tag, a);
            }
        }
    }

    function E() {
        else
            for (var b = 0; b < C.length; b++) {
                var d = C[b];
            }
    }
    var q = "",
        k = {},
        C = ["rtgNoSync", "rtgCheck", "rtgSyncFrame",
            "rtgCounter", "rtgSyncWith"
        ],
        m = {
            tag: "img",
            iframe: "iframe"
        },
        B = {
            tag: "_calltime_tag",
            iframe: "_calltime_syncframe"
        },
        t = {
            getRandomId: function() {
                return Math.floor(1E20 * Math.random())
            },
            isTimingRnd: function(b) {
                return b < .002 * 1E20
            }
        };
    (function() {
        E();
        q = !0 === k.rtgCounter ? "https://counter.sberbank.ru/t?" : "https://tag.rutarget.ru/tag?";
        x(b) && y(b);
        var b = [],
            d = b.push;
        b.push = function(c) {
            d.apply(b, arguments);
            y(b)
        };
    })()
})();