function WaitListCollection() {

}

function WaitListCollection(store_id) {

}

WaitListCollection.prototype = {

    collection: null,

    getAll: function(callback) {

            .done(function(data) {

                that.setCollections(data.lists);
                callback(that.collection, that.item_types);
            }).fail(function() {
            })
            .always(function() {
            });;
    },

    getAllContactsView: function(callback) {

            .done(function(data) {

                that.setCollections(data.lists);
                callback(that.collection);
            }).fail(function() {
            })
            .always(function() {
            });;
    },

    setCollections: function(lists) {

        that.collection = [];
        that.item_types = [{
            id: 0,
            name: "All Types"
        }];

        if (lists.pslr_lists !== undefined) {

            that.setCollection(that, lists.pslr_lists);
            that.item_types.push({
                id: 1,
                name: "Product"
            });
        }

        if (lists.event_lists !== undefined) {

            that.setCollection(that, lists.event_lists);
            that.item_types.push({
                id: 1,
                name: "Class"
            });
        }

        if (lists.contacts !== undefined) {

            that.setContactsViewCollection(that, lists.contacts);
        }
    },

    setCollection: function(that, lists) {

        for (var i = 0; i < lists.length; i++) {
            var row = lists[i];
            for (var j = 0; j < wait_list.contacts.length; j++) {

                var contact = wait_list.contacts[j];
                wait_list.contacts[j] = wait_list_contact;
            }
            that.collection.push(wait_list);
        }
    },

    setContactsViewCollection: function(that, lists) {

        for (var i = 0; i < lists.length; i++) {
            var row = lists[i];
            for (var j = 0; j < contact.waitlists.length; j++) {

                var wailist = contact.waitlists[j];
                contact.waitlists[j] = wait_list;
            }
            that.collection.push(contact);
        }
    },

    getExistingContactInfoByEmail: function(item_id, email, callback) {

            .done(function(data) {

                callback(data.contact_data);
            }).fail(function() {})
            .always(function() {});
    }
}

function WaitList() {

    that.wait_list_id = null;
    that.store_id = null;
    that.store_location_id = null;
    that.item_id = null;
    that.status_id = null;
    that.item_type_id = null;
    that.item_type = null;
    that.title = null;
    that.contacts = [];
}

WaitList.prototype = {

    wait_list_id: null,
    store_id: null,
    store_location_id: null,
    item_id: null,
    status_id: null,
    item_type_id: null,
    item_type: null,
    title: null,
    contacts: [],

    save: function(callback) {


            callback(response);
        });
    },

    getNumberOfContacts: function() {

    },

    getQuantity: function() {

        var qty = 0;


            }
        }
        return qty;
    }
};

function WaitListContact() {

}

WaitListContact.prototype = {

    wait_list_contact_rel_id: null,
    wait_list_id: null,
    store_id: null,
    store_location_id: null,
    pos_customer_id: null,
    first_name: null,
    last_name: null,
    phone: null,
    email: null,
    quantity: null,
    wait_list_status_id: null,
    waitlists: [],

    getFullName: function() {

    },

    getWaitlistsQuantity: function() {

        var qty = 0;


            }
        }
        return qty;
    },

    delete: function(callback) {


            callback();
        });
    },

    deleteByCustomerIdAndWaitListId: function(waitlist_id, callback) {


            callback();
        });
    }
};