! function(e, n) {
}(window, function(e) {
    var n = {};

    function t(r) {
        if (n[r]) return n[r].exports;
        var i = n[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return e[r].call(i.exports, i, i.exports, t), i.l = !0, i.exports
    }
            enumerable: !0,
            get: r
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
        if (4 & n && "object" == typeof e && e && e.__esModule) return e;
        var r = Object.create(null);
                enumerable: !0,
                value: e
            }), 2 & n && "string" != typeof e)
                return e[n]
            }.bind(null, i));
        return r
        var n = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return Object.prototype.hasOwnProperty.call(e, n)
}({
    0: function(e, n, t) {
    },
    UabE: function(e, n) {
            prebidTimeout: 1e3,
            bidderSettings: {
                smartadserver: {
                    bidCpmAdjustment: function(e) {
                        return 1 * e * 4.3
                    }
                },
                appnexus: {
                    bidCpmAdjustment: function(e) {
                        return 1 * e * 3.82
                    }
                }
            },
            prebidConfig: {
                userSync: {
                    filterSettings: {
                        image: {
                            bidders: "*",
                            filter: "include"
                        }
                    }
                },
                bidderSequence: "random",
                bidderTimeout: 1e3,
                timeoutBuffer: 400,
                enableSendAllBids: !1,
                priceGranularity: {
                    buckets: [{
                        precision: 2,
                        min: 0,
                        max: 15.01,
                        increment: .01
                    }, {
                        precision: 2,
                        max: 30.04,
                        increment: .02
                    }, {
                        precision: 2,
                        max: 52.5,
                        increment: .05
                    }, {
                        precision: 2,
                        max: 165,
                        increment: 1
                    }, {
                        precision: 0,
                        max: 300,
                        increment: 10
                    }]
                }
            }
        }
    }
}));
//# sourceMappingURL=bidder-settings_d9c969ff.js.map