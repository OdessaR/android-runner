(function() {
            kampyleInit: function() {
                t.type = 'text/javascript';
                t.async = true;
                t.charset = 'UTF-8';
            },
            kampyleLoadLogger: function() {},
            kampyleEventHandler: function(elem, eventType, handler) {
                if (elem.addEventListener) {
                    elem.addEventListener(eventType, handler, false);
                } else if (elem.attachEvent) {
                    elem.attachEvent('on' + eventType, handler);
                }
            },
            isSupported: function() {
                var result = {
                    isIE: false,
                    trueVersion: 0,
                    actingVersion: 0,
                    compatibilityMode: false
                };
                if (trident) {
                    result.isIE = true;
                    result.trueVersion = parseInt(trident[1], 10) + 4;
                }
                if (msie) {
                    result.isIE = true;
                    result.actingVersion = parseInt(msie[1]);
                } else {
                    result.actingVersion = result.trueVersion;
                }
                if (result.isIE && result.trueVersion > 0 && result.actingVersion > 0) {
                    result.compatibilityMode = result.trueVersion != result.actingVersion;
                }
                return !result.isIE || result.trueVersion > 9 || (result.actingVersion >= 9 && result.compatibilityMode);
            },
            getUserAgent: function() {
            },
            getGenericLocation: function() {
                return genericLocation;
            },
        };
            } else {
            }
        }
    }
})();