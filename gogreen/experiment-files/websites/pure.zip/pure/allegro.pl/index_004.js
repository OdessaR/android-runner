((e, t) => {
})(window, (e => {
    var t = {};

    function r(i) {
        if (t[i]) return t[i].exports;
        var s = t[i] = {
            i,
            l: !1,
            exports: {}
        };
        return e[i].call(s.exports, s, s.exports, r), s.l = !0, s.exports
    }
            enumerable: !0,
            get: i
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var i = Object.create(null);
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
        return i
        var t = e && e.__esModule ? () => e.default : () => e;
})({
    0(e, t, r) {
    },
    O14P(e, t, r) {
        r.r(t);
        var i = r("kiQV");

        function s(e, t, r) {
            return t in e ? Object.defineProperty(e, t, {
                value: r,
                enumerable: !0,
                configurable: !0,
                writable: !0
        }

        function a(e, t) {
            return e.reduce((e, r) => Object.assign({}, e, {
                [r.getAttribute(t)]: r
            }), {})
        }

        function o(e) {
        }
            prototypeName: "allegro.navigation.layers",
            clientImplementationVersion: i.a
        }, class {
            }) {
                s(this, "moveIndicator", e => {
                    if (!this.registryKeys.length) return;
                    const t = e.getBoundingClientRect().top,
                        r = this.registry[this.registryKeys[0]].trigger.getBoundingClientRect().top;
                }), s(this, "showIndicator", () => {
                    this.indicator.classList.remove(this.hiddenClassName)
                }), s(this, "hideIndicator", () => {
                    this.indicator.classList.add(this.hiddenClassName)
                }), s(this, "showLayer", e => {
                    this.registry[e] && (this.hideAllLayers(), this.showIndicator(), this.registry[e].trigger.classList.add(this.activeTriggerClassName), this.moveIndicator(this.registry[e].trigger), o(this.registry[e].layer))
                }), s(this, "hideLayer", e => {
                    this.registry[e] && (this.registry[e].trigger.classList.remove(this.activeTriggerClassName), o(this.registry[e].layer))
                }), s(this, "hideAllLayers", () => {
                    this.hideIndicator(), this.registryKeys.forEach(this.hideLayer)
                }), s(this, "handleBaseNodeMouseenter", () => {
                    clearTimeout(this.deactiveAllGroupsTimeout)
                }), s(this, "handleBaseNodeMouseleave", () => {
                        this.hideAllLayers()
                    }, this.delay)
                }), s(this, "handleLinkMouseenter", e => {
                        this.showLayer(e.target.getAttribute("data-group-id"))
                    }, this.delay)
                }), s(this, "handleLinkMouseleave", () => {
                    clearTimeout(this.showLayerTimeout)
                }) => {
                    const s = a(e, r),
                        o = a(t, i),
                        n = {};
                    return Object.keys(s).forEach(e => {
                        n[e] = {
                            trigger: s[e],
                            layer: o[e]
                        }
                    }), n
                })({
                    layersTriggers: Array.from(e.querySelectorAll(`[${this.dataTriggerAttr}]`)),
                    layers: Array.from(e.querySelectorAll(`[${this.dataLayerAttr}]`)),
                    triggersId: this.dataTriggerAttr,
                    layersId: this.dataLayerAttr
            }
                }))
            }
                }))
            }
        })
    },
    kiQV(e) {
    }
}));
//# sourceMappingURL=index.es6_fd432c82.js.map