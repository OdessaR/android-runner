((e, t) => {
})(window, (e => {
    var t = {};

    function i(s) {
        if (t[s]) return t[s].exports;
        var o = t[s] = {
            i: s,
            l: !1,
            exports: {}
        };
        return e[s].call(o.exports, o, o.exports, i), o.l = !0, o.exports
    }
            enumerable: !0,
            get: s
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var s = Object.create(null);
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
        return s
        var t = e && e.__esModule ? () => e.default : () => e;
})({
    "+GN7"(e, t) {
    },
    0(e, t, i) {
    },
    O14P(e, t, i) {
        i.r(t);
        var s = i("+GN7"),
            o = i.n(s);

        function a(e, t, i) {
            return t in e ? Object.defineProperty(e, t, {
                value: i,
                enumerable: !0,
                configurable: !0,
                writable: !0
        }
        const h = () => {};
            prototypeName: "allegro.modal",
            clientImplementationVersion: o.a
        }, class {
            }) {
                a(this, "showModalByAPI", (e = h) => {
                        contextNode: this.modalNode,
                        label: "modalAPI",
                        value: "open"
                    }))
                }), a(this, "hideModalByAPI", () => {
                    this.visible && (this.hideModal(), this.window.opbox.analytics.sendBoxInteractionEvent({
                        contextNode: this.modalNode,
                        label: "modalAPI",
                        value: "close"
                    }))
                }), a(this, "handleHashChange", () => {
                    if (this.visible && !this.doesHashMatch(this.triggerHash)) return this.hideModal(), void this.handleHashChangeAnalytics(this.actionTypeValue.close);
                    !this.visible && this.doesHashMatch(this.triggerHash) && (this.showModal(), this.handleHashChangeAnalytics(this.actionTypeValue.open))
                }), a(this, "onKeyDown", e => {
                    27 === e.keyCode && this.visible && (e.preventDefault(), this.window.opbox.analytics.sendBoxInteractionEvent({
                        contextNode: this.baseNode,
                        label: "modalClose_escKey"
                    }), this.delegateHideModal())
                }), a(this, "delegateHideModal", () => {
                    this.doesHashMatch(this.triggerHash) ? this.simulateModalAsPage ? this.pushBrowserHistory() : this.replaceBrowserHistory() : this.hideModal()
                }), a(this, "toggleVisibility", e => {
                    e.target === this.overlayNode && this.window.opbox.analytics.sendBoxInteractionEvent({
                        contextNode: this.overlayNode,
                        label: "modalClose_overlay"
                    }), this.visible ? this.delegateHideModal() : this.showModal()
                    open: "open",
                    close: "close"
            }
            }
                const {
                return e instanceof Object && e.previousHash || ""
            }
                    case "startsWith":
                    case "exact":
                    default:
                }
            }
                    const {
                }
            }
            }
            }
                    value: "hashChange"
                })
            }
                const {
            }
                const {
                    previousHash: i
            }
            }
            }
            }
                        const e = (() => {
                            const e = new Date;
                            return `${e.getDate()}${e.getMonth()}${e.getYear()}`
                        })();
                    }
                }
            }
            }
            }
        })
    }
}));
//# sourceMappingURL=index.es6-pl-PL_100105e1.js.map