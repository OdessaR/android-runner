(window.webpackJsonp_fee54 = window.webpackJsonp_fee54 || []).push([
    [3], {
        K8jm: function(e, t, r) {
            "use strict";
            r.d(t, "a", (function() {
                return n
            })), r.d(t, "b", (function() {
                return i
            })), r.d(t, "c", (function() {
                return o
            }));
            var n = "mq1m_0 mj7u_0 mnjl_0 mjb5_zr _fee54_3omDk",
                i = "mpof_5r",
                o = "m9vn_gl"
        },
        SnEL: function(e, t, r) {
            "use strict";
            r.r(t), r.d(t, "default", (function() {
                return h
            }));
            var n = r("1OyB"),
                i = r("vuIU"),
                o = r("rePB"),
                s = r("U8x5"),
                a = r("K8jm"),
                c = function(e, t) {
                    return e.split(" ").forEach((function(e) {
                        return t(e)
                    }))
                },
                u = function(e, t) {
                    e && c(t, e.classList.add.bind(e.classList))
                },
                d = function(e, t) {
                    e && c(t, e.classList.remove.bind(e.classList))
                },
                h = function() {
                    function e(t) {
                        Object(n.a)(this, e), Object(o.a)(this, "setSticky", (function() {
                            r.baseNode.style.height = "".concat(r.baseNode.offsetHeight, "px"), u(r.headerWrapper, a.a), u(r.primaryBar, "_fee54_3qUGn"), u(r.secondaryBar, a.b)
                        })), Object(o.a)(this, "removeSticky", (function() {
                            r.baseNode.style.height = "", d(r.headerWrapper, a.a), d(r.primaryBar, "_fee54_3qUGn"), d(r.secondaryBar, a.b)
                        })), Object(o.a)(this, "positionObserver", (function(e) {
                            e.forEach((function(e) {
                                var t = e.isIntersecting,
                                    n = e.boundingClientRect.top;
                                r.targetWindow.requestAnimationFrame(!t && n < 0 ? r.setSticky : r.removeSticky)
                            }))
                    }
                    return Object(i.a)(e, [{
                        key: "initialize",
                        value: function() {
                            (function() {
                                return "IntersectionObserver" in e && "IntersectionObserverEntry" in e && "intersectionRatio" in e.IntersectionObserverEntry.prototype
                        }
                    }]), e
                }()
        }
    }
]);
//# sourceMappingURL=sticky-pl-PL_9a6ba169.js.map