! function(e, n) {
}(window, function(e) {
    var n = {};

    function r(t) {
        if (n[t]) return n[t].exports;
        var i = n[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(i.exports, i, i.exports, r), i.l = !0, i.exports
    }
            enumerable: !0,
            get: t
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
        if (4 & n && "object" == typeof e && e && e.__esModule) return e;
        var t = Object.create(null);
                enumerable: !0,
                value: e
            }), 2 & n && "string" != typeof e)
                return e[n]
            }.bind(null, i));
        return t
        var n = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return {}.hasOwnProperty.call(e, n)
}({
    0(e, n, r) {
    },
    UabE(e, n) {
            prebidTimeout: 1e3,
            bidderSettings: {
                smartadserver: {
                    bidCpmAdjustment: e => 1 * e * 4.3
                },
                appnexus: {
                    bidCpmAdjustment: e => 1 * e * 3.82
                }
            },
            prebidConfig: {
                userSync: {
                    filterSettings: {
                        image: {
                            bidders: "*",
                            filter: "include"
                        }
                    }
                },
                bidderSequence: "random",
                bidderTimeout: 1e3,
                timeoutBuffer: 400,
                enableSendAllBids: !1,
                priceGranularity: {
                    buckets: [{
                        precision: 2,
                        min: 0,
                        max: 15.01,
                        increment: .01
                    }, {
                        precision: 2,
                        max: 30.04,
                        increment: .02
                    }, {
                        precision: 2,
                        max: 52.5,
                        increment: .05
                    }, {
                        precision: 2,
                        max: 165,
                        increment: 1
                    }, {
                        precision: 0,
                        max: 300,
                        increment: 10
                    }]
                }
            }
        }
    }
}));
//# sourceMappingURL=bidder-settings.es6_bc368117.js.map