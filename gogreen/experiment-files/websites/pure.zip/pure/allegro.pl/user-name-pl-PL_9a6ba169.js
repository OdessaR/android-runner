(window.webpackJsonp_fee54 = window.webpackJsonp_fee54 || []).push([
    [5], {
        "Wq/3": function(e, t, n) {
            "use strict";
            n.r(t), n.d(t, "default", (function() {
                return c
            }));
            var i = n("1OyB"),
                o = n("vuIU"),
                r = n("U8x5"),
                u = {
                    withCredentials: !0,
                    headers: {
                        Accept: "application/vnd.allegro.internal.v1+json"
                    }
                },
                a = function(e) {
                    return function(t) {
                        return t.name === e
                    }
                },
                s = function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        t = e.userAttributesGroups,
                        n = void 0 === t ? [] : t,
                        i = n.find(a("user")) || {},
                        o = i.attributes,
                        r = void 0 === o ? [] : o,
                        u = r.find(a("firstName")) || {},
                        s = r.find(a("login")) || {},
                        c = r.find(a("type")) || {},
                        d = "Company" === c.value,
                        f = d ? s.value : u.value || s.value;
                    return f || ""
                },
                c = function() {
                    function e(t) {
                            if (t) {
                                var n = t.split("; ").reduce((function(e, t) {
                                    var n = t.split("="),
                                        i = decodeURIComponent(n[0]),
                                        o = decodeURIComponent(n[1]);
                                }), {});
                                return n[e]
                            }
                        }("qeppo_login2")
                    }
                    return Object(o.a)(e, [{
                        key: "setAuthenticatedUser",
                        value: function(e) {
                            }))
                        }
                    }, {
                        key: "setFromOneCookie",
                        value: function() {
                                return e.data
                            })).then(s).then((function(t) {
                                e.setAuthenticatedUser(t)
                            }))
                        }
                    }]), e
                }()
        }
    }
]);
//# sourceMappingURL=user-name-pl-PL_9a6ba169.js.map