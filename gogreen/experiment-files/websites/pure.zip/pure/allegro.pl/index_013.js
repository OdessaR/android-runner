((t, e) => {
})(window, (t => {
    var e = {};

    function o(i) {
        if (e[i]) return e[i].exports;
        var n = e[i] = {
            i,
            l: !1,
            exports: {}
        };
        return t[i].call(n.exports, n, n.exports, o), n.l = !0, n.exports
    }
            enumerable: !0,
            get: i
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var i = Object.create(null);
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
        return i
        var e = t && t.__esModule ? () => t.default : () => t;
})({
    0(t, e, o) {
    },
    O14P(t, e, o) {
        o.r(e);
        const i = '[data-role="opbox-expander-expand-button"]';
            prototypeName: "allegro.expander"
        }, class {
            }) {
            }
                }, !1)
            }
            }
            }
            }
            }
            }
            }
        })
    }
}));
//# sourceMappingURL=index.es6_f4a60fd7.js.map