(function(f) {
    function p() {
            a._dom_loaded()
        }))
    }
    var w = [],
        D = Array.prototype,
        r = Object.prototype,
        E = D.slice,
        x = r.toString,
        y = r.hasOwnProperty,
        t = z.userAgent,
        F = "http:" == k.location.protocol ? "http://" : "https://",
        r = f && f.__SV || 0,
        C = !A && -1 == t.indexOf("MSIE") && -1 == t.indexOf("Mozilla"),
        b = {},
        H = {
            api_host: F + "api.cooladata.com",
            loaded: function() {},
            img: !1,
            http_post: !1,
            track_pageload: !1,
            cookie_expiration: 365,
            disable_cookie: !1,
            cookie_name: "cd_user_id"
        },
        B = !1;
    (function() {
        var a = D.forEach,
            g = Array.isArray,
            e = {},
            d = b.each = function(d, g, b) {
                if (null != d)
                    if (a && d.forEach === a) d.forEach(g, b);
                    else if (d.length === +d.length)
                    for (var c = 0, f = d.length; c < f && !(c in d && g.call(b, d[c], c, d) === e); c++);
                else
                    for (c in d)
                        if (y.call(d, c) && g.call(b, d[c], c, d) === e) break
            };
        b.extend = function(a) {
            d(E.call(arguments, 1), function(e) {
                for (var d in e) void 0 !== e[d] && (a[d] = e[d])
            });
            return a
        };
        b.isArray = g || function(a) {
            return "[object Array]" ===
                x.call(a)
        };
        b.isFunction = function(a) {
            try {
                return /^\s*\bfunction\b/.test(a)
            } catch (e) {
                return !1
            }
        };
        b.isArguments = function(a) {
            return !(!a || !y.call(a, "callee"))
        };
        b.toArray = function(a) {
            return a ? a.toArray ? a.toArray() : b.isArray(a) || b.isArguments(a) ? E.call(a) : b.values(a) : []
        };
        b.values = function(a) {
            var e = [];
            if (null == a) return e;
            d(a, function(a) {
                e[e.length] = a
            });
            return e
        }
    })();
    b.isObject = function(a) {
        return a === Object(a) && !b.isArray(a)
    };
    b.isUndefined = function(a) {
        return void 0 === a
    };
    b.isString = function(a) {
        return "[object String]" ==
            x.call(a)
    };
    b.JSONEncode = function() {
        return function(a) {
            var g = function(a) {
                    var e = /[\\\"\x00-\x1f\x7f-\x9f\u00ad\u0600-\u0604\u070f\u17b4\u17b5\u200c-\u200f\u2028-\u202f\u2060-\u206f\ufeff\ufff0-\uffff]/g,
                        g = {
                            "\b": "\\b",
                            "\t": "\\t",
                            "\n": "\\n",
                            "\f": "\\f",
                            "\r": "\\r",
                            '"': '\\"',
                            "\\": "\\\\"
                        };
                    e.lastIndex = 0;
                    return e.test(a) ? '"' + a.replace(e, function(a) {
                        var e = g[a];
                        return "string" === typeof e ? e : "\\u" + ("0000" + a.charCodeAt(0).toString(16)).slice(-4)
                    }) + '"' : '"' + a + '"'
                },
                e = function(a, b) {
                    var h = "",
                        c = 0,
                        s = c = "",
                        s = 0,
                        f = h,
                        n = [],
                        l =
                        b[a];
                    l && "object" === typeof l && "function" === typeof l.toJSON && (l = l.toJSON(a));
                    switch (typeof l) {
                        case "string":
                            return g(l);
                        case "number":
                            return isFinite(l) ? String(l) : "null";
                        case "boolean":
                        case "null":
                            return String(l);
                        case "object":
                            if (!l) return "null";
                            h += "    ";
                            n = [];
                            if ("[object Array]" === x.apply(l)) {
                                s = l.length;
                                for (c = 0; c < s; c += 1) n[c] = e(c, l) || "null";
                                return s = 0 === n.length ? "[]" : h ? "[\n" + h + n.join(",\n" + h) + "\n" + f + "]" : "[" + n.join(",") + "]"
                            }
                            for (c in l) y.call(l, c) && (s = e(c, l)) && n.push(g(c) + (h ? ": " : ":") + s);
                            return s = 0 ===
                                n.length ? "{}" : h ? "{" + n.join(",") + "" + f + "}" : "{" + n.join(",") + "}"
                    }
                };
            return e("", {
                "": a
            })
        }
    }();
    b.strip_empty_properties = function(a) {
        var g = {};
        b.each(a, function(a, d) {
            b.isString(a) && 0 < a.length && (g[d] = a)
        });
        return g
    };
    b.base64Encode = function(a) {
        var g = {
            _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/\x3d",
            encode: function(a) {
                var d = "",
                    b, h, c, f, k, n, l = 0;
                return d
            },
            _utf8_encode: function(a) {
                for (var d = "", g = 0; g < a.length; g++) {
                    var b = a.charCodeAt(g);
                    128 > b ? d += String.fromCharCode(b) : (127 < b && 2048 > b ? d += String.fromCharCode(b >> 6 | 192) : (d += String.fromCharCode(b >> 12 | 224), d += String.fromCharCode(b >> 6 & 63 | 128)), d += String.fromCharCode(b & 63 | 128))
                }
                return d
            }
        };
        return g.encode(a)
    };
    b.utf8Encode = function(a) {
            "\n");
        for (var b = "", e = 0; e < a.length; e++) {
            var d = a.charCodeAt(e);
            128 > d ? b += String.fromCharCode(d) : (127 < d && 2048 > d ? b += String.fromCharCode(d >> 6 | 192) : (b += String.fromCharCode(d >> 12 | 224), b += String.fromCharCode(d >> 6 & 63 | 128)), b += String.fromCharCode(d & 63 | 128))
        }
        return b
    };
    b.HTTPBuildQuery = function(a, g) {
        var e, d, c = [];
        b.each(a, function(a, b) {
            e = encodeURIComponent(a.toString());
            d = encodeURIComponent(b);
            c[c.length] = d + "\x3d" + e
        });
        return c.join(g)
    };
    b.UUID = function() {
        var a = function() {
                for (var a =
                        1 * new Date, b = 0; a == 1 * new Date;) b++;
                return a.toString(16) + b.toString(16)
            },
            b = function(a) {
                function b(a, e) {
                    var d, g = 0;
                    for (d = 0; d < e.length; d++) g |= c[d] << 8 * d;
                    return a ^ g
                }
                var g, c = [],
                    f = 0;
                for (a = 0; a < t.length; a++) g = t.charCodeAt(a), c.unshift(g & 255), 4 <= c.length && (f = b(f, c), c = []);
                0 < c.length && (f = b(f, c));
                return f.toString(16)
            };
        return function() {
            return a() + "-" + Math.random().toString(16).replace(".", "") + "-" + b() + "-" + e + "-" + a()
        }
    }();
    b.getQueryParam = function(a, b) {
        b = b.replace(/[\[]/,
            "\\[").replace(/[\]]/, "\\]");
        var e = (new RegExp("[\\?\x26]" + b + "\x3d([^\x26#]*)")).exec(a);
        return null === e || e && "string" !== typeof e[1] && e[1].length ? "" : decodeURIComponent(e[1]).replace(/\+/g, " ")
    };
    b.register_event = function() {
        function a(a, d, c) {
            return function(h) {
                    var f = !0,
                        k;
                    b.isFunction(c) && (k = c(h));
                    if (!1 === k || !1 === h) f = !1;
                    return f
                }
            }
        }

        function g(a) {
            return a
        }
        };
        };
        return function(b, d, g, c) {
        }
    }();
    b.info = {
        campaignParams: function() {
            var a = "",
                g = {};
            b.each(["utm_source", "utm_medium", "utm_campaign", "utm_content", "utm_term"], function(e) {
                a = b.getQueryParam(k.URL, e);
                a.length && (g[e] = a)
            });
            return g
        },
        referringDomain: function(a) {
            return 3 <= a.length ? a[2] : ""
        },
        properties: function() {
            return b.extend(b.strip_empty_properties({
                session_dua: z.userAgent,
                session_platform: z.platform,
                referring_url: k.referrer,
                referring_domain: b.info.referringDomain(k.referrer)
            }), {
                tracker_type: "javascript",
                tracker_version: "2.1.15"
            })
        },
        pageviewInfo: function(a) {
            return b.strip_empty_properties({
                event_timestamp_epoch: 1 * new Date,
                page_title: k.title
            })
        }
    };
    var I = {
            critical: function() {
                if (!b.isUndefined(m) && m) {
                    var a = ["Cooladata error:"].concat(b.toArray(arguments));
                    try {
                        m.error.apply(m, a)
                        b.each(a, function(a) {
                            m.error(a)
                        })
                    }
                }
            }
        },
        v = function(a, g, e) {
            var d, u = "cooladata" === e ? f : f[e];
            if (u && !b.isArray(u)) m.log("You have already initialized " + e);
            else return d = new c, d._init(a, g, e), b.isUndefined(u) || d._execute_array(u), d
        },
        c = function() {};
    c.prototype.init = function(a, b, e) {
        if ("undefined" === typeof e) m.log("You must name your new library: init(token, config, name)");
        else if ("cooladata" === e) m.log("You must initialize the main cooladata object right after you include the Cooladata js snippet");
    };
    c.prototype._init = function(a) {
            token: a.app_key,
            img: a.img_src_get_request,
            session_id: a.session_id,
            http_post: a.http_post,
            track_pageload: a.track_pageload,
            disable_cookie: a.disable_cookie
        }));
            api_host: F + a.api_host
        });
            cookie_expiration: a.cookie_expiration
        });
            user_id: a.user_id
        });
            user_id: b.UUID()
        });
        else {
                user_id: b.UUID()
                user_id: e
                user_id: e
            })
        }
    };
    c.prototype.getCookie = function(a) {
        for (var b = k.cookie.split(";"), e = 0; e < b.length; e++) {
            for (var d = b[e];
                " " == d.charAt(0);) d = d.substring(1);
            if (0 == d.indexOf(a)) return d.substring(a.length,
                d.length)
        }
        return ""
    };
    c.prototype.setCookie = function(a) {
            e = new Date;
        e.setTime(e.getTime() + 864E5 * g);
        var g = "; expires\x3d" + e.toGMTString(),
            e = "com org net int edu gov mil biz".split(" "),
            c = "";
        if ("www" == d[0] || 4 == d.length) d.shift(), c = d.join(".");
        else switch (d.length) {
            case 2:
                c = d.join(".");
                break;
            case 3:
                for (var h = e.length; h--;)
                    if (e[h] === d[2]) {
                        d.shift();
                        c = d.join(".");
                        break
                    }
                "" == c && (c = d.join("."))
        }
        k.cookie = a + "\x3d" + b.UUID() + g + ";domain\x3d." +
            c + ";path\x3d/"
    };
    c.prototype._loaded = function() {
    };
    c.prototype._dom_loaded = function() {
        }, this);
        }, this);
    };
    c.prototype._track_dom = function(a, b) {
            !1;
        var e = (new a).init(this);
        return e.track.apply(e, b)
    };
    c.prototype.trackEventLater = function(a, c) {
        if ("undefined" === typeof a) m.log("No event name provided to cooladata.trackEventLater");
        else {
            c = c || {};
            var e = new Date,
                e = b.extend({}, b.info.properties(), b.info.campaignParams(), {
                    event_name: a,
                    event_timestamp_epoch: e.getTime().toString(),
                    event_timezone_offset: -1 * (e.getTimezoneOffset() / 60),
                }),
                e = b.extend(e, c);
            w.push(e)
        }
    };
    c.prototype.flush = function() {
        var a = b.JSONEncode({
            events: w
        });
        w = []
    };
    c.prototype._onError = function(a, b) {};
    c.prototype._send_request = function(a, c) {
        else {
            var e = function() {
                    return -1 < a.indexOf("MSIE ") && 1 !== a.split("MSIE ")[1].charAt(0) ? !0 : !1
                },
                d = !1;
            1400 < a.length && (d = !0);
                var f =
                    null;
                if (A) {
                    e = null;
                        data: b.base64Encode(a)
                        "application/x-www-form-urlencoded")) : h.open("GET", f, !0);
                    h.withCredentials = !0;
                    h.onreadystatechange = function(a) {
                        4 === h.readyState && (200 === h.status ? c && c() : m.log("Bad HTTP status: " + h.status + " " + h.statusText))
                    };
                    h.send(e)
            else {
                f += "?data\x3d" +
                    a;
                d = k.createElement("img");
                d.onerror = function() {
                    p._onError(a, c)
                };
                d.width = 1;
                d.height = 1;
                d.src = f
            }
        }
    };
    c.prototype._execute_array = function(a) {
        var c, e = [],
            d = [],
            f = [];
        b.each(a, function(a) {
        }, this);
            b.each(a, function(a) {
            }, d)
        };
        a(e, this);
        a(d, this);
        a(f, this)
    };
    c.prototype.push = function(a) {
    };
    c.prototype.trackEvent = function(a, c, e) {
        if ("undefined" === typeof a) m.log("No event name provided to cooladata.trackEvent");
        else {
            c = c || {};
            var d = new Date;
                event_name: a,
                event_timestamp_epoch: d.getTime().toString(),
                event_timezone_offset: -1 * (d.getTimezoneOffset() / 60),
            });
                events: [a]
            };
            c = b.JSONEncode(a);
        }
    };
    c.prototype.track_pageload = function(a) {
        "undefined" ===
    };
    c.prototype.set_config = function(a) {
    };
    c.prototype.get_config = function(a) {
    };
    c.prototype.toString = function() {
        "cooladata" !== a && (a = "cooladata." + a);
        return a
    };
    b.toArray = b.toArray;
    b.isObject = b.isObject;
    b.JSONEncode = b.JSONEncode;
    b.info = b.info;
    c.prototype.init = c.prototype.init;
    c.prototype.track_event = c.prototype.trackEvent;
    c.prototype.track_event_later =
        c.prototype.trackEventLater;
    c.prototype.flush = c.prototype.flush;
    c.prototype.track_pageload = c.prototype.track_pageload;
    c.prototype.set_config = c.prototype.set_config;
    c.prototype.get_config = c.prototype.get_config;
    c.prototype.toString = c.prototype.toString;
    if (b.isUndefined(f)) I.critical("'cooladata' object not initialized. Ensure you are using the latest version of the Cooladata JS Library along with the snippet we provide.");
    else if (f.__loaded || f.config) m.log("Cooladata library has already been downloaded at least once.");
    else if (1.1 > r) m.critical("Version mismatch; please ensure you're using the latest version of the Cooladata code snippet.");
    else {
        var q = {};
        b.each(f._i, function(a) {
            var c;
        });
        var J = function() {
            b.each(q, function(a, b) {
            });
        };
        };
        f.init();
        b.each(q, function(a) {
            a._loaded()
        });
        if (k.addEventListener) "complete" == k.readyState ? p() : k.addEventListener("DOMContentLoaded", p, !1);
        else if (k.attachEvent) {
            k.attachEvent("onreadystatechange", p);
            r = !1;
            try {
            if (k.documentElement.doScroll && r) {
                var G = function() {
                    try {
                        k.documentElement.doScroll("left")
                        setTimeout(G, 1);
                        return
                    }
                    p()
                };
                G()
            }
        }
        b.register_event(window, "load", p, !0)
    }
})(window.cooladata);