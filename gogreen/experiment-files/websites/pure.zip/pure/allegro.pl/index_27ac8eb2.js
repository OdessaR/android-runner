! function(o, e) {
}(window, function(o) {
    var e = {};

    function t(n) {
        if (e[n]) return e[n].exports;
        var r = e[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return o[n].call(r.exports, r, r.exports, t), r.l = !0, r.exports
    }
            enumerable: !0,
            get: n
        })
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(o, "__esModule", {
            value: !0
        })
        if (4 & e && "object" == typeof o && o && o.__esModule) return o;
        var n = Object.create(null);
                enumerable: !0,
                value: o
            }), 2 & e && "string" != typeof o)
                return o[e]
            }.bind(null, r));
        return n
        var e = o && o.__esModule ? function() {
            return o.default
        } : function() {
            return o
        };
        return Object.prototype.hasOwnProperty.call(o, e)
}({
    0: function(o, e, t) {
    },
    O14P: function(o, e, t) {
        "use strict";
            prototypeName: "allegro.navigation.scrollTop"
        }, (function(o) {
            var e = o.domNodes,
                n = t.documentElement,
                r = t.body;
            e.forEach((function(o) {
                var e, t = o.querySelector("button"),
                    u = t.classList;

                function i(o) {
                    u.remove(o)
                }

                function c(o) {
                    u.add(o)
                }

                function l(o, e) {
                    var n = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : t;
                    n.addEventListener(o, e, !1)
                }

                function f(o) {
                    n.scrollTop = o, r.parentNode.scrollTop = o, r.scrollTop = o
                }

                function a() {
                }
                t && (l("click", (function() {
                    var o = n.scrollTop || r.parentNode.scrollTop || r.scrollTop;
                        duration: 1e3
                    })
                })), l("mouseover", (function() {
                    c("_34272_2QxBe")
                })), l("mouseout", (function() {
                    i("_34272_2QxBe")
                })), l("scroll", (function() {
                    clearTimeout(e), e = setTimeout(a, 100)
                }), window), a())
            }))
        }))
    }
}));
//# sourceMappingURL=index_27ac8eb2.js.map