if ("undefined" == typeof gemius_cmpclient && (gemius_cmpclient = {
        gemius_vendor_id: 328,
        cmp_frame: null,
        cmp_callbacks: {},
        add_event: function(e, n, i) {
            e.addEventListener ? e.addEventListener(n, i, !1) : e.attachEvent && e.attachEvent("on" + n, i)
        },
        find_cmp: function() {
                try {
                } catch (e) {}
                e = e.parent
            }
                try {
                    var n = "string" == typeof e.data ? JSON.parse(e.data) : e.data;
                    if (n.__cmpReturn) {
                        var i = n.__cmpReturn;
                    }
                } catch (e) {}
            })), !0)
        },
        get_consent: function(e, n) {
            var i = !1,
                c = function(c, t) {
                    if (!i) {
                        i = !0;
                        try {
                            for (var s = 0; s < n.length; s++)
                                if (!c.purposeConsents[n[s]]) return void e(!1)
                        } catch (n) {
                            return void e(!1)
                        }
                        e(!0)
                    }
                };
                    var t = Math.random() + "",
                        s = {
                            __cmpCall: {
                                command: "getVendorConsents",
                                callId: t
                            }
                        };
                } else e(!1);
        }
    }), "undefined" == typeof gemius_hcconn) {
    gemius_hcconn = {
        lsdata: "",
        fpdata: "",
        gdprdata: [],
        event_identifier: null,
        current_receiver: null,
        waiting_for_fpdata: 1,
        waiting_for_lsdata: 1,
        params_ready_called: 0,
        waiting_on_prerender: 1,
        waiting_for_consent: 1,
        has_consent: null,
        closing: 0,
        visapi_s: "",
        visapi_h: "",
        visapi_c: "",
        loadinit: 0,
        fto: null,
        addto: null,
        sto: null,
        cmpto: null,
        ltime: 0,
        lsgetframe: null,
        sonar_data: [],
        timerevents: [],
        requests: [],
        images: [],
        state: 0,
        flashv: "",
        ssl: document.location && document.location.protocol && "https:" == document.location.protocol ? 1 : 0,
        hc: "string" == typeof gemius_hitcollector ? gemius_hitcollector : "string" == typeof pp_gemius_hitcollector ? pp_gemius_hitcollector : "allegro.hit.gemius.pl",
        dnt: "undefined" != typeof gemius_dnt && gemius_dnt || "undefined" != typeof pp_gemius_dnt && pp_gemius_dnt ? 1 : 0,
        use_cmp: "undefined" != typeof gemius_use_cmp && gemius_use_cmp || "undefined" != typeof pp_gemius_use_cmp && pp_gemius_use_cmp ? 1 : 0,
        cmp_purposes: "undefined" != typeof gemius_cmp_purposes ? gemius_cmp_purposes : "undefined" != typeof pp_gemius_cmp_purposes ? pp_gemius_cmp_purposes : [1, 5],
        gdpr_applies: "undefined" != typeof gemius_gdpr_applies ? gemius_gdpr_applies : "undefined" != typeof pp_gemius_gdpr_applies ? pp_gemius_gdpr_applies : null,
        gdpr_consent: "undefined" != typeof gemius_gdpr_consent ? gemius_gdpr_consent : "undefined" != typeof pp_gemius_gdpr_consent ? pp_gemius_gdpr_consent : null,
        add_event: function(e, n, i) {
            e.addEventListener ? e.addEventListener(n, i, !1) : e.attachEvent && e.attachEvent("on" + n, i)
        },
        remove_script: function(e, n) {
            if (i) {
                if (n) try {
                } catch (e) {}
                try {
                    i.parentNode.removeChild(i)
                } catch (e) {}
            }
        },
        append_script: function(e, n, i) {
            var c = "gemius_hcconn_" + (new Date).getTime() + "_" + Math.floor(1e8 * Math.random());
            try {
                    t.readyState && "loaded" !== t.readyState && "complete" !== t.readyState || n()
            } catch (e) {}
        },
        xdot_loaded: function() {
        },
        sendhits: function(e) {
            var n;
                        t = (new Date).getTime(),
                        else {
                        }
                }
            }
        },
        latehits: function() {
                    }
        },
        lsaddto: function() {
        },
        paramsready: function() {
                var e = {
                };
                try {
                } catch (e) {}
            }
        },
        visibilitychanged: function() {
        },
        unloadhit: function(e, n) {
                c = (new Date).getTime(),
                else {
                }
        },
        unload: function(e) {
            try {
                }
                    for (var t = (new Date).getTime(); t + 200 > (new Date).getTime(););
            } catch (e) {}
        },
        getfpcookie: function() {
            try {
        },
        setfpcookie: function() {
            var e = (new Date).getTime() + 864e8;
            } catch (e) {}
        },
        fpdata_loaded: function() {
        },
        addframe: function(e, n, i, c) {
                var t = "http" + (e ? "s" : "") + "://ls.hit.gemius.pl/ls" + n + ".html" + i;
                var s = "gemius_hcconn_" + (new Date).getTime() + "_" + Math.floor(1e8 * Math.random()),
            } else setTimeout((function() {
            }), 100)
        },
        frameto: function() {
        },
        scriptto: function() {
        },
        last_datareceiver: function(e) {
        },
        second_datareceiver: function(e) {
        },
        first_datareceiver: function(e) {
            var n = e.match(/^([A-Z0-9a-z\.\_\/]*).*\|([0-9]+)$/),
                i = (new Date).getTime();
        },
        msgreceiver: function(e) {
                var n = e.data.substr(19);
            }
        },
        getflashv: function() {
            var e = "-";
            if ("undefined" != typeof Error) {
                var n;
                try {
                } catch (e) {}
                    try {
                        try {
                        } catch (n) {
                            "X" == e && (e = "WIN 6,0,20,0")
                        }
                        try {
                        } catch (e) {}
                    }
                    "-" != e && "X" != e || !n || (e = n.GetVariable("$version"))
                }
            }
            return e
        },
        gdpr_params: function(e) {
            var n = "";
        },
        parameters: function() {
                t = new String(i.location.href),
                s = 0;
            if (e = i.referrer ? new String(i.referrer) : "", "undefined" != typeof Error) try {
            } catch (e) {
                s = 3
            }
            try {
            } catch (e) {}
            var o = "&fr=" + s + "&tz=" + (new Date).getTimezoneOffset();
                a.width && (a.deviceXDPI && a.deviceYDPI ? o += "&screen=" + Math.floor(a.width * a.deviceXDPI / 96) + "x" + Math.floor(a.height * a.deviceYDPI / 96) : o += "&screen=" + a.width + "x" + a.height), c.devicePixelRatio && (o += "r" + Math.round(1e3 * c.devicePixelRatio)), a.colorDepth && (o += "&col=" + a.colorDepth)
            }
            return "number" == typeof c.innerWidth ? o += "&window=" + c.innerWidth + "x" + c.innerHeight : ((n = i.documentElement) && (n.clientWidth || n.clientHeight) || (n = i.body) && (n.clientWidth || n.clientHeight)) && (o += "&window=" + n.clientWidth + "x" + n.clientHeight), o
        },
        array_to_string: function(e, n) {
            var i, c;
            if ("string" == typeof e) return e;
            if (c = "", void 0 !== e.length)
                for (i = n; i < e.length; i++) i > n && (c += "|"), c += new String(e[i]).replace(/\|/g, "_");
            return c
        },
        internal_hit: function(e, n, i, c, t, s, o, a) {
            var _ = "";
                if (u[0] >= 1)
            }
                req: _,
                allowaddscript: e,
                vers: n
        },
        timer: function() {
            var e;
        },
        gtimer_add: function(e) {
        },
        sonar_update: function() {
            var e;
                    i = (new Date).getTime() - n.lvchange;
            }
        },
        sonar_add: function(e, n, i, c) {
            var t, s = {};
                });
                s.to = setInterval(o, 1e3)
            }
        },
        sonar: function(e) {
            var n, i;
        },
        sonar_save: function() {
                    try {
                    } catch (e) {}
                }
            }
        },
        sonar_load: function(e, n) {
            try {
                    var t = i[c].split("=");
                    if (t[0].replace(/^\s+|\s+$/g, "") == "__gfp_" + e) {
                        var s = t[1].replace(/^\s+|\s+$/g, "").split("|", 6);
                        if (6 == s.length) {
                            if (n) try {
                            } catch (e) {}
                            return [parseInt(s[0]), parseInt(s[1]), parseInt(s[2]), parseInt(s[3]), parseInt(s[4])]
                        }
                    }
                }
            } catch (e) {}
            return [0, 0, 0, 0, 0]
        },
        gdprdata_loaded: function() {
            try {
            }
        },
        consent_loaded: function(e) {
        },
        consentto: function() {
        },
        ghit: function(e, n, i, c, t, s) {
        },
        gevent: function(e, n, i, c, t, s) {
            var o = 0,
                a = "view";
            if (i.length > 1) {
                var _ = new String(i[0]).match("^_([a-zA-Z0-9]+)_$");
                _ && (a = _[1], o = 1)
            }
        },
        addscripthit: function() {
        },
        plainhit: function() {
        },
        addscriptevent: function() {
        },
        plainevent: function() {
        },
        pendingdata: function(e, n) {
            var i;
            }
        },
        sendpendingdata: function() {
        },
        findvisapi: function() {
            var e, n = ["moz", "webkit", "ms", "o"];
            else
        },
        load_fpdata: function() {
                else {
                }
            }
        },
        load_lsdata: function() {
        },
        getchromever: function() {
                return null == e ? -1 : parseInt(e[3])
            }
            return -1
        },
        init: function() {
            try {
            }
            }))
        }
    }, gemius_hcconn.init(), gemius_hit = gemius_hcconn.plainhit, gemius_event = gemius_hcconn.plainevent, pp_gemius_hit = gemius_hcconn.addscripthit, pp_gemius_event = gemius_hcconn.addscriptevent;
    try {
        "undefined" != typeof gemius_loaded ? gemius_loaded() : "undefined" != typeof pp_gemius_loaded && pp_gemius_loaded()
    } catch (e) {}
    "undefined" != typeof gemius_identifier ? gemius_hcconn.event_identifier = gemius_identifier : "undefined" != typeof pp_gemius_identifier && (gemius_hcconn.event_identifier = pp_gemius_identifier), gemius_hcconn.sendpendingdata()
}! function() {
    else {
    }
}();