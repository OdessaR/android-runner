! function(e, t) {
    var n = function(e, t, n) {
        var i, a;
        if (function() {
                var t, n = {
                    lazyClass: "lazyload",
                    loadedClass: "lazyloaded",
                    loadingClass: "lazyloading",
                    preloadClass: "lazypreload",
                    errorClass: "lazyerror",
                    autosizesClass: "lazyautosizes",
                    srcAttr: "data-src",
                    srcsetAttr: "data-srcset",
                    sizesAttr: "data-sizes",
                    minSize: 40,
                    customMedia: {},
                    init: !0,
                    expFactor: 1.5,
                    hFac: .8,
                    loadMode: 2,
                    loadHidden: !0,
                    ricTimeout: 0,
                    throttleDelay: 125
                };
                for (t in a = e.lazySizesConfig || e.lazysizesConfig || {}, n) t in a || (a[t] = n[t])
            }(), !t || !t.getElementsByClassName) return {
            init: function() {},
            cfg: a,
            noSupport: !0
        };
        var r, s, o, l, d, c, u, f, g, m, z, y, h, v, p, b, A, C, E, w, _, M, N, L, x, S, W, B, T, F, R, D, H, k, O, P, $, q, I, U, j, G, J, K = t.documentElement,
            Q = e.HTMLPictureElement,
            V = e.addEventListener.bind(e),
            X = e.setTimeout,
            Y = e.requestAnimationFrame || X,
            Z = e.requestIdleCallback,
            ee = /^picture$/i,
            te = ["load", "error", "lazyincluded", "_lazyloaded"],
            ne = {},
            ie = Array.prototype.forEach,
            ae = function(e, t) {
                return ne[t] || (ne[t] = new RegExp("(\\s|^)" + t + "(\\s|$)")), ne[t].test(e.getAttribute("class") || "") && ne[t]
            },
            re = function(e, t) {
                ae(e, t) || e.setAttribute("class", (e.getAttribute("class") || "").trim() + " " + t)
            },
            se = function(e, t) {
                var n;
                (n = ae(e, t)) && e.setAttribute("class", (e.getAttribute("class") || "").replace(n, " "))
            },
            oe = function(e, t, n) {
                var i = n ? "addEventListener" : "removeEventListener";
                n && oe(e, t), te.forEach((function(n) {
                    e[i](n, t)
                }))
            },
            le = function(e, n, a, r, s) {
                var o = t.createEvent("Event");
                return a || (a = {}), a.instance = i, o.initEvent(n, !r, !s), o.detail = a, e.dispatchEvent(o), o
            },
            de = function(t, n) {
                var i;
                !Q && (i = e.picturefill || a.pf) ? (n && n.src && !t.getAttribute("srcset") && t.setAttribute("srcset", n.src), i({
                    reevaluate: !0,
                    elements: [t]
            },
            ce = function(e, t) {
                return (getComputedStyle(e, null) || {})[t]
            },
            ue = function(e, t, n) {
                return n
            },
            fe = (U = [], j = I = [], (J = function(e, n) {
                $ && !n ? e.apply(this, arguments) : (j.push(e), q || (q = !0, (t.hidden ? X : Y)(G)))
            })._lsFlush = G = function() {
                var e = j;
                for (j = I.length ? U : I, $ = !0, q = !1; e.length;) e.shift()();
                $ = !1
            }, J),
            ge = function(e, t) {
                return t ? function() {
                    fe(e)
                } : function() {
                        n = arguments;
                    fe((function() {
                        e.apply(t, n)
                    }))
                }
            },
            me = function(e) {
                var t, i, a = function() {
                        t = null, e()
                    },
                    r = function() {
                        var e = n.now() - i;
                        e < 99 ? X(r, 99 - e) : (Z || a)(a)
                    };
                return function() {
                    i = n.now(), t || (t = X(r, 99))
                }
            },
                _--, (!e || _ < 0 || !e.target) && (_ = 0)
            }, L = function(e) {
                return null == b && (b = "hidden" == ce(t.body, "visibility")), b || !("hidden" == ce(e.parentNode, "visibility") && "hidden" == ce(e, "visibility"))
            }, x = function(e, n) {
                var i, a = e,
                    r = L(e);
                for (y -= n, p += n, h -= n, v += n; r && (a = a.offsetParent) && a != t.body && a != K;)(r = (ce(a, "opacity") || 1) > 0) && "visible" != ce(a, "overflow") && (i = a.getBoundingClientRect(), r = v > i.left && h < i.right && p > i.top - 1 && y < i.bottom + 1);
                return r
            }, W = function(e) {
                var t, i = 0,
                    r = a.throttleDelay,
                    s = a.ricTimeout,
                    o = function() {
                        t = !1, i = n.now(), e()
                    },
                    l = Z && s > 49 ? function() {
                        Z(o, {
                            timeout: s
                        }), s !== a.ricTimeout && (s = a.ricTimeout)
                    } : ge((function() {
                        X(o)
                    }), !0);
                return function(e) {
                    var a;
                }
            }(S = function() {
                var e, n, r, s, o, l, u, g, A, C, N, S, W = i.elements;
                if ((f = a.loadMode) && _ < 8 && (e = W.length)) {
                    for (n = 0, M++; n < e; n++)
                        if (W[n] && !W[n]._lazyRace)
                            if (!E || i.prematureUnveil && i.prematureUnveil(W[n])) H(W[n]);
                        if (H(W[n]), o = !0, _ > 9) break
                    } else !o && c && !s && _ < 4 && M < 4 && f > 2 && (d[0] || a.preloadAfterLoad) && (d[0] || !g && (p || v || h || y || "auto" != W[n].getAttribute(a.sizesAttr))) && (s = d[0] || W[n]);
                    s && !o && H(s)
                }
            }), T = ge(B = function(e) {
                var t = e.target;
                t._lazyCache ? delete t._lazyCache : (N(e), re(t, a.loadedClass), se(t, a.loadingClass), oe(t, F), le(t, "lazyloaded"))
            }), F = function(e) {
                T({
                    target: e.target
                })
            }, R = function(e) {
                var t, n = e.getAttribute(a.srcsetAttr);
                (t = a.customMedia[e.getAttribute("data-media") || e.getAttribute("media")]) && e.setAttribute("media", t), n && e.setAttribute("srcset", n)
            }, D = ge((function(e, t, n, i, r) {
                var s, o, l, d, c, f;
                (c = le(e, "lazybeforeunveil", t)).defaultPrevented || (i && (n ? re(e, a.autosizesClass) : e.setAttribute("sizes", i)), o = e.getAttribute(a.srcsetAttr), s = e.getAttribute(a.srcAttr), r && (d = (l = e.parentNode) && ee.test(l.nodeName || "")), f = t.firesLoad || "src" in e && (o || s || d), c = {
                    target: e
                }, re(e, a.loadingClass), f && (clearTimeout(u), u = X(N, 2500), oe(e, F, !0)), d && ie.call(l.getElementsByTagName("source"), R), o ? e.setAttribute("srcset", o) : s && !d && (C.test(e.nodeName) ? function(e, t) {
                    try {
                        e.contentWindow.location.replace(t)
                    } catch (n) {
                    }
                    src: s
                })), e._lazyRace && delete e._lazyRace, se(e, a.lazyClass), fe((function() {
                    var t = e.complete && e.naturalWidth > 1;
                        "_lazyCache" in e && delete e._lazyCache
                    }), 9)), "lazy" == e.loading && _--
                }), !0)
            })), H = function(e) {
                if (!e._lazyRace) {
                    var t, n = A.test(e.nodeName),
                        i = n && (e.getAttribute(a.sizesAttr) || e.getAttribute("sizes")),
                        r = "auto" == i;
                }
            }, k = me((function() {
                a.loadMode = 3, W()
            })), P = function() {
                c || (n.now() - g < 999 ? X(P, 999) : (c = !0, a.loadMode = 3, W(), V("scroll", O, !0)))
            }, {
                _: function() {
                    g = n.now(), i.elements = t.getElementsByClassName(a.lazyClass), d = t.getElementsByClassName(a.lazyClass + " " + a.preloadClass), V("scroll", W, !0), V("resize", W, !0), V("pageshow", (function(e) {
                        if (e.persisted) {
                            var n = t.querySelectorAll("." + a.loadingClass);
                            n.length && n.forEach && Y((function() {
                                n.forEach((function(e) {
                                    e.complete && H(e)
                                }))
                            }))
                        }
                        childList: !0,
                        subtree: !0,
                        attributes: !0
                    }) : (K.addEventListener("DOMNodeInserted", W, !0), K.addEventListener("DOMAttrModified", W, !0), setInterval(W, 999)), V("hashchange", W, !0), ["focus", "mouseover", "click", "load", "transitionend", "animationend"].forEach((function(e) {
                        t.addEventListener(e, W, !0)
                    })), /d$|^c/.test(t.readyState) ? P() : (V("load", P), t.addEventListener("DOMContentLoaded", W), X(P, 2e4)), i.elements.length ? (S(), fe._lsFlush()) : W()
                },
                checkElems: W,
                unveil: H,
                _aLSL: O = function() {
                    3 == a.loadMode && (a.loadMode = 2), k()
                }
            }),
            ye = (s = ge((function(e, t, n, i) {
                var a, r, s;
                    for (r = 0, s = (a = t.getElementsByTagName("source")).length; r < s; r++) a[r].setAttribute("sizes", i);
                n.detail.dataAttr || de(e, n.detail)
            })), o = function(e, t, n) {
                var i, a = e.parentNode;
                a && (n = ue(e, a, n), (i = le(e, "lazybeforesizes", {
                    width: n,
                    dataAttr: !!t
                })).defaultPrevented || (n = i.detail.width) && n !== e._lazysizesWidth && s(e, a, i, n))
            }, {
                _: function() {
                    r = t.getElementsByClassName(a.autosizesClass), V("resize", l)
                },
                checkElems: l = me((function() {
                    var e, t = r.length;
                    if (t)
                        for (e = 0; e < t; e++) o(r[e])
                })),
                updateElem: o
            }),
            he = function() {
                !he.i && t.getElementsByClassName && (he.i = !0, ye._(), ze._())
            };
        return X((function() {
            a.init && he()
        })), i = {
            cfg: a,
            autoSizer: ye,
            loader: ze,
            init: he,
            uP: de,
            aC: re,
            rC: se,
            hC: ae,
            fire: le,
            gW: ue,
            rAF: fe
        }
    }(e, e.document, Date);
}("undefined" != typeof window ? window : {}), window.lazySizesConfig = window.lazysizesConfig || {
    expand: Math.min(window.innerHeight, 1e3)
};