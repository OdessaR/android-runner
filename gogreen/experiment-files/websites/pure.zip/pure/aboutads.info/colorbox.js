/**
 * @file
 * Colorbox module init js.
 */

(function($) {

        attach: function(context, settings) {
            if (!$.isFunction($('a, area, input', context).colorbox) || typeof settings.colorbox === 'undefined') {
                return;
            }

                // Disable Colorbox for small screens.
                if (mq.matches) {
                    return;
                }
            }

            // Use "data-colorbox-gallery" if set otherwise use "rel".
                if ($(this).data('colorbox-gallery')) {
                    return $(this).data('colorbox-gallery');
                } else {
                    return $(this).attr('rel');
                }
            };

            $('.colorbox', context)
                .once('init-colorbox').each(function() {
                    $(this).colorbox(settings.colorbox);
                });

            $(context).bind('cbox_complete', function() {
            });
        }
    };

})(jQuery);