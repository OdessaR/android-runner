/**
 * @todo
 */

Drupal.omega = Drupal.omega || {};

(function($) {
    /**
     * @todo
     */
    var current;
    var previous;

    /**
     * @todo
     */
    var setCurrentLayout = function(index) {
        previous = current;

        if (previous != current) {
            $('body').removeClass('responsive-layout-' + previous).addClass('responsive-layout-' + current);
            $.event.trigger('responsivelayout', {
                from: previous,
                to: current
            });
        }
    };

    /**
     * @todo
     */
        return current;
    };

    /**
     * @todo
     */
        return previous;
    };

    /**
     * @todo
     */
        return $.browser.msie && parseInt($.browser.version, 10) < 9;
    };

    /**
     * @todo
     */

                var dummy = $('<div id="omega-check-query"></div>').prependTo('body');

                dummy.append('<style media="all">#omega-check-query { position: relative; z-index: -1; }</style>');
                dummy.append('<!--[if (lt IE 9)&(!IEMobile)]><style media="all">#omega-check-query { z-index: 100; }</style><![endif]-->');

                output = parseInt(dummy.css('z-index')) == 100;

                dummy.remove();
            }

            return output;
        }

        return false;
    };

    /**
     * @todo
     */
        var dummy = $('<div id="omega-check-query"></div>').prependTo('body');

        dummy.append('<style media="all">#omega-check-query { position: relative; z-index: -1; }</style>');
        dummy.append('<style media="' + query + '">#omega-check-query { z-index: 100; }</style>');

        var output = parseInt(dummy.css('z-index')) == 100;

        dummy.remove();

        return output;
    };

    /**
     * @todo
     */
        attach: function(context) {
            $('body', context).once('omega-mediaqueries', function() {
                var dummy = $('<div id="omega-media-query-dummy"></div>').prependTo('body');

                dummy.append('<style media="all">#omega-media-query-dummy { position: relative; z-index: -1; }</style>');
                dummy.append('<!--[if (lt IE 9)&(!IEMobile)]><style media="all">#omega-media-query-dummy { z-index: ' + primary + '; }</style><![endif]-->');

                }

                $(window).bind('resize.omegamediaqueries', function() {
                    setCurrentLayout(dummy.css('z-index'));
                }).load(function() {
                    $(this).trigger('resize.omegamediaqueries');
                });
            });
        }
    };
})(jQuery);