(function($) {

        attach: function(context) {
            $('#edit-notify', context)
                .bind('change', function() {
                        .find('input[type=checkbox]:checked').attr('checked', 'checked');
                })
                .trigger('change');
        }
    }

})(jQuery);