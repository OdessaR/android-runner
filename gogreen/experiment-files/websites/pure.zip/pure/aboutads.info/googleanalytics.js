(function($) {


    $(document).ready(function() {

        // Attach mousedown, keyup, touchstart events to document only and catch
        // clicks on all elements.

            // Catch the closest surrounding link of a clicked element.
            $(event.target).closest("a,area").each(function() {

                // Is the clicked URL internal?
                    // Skip 'click' tracking, if custom tracking events are bound.
                        // Do nothing here. The custom event will handle all tracking.
                        //console.info("Click on .colorbox item has been detected.");
                    }
                    // Is download tracking activated and the file extension configured for download tracking?
                        // Download link clicked.
                        ga("send", {
                            "hitType": "event",
                            "eventCategory": "Downloads",
                            "transport": "beacon"
                        });
                        // Keep the internal URL for Google Analytics website overlay intact.
                        ga("send", {
                            "hitType": "pageview",
                            "transport": "beacon"
                        });
                    }
                } else {
                        // Mailto link clicked.
                        ga("send", {
                            "hitType": "event",
                            "eventCategory": "Mails",
                            "eventAction": "Click",
                            "transport": "beacon"
                        });
                            // External link clicked / No top-level cross domain clicked.
                            ga("send", {
                                "hitType": "event",
                                "eventCategory": "Outbound links",
                                "eventAction": "Click",
                                "transport": "beacon"
                            });
                        }
                    }
                }
            });
        });

        // Track hash changes as unique pageviews, if this option has been enabled.
                ga("send", {
                    "hitType": "pageview",
                });
            };
        }

        // Colorbox: This event triggers when the transition has completed and the
        // newly loaded content has been revealed.
            $(document).bind("cbox_complete", function() {
                var href = $.colorbox.element().attr("href");
                if (href) {
                    ga("send", {
                        "hitType": "pageview",
                    });
                }
            });
        }

    });

    /**
     * Check whether the hostname is part of the cross domains or not.
     *
     * @param string hostname
     *   The hostname of the clicked URL.
     * @param array crossDomains
     *   All cross domain hostnames as JS array.
     *
     * @return boolean
     */
        /**
         * jQuery < 1.6.3 bug: $.inArray crushes IE6 and Chrome if second argument is
         * `null` or `undefined`, https://bugs.jquery.com/ticket/10076,
         * https://github.com/jquery/jquery/commit/a839af034db2bd934e4d4fa6758a3fed8de74174
         *
         * @todo: Remove/Refactor in D8
         */
        if (!crossDomains) {
            return false;
        } else {
            return $.inArray(hostname, crossDomains) > -1 ? true : false;
        }
    };

    /**
     * Check whether this is a download URL or not.
     *
     * @param string url
     *   The web url to check.
     *
     * @return boolean
     */
        return isDownload.test(url);
    };

    /**
     * Check whether this is an absolute internal URL or not.
     *
     * @param string url
     *   The web url to check.
     *
     * @return boolean
     */
        return isInternal.test(url);
    };

    /**
     * Check whether this is a special URL or not.
     *
     * URL types:
     *  - gotwo.module /go/* links.
     *
     * @param string url
     *   The web url to check.
     *
     * @return boolean
     */
        var isInternalSpecial = new RegExp("(\/go\/.*)$", "i");
        return isInternalSpecial.test(url);
    };

    /**
     * Extract the relative internal URL from an absolute internal URL.
     *
     * Examples:
     * - https://mydomain.com/node/1 -> /node/1
     * - https://example.com/foo/bar -> https://example.com/foo/bar
     *
     * @param string url
     *   The web url to check.
     *
     * @return string
     *   Internal website URL
     */
        return url.replace(extractInternalUrl, '');
    };

    /**
     * Extract the download file extension from the URL.
     *
     * @param string url
     *   The web url to check.
     *
     * @return string
     *   The file extension of the passed url. e.g. "zip", "txt"
     */
        var extension = extractDownloadextension.exec(url);
        return (extension === null) ? '' : extension[1];
    };

})(jQuery);