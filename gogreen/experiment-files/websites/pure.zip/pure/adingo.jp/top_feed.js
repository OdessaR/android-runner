$(function() {
        type: "GET",
        //url: "feed.json?callback=?",
        url: "https://pressrelease.fluct.jp/feed_all.js?callback=?",
        dataType: 'jsonp',
        jsonpCallback: "jsonpcall",
        scriptCharset: "utf-8",
        error: function() {
            alert("error");
        },
        success: function(jsondata, datatype) {
            //for(var i in jsondata){
            //for(var i = 0;i < jsondata.length;i++){
            for (var i = 0; i < 5; i++) {
                //$("#newsList").append("<li><span>[" + jsondata[i].date + "]</span><p>" + jsondata[i].contents + "</p></li>");
                if (jsondata[i].category == "seminar") {
                    $(".newsList").append("<li class='entry'><a href='" + jsondata[i].link + "'><span class='date'>" + jsondata[i].date + "</span><span class='cateSem'>セミナー情報</span><span class='newsTxt'>" + jsondata[i].ttl + "</span></a></li>");
                } else if (jsondata[i].category == "publicity") {
                    var noLink = "http://non";
                    if (jsondata[i].linkOut == noLink) {
                        $(".newsList").append("<li class='entry'><span class='date'>" + jsondata[i].date + "</span><span class='catePub'>パブリシティ</span><span class='newsTxt'>" + jsondata[i].ttl + "</span></li>");
                    } else {
                        $(".newsList").append("<li class='entry'><a href='" + jsondata[i].linkOut + "' target='_blank'><span class='date'>" + jsondata[i].date + "</span><span class='catePub'>パブリシティ</span><span class='newsTxt'>" + jsondata[i].ttl + "</span></a></li>");
                    }
                } else {
                    $(".newsList").append("<li class='entry'><a href='" + jsondata[i].link + "'><span class='date'>" + jsondata[i].date + "</span><span class='catePre'> プレスリリース </span><span class='newsTxt'>" + jsondata[i].ttl + "</span></a></li>");
                }
            }
        }
    });
})