//ナビ白黒
$(function() {
    $(window).scroll(function() {
        var s = $(this).scrollTop();
        if (s > m) {
            $("#top header").removeClass("mov");
        } else {
            $("#top header").addClass("mov");
        }
    });
});


//動画埋め込み
$(function() {
    $("document").ready(function() {
            $('head').append('<style>#top #wrapper::before {background:url("img/main_bg_sp.gif") no-repeat left top;background-size: 100% auto;display: block;position: fixed;top: 0;left: 0;width: 100%;height: 100%;padding-bottom: 108px;content: "";z-index: -1;}</style>');
            //$("#top #wrapper").css("background","url(img/bg_sp.gif) center/cover no-repeat fixed");
            $("#top #wrapper").css("background-image", "url(img/main_bg_sp.gif)").css("background-position", "top center").css("background-repeat", "no-repeat").css("background-attachment", "fixed");
            $("#top #wrapper").css("background-size", "cover");
        } else { //user="pc";
            //var options = { videoId: "xIUyBVT3AVk"};//bqSQz7QfjiM
            //$("#top #wrapper").tubular(options);
            $('#top #wrapper').append('<video autoplay loop poster="img/main_bg_mov_poster.png" id="video-background" muted><source src="img/main_bg_mov.mp4" type="video/mp4"></video>')
            $("#video-background").css("position", "fixed").css("left", "50%").css("top", "50%").css("transform", "translate(-50%,-50%)").css("min-width", "100%").css("min-height", "100%").css("width", "auto").css("height", "auto").css("z-index", "-9999");

        }
    });
});

//高さ揃え
$(function() {
    $('.inline').matchHeight();
});