$('.slider-for').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    fade: false,
    infinite: true,
    rtl: true,
    autoplay: false,
    vertical: false,
    dots: false,
    autoplaySpeed: 6000,
    asNavFor: '.slider-nav',
});
$('.slider-nav').slick({
    asNavFor: '.slider-for',
    dots: false,
    centerMode: false,
    infinite: false,
    rtl: true,
    focusOnSelect: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    responsive: [{
        breakpoint: 470,
        settings: {
            slidesToShow: 2,
            slidesToScroll: 1,
        }
    }, {
        breakpoint: 992,
        settings: {
            slidesToShow: 4,
            slidesToScroll: 1,
        }
    }, {
        breakpoint: 1200,
        settings: {
            slidesToShow: 5,
            slidesToScroll: 1,
        }
    }]
});
$('.slider-post').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    fade: false,
    infinite: false,
    rtl: true,
    asNavFor: '.slider-post-nav'
});
$('.slider-post-nav').slick({
    asNavFor: '.slider-post',
    dots: false,
    centerMode: false,
    infinite: true,
    rtl: true,
    focusOnSelect: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    responsive: [{
        breakpoint: 470,
        settings: {
            slidesToShow: 2,
        }
    }, {
        breakpoint: 992,
        settings: {
            slidesToShow: 4,
        }
    }, {
        breakpoint: 1200,
        settings: {
            slidesToShow: 5,
        }
    }]
});

function breaking() {
    setTimeout(function() {
        $('.breaking').addClass('animated');
    }, 1500);
    $('.closebreak').click(function() {
        $('.breaking').fadeOut(400);
        $('.breaking').remove();
        $('body').css('padding-bottom', 0);
    });
    if ($('.breaking').length > 0)
        $('body').css('padding-bottom', 42);
    $(window).on("resize", function() {
        if ($(window).width() <= 768) {
            $('body').css('padding-bottom', 0);
            $('#breakNews').remove(this);
        }
    });
}
$('.slider-cat').slick({
    slidesToShow: 1,
    slidesToScroll: 1,
    arrows: true,
    fade: false,
    infinite: false,
    rtl: true,
    asNavFor: '.slider-cat-nav'
});
$('.slider-cat-nav').slick({
    asNavFor: '.slider-for',
    dots: false,
    centerMode: false,
    infinite: true,
    rtl: true,
    focusOnSelect: true,
    slidesToShow: 6,
    slidesToScroll: 1,
    responsive: [{
        breakpoint: 470,
        settings: {
            slidesToShow: 2,
        }
    }, {
        breakpoint: 992,
        settings: {
            slidesToShow: 4,
        }
    }, {
        breakpoint: 1200,
        settings: {
            slidesToShow: 5,
        }
    }]
});
try {
    $(".sponser.ad-right .ad120").sticky({
        topSpacing: 50
    });
    $(".sponser.ad-left .ad120").sticky({
        topSpacing: 50
    });
    $(".stick").sticky({
        topSpacing: 0
    });
} catch (exp) {}
try {
    $('#news').simplemarquee({
        speed: 80,
        direction: 'right',
        handleResize: true,
        cycles: 5,
        space: 0,
        delayBetweenCycles: 1000,
    });
} catch (exp) {}
$('.sites').owlCarousel({
    loop: true,
    margin: 10,
    responsiveClass: true,
    rtl: true,
    responsive: {
        0: {
            items: 1,
            nav: false,
            autoplay: true,
            autoplayTimeout: 2500,
            autoplayHoverPause: true
        },
        600: {
            items: 3,
            nav: false
        },
        1000: {
            autoplay: false,
            items: 5,
            nav: false,
            loop: false,
        }
    }
});
$('.decobes').owlCarousel({
    loop: true,
    margin: 10,
    dots: false,
    responsiveClass: true,
    rtl: true,
    responsive: {
        0: {
            items: 1,
            nav: false,
            autoplay: true,
            autoplayTimeout: 2500,
            autoplayHoverPause: true
        },
        768: {
            autoplay: false,
            items: 2,
            nav: false,
            loop: false,
            dots: false,
        },
        992: {
            items: 1,
            nav: false,
            autoplay: true,
            autoplayTimeout: 2500,
            autoplayHoverPause: true
        },
        1200: {
            autoplay: false,
            items: 2,
            nav: false,
            loop: false,
            dots: false,
        }
    }
});
(function($) {
    'use strict';
    $('.elevator-wrapper').append('<div class="elevator"><i class="fa fa-chevron-up" aria-hidden="true"></i></div>');
    var offset = 300,
        scroll_top_duration = 700,
        $back_to_top = $('.elevator');
    $(window).scroll(function() {
        ($(this).scrollTop() > offset) ? $back_to_top.addClass('elevator-is-visible'): $back_to_top.removeClass('elevator-is-visible');
    });
    $back_to_top.on('click', function(event) {
        event.preventDefault();
        $('body,html').animate({
            scrollTop: 0
        }, scroll_top_duration);
    });
})(jQuery);