if (typeof deconcept == "undefined") var deconcept = new Object();
if (typeof deconcept.util == "undefined") deconcept.util = new Object();
if (typeof deconcept.SWFObjectUtil == "undefined") deconcept.SWFObjectUtil = new Object();
deconcept.SWFObject = function(swf, id, w, h, ver, c, quality, xiRedirectUrl, redirectUrl, detectKey) {
        return;
    }
    if (swf) {
    }
    if (id) {
    }
    if (w) {
    }
    if (h) {
    }
    if (ver) {
    }
    }
    if (c) {
    }
    var q = quality ? quality : 'high';
    if (redirectUrl) {
    }
}
deconcept.SWFObject.prototype = {
    useExpressInstall: function(path) {
    },
    setAttribute: function(name, value) {
    },
    getAttribute: function(name) {
    },
    addParam: function(name, value) {
    },
    getParams: function() {
    },
    addVariable: function(name, value) {
    },
    getVariable: function(name) {
    },
    getVariables: function() {
    },
    getVariablePairs: function() {
        var variablePairs = new Array();
        var key;
        for (key in variables) {
            variablePairs.push(key + "=" + variables[key]);
        }
        return variablePairs;
    },
    getSWFHTML: function() {
        var swfNode = "";
            }
            for (var key in params) {
                swfNode += [key] + '="' + params[key] + '" ';
            }
            if (pairs.length > 0) {
                swfNode += 'flashvars="' + pairs + '"';
            }
            swfNode += '/>';
        } else {
            }
            for (var key in params) {
                swfNode += '<param name="' + key + '" value="' + params[key] + '" />';
            }
            if (pairs.length > 0) {
                swfNode += '<param name="flashvars" value="' + pairs + '" />';
            }
            swfNode += "</object>";
        }
        return swfNode;
    },
    write: function(elementId) {
            }
        }
            return true;
        } else {
            }
        }
        return false;
    }
}
deconcept.SWFObjectUtil.getPlayerVersion = function() {
        if (x && x.description) {
        }
    } else {
        try {
            try {
                axo.AllowScriptAccess = "always";
                if (PlayerVersion.major == 6) {
                    return PlayerVersion;
                }
            }
            try {
        }
        }
    }
    return PlayerVersion;
}
deconcept.PlayerVersion = function(arrVersion) {
}
deconcept.PlayerVersion.prototype.versionIsValid = function(fv) {
    return true;
}
deconcept.util = {
    getRequestParameter: function(param) {
        if (q) {
            var pairs = q.substring(1).split("&");
            for (var i = 0; i < pairs.length; i++) {
                if (pairs[i].substring(0, pairs[i].indexOf("=")) == param) {
                    return pairs[i].substring((pairs[i].indexOf("=") + 1));
                }
            }
        }
        return "";
    }
}
deconcept.SWFObjectUtil.cleanupSWFs = function() {
    for (var i = 0; i < objects.length; i++) {
        objects[i].style.display = 'none';
        for (var x in objects[i]) {
            if (typeof objects[i][x] == 'function') {
                objects[i][x] = function() {};
            }
        }
    }
}
if (deconcept.SWFObject.doPrepUnload) {
    deconcept.SWFObjectUtil.prepUnload = function() {
    }
    window.attachEvent("onbeforeunload", deconcept.SWFObjectUtil.prepUnload);
}
if (Array.prototype.push == null) {
    Array.prototype.push = function(item) {
    }
}
var getQueryParamValue = deconcept.util.getRequestParameter;
var FlashObject = deconcept.SWFObject;
var SWFObject = deconcept.SWFObject;