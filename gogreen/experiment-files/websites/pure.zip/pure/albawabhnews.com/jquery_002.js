/*! SmartMenus jQuery Plugin - v1.0.0 - January 27, 2016
 * http://www.smartmenus.org/
 * Copyright Vasil Dinkov, Vadikom Web Ltd. http://vadikom.com; Licensed MIT */
(function(t) {
})(function(t) {
    function i(i) {
        var a = ".smartmenus_mouse";
        if (h || i) h && i && (t(document).unbind(a), h = !1);
        else {
            var u = !0,
                l = null;
            t(document).bind(s([
                ["mousemove", function(i) {
                    var e = {
                        x: i.pageX,
                        y: i.pageY,
                        timeStamp: (new Date).getTime()
                    };
                    if (l) {
                        var s = Math.abs(l.x - e.x),
                            a = Math.abs(l.y - e.y);
                        if ((s > 0 || a > 0) && 2 >= s && 2 >= a && 300 >= e.timeStamp - l.timeStamp && (r = !0, u)) {
                            var n = t(i.target).closest("a");
                            n.is("a") && t.each(o, function() {
                                    currentTarget: n[0]
                                }), !1) : void 0
                            }), u = !1
                        }
                    }
                    l = e
                }],
                [n ? "touchstart" : "pointerover pointermove pointerout MSPointerOver MSPointerMove MSPointerOut", function(t) {
                    e(t.originalEvent) && (r = !1)
                }]
            ], a)), h = !0
        }
    }

    function e(t) {
        return !/^(4|mouse)$/.test(t.pointerType)
    }

    function s(i, e) {
        var s = {};
        return t.each(i, function(t, i) {
            s[i[0].split(" ").join(e + " ") + e] = i[1]
        }), s
    }
    var o = [],
        r = !1,
        h = !1,
            return setTimeout(t, 1e3 / 60)
        },
            clearTimeout(t)
        };
    }, t.extend(t.SmartMenus, {
        hideAll: function() {
            t.each(o, function() {
            })
        },
        destroy: function() {
            for (; o.length;) o[0].destroy();
            i(!0)
        },
        prototype: {
            init: function(e) {
                if (!e) {
                    var r = ".smartmenus";
                    ], r)).delegate("a", s([
                    ], r)), t(window).bind(s([
                }
                        a.menuInit(t(this))
                    var n = /(index|default)\.[^#\?\/]*/i,
                        h = /#.*/,
                        l = u.replace(h, "");
                            e = t(this);
                        (i == u || i == l) && (e.addClass("current"), a.opts.markCurrentTree && e.parentsUntil("[data-smartmenus-id]", "ul").each(function() {
                            t(this).dataSM("parent-a").addClass("current")
                        }))
                    })
                }
            },
            destroy: function(i) {
                if (!i) {
                    var e = ".smartmenus";
                }
                    var i = t(this);
                    i.dataSM("scroll-arrows") && i.dataSM("scroll-arrows").remove(), i.dataSM("shown-before") && ((s.opts.subMenusMinWidth || s.opts.subMenusMaxWidth) && i.css({
                        width: "",
                        minWidth: "",
                        maxWidth: ""
                    }).removeClass("sm-nowrap"), i.dataSM("scroll-arrows") && i.dataSM("scroll-arrows").remove(), i.css({
                        zIndex: "",
                        top: "",
                        left: "",
                        marginLeft: "",
                        marginTop: "",
                        display: ""
                    })), 0 == (i.attr("id") || "").indexOf(s.accessIdPrefix) && i.removeAttr("id")
                    var i = t(this);
                    0 == i.attr("id").indexOf(s.accessIdPrefix) && i.removeAttr("id")
            },
            disable: function(i) {
                            position: "absolute",
                            top: e.top,
                            left: e.left,
                            opacity: 0
                    }
                }
            },
            docClick: function(i) {
            },
            docTouchEnd: function() {
                            i.menuHideAll()
                        }, 350)
                    }
                }
            },
            docTouchMove: function(t) {
                    var i = t.originalEvent.touches[0];
                }
            },
            docTouchStart: function(t) {
                var i = t.originalEvent.touches[0];
                    x1: i.pageX,
                    y1: i.pageY,
                    target: i.target
                }
            },
            enable: function() {
            },
            getClosestMenu: function(i) {
                for (var e = t(i).closest("ul"); e.dataSM("in-mega");) e = e.parent().closest("ul");
                return e[0] || null
            },
            getHeight: function(t) {
            },
            getOffset: function(t, i) {
                var e;
                "none" == t.css("display") && (e = {
                    position: t[0].style.position,
                    visibility: t[0].style.visibility
                }, t.css({
                    position: "absolute",
                    visibility: "hidden"
                }).show());
                var s = t[0].getBoundingClientRect && t[0].getBoundingClientRect(),
                    o = s && (i ? s.height || s.bottom - s.top : s.width || s.right - s.left);
                return o || 0 === o || (o = i ? t[0].offsetHeight : t[0].offsetWidth), e && t.hide().css(e), o
            },
            getStartZIndex: function(t) {
            },
            getTouchPoint: function(t) {
                return t.touches && t.touches[0] || t.changedTouches && t.changedTouches[0] || t
            },
            getViewport: function(t) {
                var i = t ? "Height" : "Width",
                return s && (e = Math.min(e, s)), e
            },
            getViewportHeight: function() {
            },
            getViewportWidth: function() {
            },
            getWidth: function(t) {
            },
            handleEvents: function() {
            },
            handleItemEvents: function(t) {
            },
            isCollapsible: function() {
            },
            isCSSOn: function() {
            },
            isFixed: function() {
                    return "fixed" == t(this).css("position") ? (i = !0, !1) : void 0
                }), i
            },
            isLinkInMegaMenu: function(i) {
            },
            isTouchMode: function() {
            },
            itemActivate: function(i, e) {
                var s = i.closest("ul"),
                    o = s.dataSM("level");
                    t(s.parentsUntil("[data-smartmenus-id]", "ul").get().reverse()).add(s).each(function() {
                        a.itemActivate(t(this).dataSM("parent-a"))
                    })
                }
                    var r = i.dataSM("sub");
                }
            },
            itemBlur: function(i) {
                var e = t(i.currentTarget);
            },
            itemClick: function(i) {
                var e = t(i.currentTarget);
                    var s = t(i.target).is("span.sub-arrow"),
                        o = e.dataSM("sub"),
                        a = o ? 2 == o.dataSM("level") : !1;
                    if (o && !o.is(":visible")) {
                }
            },
            itemDown: function(i) {
                var e = t(i.currentTarget);
            },
            itemEnter: function(i) {
                var e = t(i.currentTarget);
                            s.itemActivate(e)
                    }
                }
            },
            itemFocus: function(i) {
                var e = t(i.currentTarget);
            },
            itemLeave: function(i) {
                var e = t(i.currentTarget);
            },
            menuHide: function(i) {
                    var e = function() {
                        i.css("z-index", "")
                    };
                        "-webkit-transform": "",
                        transform: ""
                        "touch-action": "",
                        "-ms-touch-action": "",
                        "-webkit-transform": "",
                        transform: ""
                    }).unbind(".smartmenus_scroll").removeDataSM("scroll").dataSM("scroll-arrows").hide()), i.dataSM("parent-a").removeClass("highlighted").attr("aria-expanded", "false"), i.attr({
                        "aria-expanded": "false",
                        "aria-hidden": "true"
                    });
                    var s = i.dataSM("level");
                }
            },
            menuHideAll: function() {
            },
            menuHideSubMenus: function(t) {
                }
            },
            menuIframeShim: function(i) {
                    src: "javascript:0",
                    tabindex: -9
                }).css({
                    position: "absolute",
                    top: "auto",
                    left: "0",
                    opacity: 0,
                    border: "0"
                }))
            },
            menuInit: function(t) {
                if (!t.dataSM("in-mega")) {
                    t.hasClass("mega-menu") && t.find("ul").dataSM("in-mega", !0);
                    for (var i = 2, e = t[0];
                    var s = t.prevAll("a").eq(-1);
                    s.length || (s = t.prevAll().find("a").eq(-1)), s.addClass("has-submenu").dataSM("sub", t), t.dataSM("parent-a", s).dataSM("level", i).parent().dataSM("sub", t);
                    s.attr({
                        id: o,
                        "aria-haspopup": "true",
                        "aria-controls": a,
                        "aria-expanded": "false"
                    }), t.attr({
                        id: a,
                        role: "group",
                        "aria-hidden": "true",
                        "aria-labelledby": o,
                        "aria-expanded": "false"
                }
            },
            menuPosition: function(i) {
                var e, o, a = i.dataSM("parent-a"),
                    r = a.closest("li"),
                    h = r.parent(),
                    u = i.dataSM("level"),
                    d = a.offset(),
                    m = d.left,
                    p = d.top,
                    b = t(window),
                    S = b.scrollLeft(),
                    g = b.scrollTop(),
                    T = h.parent().is("[data-sm-horizontal-sub]") || 2 == u && !h.hasClass("sm-vertical"),
                    var x = m + e,
                        C = p + o;
                    if ($ && S > x ? e = T ? S - x + e : f - y : !$ && x + l > S + M && (e = T ? S + M - l - x + e : y - l), T || (w > c && C + c > g + w ? o += g + w - c - C : (c >= w || g > C) && (o += g - C)), T && (C + c > g + w + .49 || g > C) || !T && c > w + .49) {
                        i.dataSM("scroll-arrows") || i.dataSM("scroll-arrows", t([t('<span class="scroll-up"><span class="scroll-up-arrow"></span></span>')[0], t('<span class="scroll-down"><span class="scroll-down-arrow"></span></span>')[0]]).bind({
                            mouseenter: function() {
                                i.dataSM("scroll").up = t(this).hasClass("scroll-up"), H.menuScroll(i)
                            },
                            mouseleave: function(t) {
                                H.menuScrollStop(i), H.menuScrollOut(i, t)
                            },
                            "mousewheel DOMMouseScroll": function(t) {
                                t.preventDefault()
                            }
                        }).insertAfter(i));
                        var A = ".smartmenus_scroll";
                        i.dataSM("scroll", {
                            step: 1,
                            itemH: v,
                            subH: c,
                        }).bind(s([
                            ["mouseover", function(t) {
                                H.menuScrollOver(i, t)
                            }],
                            ["mouseout", function(t) {
                                H.menuScrollOut(i, t)
                            }],
                            ["mousewheel DOMMouseScroll", function(t) {
                                H.menuScrollMousewheel(i, t)
                            }]
                        ], A)).dataSM("scroll-arrows").css({
                            top: "auto",
                            left: "0",
                            marginLeft: e + (parseInt(i.css("border-left-width")) || 0),
                            width: l - (parseInt(i.css("border-left-width")) || 0) - (parseInt(i.css("border-right-width")) || 0),
                            zIndex: i.css("z-index")
                            "touch-action": "none",
                            "-ms-touch-action": "none"
                        }).bind(s([
                            [n ? "touchstart touchmove touchend" : "pointerdown pointermove pointerup MSPointerDown MSPointerMove MSPointerUp", function(t) {
                                H.menuScrollTouch(i, t)
                            }]
                        ], A))
                    }
                }
                i.css({
                    top: "auto",
                    left: "0",
                    marginLeft: e,
                    marginTop: o - v
                    zIndex: i.css("z-index"),
                    width: l,
                    height: c,
                    marginLeft: e,
                    marginTop: o - v
                })
            },
            menuScroll: function(t, i, e) {
                var s, o = t.dataSM("scroll"),
                    a = t.dataSM("scroll-arrows"),
                    n = o.up ? o.upEnd : o.downEnd;
                if (!i && o.momentum) {
                var h = t.dataSM("level");
                        "-webkit-transform": "translate3d(0, " + o.y + "px, 0)",
                        transform: "translate3d(0, " + o.y + "px, 0)"
                    } : {
                        marginTop: o.y
                else if (!i) {
                        l.menuScroll(t)
                    })
                }
            },
            menuScrollMousewheel: function(t, i) {
                    var e = (i.wheelDelta || -i.detail) > 0;
                }
                i.preventDefault()
            },
            menuScrollOut: function(i, e) {
            },
            menuScrollOver: function(i, e) {
                    var s = i.dataSM("scroll"),
                        o = t(window).scrollTop() - i.dataSM("parent-a").offset().top - s.itemH;
                }
            },
            menuScrollRefreshData: function(i) {
                var e = i.dataSM("scroll"),
                    s = t(window).scrollTop() - i.dataSM("parent-a").offset().top - e.itemH;
                    upEnd: s,
                })
            },
            menuScrollStop: function(t) {
            },
            menuScrollTouch: function(i, s) {
                        var a = i.dataSM("scroll");
                            touchStartY: o.pageY,
                            touchStartTime: s.timeStamp
                        });
                        else if (/move$/i.test(s.type)) {
                            var r = void 0 !== a.touchY ? a.touchY : a.touchStartY;
                            if (void 0 !== r && r != o.pageY) {
                                var n = o.pageY > r;
                                void 0 !== a.up && a.up != n && t.extend(a, {
                                    touchStartY: o.pageY,
                                    touchStartTime: s.timeStamp
                                }), t.extend(a, {
                                    up: n,
                                    touchY: o.pageY
                            }
                            s.preventDefault()
                    }
                }
            },
            menuShow: function(t) {
                    var i = t.dataSM("parent-a");
                        zIndex: "",
                        width: "auto",
                        minWidth: "",
                        maxWidth: "",
                        top: "",
                        left: "",
                        marginLeft: "",
                        marginTop: ""
                    });
                    else {
                                width: "auto",
                                minWidth: "",
                                maxWidth: ""
                        }
                    }
                    var s = function() {
                        t.css("overflow", "")
                    };
                        "aria-expanded": "true",
                        "aria-hidden": "false"
                }
            },
            popupHide: function(t) {
                    i.menuHideAll()
            },
            popupShow: function(t, i) {
                        left: t,
                        top: i
                        left: t,
                        top: i
                        s = function() {
                            e.$root.css("overflow", "")
                        };
                }
            },
            refresh: function() {
            },
            rootKeyDown: function(i) {
                    case 27:
                        if (e) {
                            var s = e.dataSM("sub");
                        }
                        break;
                    case 32:
                        var o = t(i.target);
                            var s = o.dataSM("sub");
                                currentTarget: i.target
                            }), i.preventDefault())
                        }
                }
            },
            rootOut: function(t) {
                        i.menuHideAll()
                }
            },
            rootOver: function(t) {
            },
            winResize: function(t) {
                    }
                        top: e.top,
                        left: e.left,
                    })
                }
            }
        }
        if ("string" == typeof i) {
            var e = arguments,
                s = i;
                var i = t(this).data("smartmenus");
                i && i[s] && i[s].apply(i, e)
            })
        }
        var o = t.extend({}, t.fn.smartmenus.defaults, i);
        })
        isPopup: !1,
        mainMenuSubOffsetX: 0,
        mainMenuSubOffsetY: 0,
        subMenusSubOffsetX: 0,
        subMenusSubOffsetY: 0,
        subMenusMinWidth: "10em",
        subMenusMaxWidth: "20em",
        subIndicators: !0,
        subIndicatorsPos: "prepend",
        subIndicatorsText: "+",
        scrollStep: 30,
        scrollAccelerate: !0,
        showTimeout: 250,
        hideTimeout: 500,
        showDuration: 0,
        showFunction: null,
        hideDuration: 0,
        hideFunction: function(t, i) {
            t.fadeOut(200, i)
        },
        collapsibleShowDuration: 0,
        collapsibleShowFunction: function(t, i) {
            t.slideDown(200, i)
        },
        collapsibleHideDuration: 0,
        collapsibleHideFunction: function(t, i) {
            t.slideUp(200, i)
        },
        showOnClick: !1,
        hideOnClick: !0,
        noMouseOver: !1,
        keepInViewport: !0,
        keepHighlighted: !0,
        markCurrentItem: !1,
        markCurrentTree: !0,
        rightToLeftSubMenus: !1,
        bottomToTopSubMenus: !1,
        overlapControlsInIE: !0
    }, t
});