/*! SmartMenus jQuery Plugin Bootstrap Addon - v0.3.1 - November 1, 2016
 * http://www.smartmenus.org/
 * Copyright Vasil Dinkov, Vadikom Web Ltd. http://vadikom.com; Licensed MIT */
(function(t) {
})(function(t) {
        keydownFix: !1,
        init: function() {
            var e = t("ul.navbar-nav:not([data-sm-skip])");
            e.each(function() {
                function e() {
                    o.find("a.current").parent().addClass("active"), o.find("a.has-submenu").each(function() {
                        var e = t(this);
                        e.is('[data-toggle="dropdown"]') && e.dataSM("bs-data-toggle-dropdown", !0).removeAttr("data-toggle"), e.is('[role="button"]') && e.dataSM("bs-role-button", !0).removeAttr("role")
                    })
                }

                function s() {
                    o.find("a.current").parent().removeClass("active"), o.find("a.has-submenu").each(function() {
                        var e = t(this);
                        e.dataSM("bs-data-toggle-dropdown") && e.attr("data-toggle", "dropdown").removeDataSM("bs-data-toggle-dropdown"), e.dataSM("bs-role-button") && e.attr("role", "button").removeDataSM("bs-role-button")
                    })
                }

                function i(t) {
                    var e = a.getViewportWidth();
                        var s = o.find(".caret");
                    }
                }
                var o = t(this),
                    a = o.data("smartmenus");
                if (!a) {
                    o.smartmenus({
                        subMenusSubOffsetX: 2,
                        subMenusSubOffsetY: -6,
                        subIndicators: !1,
                        collapsibleShowFunction: null,
                        collapsibleHideFunction: null,
                        rightToLeftSubMenus: o.hasClass("navbar-right"),
                        bottomToTopSubMenus: o.closest(".navbar").hasClass("navbar-fixed-bottom")
                    }).bind({
                        "show.smapi": function(e, s) {
                            var i = t(s),
                                o = i.dataSM("scroll-arrows");
                        },
                        "hide.smapi": function(e, s) {
                            t(s).parent().removeClass("open")
                        }
                    }), e(), a = o.data("smartmenus"), a.isCollapsible = function() {
                    }, a.refresh = function() {
                        t.SmartMenus.prototype.refresh.call(this), e(), i(!0)
                    }, a.destroy = function(e) {
                        s(), t.SmartMenus.prototype.destroy.call(this, e)
                    }, o.is("[data-sm-skip-collapsible-behavior]") && o.bind({
                        "click.smapi": function(e, s) {
                            if (a.isCollapsible()) {
                                var i = t(s),
                                    o = i.parent().dataSM("sub");
                                if (o && o.dataSM("shown-before") && o.is(":visible")) return a.itemActivate(i), a.menuHide(o), !1
                            }
                        }
                    });
                    var n;
                    i(), t(window).bind("resize.smartmenus" + a.rootId, i)
                }
        }
    }), t(t.SmartMenus.Bootstrap.init), t
});