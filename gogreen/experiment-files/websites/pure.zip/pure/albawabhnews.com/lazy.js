! function(window) {
    var $q = function(q, res) {
            } else {
                    a = d.styleSheets[0] || d.createStyleSheet();
                a.addRule(q, 'f:b');
                for (var l = d.all, b = 0, c = [], f = l.length; b < f; b++)
                    l[b].currentStyle.f && c.push(l[b]);
                a.removeRule(0);
            }
            return res;
        },
        addEventListener = function(evt, fn) {
        },
        _has = function(obj, key) {
            return Object.prototype.hasOwnProperty.call(obj, key);
        };

    function loadImage(el, fn) {
            src = el.getAttribute('data-src');
        img.onload = function() {
            if (!!el.parent)
                el.parent.replaceChild(img, el)
            else
            fn ? fn() : null;
        }
        img.src = src;
    }

    function elementInViewport(el) {
        var rect = el.getBoundingClientRect()
    }
    var images = new Array(),
        query = $q('img.lazy'),
        processScroll = function() {
            for (var i = 0; i < images.length; i++) {
                if (elementInViewport(images[i])) {
                    loadImage(images[i], function() {
                        images.splice(i, i);
                    });
                }
            };
        };
    for (var i = 0; i < query.length; i++) {
        images.push(query[i]);
    };
    processScroll();
    addEventListener('scroll', processScroll);
}(this);