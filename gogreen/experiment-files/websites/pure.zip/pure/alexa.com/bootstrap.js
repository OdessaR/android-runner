+ function(a) {
    "use strict";

    function b(c, d) {
    }

    function c(c) {
            var d = a(this),
                e = d.data("bs.scrollspy"),
                f = "object" == typeof c && c;
        })
    }
        offset: 10
        var b = "offset",
            c = 0;
            var d = a(this),
                e = d.data("target") || d.attr("href"),
                f = /^#./.test(e) && a(e);
            return f && f.length && f.is(":visible") && [
                [f[b]().top + c, e]
            ] || null
        }).sort(function(a, b) {
            return a[0] - b[0]
        }).each(function() {
        })
            d = "/" == c[0].charAt(c[0].length - 1) ? c[0] : c[0] + "/",
            f = a(e).parents("li").addClass("current-menu-item");
        f.parent(".sub-menu").length && (f = f.closest("li.fusion-dropdown-menu").addClass("current-menu-item")), f.trigger("activate.bs.scrollspy")
    };
    var d = a.fn.scrollspy;
    }, a(window).on("load.bs.scrollspy.data-api", function() {
        a('[data-spy="scroll"]').each(function() {
            var b = a(this);
        })
    })
}(jQuery);