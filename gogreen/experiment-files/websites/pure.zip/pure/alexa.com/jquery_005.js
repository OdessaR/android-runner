! function(o) {
        var e = new Date;
        t.targetDate ? e = new Date(t.targetDate.month + "/" + t.targetDate.day + "/" + t.targetDate.year + " " + t.targetDate.hour + ":" + t.targetDate.min + ":" + t.targetDate.sec + (t.targetDate.utc ? " UTC" : "")) : t.targetOffset && (e.setFullYear(t.targetOffset.year + e.getFullYear()), e.setMonth(t.targetOffset.month + e.getMonth()), e.setDate(t.targetOffset.day + e.getDate()), e.setHours(t.targetOffset.hour + e.getHours()), e.setMinutes(t.targetOffset.min + e.getMinutes()), e.setSeconds(t.targetOffset.sec + e.getSeconds()));
        var s = new Date;
        if (t.gmtOffset) {
            var i = 60 * t.gmtOffset * 6e4,
                a = 6e4 * s.getTimezoneOffset();
            s = new Date(s.getTime() + i + a)
        }
            var n = s % 10;
        }
        var i = o(t + " div.top"),
            a = o(t + " div.bottom");
            display: "none"
        }), i.html(e || "0").fadeOut(s, function() {
            a.html(i.html()), a.css({
                display: "block",
                height: "auto"
            }), i.css({
                display: "none"
            })
        }))
    }
}(jQuery);