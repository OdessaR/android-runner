! function(a) {
    "use strict";
        a(this).each(function() {
            var t, i, s;
        })
        a(this).each(function() {
            var t, i, s;
        })
    }
}(jQuery);