jQuery.fn.fusionCalculateBlogEqualHeights = function() {
    var a = Math.round(1 / (jQuery(this).children(":visible").first()[0].getBoundingClientRect().width / jQuery(this).width())),
        b = jQuery(this).find(".fusion-post-grid:visible").not(".invisible-after-ajax").length;
    jQuery(this).find(".invisible-after-ajax").hide().removeClass("invisible-after-ajax"), 1 < a && 1 < b && jQuery(this).find(".fusion-post-grid:visible").each(function(b) {
        var c = parseInt(jQuery(this).css("top"), 10),
            d = 0;
        d = 1 == (b + 1) % a ? jQuery(this).parent().find(".fusion-post-grid:visible:eq(" + (b + a) + ")").length ? parseInt(jQuery(this).parent().find(".fusion-post-grid:visible:eq(" + (b + a) + ")").css("top"), 10) - c : parseInt(jQuery(this).parent().height(), 10) - c : parseInt(jQuery(this).parent().find(".fusion-post-grid:visible:eq(" + (b - 1) + ")").css("height"), 10), jQuery(this).css("height", d + "px")
    })
}, jQuery(document).ready(function() {
        void 0 !== b && !0 !== b || (jQuery(".fusion-blog-equal-heights").each(function() {
            jQuery(this).find(".fusion-post-grid").css("height", "")
            jQuery(".fusion-blog-equal-heights").isotope()
        }, 50)))
    })
}), jQuery(window).load(function() {
    var a, b;
    jQuery().isotope && jQuery(".fusion-blog-layout-grid").each(function() {
        var a = jQuery(this),
            b = ".fusion-post-grid",
            c = "packery";
        jQuery(this).hasClass("fusion-blog-layout-masonry") && (b = ".fusion-post-masonry"), jQuery(this).hasClass("fusion-blog-equal-heights") && (c = "fitRows"), jQuery(this).hasClass("fusion-blog-layout-masonry") && !jQuery(this).hasClass("fusion-blog-layout-masonry-has-vertical") && 0 < jQuery(this).find(".fusion-post-masonry:not(.fusion-grid-sizer)").not(".fusion-element-landscape").length && jQuery(this).addClass("fusion-blog-layout-masonry-has-vertical"), a.isotope({
            layoutMode: c,
            itemSelector: b,
            isOriginLeft: !jQuery("body.rtl").length,
            resizable: !0,
            initLayout: !1
        }), a.on("layoutComplete", function(a, b) {
            var c = jQuery(a.target);
            c.hasClass("fusion-blog-equal-heights") && setTimeout(function() {
                c.find(".fusion-post-grid").css("height", ""), c.fusionCalculateBlogEqualHeights()
            }, 300), c.css("min-height", "")
        }), a.isotope(), setTimeout(function() {
            jQuery(window).trigger("resize", [!1])
        }, 250)
    }), a = jQuery(".fusion-blog-layout-timeline").find(".fusion-timeline-date").last().text(), b = !0, jQuery(".fusion-blog-layout-timeline").find(".fusion-timeline-date").click(function() {
        jQuery(this).next(".fusion-collapse-month").slideToggle()
    }), jQuery(".fusion-timeline-icon").find(".fusion-icon-bubbles").click(function() {
        b ? (jQuery(this).parent().next(".fusion-blog-layout-timeline").find(".fusion-collapse-month").slideUp(), b = !1) : (jQuery(this).parent().next(".fusion-blog-layout-timeline").find(".fusion-collapse-month").slideDown(), b = !0)
    }), jQuery(".fusion-posts-container-infinite").each(function() {
        var c, d, e, f, g = jQuery(this),
            h = jQuery(this).find(".post");
        jQuery(this).find(".fusion-blog-layout-timeline").length && (g = jQuery(this).find(".fusion-blog-layout-timeline")), c = "", g.parents(".fusion-blog-shortcode").length && (c = "." + g.parents(".fusion-blog-shortcode").attr("class").replace(/\ /g, ".") + " "), jQuery(g).infinitescroll({
            navSelector: c + ".fusion-infinite-scroll-trigger",
            nextSelector: c + "a.pagination-next",
            itemSelector: c + "div.pagination .current, " + c + "article.post:not( .fusion-archive-description ), " + c + ".fusion-collapse-month, " + c + ".fusion-timeline-date",
            loading: {
            },
            maxPage: g.data("pages") ? g.data("pages") : void 0,
            errorCallback: function() {
                g.find(".fusion-post-grid").css("height", ""), jQuery(g).hasClass("isotope") && jQuery(g).isotope()
            }
        }, function(c) {
            var f;
            jQuery(g).hasClass("fusion-blog-layout-timeline") && (jQuery(c).first(".fusion-timeline-date").text() == a && jQuery(c).first(".fusion-timeline-date").remove(), a = jQuery(g).find(".fusion-timeline-date").last().text(), jQuery(g).find(".fusion-timeline-date").each(function() {
                jQuery(this).next(".fusion-collapse-month").append(jQuery(this).nextUntil(".fusion-timeline-date", ".fusion-post-timeline"))
            }), b || setTimeout(function() {
                jQuery(g).find(".fusion-collapse-month").hide()
            }, 200), setTimeout(function() {
                jQuery(g).find(".fusion-collapse-month").each(function() {
                    jQuery(this).children().length || jQuery(this).remove()
                })
            }, 10), jQuery(g).find(".fusion-timeline-date").unbind("click"), jQuery(g).find(".fusion-timeline-date").click(function() {
                jQuery(this).next(".fusion-collapse-month").slideToggle()
                jQuery(c).fadeIn(), jQuery(g).hasClass("isotope") && (g.hasClass("fusion-portfolio-equal-heights") && g.find(".fusion-post-grid").css("height", ""), jQuery(g).isotope("appended", jQuery(c)), jQuery(g).isotope()), jQuery('[data-spy="scroll"]').each(function() {
                    jQuery(this).scrollspy("refresh")
                })
            }), f = !1), jQuery(g).find(".flexslider").flexslider({
                video: !0,
                smoothHeight: f,
                pauseOnHover: !1,
                useCSS: !1,
                prevText: "&#xf104;",
                nextText: "&#xf105;",
                start: function(a) {
                            events: {
                                onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                            }
                        })
                },
                before: function(a) {
                            events: {
                                onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                            }
                        })
                    }))
                },
                after: function(a) {
                            events: {
                                onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                            }
                        })
                        jQuery(this).scrollspy("refresh")
                    })
                }
            }), jQuery(c).each(function() {
                jQuery(this).find(".full-video, .video-shortcode, .wooslider .slide-content").fitVids()
                jQuery(window).trigger("resize", [!1])
            a.preventDefault(), jQuery(g).infinitescroll("retrieve"), jQuery(g).hasClass("fusion-blog-layout-grid")
        })), d = g, jQuery(g).hasClass("fusion-blog-layout-timeline") && jQuery(g).parents(".fusion-blog-layout-timeline-wrapper").length && (d = jQuery(g).parents(".fusion-posts-container-infinite")), 1 === parseInt(d.data("pages"), 10) && (d.parent().find(".fusion-loading-container").hide(), d.parent().find(".fusion-load-more-button").hide())
    })
});