! function(a, b) {
    "use strict";

    function c(b) {
        a.fn.cycle.debug && d(b)
    }

    function d() {
    }

    function e(b, c, d) {
        var e = a(b).data("cycle.opts");
        if (e) {
            var f = !!b.cyclePause;
            f && e.paused ? e.paused(b, e, c, d) : !f && e.resumed && e.resumed(b, e, c, d)
        }
    }

    function f(c, f, g) {
        function i(b, c, e) {
            if (!b && !0 === c) {
                var f = a(e).data("cycle.opts");
                if (!f) return d("options not found, can not resume"), !1;
            }
        }
            switch (f) {
                case "destroy":
                case "stop":
                    var j = a(c).data("cycle.opts");
                case "toggle":
                case "pause":
                case "resume":
                case "prev":
                case "next":
                    return (j = a(c).data("cycle.opts")) ? ("string" == typeof g && (j.oneTimeFx = g), a.fn.cycle[f](j), !1) : (d('options not found, "prev/next" ignored'), !1);
                default:
                        fx: f
                    }
            }
            return f
        }
        if (f.constructor == Number) {
            var k = f;
        }
        return f
    }

    function g(b, c) {
        if (!a.support.opacity && c.cleartype && b.style.filter) try {
            b.style.removeAttribute("filter")
        } catch (a) {}
    }

    function h(b, c) {
        c.next && a(c.next).unbind(c.prevNextEvent), c.prev && a(c.prev).unbind(c.prevNextEvent), (c.pager || c.pagerAnchorBuilder) && a.each(c.pagerAnchors || [], function() {
    }

    function i(c, f, h, i, n) {
        var r, s = a.extend({}, a.fn.cycle.defaults, i || {}, a.metadata ? c.metadata() : a.meta ? c.data() : {}),
            t = a.isFunction(c.data) ? c.data(s.metaAttr) : null;
        t && (s = a.extend(s, t)), s.autostop && (s.countdown = s.autostopCount || h.length);
        var u = c[0];
        if (c.data("cycle.opts", s), s.$cont = c, s.stopCount = u.cycleStop, s.elements = h, s.before = s.before ? [s.before] : [], s.after = s.after ? [s.after] : [], !a.support.opacity && s.cleartype && s.after.push(function() {
                g(this, s)
            }), s.continuous && s.after.push(function() {
                m(h, s, 0, !s.backwards)
            }), j(s), a.support.opacity || !s.cleartype || s.cleartypeNoBg || q(f), "static" == c.css("position") && c.css("position", "relative"), s.width && c.width(s.width), s.height && "auto" != s.height && c.height(s.height), s.startingSlide !== b ? (s.startingSlide = parseInt(s.startingSlide, 10), s.startingSlide >= h.length || s.startSlide < 0 ? s.startingSlide = 0 : r = !0) : s.backwards ? s.startingSlide = h.length - 1 : s.startingSlide = 0, s.random) {
            s.randomMap = [];
            for (var v = 0; v < h.length; v++) s.randomMap.push(v);
            if (s.randomMap.sort(function(a, b) {
                    return Math.random() - .5
                }), r)
                for (var w = 0; w < h.length; w++) s.startingSlide == s.randomMap[w] && (s.randomIndex = w);
            else s.randomIndex = 1, s.startingSlide = s.randomMap[1]
        } else s.startingSlide >= h.length && (s.startingSlide = 0);
        s.currSlide = s.startingSlide || 0;
        var x = s.startingSlide;
        if (f.css({
                position: "absolute",
                top: 0,
                left: 0
            }).hide().each(function(b) {
                var c;
                c = s.backwards ? x ? b <= x ? h.length + (b - x) : x - b : h.length - b : x ? b >= x ? h.length - (b - x) : x - b : h.length - b, a(this).css("z-index", c)
            }), a(h[x]).css("opacity", 1).show(), g(h[x], s), s.fit && (s.aspect ? f.each(function() {
                var b = a(this),
                    c = !0 === s.aspect ? b.width() / b.height() : s.aspect;
                s.width && b.width() != s.width && (b.width(s.width), b.height(s.width / c)), s.height && b.height() < s.height && (b.height(s.height), b.width(s.height * c))
            }) : (s.width && f.width(s.width), s.height && "auto" != s.height && f.height(s.height))), !s.center || s.fit && !s.aspect || f.each(function() {
                var b = a(this);
                b.css({
                    "margin-left": s.width ? (s.width - b.width()) / 2 + "px" : 0,
                    "margin-top": s.height ? (s.height - b.height()) / 2 + "px" : 0
                })
            }), !s.center || s.fit || s.slideResize || f.each(function() {
                var b = a(this);
                b.css({
                    "margin-left": s.width ? (s.width - b.width()) / 2 + "px" : 0,
                    "margin-top": s.height ? (s.height - b.height()) / 2 + "px" : 0
                })
            }), (s.containerResize || s.containerResizeHeight) && c.innerHeight() < 1) {
            for (var y = 0, z = 0, A = 0; A < h.length; A++) {
                var B = a(h[A]),
                    C = B[0],
                    D = B.outerWidth(),
                    E = B.outerHeight();
                D || (D = C.offsetWidth || C.width || B.attr("width")), E || (E = C.offsetHeight || C.height || B.attr("height")), y = D > y ? D : y, z = E > z ? E : z
            }
            s.containerResize && y > 0 && z > 0 && c.animate({
                width: y + "px",
                height: z + "px"
            }), s.containerResizeHeight && z > 0 && c.animate({
                height: z + "px"
            })
        }
        var F = !1;
        if (s.pause && c.bind("mouseenter.cycle", function() {
            }).bind("mouseleave.cycle", function() {
            }), !1 === k(s)) return !1;
        var G = !1;
                var b = a(this);
                            a(n.s, n.c).cycle(i)
                        }, s.requeueTimeout), G = !0, !1;
                    }
                }
                return !0
            }), G) return !1;
        if (s.cssBefore = s.cssBefore || {}, s.cssAfter = s.cssAfter || {}, s.cssFirst = s.cssFirst || {}, s.animIn = s.animIn || {}, s.animOut = s.animOut || {}, f.not(":eq(" + x + ")").css(s.cssBefore), a(f[x]).css(s.cssFirst), s.timeout) {
            s.timeout = parseInt(s.timeout, 10), s.speed.constructor == String && (s.speed = a.fx.speeds[s.speed] || parseInt(s.speed, 10)), s.sync || (s.speed = s.speed / 2);
            for (var H = "none" == s.fx ? 0 : "shuffle" == s.fx ? 500 : 250; s.timeout - s.speed < H;) s.timeout += s.speed
        }
        if (s.easing && (s.easeIn = s.easeOut = s.easing), s.speedIn || (s.speedIn = s.speed), s.speedOut || (s.speedOut = s.speed), s.slideCount = h.length, s.currSlide = s.lastSlide = x, s.random ? (++s.randomIndex == h.length && (s.randomIndex = 0), s.nextSlide = s.randomMap[s.randomIndex]) : s.backwards ? s.nextSlide = 0 === s.startingSlide ? h.length - 1 : s.startingSlide - 1 : s.nextSlide = s.startingSlide >= h.length - 1 ? 0 : s.startingSlide + 1, !s.multiFx) {
            var I = a.fn.cycle.transitions[s.fx];
            if (a.isFunction(I)) I(c, f, s);
            else if ("custom" != s.fx && !s.multiFx) return d("unknown transition: " + s.fx, "; slideshow terminating"), !1
        }
        var J = f[x];
        return s.skipInitializationCallbacks || (s.before.length && s.before[0].apply(J, [J, J, s, !0]), s.after.length && s.after[0].apply(J, [J, J, s, !0])), s.next && a(s.next).bind(s.prevNextEvent, function() {
            return o(s, 1)
        }), s.prev && a(s.prev).bind(s.prevNextEvent, function() {
            return o(s, 0)
        }), (s.pager || s.pagerAnchorBuilder) && p(h, s), l(s, h), s
    }

    function j(b) {
            before: [],
            after: []
            b.original.before.push(this)
        }), a.each(b.after, function() {
            b.original.after.push(this)
        })
    }

    function k(b) {
        var e, f, g = a.fn.cycle.transitions;
        if (b.fx.indexOf(",") > 0) {
                var h = b.fxs[e];
                f = g[h], f && g.hasOwnProperty(h) && a.isFunction(f) || (d("discarding unknown transition: ", h), b.fxs.splice(e, 1), e--)
            }
            if (!b.fxs.length) return d("No valid transitions named; slideshow terminating."), !1
        } else if ("all" == b.fx) {
            for (var i in g) g.hasOwnProperty(i) && (f = g[i], g.hasOwnProperty(i) && a.isFunction(f) && b.fxs.push(i))
        }
        if (b.multiFx && b.randomizeEffects) {
            var j = Math.floor(20 * Math.random()) + 30;
            for (e = 0; e < j; e++) {
                var k = Math.floor(Math.random() * b.fxs.length);
                b.fxs.push(b.fxs.splice(k, 1)[0])
            }
            c("randomized fx sequence: ", b.fxs)
        }
        return !0
    }

    function l(b, c) {
            var f = a(d),
                g = f[0];
                return Math.random() - .5
        }
    }

    function m(d, e, f, g) {
        function h() {
            var a = 0;
            e.timeout;
            e.timeout && !e.continuous ? (a = n(d[e.currSlide], d[e.nextSlide], e, g), "shuffle" == e.fx && (a -= e.speedOut)) : e.continuous && i.cyclePause && (a = 10), a > 0 && (i.cycleTimeout = setTimeout(function() {
                m(d, e, 0, !e.backwards)
            }, a))
        }
        var i = e.$cont[0],
            j = d[e.currSlide],
            k = d[e.nextSlide];
        if (i.cycleStop == e.stopCount && (0 !== i.cycleTimeout || f)) {
            var l = !1;
            if (!f && i.cyclePause || e.nextSlide == e.currSlide) h();
            else {
                l = !0;
                var o = e.fx;
                    i.cycleStop == e.stopCount && b.apply(k, [j, k, e, g])
                });
                var p = function() {
                        i.cycleStop == e.stopCount && b.apply(k, [j, k, e, g])
                    }), i.cycleStop || h()
                };
            }
            if (l || e.nextSlide == e.currSlide) {
                var q;
                    return Math.random() - .5
            }
            l && e.pager && e.updateActivePagerLink(e.pager, e.currSlide, e.activePagerClass)
        }
    }

    function n(a, b, d, e) {
        if (d.timeoutFn) {
            for (var f = d.timeoutFn.call(a, a, b, d, e);
                "none" != d.fx && f - d.speed < 250;) f += d.speed;
            if (c("calculated timeout: " + f + "; speed: " + d.speed), !1 !== f) return f
        }
        return d.timeout
    }

    function o(b, c) {
        var d = c ? 1 : -1,
            e = b.elements,
            f = b.$cont[0],
            g = f.cycleTimeout;
            if (b.nowrap) return !1;
        } else if (b.nextSlide >= e.length) {
            if (b.nowrap) return !1;
        }
        var h = b.onPrevNextEvent || b.prevNextClick;
        return a.isFunction(h) && h(d > 0, b.nextSlide, e[b.nextSlide]), m(e, b, 1, c), !1
    }

    function p(b, c) {
        var d = a(c.pager);
        a.each(b, function(e, f) {
            a.fn.cycle.createPagerAnchor(e, f, d, b, c)
        }), c.updateActivePagerLink(c.pager, c.startingSlide, c.activePagerClass)
    }

    function q(b) {
        function d(a) {
        }

        function e(b) {
                var c = a.css(b, "background-color");
                if (c && c.indexOf("rgb") >= 0) {
                    var e = c.match(/\d+/g);
                    return "#" + d(e[0]) + d(e[1]) + d(e[2])
                }
                if (c && "transparent" != c) return c
            }
            return "#ffffff"
        }
        c("applying clearType background-color hack"), b.each(function() {
            a(this).css("background-color", e(this))
        })
    }
        return a.cyclePause
        var g = {
        };
            a(g.s, g.c).cycle(b, e)
            var h = f(this, b, e);
            if (!1 !== h) {
                var j = a(this),
                    k = h.slideExpr ? a(h.slideExpr, this) : j.children(),
                    l = k.get();
                if (l.length < 2) return void d("terminating; too few slides: " + l.length);
                var o = i(j, k, l, h, g);
                if (!1 !== o) {
                    var p = o.continuous ? 10 : n(l[o.currSlide], l[o.nextSlide], o, !o.backwards);
                        m(l, o, 0, !h.backwards)
                    }, p))
                }
            }
        })
            b.before.push(this)
        }), a.each(b.original.after, function() {
            b.after.push(this)
        });
        var d = a.fn.cycle.transitions[c];
        a.isFunction(d) && d(b.$cont, a(b.elements), b)
        a(b).each(function() {
            a(this).children().removeClass(d).eq(c).addClass(d)
        })
        o(a, 1)
        o(a, 0)
        var i;
        if (a.isFunction(h.pagerAnchorBuilder) ? (i = h.pagerAnchorBuilder(b, d), c("pagerAnchorBuilder(" + b + ", el) returned: " + i)) : i = '<a href="#" aria-label="pagination"></a>', i) {
            var j = a(i);
            if (0 === j.parents("body").length) {
                var k = [];
                f.length > 1 ? (f.each(function() {
                    var b = j.clone(!0);
                    a(this).append(b), k.push(b[0])
                }), j = a(k)) : j.appendTo(f)
            }
            var l = function(c) {
                var d = h.$cont[0],
                    e = d.cycleTimeout;
                e && (clearTimeout(e), d.cycleTimeout = 0);
                var f = h.onPagerEvent || h.pagerClick;
                a.isFunction(f) && f(h.nextSlide, g[h.nextSlide]), m(g, h, 1, h.currSlide < b)
            };
            /mouseenter|mouseover/i.test(h.pagerEvent) ? j.hover(l, function() {}) : j.bind(h.pagerEvent, l), /^click/.test(h.pagerEvent) || h.allowPagerClickBubble || j.bind("click.cycle", function() {
                return !1
            });
            var n = h.$cont[0],
                o = !1;
            h.pauseOnPagerHover && j.hover(function() {
                o = !0, n.cyclePause++, e(n, !0, !0)
            }, function() {
                o && n.cyclePause--, e(n, !0, !0)
            })
        }
        var c = a.lastSlide,
            d = a.currSlide;
        return b ? d > c ? d - c : a.slideCount - c : d < c ? c - d : c + a.slideCount - d
        var h = a(b),
            i = a(c),
            j = d.speedIn,
            k = d.speedOut,
            l = d.easeIn,
            m = d.easeOut,
            n = d.animInDelay,
            o = d.animOutDelay;
        i.css(d.cssBefore), g && (j = k = "number" == typeof g ? g : 1, l = m = null);
        var p = function() {
            i.delay(n).animate(d.animIn, j, l, function() {
                e()
            })
        };
        h.delay(o).animate(d.animOut, k, m, function() {
            h.css(d.cssAfter), d.sync || p()
        }), d.sync && p()
        fade: function(b, c, d) {
            c.not(":eq(" + d.currSlide + ")").css("opacity", 0), d.before.push(function(b, c, d) {
                opacity: 1
                opacity: 0
                top: 0,
                left: 0
            }
        }
        return "3.0.3"
        activePagerClass: "activeSlide",
        after: null,
        allowPagerClickBubble: !1,
        animIn: null,
        animInDelay: 0,
        animOut: null,
        animOutDelay: 0,
        aspect: !1,
        autostop: 0,
        autostopCount: 0,
        backwards: !1,
        before: null,
        center: null,
        cleartype: !a.support.opacity,
        cleartypeNoBg: !1,
        containerResize: 1,
        containerResizeHeight: 0,
        continuous: 0,
        cssAfter: null,
        cssBefore: null,
        delay: 0,
        easeIn: null,
        easeOut: null,
        easing: null,
        end: null,
        fastOnEvent: 0,
        fit: 0,
        fx: "fade",
        fxFn: null,
        height: "auto",
        manualTrump: !0,
        metaAttr: "cycle",
        next: null,
        nowrap: 0,
        onPagerEvent: null,
        onPrevNextEvent: null,
        pager: null,
        pagerAnchorBuilder: null,
        pagerEvent: "click.cycle",
        pause: 0,
        pauseOnPagerHover: 0,
        prev: null,
        prevNextEvent: "click.cycle",
        random: 0,
        randomizeEffects: 1,
        requeueOnImageNotLoaded: !0,
        requeueTimeout: 250,
        rev: 0,
        shuffle: null,
        skipInitializationCallbacks: !1,
        slideExpr: null,
        slideResize: 1,
        speed: 1e3,
        speedIn: null,
        speedOut: null,
        startingSlide: b,
        sync: 1,
        timeout: 4e3,
        timeoutFn: null,
        updateActivePagerLink: null,
        width: null
    }
}(jQuery),
function(a) {
    "use strict";
            a(c).show(), a(b).hide(), e()
        }
        c.not(":eq(" + d.currSlide + ")").css({
            display: "block",
            opacity: 1
        }), d.before.push(function(b, c, d, e, f, g) {
            a(b).css("zIndex", d.slideCount + (!0 !== g ? 1 : 0)), a(c).css("zIndex", d.slideCount + (!0 !== g ? 0 : 1))
        b.css("overflow", "hidden"), d.before.push(a.fn.cycle.commonReset);
        var e = b.height();
        b.css("overflow", "hidden"), d.before.push(a.fn.cycle.commonReset);
        var e = b.height();
        b.css("overflow", "hidden"), d.before.push(a.fn.cycle.commonReset);
        var e = b.width();
        b.css("overflow", "hidden"), d.before.push(a.fn.cycle.commonReset);
        var e = b.width();
        b.css("overflow", "hidden").width(), d.before.push(function(b, c, d, e) {
        b.css("overflow", "hidden"), d.before.push(function(b, c, d, e) {
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        var e, f = b.css("overflow", "visible").width();
        for (c.css({
                left: 0,
                top: 0
            }), d.before.push(function(b, c, d) {
                a.fn.cycle.commonReset(b, c, d, !0, !0, !0)
                left: -f,
                top: 15
        for (e = 0; e < d.currSlide; e++) d.els.push(d.els.shift());
            d.rev && (f = !f);
            var g = a(f ? b : c);
            a(c).css(d.cssBefore);
            var h = d.slideCount;
            g.animate(d.shuffle, d.speedIn, d.easeIn, function() {
                for (var c = a.fn.cycle.hopsFromLast(d, f), i = 0; i < c; i++) f ? d.els.push(d.els.shift()) : d.els.unshift(d.els.pop());
                if (f)
                    for (var j = 0, k = d.els.length; j < k; j++) a(d.els[j]).css("z-index", k - j + h);
                else {
                    var l = a(b).css("z-index");
                    g.css("z-index", parseInt(l, 10) + 1 + h)
                }
                g.animate({
                    left: 0,
                    top: 0
                }, d.speedOut, d.easeOut, function() {
                })
            })
        }, a.extend(d.cssBefore, {
            display: "block",
            opacity: 1,
            top: 0,
            left: 0
        })
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        }), a.extend(d.cssBefore, {
            top: 0,
            left: 0,
            width: 0
        d.before.push(function(b, c, d) {
                top: 0,
                left: 0,
                width: c.cycleW,
                height: c.cycleH
            }), a.extend(d.animOut, {
                width: 0,
                height: 0,
                top: b.cycleH / 2,
                left: b.cycleW / 2
            })
        d.before.push(function(b, c, d) {
                top: 0,
                left: 0,
                width: c.cycleW,
                height: c.cycleH
            })
        var e = b.css("overflow", "hidden").width();
        d.before.push(function(b, c, d) {
        var e = b.css("overflow", "hidden").height();
        d.before.push(function(b, c, d) {
        var e = b.css("overflow", "hidden").height(),
            f = b.width();
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        d.before.push(function(b, c, d) {
        var e = d.direction || "left",
            f = b.css("overflow", "hidden").width(),
            g = b.height();
        d.before.push(function(b, c, d) {
        var e = d.direction || "left",
            f = b.css("overflow", "hidden").width(),
            g = b.height();
        d.before.push(function(b, c, d) {
        var e = b.css("overflow", "visible").width(),
            f = b.height();
        d.before.push(function(b, c, d) {
                left: 2 * e,
                top: -f / 2,
                opacity: 0
            })
        var e = b.css("overflow", "hidden").width(),
            f = b.height();
        var g;
        if (d.clip)
            if (/l2r/.test(d.clip)) g = "rect(0px 0px " + f + "px 0px)";
            else if (/r2l/.test(d.clip)) g = "rect(0px " + e + "px " + f + "px " + e + "px)";
        else if (/t2b/.test(d.clip)) g = "rect(0px " + e + "px 0px 0px)";
        else if (/b2t/.test(d.clip)) g = "rect(" + f + "px " + e + "px " + f + "px 0px)";
        else if (/zoom/.test(d.clip)) {
            var h = parseInt(f / 2, 10),
                i = parseInt(e / 2, 10);
            g = "rect(" + h + "px " + i + "px " + h + "px " + i + "px)"
        }
        var j = d.cssBefore.clip.match(/(\d+)/g),
            k = parseInt(j[0], 10),
            l = parseInt(j[1], 10),
            m = parseInt(j[2], 10),
            n = parseInt(j[3], 10);
        d.before.push(function(b, c, d) {
            if (b != c) {
                var g = a(b),
                    h = a(c);
                var i = 1,
                    j = parseInt(d.speedIn / 13, 10) - 1;
                ! function a() {
                    var b = k ? k - parseInt(i * (k / j), 10) : 0,
                        c = n ? n - parseInt(i * (n / j), 10) : 0,
                        d = m < f ? m + parseInt(i * ((f - m) / j || 1), 10) : f,
                        o = l < e ? l + parseInt(i * ((e - l) / j || 1), 10) : e;
                    h.css({
                        clip: "rect(" + b + "px " + o + "px " + d + "px " + c + "px)"
                    }), i++ <= j ? setTimeout(a, 13) : g.css("display", "none")
                }()
            }
        }), a.extend(d.cssBefore, {
            display: "block",
            opacity: 1,
            top: 0,
            left: 0
            left: 0
            left: 0
        }
    }
}(jQuery);