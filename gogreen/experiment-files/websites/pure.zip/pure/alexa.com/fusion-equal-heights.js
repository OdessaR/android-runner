! function(a) {
    "use strict";
        var d;
        a(this).parents().find(".fusion-portfolio-wrapper");
            a(this).css("min-height", "0"), a(this).css("height", "auto"), a(this).find(".fusion-column-content-centered").css("min-height", "0"), a(this).find(".fusion-column-content-centered").css("height", "auto")
            a(this).css("min-height", "0"), a(this).css("height", "auto"), a(this).find(".fusion-column-content-centered").css("min-height", "0"), a(this).find(".fusion-column-content-centered").css("height", "auto"), a(this).outerHeight() > d && (d = a(this).outerHeight())
            var b = d;
        }))
    }
}(jQuery);