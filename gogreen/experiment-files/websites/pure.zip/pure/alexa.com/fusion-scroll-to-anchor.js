! function(a) {
    "use strict";
        var b, c, d, e, f, g, h, i = a(this).attr("href"),
            j = i.substr(i.indexOf("#")).slice(1),
            k = a("#" + j);
        if (k.length && "" !== j) {
                if (h = k.hasClass("fusion-scroll-section-element") ? k : k.parents(".fusion-scroll-section-element"), h.hasClass("active") && h.offset().top >= a(window).scrollTop() && h.offset().top < a(window).scrollTop() + a(window).height()) return !1;
                    scrollTop: g
                }, {
                    duration: 400,
                    easing: "easeInExpo",
                    complete: function() {
                        setTimeout(function() {
                        }, 100)
                    }
                })), !1
            }
                scrollTop: g
            }, {
                duration: 400,
                easing: "easeInExpo",
                complete: function() {
                        scrollTop: e
                    }, 450, "easeOutExpo", function() {
                    })
                }
            }), (k.hasClass("tab-pane") || k.hasClass("tab-link")) && "function" == typeof a.fn.fusionSwitchTabOnLinkClick && setTimeout(function() {
                k.parents(".fusion-tabs").fusionSwitchTabOnLinkClick()
            }, 100), !1
        }
    }
}(jQuery), jQuery(document).ready(function() {
    jQuery('.fusion-menu a:not([href="#"], .fusion-megamenu-widgets-container a, .search-link), .fusion-mobile-nav-item a:not([href="#"], .search-link), .fusion-button:not([href="#"], input, button), .fusion-one-page-text-link:not([href="#"]), .fusion-content-boxes .fusion-read-more:not([href="#"])').click(function(a) {
        var b, c, d, e, f, g, h, i;
        if (jQuery(this).hasClass("avada-noscroll") || jQuery(this).parent().hasClass("avada-noscroll") || jQuery(this).is(".fusion-content-box-button, .fusion-tagline-button") && jQuery(this).parents(".avada-noscroll").length) return !0;
        }
    })
}), location.hash && "#_" === location.hash.substring(0, 2) && (jQuery(".fusion-page-load-link").attr("href", decodeURIComponent("#" + location.hash.substring(2))), jQuery(window).load(function() {
    jQuery(".fusion-blog-shortcode").length ? setTimeout(function() {
        jQuery(".fusion-page-load-link").fusion_scroll_to_anchor_target()
    }, 300) : jQuery(".fusion-page-load-link").fusion_scroll_to_anchor_target()
}));