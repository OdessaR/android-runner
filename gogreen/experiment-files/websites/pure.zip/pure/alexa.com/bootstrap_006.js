+ function(a) {
    "use strict";
    var b = function(c, d) {
    };
    b.DEFAULTS = {
        toggle: !0
    }, b.prototype.dimension = function() {
    }, b.prototype.show = function() {
            var b = a.Event("show.bs.collapse");
                if (c && c.length) {
                    var d = c.data("bs.collapse");
                    if (d && d.transitioning) return;
                    c.collapse("hide"), d || c.data("bs.collapse", null)
                }
                var f = function() {
                };
                if (!a.support.transition) return f.call(this);
                var g = a.camelCase(["scroll", e].join("-"));
            }
        }
    }, b.prototype.hide = function() {
            var b = a.Event("hide.bs.collapse");
                var d = function() {
                };
                if (!a.support.transition) return d.call(this);
            }
        }
    }, b.prototype.toggle = function() {
    };
    var c = a.fn.collapse;
            var d = a(this),
                e = d.data("bs.collapse"),
                f = a.extend({}, b.DEFAULTS, d.data(), "object" == typeof c && c);
        })
    }, a(document).on("click.bs.collapse.data-api", "[data-toggle=collapse]", function(b) {
        if (!jQuery(this).parents(".fusion-accordian").find(".toggle-fadein").length || jQuery(this).parents(".fusion-accordian").find(".toggle-fadein")[0] === jQuery(this).parents(".fusion-panel").find(".panel-collapse")[0]) {
            var c, d = a(this),
                e = d.attr("data-target") || b.preventDefault() || (c = d.attr("href")) && c.replace(/.*(?=#[^\s]+$)/, ""),
                f = a(e),
                g = f.data("bs.collapse"),
                h = g ? "toggle" : d.data(),
                i = d.attr("data-parent"),
                j = i && a(i);
            g && g.transitioning || (j && j.find('[data-toggle=collapse][data-parent="' + i + '"]').not(d).addClass("collapsed"), d[f.hasClass("in") ? "addClass" : "removeClass"]("collapsed")), f.collapse(h)
        }
    }), jQuery("click.bs.collapse.data-api, [data-toggle=collapse]").each(function() {
        jQuery(this).attr("data-parent");
        if (0 == jQuery(this).parents(".panel-group").length) {
            var a = Math.floor(10 * Math.random() + 1),
                b = jQuery(this).parents(".fusion-panel");
            jQuery(this).attr("data-parent", "accordian-" + a), jQuery(b).wrap('<div class="accordian fusion-accordian fusion-single-accordian"><div class="panel-group" id="accordion-' + a + '"></div></div>')
        }
    })
}(jQuery);