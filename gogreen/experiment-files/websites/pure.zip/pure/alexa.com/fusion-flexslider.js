jQuery(window).load(function() {
    var a, b, c, d;
        var a = jQuery(this).attr("id"),
            b = jQuery(this).attr("src");
            jQuery("#" + a).parents("li").parent().parent().flexslider("pause")
        }), c.on("pause", function() {
            "yes" === jQuery(d).attr("data-loop") ? jQuery("#" + a).parents("li").parent().parent().flexslider("pause") : jQuery("#" + a).parents("li").parent().parent().flexslider("play")
        }))
        video: !0,
        smoothHeight: a,
        pauseOnHover: !1,
        useCSS: !1,
        prevText: "&#xf104;",
        nextText: "&#xf105;",
        start: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
        },
        before: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
            }), playVideoAndPauseOthers(a))
        },
        after: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
                jQuery(this).scrollspy("refresh")
            })
        }
        video: !0,
        smoothHeight: b,
        pauseOnHover: !1,
        useCSS: !1,
        prevText: "&#xf104;",
        nextText: "&#xf105;",
        start: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
        },
        before: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
            }), playVideoAndPauseOthers(a))
        },
        after: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
                jQuery(this).scrollspy("refresh")
            })
        }
    }), jQuery(".flexslider:not(.tfs-slider)").flexslider({
        video: !0,
        smoothHeight: b,
        pauseOnHover: !1,
        useCSS: !1,
        prevText: "&#xf104;",
        nextText: "&#xf105;",
        start: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
        },
        before: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
            }), playVideoAndPauseOthers(a))
        },
        after: function(a) {
                    events: {
                        onStateChange: onPlayerStateChange(a.slides.eq(a.currentSlide).find("iframe").attr("id"), a)
                    }
                })
                jQuery(this).scrollspy("refresh")
            })
        }
    }), 1 <= jQuery(".flexslider-attachments").length && (void 0 !== jQuery(".flexslider-attachments").data("flexslider") && jQuery(".flexslider-attachments").flexslider("destroy"), jQuery(".flexslider-attachments").flexslider({
        video: !1,
        smoothHeight: b,
        pauseOnHover: !1,
        useCSS: !1,
        prevText: "&#xf104;",
        nextText: "&#xf105;",
        controlNav: "thumbnails",
        start: function(a) {
            jQuery(a).find(".fusion-slider-loading").remove(), a.removeClass("fusion-flexslider-loading")
        }
    }), b && jQuery(".flexslider-attachments .flex-control-nav").css("position", "absolute")))
});