! function(a, b, c) {
    for (var d, e = 0, f = function(a) {
        var d = (new Date).getTime(),
            f = d - e,
            g = Math.max(0, 16 - f),
            h = b.setTimeout(function() {
                a(d + g)
            }, g);
        return e = d + g, h
        clearTimeout(a)
        d = !1
    }
}(jQuery, this);