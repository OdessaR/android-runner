jQuery(window).load(function() {
    jQuery(".fusion-toggle-boxed-mode .panel-collapse").on("click", function(e) {
        jQuery(e.target).is("a") || jQuery(e.target).is("button") || jQuery(e.target).hasClass("fusion-button-text") || jQuery(this).parents(".fusion-panel").find(".panel-title > a").trigger("click")
        var i, n, o;
                jQuery(this).reinitializeGoogleMap()
                var e = jQuery(this).find(".fusion-portfolio-wrapper"),
                    i = e.attr("id");
                i && (e = jQuery("#" + i)), e.isotope()
            }), n.find(".fusion-gallery").each(function() {
                jQuery(this).isotope()
                jQuery(this).fusionCalcFlipBoxesHeight()
                jQuery(this).find(".fusion-layout-column .fusion-column-wrapper").equalHeights()
            }), n.find(".crossfade-images").each(function() {
                fusionResizeCrossfadeImagesContainer(jQuery(this)), fusionResizeCrossfadeImages(jQuery(this))
            }), n.find(".fusion-blog-shortcode").each(function() {
                jQuery(this).find(".fusion-blog-layout-grid").isotope()
            }), n.find(".fusion-testimonials .reviews").each(function() {
                jQuery(this).css("height", jQuery(this).children(".active-testimonial").height())
    })
}), jQuery(document).ready(function() {
    jQuery(".fusion-accordian .panel-title a").click(function(e) {
        e.preventDefault()
    })
});