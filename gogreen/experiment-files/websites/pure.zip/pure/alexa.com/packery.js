! function(a, b) {
}(window, function() {
    function a(b) {
    }
        x: 0,
        y: 0,
        width: 0,
        height: 0
    };
    return b.contains = function(a) {
        var b = a.width || 0,
            c = a.height || 0;
    }, b.overlaps = function(a) {
            d = a.x + a.width,
            e = a.y + a.height;
    }, b.getMaximalFreeRects = function(b) {
        var c, d = [],
            i = Math.round(b.x),
            j = Math.round(b.y),
            k = Math.round(b.width),
            l = Math.round(b.height),
            m = e + g,
            n = f + h,
            o = i + k,
            p = j + l;
            x: e,
            y: f,
            width: g,
            height: j - f
            x: o,
            y: f,
            width: m - o,
            height: h
            x: e,
            y: p,
            width: g,
            height: n - p
            x: e,
            y: f,
            width: i - e,
            height: h
        }), d.push(c)), d
    }, b.canFit = function(a) {
}),
function(a, b) {
    else {
        c.Packer = b(c.Rect)
    }
}(window, function(a) {
    function b(a, b, c) {
    }
    c.reset = function() {
        var b = new a({
            x: 0,
            y: 0,
        });
    }, c.pack = function(a) {
            if (c.canFit(a)) {
                break
            }
        }
    }, c.columnPack = function(a) {
            if (c.x <= a.x && c.x + c.width >= a.x + a.width && c.height >= a.height - .01) {
                break
            }
        }
    }, c.rowPack = function(a) {
            if (c.y <= a.y && c.y + c.height >= a.y + a.height && c.width >= a.width - .01) {
                break
            }
        }
    }, c.placeInSpace = function(a, b) {
    }, c.placed = function(a) {
                e = d.getMaximalFreeRects(a);
            e ? b.push.apply(b, e) : b.push(d)
        }
        if ("object" == typeof b) {
            var f = [],
                g = [];
            b.forEach(function(a) {
                if (1 < a.width) {
                    var b = a.y + 1,
                }
            }), b = f
        }
    }, c.mergeSortSpaces = function() {
    }, c.addSpace = function(a) {
        var b = 0,
            c = a[b];
        a: for (; c;) {
            for (var d = 0, e = a[b + d]; e;) {
                if (e == c) d++;
                else {
                    if (e.contains(c)) {
                        a.splice(b, 1), c = a[b];
                        continue a
                    }
                    c.contains(e) ? a.splice(b + d, 1) : d++
                }
                e = a[b + d]
            }
            b++, c = a[b]
        }
        return a
    };
    var d = {
        downwardLeftToRight: function(a, b) {
            return a.y - b.y || a.x - b.x
        },
        rightwardTopToBottom: function(a, b) {
            return a.x - b.x || a.y - b.y
        }
    };
}),
function(a, b) {
}(window, function(a, b) {
        d = "string" == typeof c.transform ? "transform" : "WebkitTransform",
        e = function() {
            a.Item.apply(this, arguments)
        },
        f = e.prototype = Object.create(a.Item.prototype),
        g = f._create;
    f._create = function() {
    };
    var h = f.moveTo;
    return f.moveTo = function(a, b) {
        h.apply(this, arguments)
    }, f.enablePlacing = function() {
    }, f.disablePlacing = function() {
    }, f.removeElem = function() {
    }, f.showDropPlaceholder = function() {
    }, f.positionDropPlaceholder = function() {
    }, f.hideDropPlaceholder = function() {
    }, e
}),
function(a, b) {
}(window, function(a, b, c, d, e) {
    function f(a, b) {
        return a.position.y - b.position.y || a.position.x - b.position.x
    }

    function g(a, b) {
        return a.position.x - b.position.x || a.position.y - b.position.y
    }

    function h(a, b) {
        var c = b.x - a.x,
            d = b.y - a.y;
        return Math.sqrt(c * c + d * d)
    }
    };
    var i = b.create("packery");
    i.Item = e;
    var j = i.prototype;
    j._create = function() {
            dragStart: function() {
            },
            dragMove: function() {
            },
            dragEnd: function() {
            }
            start: function(b, c) {
                c && a.itemDragStart(b.currentTarget)
            },
            drag: function(b, c) {
                c && a.itemDragMove(b.currentTarget, c.position.left, c.position.top)
            },
            stop: function(b, c) {
                c && a.itemDragEnd(b.currentTarget)
            }
        }
    }, j._resetLayout = function() {
        var a, b, c;
    }, j._getMeasurements = function() {
    }, j._getItemLayoutPosition = function(a) {
    }, j.shiftLayout = function() {
    }, j._getPackMethod = function() {
    }, j._setMaxXY = function(a) {
    }, j._setRectSize = function(b, c) {
        var d = a(b),
            e = d.outerWidth,
            f = d.outerHeight;
    }, j._applyGridGutter = function(a, b) {
        var c = a % b,
            d = c && c < 1 ? "round" : "ceil";
    }, j._getContainerSize = function() {
        } : {
        }
    }, j._manageStamp = function(a) {
        if (d && d.isPlacing) b = d.rect;
        else {
            b = new c({
            })
        }
    }, j.sortItemsByPosition = function() {
    }, j.fit = function(a, b, c) {
    }, j._bindFitEvents = function(a) {
        function b() {
            2 == ++d && c.dispatchEvent("fitComplete", null, [a])
        }
            d = 0;
    }, j.resize = function() {
    }, j.needsResizeLayout = function() {
    }, j.resizeShiftPercentLayout = function() {
            d = c ? "y" : "x",
            e = c ? "height" : "width",
            f = c ? "rowHeight" : "columnWidth",
            g = c ? "innerHeight" : "innerWidth",
            b.forEach(function(a) {
                var b = Math.round(a.rect[d] / h);
            })
        } else {
            b.forEach(function(a) {
            })
        }
    }, j.itemDragStart = function(a) {
        }
    }, j.updateShiftTargets = function(a) {
            if (!e || !e.isPlacing) {
                    g = new c({
                        x: b ? f.left : f.right,
                        y: d ? f.top : f.bottom
                    });
            }
        }, this);
            f = e ? "rowHeight" : "columnWidth",
            g = e ? "height" : "width";
            var j = Math.ceil(a.rect[g] / i),
            h = (k - j) * i;
        m.forEach(function(a) {
            var b = a.rect;
            var c = e ? b.x + b.width : b.x,
                d = e ? b.y : b.y + b.height;
                for (var f = Math.round(b[g] / i), j = 1; j < f; j++) {
                    var k = e ? c : b.x + i * j,
                        l = e ? b.y + i * j : d;
                }
        }, this)
    }, j._addShiftTarget = function(a, b, c) {
        if (!(0 !== d && d > c)) {
                x: a,
                y: b
            }))
        }
    }, j.shift = function(a, b, c) {
        var d, e = 1 / 0,
            f = {
                x: b,
                y: c
            };
            var b = h(a, f);
            b < e && (d = a, e = b)
    };
    j.itemDragMove = function(a, b, c) {
        function d() {
        }
        if (e) {
                g = new Date;
        }
    }, j.itemDragEnd = function(a) {
        function b() {
        }
        if (c) {
            var d = 0,
        }
    }, j.bindDraggabillyEvents = function(a) {
    }, j.unbindDraggabillyEvents = function(a) {
    }, j._bindDraggabillyEvents = function(a, b) {
        a[b]("dragStart", c.dragStart), a[b]("dragMove", c.dragMove), a[b]("dragEnd", c.dragEnd)
    }, j.bindUIDraggableEvents = function(a) {
    }, j.unbindUIDraggableEvents = function(a) {
    }, j._bindUIDraggableEvents = function(a, b) {
        a[b]("dragstart", c.start)[b]("drag", c.drag)[b]("dragstop", c.stop)
    };
    var k = j.destroy;
    return j.destroy = function() {
    }, i.Rect = c, i.Packer = d, i
}),
function(a, b) {
}(window, function(a, b) {
    var c = a.create("packery"),
        d = c.prototype,
        e = {
            _getElementOffset: !0,
            _getMeasurement: !0
        };
    for (var f in b.prototype) e[f] || (d[f] = b.prototype[f]);
    var g = d._resetLayout;
    d._resetLayout = function() {
    };
    var h = d._getItemLayoutPosition;
    d._getItemLayoutPosition = function(a) {
    };
    var i = d.needsResizeLayout;
    d.needsResizeLayout = function() {
    };
    var j = d._getOption;
    return d._getOption = function(a) {
    }, c
});