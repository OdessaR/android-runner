jQuery(document).ready(function() {
    jQuery(".fusion-video").each(function() {
        !jQuery(this).parents(".fusion-modal").length && 1 == jQuery(this).data("autoplay") && jQuery(this).is(":visible") && jQuery(this).find("iframe").each(function() {
            jQuery(this).attr("src", jQuery(this).attr("src").replace("autoplay=0", "autoplay=1"))
        })
    }), jQuery(window).on("resize", function() {
            s = i.length;
        if (jQuery(".fusion-youtube").each(function() {
                jQuery(this).is(":visible") || jQuery(this).parents(".fusion-modal").length && !jQuery(this).parents(".fusion-modal").is(":visible") || jQuery(this).find("iframe").each(function() {
                })
    })
});