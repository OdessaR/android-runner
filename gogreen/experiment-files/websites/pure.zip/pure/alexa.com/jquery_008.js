jQuery.easing.jswing = jQuery.easing.swing, jQuery.extend(jQuery.easing, {
    def: "easeOutQuad",
    swing: function(a, b, c, d, e) {
    },
    easeInQuad: function(a, b, c, d, e) {
    },
    easeOutQuad: function(a, b, c, d, e) {
    },
    easeInOutQuad: function(a, b, c, d, e) {
    },
    easeInCubic: function(a, b, c, d, e) {
    },
    easeOutCubic: function(a, b, c, d, e) {
    },
    easeInOutCubic: function(a, b, c, d, e) {
    },
    easeInQuart: function(a, b, c, d, e) {
    },
    easeOutQuart: function(a, b, c, d, e) {
    },
    easeInOutQuart: function(a, b, c, d, e) {
    },
    easeInQuint: function(a, b, c, d, e) {
    },
    easeOutQuint: function(a, b, c, d, e) {
    },
    easeInOutQuint: function(a, b, c, d, e) {
    },
    easeInSine: function(a, b, c, d, e) {
        return -d * Math.cos(b / e * (Math.PI / 2)) + d + c
    },
    easeOutSine: function(a, b, c, d, e) {
        return d * Math.sin(b / e * (Math.PI / 2)) + c
    },
    easeInOutSine: function(a, b, c, d, e) {
        return -d / 2 * (Math.cos(Math.PI * b / e) - 1) + c
    },
    easeInExpo: function(a, b, c, d, e) {
        return 0 == b ? c : d * Math.pow(2, 10 * (b / e - 1)) + c
    },
    easeOutExpo: function(a, b, c, d, e) {
        return b == e ? c + d : d * (1 - Math.pow(2, -10 * b / e)) + c
    },
    easeInOutExpo: function(a, b, c, d, e) {
    },
    easeInCirc: function(a, b, c, d, e) {
    },
    easeOutCirc: function(a, b, c, d, e) {
    },
    easeInOutCirc: function(a, b, c, d, e) {
    },
    easeInElastic: function(a, b, c, d, e) {
        var f = 1.70158,
            g = 0,
            h = d;
        if (0 == b) return c;
        if (g || (g = .3 * e), h < Math.abs(d)) {
            h = d;
            var f = g / 4
        } else var f = g / (2 * Math.PI) * Math.asin(d / h);
    },
    easeOutElastic: function(a, b, c, d, e) {
        var f = 1.70158,
            g = 0,
            h = d;
        if (0 == b) return c;
        if (g || (g = .3 * e), h < Math.abs(d)) {
            h = d;
            var f = g / 4
        } else var f = g / (2 * Math.PI) * Math.asin(d / h);
        return h * Math.pow(2, -10 * b) * Math.sin((b * e - f) * (2 * Math.PI) / g) + d + c
    },
    easeInOutElastic: function(a, b, c, d, e) {
        var f = 1.70158,
            g = 0,
            h = d;
        if (0 == b) return c;
        if (g || (g = e * (.3 * 1.5)), h < Math.abs(d)) {
            h = d;
            var f = g / 4
        } else var f = g / (2 * Math.PI) * Math.asin(d / h);
    },
    easeInBack: function(a, b, c, d, e, f) {
    },
    easeOutBack: function(a, b, c, d, e, f) {
    },
    easeInOutBack: function(a, b, c, d, e, f) {
    },
    easeInBounce: function(a, b, c, d, e) {
    },
    easeOutBounce: function(a, b, c, d, e) {
    },
    easeInOutBounce: function(a, b, c, d, e) {
    }
});