var headerHeight = jQuery(".fusion-header-wrapper").height(),
    fusionReanimateSlider = function(a) {
        var b = a.find(".slide-content"),
            c = a.siblings(".tfs-scroll-down-indicator");
        jQuery(b).each(function() {
            jQuery(this).stop(!0, !0), jQuery(this).css("margin-top", "50px"), jQuery(this).animate({
                opacity: "1",
                "margin-top": "0"
            }, 1e3)
        }), jQuery(c).each(function() {
            var a = jQuery(this);
            a.stop(!0, !0), a.css("opacity", "0"), b.offset().top + b.height() + 25 < a.offset().top && (a.css("padding-bottom", "50px"), setTimeout(function() {
                a.animate({
                    opacity: "1",
                    "padding-bottom": "0"
                }, 500, "easeOutCubic")
            }, 500))
        })
    };
! function(a) {
    "use strict";
    a(".tfs-slider").each(function() {
    })
}(jQuery), jQuery(window).load(function() {
    jQuery().flexslider && jQuery(".tfs-slider").each(function() {
            m = jQuery(l).find("li").get(0);
            var a, c = jQuery(this).width() / jQuery(this).height(),
                d = c * b,
                e = "-" + (d - jQuery(l).width()) / 2 + "px",
                f = jQuery(l).parent().parent().parent().width();
            jQuery(l).parents(".post-content").length && (f = jQuery(l).width()), f > d ? (d = "100%", e = 0, a = "static") : a = "absolute", jQuery(this).width(d), jQuery(this).css({
                left: e,
                position: a
            })
            jQuery(this).removeClass("button-xlarge button-large button-medium"), jQuery(this).addClass("button-small")
        }), jQuery(l).find("li").each(function() {
            jQuery(this).attr("data-autoplay", "no"), jQuery(this).data("autoplay", "no")
        })), jQuery(l).find("a.button").each(function() {
            jQuery(this).data("old", jQuery(this).attr("class"))
            jQuery(this).data("old", jQuery(this).attr("class")), jQuery(this).removeClass("button-xlarge button-large button-medium"), jQuery(this).addClass("button-small")
        }) : jQuery(l).find("a.button").each(function() {
            jQuery(this).attr("class", jQuery(this).data("old"))
        })), jQuery(window).scroll(function() {
        })), h = jQuery(window).width(), i = jQuery(window).height(), jQuery(window).on("resize", function() {
            var a, b, c, d, e, f, g, j, k, m, n, o, p;
            (h !== jQuery(window).width() || h !== jQuery(window).width() && i !== jQuery(window).height()) && (a = jQuery(".fusion-header-wrapper").height(), b = 0, void 0 !== jQuery(l).find(".flex-active-slide").find(".tfs-scroll-down-indicator").offset() && jQuery(l).find(".flex-active-slide").find(".slide-content").offset().top + jQuery(l).find(".flex-active-slide").find(".slide-content").height() + 25 < jQuery(l).find(".flex-active-slide").find(".tfs-scroll-down-indicator").offset().top ? jQuery(l).find(".flex-active-slide").find(".tfs-scroll-down-indicator").css("opacity", "1") : jQuery(l).find(".flex-active-slide").find(".tfs-scroll-down-indicator").css("opacity", "0"), jQuery("#wpadminbar").length && (b = jQuery("#wpadminbar").height()), e = Math.max.apply(null, jQuery(l).find(".slide-content").map(function() {
                return jQuery(this).outerHeight()
                jQuery(l).find("video").each(function() {
                    var a, b = jQuery(this).width() / jQuery(this).height(),
                        d = b * c,
                        e = "-" + (d - jQuery(l).width()) / 2 + "px",
                        f = jQuery(l).parent().parent().parent().width();
                    jQuery(l).parents(".post-content").length && (f = jQuery(l).width()), f > d ? (d = "100%", e = 0, a = "static") : a = "absolute", jQuery(this).width(d), jQuery(this).css({
                        left: e,
                        position: a
                    })
                })
            }, 100)) : (d = jQuery(l).data("slider_width"), -1 !== d.indexOf("%") ? (d = jQuery(l).data("first_slide_width"), d < jQuery(l).data("slider_width") && (d = jQuery(l).data("slider_width")), f = !0) : d = parseInt(jQuery(l).data("slider_width"), 10), c = parseInt(jQuery(l).data("slider_height"), 10), g = c / d, .5 > g && (g = .5), j = jQuery(l).parent().parent().parent().width(), 1 <= jQuery(l).parents(".post-content").length && (j = jQuery(l).width(), jQuery(l).parents(".tab-content").length && (j = jQuery(l).parents(".tab-content").width() - 60)), c = g * j, c > parseInt(jQuery(l).data("slider_height"), 10) && (c = parseInt(jQuery(l).data("slider_height"), 10)), 200 > c && (c = 200), c < e && e <= parseInt(jQuery(l).data("slider_height"), 10) && (c = e), jQuery(l).find("video").each(function() {
                var a, b, e = jQuery(this).width() / jQuery(this).height(),
                    g = e * c;
                g < d && !jQuery(l).hasClass("full-width-slider") && (g = d), a = "-" + (g - jQuery(l).width()) / 2 + "px", b = jQuery(l).parent().parent().parent().width(), 1 <= jQuery(l).parents(".post-content").length && (b = jQuery(l).width()), b > g && !0 === f && 1 != jQuery(l).data("full_screen") && (g = "100%", a = 0), jQuery(this).width(g), jQuery(this).css("left", a)
                void 0 === jQuery(this).data("old") && jQuery(this).data("old", jQuery(this).attr("class")), jQuery(this).removeClass("button-xlarge button-large button-medium"), jQuery(this).addClass("button-small")
            }) : jQuery(l).find(".fusion-button").each(function() {
                jQuery(this).attr("class", jQuery(this).data("old"))
                jQuery(this).css("padding-top", "")
                jQuery(this).css("padding-top", a + "px")
                var a, b, d = jQuery(".mobile_video_image").css("background-image").replace("url(", "").replace(")", "");
                        d = jQuery(l).parent().parent().parent().width();
                    1 <= jQuery(l).parents(".post-content").length && (d = jQuery(l).width()), (b = a * d) < c && (jQuery(l).find(".mobile_video_image").css("height", b), jQuery(l).css("height", b))
                })
        }), 1 <= jQuery(l).parents(".post-content").length && (jQuery(l).css("max-width", "100%"), "slide" !== jQuery(l).data("animation") && jQuery(l).find(".slides").css("max-width", "100%")), jQuery(l).find("video").each(function() {
            "function" == typeof jQuery(this)[0].pause && jQuery(this)[0].pause()
        }), jQuery(l).flexslider({
            animation: jQuery(l).data("animation"),
            slideshow: jQuery(l).data("autoplay"),
            slideshowSpeed: jQuery(l).data("slideshow_speed"),
            animationSpeed: jQuery(l).data("animation_speed"),
            controlNav: Boolean("pagination_circles" === jQuery(l).data("slider_indicator")),
            directionNav: Boolean(Number(jQuery(l).data("nav_arrows"))),
            animationLoop: Boolean(Number(jQuery(l).data("loop"))),
            smoothHeight: !0,
            pauseOnHover: !1,
            useCSS: !0,
            video: !0,
            touch: !0,
            prevText: "&#xe61e;",
            nextText: "&#xe620;",
            start: function(a) {
                var b, c, e, f, h, i, j, k, n = 0;
                    return jQuery(this).outerHeight()
                    var a = jQuery(this).width() / jQuery(this).height(),
                        b = a * c,
                        d = "-" + (b - jQuery(l).width()) / 2 + "px";
                    h = jQuery(l).parent().parent().parent().width(), 1 <= jQuery(l).parents(".post-content").length && (h = jQuery(l).width()), h > b && (b = "100%", d = 0), jQuery(this).width(b), jQuery(this).css("left", d)
                    var a, b, d = jQuery(this).width() / jQuery(this).height(),
                        g = d * c;
                    g < e && !jQuery(l).hasClass("full-width-slider") && (g = e), a = "-" + (g - jQuery(l).width()) / 2 + "px", b = jQuery(l).parent().parent().parent().width(), 1 <= jQuery(l).parents(".post-content").length && (b = jQuery(l).width()), b > g && !0 === f && 1 != jQuery(l).data("full_screen") && (g = "100%", a = 0), jQuery(this).width(g), jQuery(this).css("left", a)
                    jQuery(this).css("padding-top", "")
                }))), g = jQuery(l).find(".slide-content-container"), jQuery(a.slides.eq(a.currentSlide)).find("video").each(function() {
                    "yes" === jQuery(this).parents("li").attr("data-autoplay") && "function" == typeof jQuery(this)[0].play && jQuery(this)[0].play()
                })), fusionReanimateSlider(g), void 0 !== a.slides && 0 !== a.slides.eq(a.currentSlide).find("iframe").length && playVideoAndPauseOthers(a), jQuery(l).find(".overlay-link").hide(), jQuery(a.slides.eq(a.currentSlide)).find(".overlay-link").show(), jQuery(l).find("[data-youtube-video-id], [data-vimeo-video-id]").each(function() {
                    var a = jQuery(this);
                    setTimeout(function() {
                        resizeVideo(a)
                    }, 500)
            },
            before: function() {
                jQuery(l).find(".slide-content-container").hide(), jQuery(l).find(".tfs-scroll-down-indicator").hide()
            },
            after: function(a) {
                    resizeVideo(jQuery(this))
                }), playVideoAndPauseOthers(a), jQuery('[data-spy="scroll"]').each(function() {
                    jQuery(this).scrollspy("refresh")
                })
            }
        })
    })
});