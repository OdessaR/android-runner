jQuery(window).load(function() {
        jQuery(this).attr("data-trigger", "click"), jQuery(this).data("trigger", "click")
    }), jQuery('[data-toggle~="popover"]').popover({
        container: "body"
    })
});