jQuery(document).ready(function() {
    "use strict";

    function a(a) {
            jQuery(this).find("> div").length && 0 > jQuery(this).find("> div").offset().left && jQuery(this).find("> div").css({
                left: "0",
                right: "auto"
            }), jQuery(this).find("> div").length && jQuery(this).find("> div").offset().left + jQuery(this).find("> div").width() > jQuery(window).width() && jQuery(this).find("> div").css({
                left: "auto",
                right: "0"
            })
        }), jQuery(window).on("resize", function() {
            jQuery(a).find("> div").each(function() {
                var a = jQuery(this),
                    b = a.outerWidth(),
                    c = a.offset().left,
                    d = c + b,
                    e = a.parent().offset().left,
                    f = jQuery(window).width();
                jQuery("body.rtl").length ? c == e && d > f || c < e && d + b > f ? a.css({
                    left: "auto",
                    right: "0"
                }) : a.css({
                    left: "0",
                    right: "auto"
                }) : c < e && 0 > c || c == e && 0 > c - b ? a.css({
                    left: "0",
                    right: "auto"
                }) : a.css({
                    left: "auto",
                    right: "0"
                })
            })
        }))
    }

    function b() {
        var a, b, c = jQuery(".fusion-header-has-flyout-menu"),
            d = 0,
            e = c.find(".fusion-header").offset().top;
        jQuery("body").bind("touchmove", function(a) {
            jQuery(a.target).parents(".fusion-flyout-menu").length || a.preventDefault()
        }), 1 <= jQuery(".fusion-mobile-menu-design-flyout").length ? (b = 1 <= jQuery(".fusion-is-sticky").length && 1 <= jQuery(".fusion-mobile-sticky-nav-holder").length ? c.find(".fusion-flyout-menu.fusion-mobile-sticky-nav-holder") : c.find(".fusion-flyout-menu:not(.fusion-mobile-sticky-nav-holder)"), c.find(".fusion-flyout-menu").css({
            display: "none"
        }), b.css({
            display: "flex"
            height: "calc(100% - " + a + "px)",
            "margin-top": a
            position: "fixed",
            width: "100%",
            "max-width": "100%",
            "z-index": "210"
        }), jQuery(".fusion-header-sticky-height").css({
            display: "block",
            height: c.find(".fusion-header").outerHeight()
            position: "fixed",
        }), jQuery(".layout-boxed-mode").length && c.find(".fusion-header").css("max-width", jQuery("#wrapper").outerWidth() + "px"), jQuery(".fusion-header-wrapper").css("height", ""))
    }

    function c() {
        setTimeout(function() {
            var a = jQuery(".fusion-header-has-flyout-menu"),
                b = 0;
        }, 250)
    }
    var d;
    jQuery(".fusion-dropdown-svg").length && jQuery(".fusion-dropdown-svg").each(function() {
        var a = jQuery(this).parents("li").find("> .sub-menu > li:first-child");
        (jQuery(a).hasClass("current-menu-item") || jQuery(a).hasClass("current-menu-parent") || jQuery(a).hasClass("current_page_item")) && jQuery(this).addClass("fusion-svg-active"), jQuery(a).not(".current-menu-item, .current-menu-parent, .current_page_item").find("> a").on("hover", function() {
            jQuery(this).parents("li").find(".fusion-dropdown-svg").toggleClass("fusion-svg-active")
        })
            var a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p = jQuery(this);
            p.removeAttr("style"), p.show(), p.removeData("shifted"), p.length && (a = p.offset(), b = a.left, c = a.top, d = p.height(), e = p.outerWidth(), f = c + d, g = b + e, j = jQuery("#wpadminbar").length ? jQuery("#wpadminbar").height() : 0, k = jQuery(window).scrollTop(), l = jQuery(window).height(), m = k + l, h = jQuery(window).width(), g > h ? (p.addClass("fusion-switched-side"), p.parent().parent(".sub-menu").length ? p.css({
                left: -1 * e
                p.parents("li").find(".fusion-dropdown-svg").toggleClass("fusion-svg-active")
            })), p.css("top", i)))
        }) : jQuery(this).children(".sub-menu").each(function() {
            var a, b, c, d, e, f, g, h, i, j, k, l, m, n, o;
                a.parents("li").find(".fusion-dropdown-svg").toggleClass("fusion-svg-active")
            })), a.css("top", l)))
        })
        jQuery(this).fusion_position_menu_dropdown(), jQuery(this).find(".sub-menu").length && jQuery(this).find(".sub-menu li").walk_through_menu_items()
            var a, b, c, d = jQuery(this),
                e = d.height(),
                f = jQuery("#wpadminbar").length ? jQuery("#wpadminbar").height() : 0,
                g = jQuery(window).scrollTop(),
                h = jQuery(window).height(),
                i = g + h;
            d.css("top", ""), a = d.offset().top, (b = a + e) > i && (c = e < h ? -1 * (b - i + 10) : -1 * (a - g - f), d.css("top", c))
        })
            var a, b, c, d = jQuery(this),
                e = d.outerHeight(),
                f = jQuery(window).scrollTop(),
                g = jQuery(window).height(),
                h = f + g;
            d.css("top", ""), a = d.offset().top, (b = a + e) > h && (c = -1 * (b - h + 10), d.css("top", c))
        })
        var a, b, c, d, e, f;
            jQuery(this).children("li").each(function() {
                var a, b, c, d, e, f, g, h, i = jQuery(this),
                    j = i.find(".fusion-megamenu-wrapper");
                j.length && (j.removeAttr("style"), a = jQuery("#side-header").outerWidth() - 1, b = j.offset().top, c = j.height(), d = b + c, e = jQuery("#wpadminbar").length ? jQuery("#wpadminbar").height() : 0, f = jQuery(".side-header-wrapper").offset().top - e, g = jQuery(window).height(), jQuery("body.rtl").length ? j.css({
                    left: a,
                    right: "auto"
                }) : j.css("left", a), d > f + g && jQuery(window).height() >= jQuery(".side-header-wrapper").height() && (h = c < g ? -1 * (d - f - g + 20) : -1 * (b - e), j.css("top", h)))
            })
            jQuery(this).children("li").each(function() {
                var a, b, c, d, e, f, g, h, i = jQuery(this),
                    j = i.find(".fusion-megamenu-wrapper");
                j.length && (j.removeAttr("style"), a = -1 * j.outerWidth(), b = j.offset().top, c = j.height(), d = b + c, e = jQuery("#wpadminbar").length ? jQuery("#wpadminbar").height() : 0, f = jQuery(".side-header-wrapper").offset().top - e, g = jQuery(window).height(), jQuery("body.rtl").length ? j.css({
                    left: a,
                    right: "auto"
                }) : j.css("left", a), d > f + g && jQuery(window).height() >= jQuery(".side-header-wrapper").height() && (h = c < g ? -1 * (d - f - g + 20) : -1 * (b - e), j.css("top", h)))
            })
            jQuery(this).children("li").each(function() {
                var a, b = jQuery(this),
                    c = b.offset(),
                    d = c.left + b.outerWidth(),
                    g = b.find(".fusion-megamenu-wrapper"),
                    h = g.outerWidth(),
                    i = 0;
            })
            jQuery(this).children("li").each(function() {
                var a = jQuery(this),
                    b = a.offset(),
                    c = a.find(".fusion-megamenu-wrapper"),
                    d = c.outerWidth(),
                    g = 0,
                    h = 0;
            })
        })) : void 0)
        jQuery(this).find(".fusion-megamenu-menu").each(function() {
            var a, b = jQuery(this).find(".fusion-megamenu-holder"),
                c = b.data("width"),
                d = jQuery(".fusion-secondary-main-menu").length ? jQuery(".fusion-header-wrapper .fusion-secondary-main-menu .fusion-row") : jQuery(".fusion-header-wrapper .fusion-row"),
                e = d.width();
                var a = jQuery(this),
                    b = a.data("width") * e / c;
                a.css("width", b)
            })) : (b.css("width", c), b.parents(".fusion-megamenu-wrapper").hasClass("fusion-megamenu-fullwidth") || b.find(".fusion-megamenu-submenu").each(function() {
                jQuery(this).css("width", jQuery(this).data("width"))
            }))
        })
        var a, b, c, d, e, f;
        (jQuery(this).children("ul").length || jQuery(this).children("div").length) && (a = jQuery(this), b = a.position().left, a.outerWidth(), d = jQuery(".fusion-secondary-header .fusion-row"), e = d.position().left, f = d.outerWidth(), a.children("ul").length ? c = a.children("ul") : a.children("div").length && (c = a.children("div")), jQuery("body.rtl").length ? c.position().left < b && (c.css("left", "-1px").css("right", "auto"), c.find(".sub-menu").each(function() {
            jQuery(this).css("left", "100px").css("right", "auto")
        })) : b + c.outerWidth() > e + f && (c.css("right", "-1px").css("left", "auto"), c.find(".sub-menu").each(function() {
            jQuery(this).css("right", "100px").css("left", "auto")
        })))
        jQuery(this).fusion_position_menu_dropdown()
    }), jQuery(".fusion-dropdown-menu > ul > li").each(function() {
        jQuery(this).walk_through_menu_items()
    }), jQuery(window).on("resize", function() {
        jQuery(".fusion-dropdown-menu > ul > li").each(function() {
            jQuery(this).walk_through_menu_items()
        })
    })), jQuery(".fusion-dropdown-menu").mouseenter(function() {
        jQuery(this).css("overflow", "visible")
    }), jQuery(".fusion-dropdown-menu, .fusion-megamenu-menu, .fusion-custom-menu-item ").mouseleave(function() {
        jQuery(this).css("overflow", ""), jQuery(".fusion-active-link").removeClass("fusion-active-link")
    }), jQuery("a").on("focus", function() {
        jQuery(".fusion-active-link ").removeClass("fusion-active-link"), jQuery(this).parents(".fusion-dropdown-menu, .fusion-main-menu-cart, .fusion-megamenu-menu, .fusion-custom-menu-item").length && (jQuery(this).parents("li").addClass("fusion-active-link"), jQuery(".fusion-main-menu").css("overflow", "visible"))
    }), jQuery(document).click(function() {
        jQuery(".fusion-main-menu-search .fusion-custom-menu-item-contents").hide(), jQuery(".fusion-main-menu-search").removeClass("fusion-main-menu-search-open"), jQuery(".fusion-main-menu-search").find("style").remove()
    }), jQuery(".fusion-main-menu-search").click(function(a) {
        a.stopPropagation()
    }), jQuery(".fusion-main-menu-search .fusion-main-menu-icon").click(function(a) {
            left: "0",
            right: "auto"
        }), jQuery("body.rtl").length && jQuery(this).parent().find(".fusion-custom-menu-item-contents").offset().left + jQuery(this).parent().find(".fusion-custom-menu-item-contents").width() > jQuery(window).width() && jQuery(this).parent().find(".fusion-custom-menu-item-contents").css({
            left: "auto",
            right: "0"
        })))
        jQuery(this).parent().fusion_position_megamenu()
    }), jQuery(window).resize(function() {
        jQuery(".fusion-main-menu > ul").fusion_position_megamenu()
        jQuery(".fusion-main-menu > ul").calc_megamenu_responsive_column_widths()
    })), jQuery(".fusion-header-wrapper .fusion-secondary-menu > ul > li:last-child").position_last_top_menu_item(), a(".fusion-main-menu .fusion-main-menu-cart"), a(".fusion-secondary-menu .fusion-menu-login-box"), jQuery(".fusion-megamenu-menu").mouseenter(function() {
        jQuery(this).find(".shortcode-map").length && jQuery(this).find(".shortcode-map").each(function() {
            jQuery(this).reinitializeGoogleMap()
        })
    }), d = !1, jQuery(".fusion-megamenu-menu").mouseover(function() {
        jQuery(this).find(".fusion-megamenu-widgets-container iframe").each(function() {
            d || jQuery(this).attr("src", jQuery(this).attr("src")), d = !0
        })
    }), jQuery(".fusion-megamenu-wrapper iframe").mouseover(function() {
        jQuery(this).parents(".fusion-megamenu-widgets-container").css("display", "block"), jQuery(this).parents(".fusion-megamenu-wrapper").css({
            opacity: "1",
            visibility: "visible"
        })
    }), jQuery(".fusion-megamenu-wrapper iframe").mouseout(function() {
        jQuery(this).parents(".fusion-megamenu-widgets-container").css("display", ""), jQuery(this).parents(".fusion-megamenu-wrapper").css({
            opacity: "",
            visibility: ""
        })
    }), jQuery(".fusion-main-menu").on("mouseenter", ".fusion-menu-cart", function() {
        jQuery(this).position_cart_dropdown()
    }), jQuery(".fusion-main-menu .fusion-main-menu-search .fusion-main-menu-icon").click(function() {
        var a = jQuery(this);
        setTimeout(function() {
            a.parent().find(".fusion-custom-menu-item-contents").position_menu_search_form()
        }, 5)
    }), jQuery(window).on("resize", function() {
        jQuery(".fusion-main-menu .fusion-main-menu-search .fusion-custom-menu-item-contents").position_menu_search_form()
    }), jQuery(".fusion-mobile-nav-holder").not(".fusion-mobile-sticky-nav-holder").each(function() {
        var a = jQuery(this),
            b = "",
            c = "",
            d = "";
            var a = "fusion-mobile-nav-item";
            jQuery(this).data("classes") && (a += " " + jQuery(this).data("classes")), jQuery(this).find("img").hasClass("wpml-ls-flag") && (a += " wpml-ls-item"), jQuery(this).hasClass("menu-item-has-children") && (a += " menu-item-has-children"), jQuery(this).find("> a > .menu-text").removeAttr("class").addClass("menu-text"), (jQuery(this).hasClass("current-menu-item") || jQuery(this).hasClass("current-menu-parent") || jQuery(this).hasClass("current-menu-ancestor")) && (a += " fusion-mobile-current-nav-item"), jQuery(this).attr("class", a), jQuery(this).attr("id") && jQuery(this).attr("id", jQuery(this).attr("id").replace("menu-item", "mobile-menu-item")), jQuery(this).attr("style", "")
        }), jQuery(this).find(".fusion-mobile-selector").click(function() {
            b.hasClass("mobile-menu-expanded") ? (b.removeClass("mobile-menu-expanded"), jQuery(this).attr("aria-expanded", "false")) : (b.addClass("mobile-menu-expanded"), jQuery(this).attr("aria-expanded", "true")), b.slideToggle(200, "easeOutQuad"), jQuery(".fusion-mobile-menu-search").slideToggle(200, "easeOutQuad")
        }))
    }), jQuery(".fusion-mobile-sticky-nav-holder").each(function() {
        var a = jQuery(this),
            b = "",
            c = jQuery(this).parent().find(".fusion-sticky-menu");
            var a = "fusion-mobile-nav-item";
            jQuery(this).data("classes") && (a += " " + jQuery(this).data("classes")), jQuery(this).find("img").hasClass("wpml-ls-flag") && (a += " wpml-ls-item"), (jQuery(this).hasClass("current-menu-item") || jQuery(this).hasClass("current-menu-parent") || jQuery(this).hasClass("current-menu-ancestor")) && (a += " fusion-mobile-current-nav-item"), jQuery(this).attr("class", a), jQuery(this).attr("id") && jQuery(this).attr("id", jQuery(this).attr("id").replace("menu-item", "mobile-menu-item")), jQuery(this).attr("style", "")
        }), jQuery(this).find(".fusion-mobile-selector").click(function() {
            b.hasClass("mobile-menu-expanded") ? (b.removeClass("mobile-menu-expanded"), jQuery(this).attr("aria-expanded", "false")) : (b.addClass("mobile-menu-expanded"), jQuery(this).attr("aria-expanded", "true")), b.slideToggle(200, "easeOutQuad"), jQuery(".fusion-mobile-menu-search").slideToggle(200, "easeOutQuad")
        })
    }), jQuery(".fusion-mobile-nav-holder > ul > li").each(function() {
        jQuery(this).find(".fusion-megamenu-widgets-container").remove(), jQuery(this).find(".fusion-megamenu-holder > ul").each(function() {
            jQuery(this).attr("class", "sub-menu"), jQuery(this).attr("style", ""), jQuery(this).find("> li").each(function() {
                var a, b = "fusion-mobile-nav-item";
                jQuery(this).data("classes") && (b += " " + jQuery(this).data("classes")), jQuery(this).find("img").hasClass("wpml-ls-flag") && (b += " wpml-ls-item"), (jQuery(this).hasClass("current-menu-item") || jQuery(this).hasClass("current-menu-parent") || jQuery(this).hasClass("current-menu-ancestor") || jQuery(this).hasClass("fusion-mobile-current-nav-item")) && (b += " fusion-mobile-current-nav-item"), jQuery(this).hasClass("menu-item-has-children") && (b += " menu-item-has-children"), jQuery(this).attr("class", b), jQuery(this).find(".fusion-megamenu-title a, > a").length || (jQuery(this).find(".fusion-megamenu-title").each(function() {
                    jQuery(this).children("a").length || jQuery(this).append('<a href="#">' + jQuery(this).text() + "</a>")
                }), jQuery(this).find(".fusion-megamenu-title").length || (a = jQuery(this), jQuery(this).find(".sub-menu").each(function() {
                    a.after(jQuery(this))
                }), jQuery(this).remove())), jQuery(this).prepend(jQuery(this).find(".fusion-megamenu-title a, > a")), jQuery(this).find(".fusion-megamenu-title").remove()
            }), jQuery(this).closest(".fusion-mobile-nav-item").append(jQuery(this))
        }), jQuery(this).find(".fusion-megamenu-wrapper, .caret, .fusion-megamenu-bullet").remove()
    }), jQuery(".fusion-is-sticky").length && jQuery(".fusion-mobile-sticky-nav-holder").length ? jQuery(".fusion-mobile-menu-icons .fusion-icon-bars").attr("aria-controls", jQuery(".fusion-mobile-sticky-nav-holder > ul").attr("id")) : jQuery(".fusion-mobile-menu-icons .fusion-icon-bars").attr("aria-controls", jQuery(".fusion-mobile-nav-holder").not(".fusion-mobile-sticky-nav-holder").find("> ul").attr("id")), jQuery(window).scroll(function() {
        setTimeout(function() {
            jQuery(".fusion-is-sticky").length && jQuery(".fusion-mobile-sticky-nav-holder").length ? jQuery(".fusion-mobile-menu-icons .fusion-icon-bars").attr("aria-controls", jQuery(".fusion-mobile-sticky-nav-holder > ul").attr("id")) : jQuery(".fusion-mobile-menu-icons .fusion-icon-bars").attr("aria-controls", jQuery(".fusion-mobile-nav-holder").not(".fusion-mobile-sticky-nav-holder").find("> ul").attr("id"))
        }, 50)
    }), jQuery(".fusion-mobile-menu-icons .fusion-icon-bars").click(function(a) {
        var b, c;
        a.preventDefault(), b = 1 <= jQuery(".fusion-header-v4").length || 1 <= jQuery(".fusion-header-v5").length ? ".fusion-secondary-main-menu" : 1 <= jQuery("#side-header").length ? "#side-header" : ".fusion-header", c = 1 <= jQuery(".fusion-is-sticky").length && 1 <= jQuery(".fusion-mobile-sticky-nav-holder").length ? jQuery(b).find(".fusion-mobile-sticky-nav-holder") : jQuery(b).find(".fusion-mobile-nav-holder").not(".fusion-mobile-sticky-nav-holder"), c.slideToggle(200, "easeOutQuad"), c.toggleClass("fusion-mobile-menu-expanded"), c.hasClass("fusion-mobile-menu-expanded") ? jQuery(this).attr("aria-expanded", "true") : jQuery(this).attr("aria-expanded", "false")
    }), jQuery(".fusion-mobile-menu-icons .fusion-icon-search").click(function(a) {
        a.preventDefault(), jQuery(".fusion-mobile-menu-search").slideToggle(200, "easeOutQuad")
    }), jQuery('.fusion-mobile-nav-holder .fusion-mobile-nav-item a:not([href="#"])').click(function() {
        var a = "fusion-mobile-nav-item";
    }), jQuery(".fusion-mobile-nav-holder .fusion-open-submenu").click(function(a) {
        var b = jQuery(this).parent().children(".sub-menu");
    }), jQuery(".fusion-mobile-nav-holder a").click(function(a) {
        "#" === jQuery(this).attr("href") && ("modal" === jQuery(this).data("toggle") ? jQuery(this).trigger("show.bs.modal") : (a.preventDefault(), a.stopPropagation()), jQuery(this).prev(".fusion-open-submenu").trigger("click"))
    })), jQuery(".fusion-flyout-menu-icons .fusion-flyout-menu-toggle").on("click", function(a) {
        var d = jQuery(".fusion-header-has-flyout-menu");
        a.preventDefault(), d.hasClass("fusion-flyout-active") ? (d.hasClass("fusion-flyout-search-active") ? (d.addClass("fusion-flyout-menu-active"), b()) : (d.removeClass("fusion-flyout-active"), d.removeClass("fusion-flyout-menu-active"), c()), d.removeClass("fusion-flyout-search-active")) : (d.addClass("fusion-flyout-active"), d.addClass("fusion-flyout-menu-active"), b())
    }), jQuery(".fusion-flyout-menu-icons .fusion-flyout-search-toggle").on("click", function(a) {
        var d = jQuery(".fusion-header-has-flyout-menu");
    }), jQuery(window).resize(function() {
    })
}), jQuery(window).load(function() {
    function a() {
        var a = 0;
            a += jQuery(this).outerWidth(!0) + 2
            position: "absolute",
            top: jQuery(".fusion-secondary-menu > ul > li").height() - 1 + "px",
            width: "100%",
            "border-bottom-width": "1px",
            "border-bottom-style": "solid"
    }
        jQuery(this).parents("li").remove()
    }), jQuery(".sh-mobile-nav-holder ul#mobile-nav").find("li").each(function() {
        var a = "mobile-nav-item";
        (jQuery(this).hasClass("current-menu-item") || jQuery(this).hasClass("current-menu-parent") || jQuery(this).hasClass("current-menu-ancestor")) && (a += " mobile-current-nav-item"), jQuery(this).attr("class", a), jQuery(this).attr("id") && jQuery(this).attr("id", jQuery(this).attr("id").replace("menu-item", "mobile-menu-item")), jQuery(this).attr("style", "")
    }), jQuery(".sh-mobile-nav-holder .mobile-selector").click(function() {
        jQuery(".sh-mobile-nav-holder #mobile-nav").hasClass("mobile-menu-expanded") ? jQuery(".sh-mobile-nav-holder #mobile-nav").removeClass("mobile-menu-expanded") : jQuery(".sh-mobile-nav-holder #mobile-nav").addClass("mobile-menu-expanded"), jQuery(".sh-mobile-nav-holder #mobile-nav").slideToggle(200, "easeOutQuad")
            var a = "mobile-nav-item";
            (jQuery(this).hasClass("current-menu-item") || jQuery(this).hasClass("current-menu-parent") || jQuery(this).hasClass("current-menu-ancestor") || jQuery(this).hasClass("mobile-current-nav-item")) && (a += " mobile-current-nav-item"), jQuery(this).attr("class", a), jQuery(this).find(" > ul").length && (jQuery(this).prepend('<span href="#" aria-haspopup="true" class="open-submenu"></span>'), jQuery(this).find(" > ul").hide())
        }),
        jQuery(".header-wrapper .mobile-topnav-holder .open-submenu, .header-wrapper .mobile-nav-holder .open-submenu, .sticky-header .mobile-nav-holder .open-submenu, .sh-mobile-nav-holder .open-submenu").click(function(a) {
            a.stopPropagation(), jQuery(this).parent().children(".sub-menu").slideToggle(200, "easeOutQuad")
        var a = jQuery(this);
        return a.hasClass("hover") ? (a.removeClass("hover"), !0) : (a.addClass("hover"), jQuery(".fusion-main-menu li.menu-item-has-children > a, .fusion-secondary-menu li.menu-item-has-children > a, .order-dropdown > li .current-li").not(this).removeClass("hover"), !1)
    }), jQuery(".sub-menu li, .fusion-mobile-nav-item li").not("li.menu-item-has-children").on("click", function() {
        var a = jQuery(this).find("a").attr("href");
    })), jQuery(".fusion-main-menu li.menu-item-has-children > a, .fusion-secondary-menu li.menu-item-has-children > a, .side-nav li.page_item_has_children > a").each(function() {
        jQuery(this).attr("aria-haspopup", "true")
        jQuery(".main-nav-search").each(function() {
            var a, b, c, d, e, f;
            jQuery(this).hasClass("search-box-open") && (a = jQuery(this).find(".main-nav-search-form"), b = a.outerWidth(), c = a.offset().left, d = c + b, e = a.parent().offset().left, f = jQuery(window).width(), jQuery("body.rtl").length ? c == e && d > f || c < e && d + b > f ? a.css({
                left: "auto",
                right: "0"
            }) : a.css({
                left: "0",
                right: "auto"
            }) : c < e && 0 > c || c == e && 0 > c - b ? a.css({
                left: "0",
                right: "auto"
            }) : a.css({
                left: "auto",
                right: "0"
            }))
        })
    }), jQuery(window).on("resize", function() {
        a()
    }), jQuery(".fusion-custom-menu-item").on("hover", function(a) {
        var b = jQuery(this),
            c = b.find(".fusion-custom-menu-item-contents");
        c.find("input").click(function() {
            b.addClass("fusion-active-login")
        }), c.find("input").on("change", function(a) {
            b.hasClass("fusion-active-login") && b.removeClass("fusion-active-login").addClass("fusion-active-link")
        })
    }), jQuery(document).click(function(a) {
        "fusion-custom-menu-item-contents" !== a.target.className && "input-text" !== a.target.className && jQuery(".fusion-custom-menu-item-contents").parents(".fusion-custom-menu-item").removeClass("fusion-active-login").removeClass("fusion-active-link")
    })
});