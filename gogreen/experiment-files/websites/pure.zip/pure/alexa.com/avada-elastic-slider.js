jQuery(window).load(function() {
    var a;
    jQuery().eislideshow && (a = {
});