! function(a, b, c) {
    function d(a) {
        var b = {},
            d = /^jQuery\d+$/;
        return c.each(a.attributes, function(a, c) {
            c.specified && !d.test(c.name) && (b[c.name] = c.value)
        }), b
    }

    function e(a, b) {
            e = c(d);
        if (d.value == e.attr("placeholder") && e.hasClass("placeholder"))
            if (e.data("placeholder-password")) {
                if (e = e.hide().next().show().attr("id", e.removeAttr("id").data("placeholder-id")), !0 === a) return e[0].value = b;
                e.focus()
            } else d.value = "", e.removeClass("placeholder"), d == g() && d.select()
    }

    function f() {
            f = c(b),
        if ("" == b.value) {
            if ("password" == b.type) {
                if (!f.data("placeholder-textinput")) {
                    try {
                        a = f.clone().attr({
                            type: "text"
                        })
                    } catch (b) {
                        a = c("<input>").attr(c.extend(d(this), {
                            type: "text"
                        }))
                    }
                    a.removeAttr("name").data({
                        "placeholder-password": f,
                        "placeholder-id": g
                    }).bind("focus.placeholder", e), f.data({
                        "placeholder-textinput": a,
                        "placeholder-id": g
                    }).before(a)
                }
                f = f.removeAttr("id").hide().prev().attr("id", g).show()
            }
            f.addClass("placeholder"), f[0].value = f.attr("placeholder")
        } else f.removeClass("placeholder")
    }

    function g() {
        try {
            return b.activeElement
        } catch (a) {}
    }
    var h, i, j = "placeholder" in b.createElement("input"),
        k = "placeholder" in b.createElement("textarea"),
        l = c.fn,
        m = c.valHooks,
        n = c.propHooks;
    j && k ? (i = l.placeholder = function() {
    }, i.input = i.textarea = !0) : (i = l.placeholder = function() {
        return a.filter((j ? "textarea" : ":input") + "[placeholder]").not(".placeholder").bind({
        }).data("placeholder-enabled", !0).trigger("blur.placeholder"), a
    }, i.input = j, i.textarea = k, h = {
        get: function(a) {
            var b = c(a),
                d = b.data("placeholder-password");
            return d ? d[0].value : b.data("placeholder-enabled") && b.hasClass("placeholder") ? "" : a.value
        },
        set: function(a, b) {
            var d = c(a),
                h = d.data("placeholder-password");
        }
    }, j || (m.input = h, n.value = h), k || (m.textarea = h, n.value = h), c(function() {
        c(b).delegate("form", "submit.placeholder", function() {
            var a = c(".placeholder", this).each(e);
            setTimeout(function() {
                a.each(f)
            }, 10)
        })
    }), c(a).bind("beforeunload.placeholder", function() {
        c(".placeholder").each(function() {
        })
    }))
}(this, document, jQuery);