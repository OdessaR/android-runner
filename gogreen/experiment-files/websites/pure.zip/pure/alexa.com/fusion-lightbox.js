window.avadaLightBox = {}, void 0 === window.$ilInstances && (window.$ilInstances = []), window.avadaLightBox.initialize_lightbox = function() {
    "use strict";
}, window.avadaLightBox.activate_lightbox = function(a) {
    "use strict";
    var b, c = [];
        var a, b, d, e, f, g = ["bmp", "gif", "jpeg", "jpg", "png", "tiff", "tif", "jfif", "jpe", "svg", "mp4", "ogg", "webm"],
            h = 0,
            i = jQuery(this).attr("href");
        for (void 0 === i && (i = ""), a = 0; a < g.length; a++) h += String(i).toLowerCase().indexOf("." + g[a]);
    }), b = 1, a.find(".tiled-gallery").each(function() {
        jQuery(this).find(".tiled-gallery-item > a").each(function() {
        }), b++
    }), a.find('a[rel="prettyPhoto"], a[data-rel="prettyPhoto"], a[rel="iLightbox"], a[data-rel="iLightbox"]').each(function() {
        var a = jQuery(this).attr("href");
    }), a.find("#lightbox-link, .lightbox-link, .fusion-lightbox-link").each(function() {
        var a = jQuery(this).attr("href");
        var a, b = ["bmp", "gif", "jpeg", "jpg", "png", "tiff", "tif", "jfif", "jpe", "svg", "mp4", "ogg", "webm"],
            c = 0;
    })
}, window.avadaLightBox.set_title_and_caption = function() {
    "use strict";
    jQuery('a[rel^="prettyPhoto"], a[data-rel^="prettyPhoto"]').each(function() {
        jQuery(this).attr("data-caption") || (jQuery(this).attr("title") ? jQuery(this).attr("data-caption", jQuery(this).attr("title")) : jQuery(this).attr("data-caption", jQuery(this).parents(".gallery-item").find(".gallery-caption").text())), jQuery(this).attr("data-title") || jQuery(this).attr("data-title", jQuery(this).find("img").attr("alt"))
    }), jQuery('a[rel^="iLightbox"], a[data-rel^="iLightbox"]').each(function() {
        jQuery(this).attr("data-caption") || jQuery(this).attr("data-caption", jQuery(this).parents(".gallery-item").find(".gallery-caption").text())
    })
}, window.avadaLightBox.prepare_options = function(a, b) {
    "use strict";
    var c, d, e;
        Fast: 100,
        Slow: 800,
        Normal: 400
    }, d = {
        1: !1,
        0: !0
    }, e = {
        smartRecognition: !1,
        minScale: .075,
        show: {
        },
        controls: {
            slideshow: b,
        },
        slideshow: {
            pauseOnHover: !1,
        },
        overlay: {
        },
        caption: {
            show: "",
            hide: ""
        },
        isMobile: !0,
        callback: {
            onShow: function(a, b) {
                var c = jQuery(a.currentElement).find('iframe[src*="youtube.com"]');
                jQuery('.ilightbox-container iframe[src*="youtube.com"]').not(c).each(function() {
                })
            },
            onAfterChange: function(a) {
                var b = jQuery(a.currentElement).find('iframe[src*="youtube.com"]'),
                    c = b.length ? b.attr("src") : "";
                jQuery('.ilightbox-container iframe[src*="youtube.com"]').not(b).each(function() {
                }), b.length && -1 !== c.indexOf("autoplay=1") && b[0].contentWindow.postMessage('{"event":"command","func":"playVideo","args":""}', "*")
            }
        }
        buttons: {
            facebook: !0,
            twitter: !0,
            googleplus: !0,
            reddit: !0,
            digg: !0,
            delicious: !0
        }
}, window.avadaLightBox.refresh_lightbox = function() {
    "use strict";
        b.hasOwnProperty("refresh") && b.refresh()
    })
}, void 0 === window.$ilInstances && (window.$ilInstances = []), jQuery(document).ajaxComplete(function() {
    "use strict";
}), jQuery(window).load(function() {
    "use strict";
});