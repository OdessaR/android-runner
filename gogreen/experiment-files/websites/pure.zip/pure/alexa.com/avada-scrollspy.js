jQuery(document).ready(function() {
    jQuery(window).on("resize scroll", function() {
    }), jQuery("body").scrollspy({
        target: ".fusion-menu",
        offset: parseInt(a + b + 1, 10)
    }), jQuery(window).load(function() {
        jQuery("body").data()["bs.scrollspy"].options.offset = parseInt(a + b + 1, 10)
    })
});