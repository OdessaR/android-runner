jQuery(window).load(function() {
        var a = jQuery(this).parent().outerHeight();
        jQuery(this).css("height", a)
    })
});