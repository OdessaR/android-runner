jQuery(window).load(function() {
        jQuery(this).find(".fusion-events-meta").equalHeights()
    }), jQuery(window).on("resize", function() {
        jQuery(".fusion-events-shortcode").each(function() {
            jQuery(this).find(".fusion-events-meta").equalHeights()
        })
    })), jQuery(".fusion-events-pagination-infinite, .fusion-events-pagination-load-more-button").each(function() {
        var t = jQuery(this),
            e = "." + t.attr("class").replace(/\ /g, ".").replace(/.fusion\-events\-[a-zA-Z]+\-sidebar/g, "").replace(".fusion-masonry-has-vertical", "") + " ",
            s = t.find(".fusion-events-wrapper").data("pages");
        t.find(".fusion-events-wrapper").isotope(), t.children(".fusion-events-wrapper").infinitescroll({
            navSelector: e + ".fusion-infinite-scroll-trigger",
            nextSelector: e + ".pagination-next",
            itemSelector: e + "div.pagination .current, " + e + " .fusion-events-post",
            loading: {
            },
            maxPage: s || void 0,
            errorCallback: function() {
                t.find(".fusion-events-post").css("height", ""), t.find(".fusion-events-wrapper").isotope()
            }
        }, function(o) {
                var n, e, i;
                (n = jQuery(o).find(".fusion-placeholder-image")).parents(".fusion-events-content-wrapper, .fusion-image-wrapper").animate({
                    opacity: 1
                }), (e = jQuery(o).find(".fusion-video")).each(function() {
                    jQuery(this).animate({
                        opacity: 1
                    }), jQuery(this).parents(".fusion-events-content-wrapper").animate({
                        opacity: 1
                    })
                        opacity: 1
                        opacity: 1
                }), o.fadeIn(), t.find(".fusion-events-post").css("height", ""), t.find(".fusion-events-wrapper").isotope("appended", o), o.each(function() {
                    jQuery(this).find(".full-video, .video-shortcode, .wooslider .slide-content").fitVids()
                }), jQuery('[data-spy="scroll"]').each(function() {
                    jQuery(this).scrollspy("refresh")
            }))
        }), t.hasClass("fusion-events-pagination-load-more-button") && (t.find(".fusion-events-wrapper").infinitescroll("unbind"), t.find(".fusion-load-more-button").on("click", function(e) {
            e.preventDefault(), t.find(".fusion-events-wrapper").infinitescroll("retrieve")
        }))
    })
});