jQuery(window).load(function() {
    jQuery(".fusion-recent-posts-infinite .fusion-columns").each(function() {
        var i, n = jQuery(this),
            s = n.parent(),
            e = "." + s.attr("class").replace(/\ /g, ".") + " ",
            t = jQuery(this).find(".fusion-column");
        jQuery(n).infinitescroll({
            navSelector: e + ".fusion-infinite-scroll-trigger",
            nextSelector: e + "a.pagination-next",
            itemSelector: e + "div.pagination .current, " + e + "article.post",
            loading: {
            },
            maxPage: s.data("pages") ? s.data("pages") : void 0,
            errorCallback: function() {}
        }, function(e) {
            jQuery(e).hide(), imagesLoaded(e, function() {
                jQuery(e).fadeIn()
            }), jQuery(n).find(".flexslider").flexslider({
                video: !0,
                smoothHeight: !1,
                pauseOnHover: !1,
                useCSS: !1,
                prevText: "&#xf104;",
                nextText: "&#xf105;",
                start: function(e) {
                            events: {
                                onStateChange: onPlayerStateChange(e.slides.eq(e.currentSlide).find("iframe").attr("id"), e)
                            }
                        })
                },
                before: function(e) {
                            events: {
                                onStateChange: onPlayerStateChange(e.slides.eq(e.currentSlide).find("iframe").attr("id"), e)
                            }
                        })
                    }))
                },
                after: function(e) {
                            events: {
                                onStateChange: onPlayerStateChange(e.slides.eq(e.currentSlide).find("iframe").attr("id"), e)
                            }
                        })
                        jQuery(this).scrollspy("refresh")
                    })
                }
            }), jQuery(e).each(function() {
                jQuery(this).find(".full-video, .video-shortcode, .wooslider .slide-content").fitVids()
                jQuery(window).trigger("resize", [!1])
        }), jQuery(s).hasClass("fusion-recent-posts-load-more") && (jQuery(n).infinitescroll("unbind"), jQuery(s).find(".fusion-load-more-button").on("click", function(e) {
            e.preventDefault(), jQuery(n).infinitescroll("retrieve")
        })), 1 === parseInt(s.data("pages"), 10) && (s.find(".fusion-loading-container").hide(), s.find(".fusion-load-more-button").hide())
    })
});