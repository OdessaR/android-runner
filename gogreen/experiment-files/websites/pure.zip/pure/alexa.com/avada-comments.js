jQuery(document).ready(function() {
    var a, b, c, d;
    if (jQuery(".comment-respond .comment-reply-title").length && !jQuery(".comment-respond .comment-reply-title").parents(".woocommerce-tabs").length) {
    }
    jQuery(".textarea-comment").each(function() {
        jQuery(this).css("max-width", jQuery("#content").width())
    }), jQuery(window).on("resize", function() {
        jQuery(".textarea-comment").each(function() {
            jQuery(this).css("max-width", jQuery("#content").width())
        })
    })
});