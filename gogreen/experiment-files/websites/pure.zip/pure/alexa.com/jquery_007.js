! function(a, b, c) {
    var d, e = b.event;
    e.special.smartresize = {
        setup: function() {
            b(this).bind("resize", e.special.smartresize.handler)
        },
        teardown: function() {
            b(this).unbind("resize", e.special.smartresize.handler)
        },
        handler: function(a, b) {
                e = arguments;
            }, "execAsap" === b ? 0 : 100)
        }
        animation: "sides",
        autoplay: !1,
        slideshow_interval: 3e3,
        speed: 800,
        easing: "",
        titlesFactor: .6,
        titlespeed: 800,
        titleeasing: "",
        thumbMaxWidth: 150
        _init: function(a) {
                c.$loading.hide(), c._setImagesSize(), c._initThumbs(), c.$imgItems.eq(c.current).css({
                    opacity: 1,
                    "z-index": 10
                }).show().find("div.ei-title > *").css("opacity", 1), c.options.autoplay && c._startSlideshow(), c._initEvents()
            })
        },
        _preloadImages: function() {
                c = 0;
            return b.Deferred(function(d) {
                a.$images.each(function(e) {
                    b("<img/>").load(function() {
                        ++c === a.itemsCount && d.resolve()
                    }).attr("src", b(this).attr("src"))
                })
            }).promise()
        },
        _setImagesSize: function() {
                var d = b(this);
                })
            })
        },
        _getImageDim: function(a) {
            b.src = a;
                g = f / e,
                h = b.width,
                i = b.height,
                j = i / h;
            return g > j ? (d = f, c = f / j) : (d = e * j, c = e), {
                width: c,
                height: d,
                left: (e - c) / 2,
                top: (f - d) / 2
            }
        },
        _initThumbs: function() {
        },
        _startSlideshow: function() {
                var b;
                b = a.current === a.itemsCount - 1 ? 0 : a.current + 1, a._slideTo(b), a.options.autoplay && a._startSlideshow()
        },
        _slideTo: function(a) {
                f = {
                    zIndex: 10
                },
                g = {
                    opacity: 1
                };
                marginRight: "0px",
                opacity: 1
                marginRight: "0px",
                opacity: 1
                b(this).show().css("opacity", 0)
                c.css("opacity", 0).find("div.ei-title > *").css("opacity", 0), e.current = a, e.isAnimating = !1
            })
        },
        _initEvents: function() {
            b(a).on("smartresize.eislideshow", function(a) {
                c._setImagesSize(), c.$sliderElem.css("left", c.$thumbs.eq(c.current).position().left)
                c.options.autoplay && (clearTimeout(c.slideshow), c.options.autoplay = !1);
                var d = b(this),
                    e = d.index() - 1;
                return c._slideTo(e), !1
            })
        }
    };
    var f = function(a) {
    };
        if ("string" == typeof a) {
            var c = Array.prototype.slice.call(arguments, 1);
                var d = b.data(this, "eislideshow");
                return d && b.isFunction(d[a]) && "_" !== a.charAt(0) ? void d[a].apply(d, c) : void f()
            })
        });
    }
}(window, jQuery);