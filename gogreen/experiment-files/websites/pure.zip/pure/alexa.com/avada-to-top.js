jQuery(document).ready(function() {
        easingType: "easeOutQuart"
        easingType: "easeOutQuart"
    }))
});