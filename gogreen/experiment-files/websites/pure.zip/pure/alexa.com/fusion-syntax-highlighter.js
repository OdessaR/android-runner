! function(n) {
    "use strict";
    var r = function(t) {
        var e, i;
    };
    n(document).ready(function() {
        var e, i, a, t = n(".fusion-syntax-highlighter-textarea");
        n.each(t, function(t, e) {
            i = n(e).parents(".fusion-tabs"), a = n(e).parents(".fusion-panel"), i.length ? 0 === i.find(".nav-tabs li.active").index() && i.find(".nav-tabs li.active .tab-link").attr("href") === "#" + n(e).parents(".tab-pane").attr("id") ? r(e) : i.find(".tab-link").click(function() {
                n(this).attr("href") !== "#" + n(e).parents(".tab-pane").attr("id") || n(e).hasClass("code-mirror-initialized") || setTimeout(function() {
                    r(e)
                }, 200)
            }) : a.length ? (a.find(".panel-title a.active").length && (e = a.find(a.find(".panel-title a.active").attr("href")).find(".fusion-syntax-highlighter-textarea")[0], r(e)), a.find(".panel-title a").click(function() {
                n(this).attr("href") !== "#" + n(e).parents(".panel-collapse").attr("id") || n(e).hasClass("code-mirror-initialized") || setTimeout(function() {
                    r(e)
                }, 200)
            })) : r(e)
        }), n(".syntax-highlighter-copy-code-title").click(function() {
            var t = n(this);
                position: "absolute",
                left: "-1000%"
                t.parent(".syntax-highlighter-copy-code").removeClass("syntax-highlighter-copying")
            }, 200)
        })
    })
}(jQuery);