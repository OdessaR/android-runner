! function(a, b, c, d) {
    "use strict";

    function e(b, c) {
    }
    var f = "fusion_maps",
        g = {
            addresses: {},
            address_pin: !0,
            animations: !0,
            delay: 10,
            infobox_background_color: !1,
            infobox_styling: "default",
            infobox_text_color: !1,
            map_style: "default",
            map_type: "roadmap",
            marker_icon: !1,
            overlay_color: !1,
            overlay_color_hsl: {},
            pan_control: !0,
            show_address: !0,
            scale_control: !0,
            scrollwheel: !0,
            zoom: 9,
            zoom_control: !0
        };
        init: function() {
            var b, d, e, f = {
                },
                g = 640 < a(c).width(),
                stylers: [{
                }, {
                }, {
                }]
            }, {
                featureType: "road",
                elementType: "geometry",
                stylers: [{
                    visibility: "simplified"
                }]
            }, {
                featureType: "road",
                elementType: "labels"
                styles: d
        },
        geocode_address: function(a, b) {
                i = !0;
                latLng: c
            }) : d = {
                address: a.address
                var f, g, j, k;
                    action: "fusion_cache_map",
                    addresses: h.settings.addresses,
        },
        create_marker: function(a, b, c) {
            var d, e, f = {
            };
        },
        create_infowindow: function(a, b) {
                content: e,
                disableAutoPan: !0,
                maxWidth: 150,
                zIndex: null,
                boxStyle: {
                    background: "none",
                    opacity: 1,
                    width: "250px"
                },
                closeBoxMargin: "2px 2px 2px 2px",
                closeBoxURL: "//www.google.com/intl/en_us/mapfiles/close.gif",
                var a = d.getMap();
                null === a || void 0 === a ? d.open(g.map, this) : d.close(g.map, this)
                disableAutoPan: !0,
                content: a
                var a = d.getMap();
                null === a || void 0 === a ? d.open(g.map, this) : d.close(g.map, this)
            }))
        },
        next_geocode_request: function() {
            a.next_address < a.settings.addresses.length && setTimeout(function() {
                a.geocode_address(a.settings.addresses[a.next_address], a.next_address), a.next_address++
            }, a.settings.delay)
        }
    }
}(jQuery, window, document);