! function(a) {
    function b(b) {
            d = [].slice.call(arguments, 1),
            e = 0,
            f = 0,
            g = 0;
    }
    var c = ["DOMMouseScroll", "mousewheel"];
    if (a.event.fixHooks)
        setup: function() {
        },
        teardown: function() {
        }
    }, a.fn.extend({
        mousewheel: function(a) {
        },
        unmousewheel: function(a) {
        }
    })
}(jQuery);