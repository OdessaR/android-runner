jQuery(function() {
                'event': 'gtm4wp.socialAction',
                'network': 'facebook',
                'socialAction': 'like',
                'opt_target': href,
            });
        });

                'event': 'gtm4wp.socialAction',
                'network': 'facebook',
                'socialAction': 'unlike',
                'opt_target': href,
            });
        });

                'event': 'gtm4wp.socialAction',
                'network': 'facebook',
                'socialAction': 'comment',
                'opt_target': href,
            });
        });

                'event': 'gtm4wp.socialAction',
                'network': 'facebook',
                'socialAction': 'uncomment',
                'opt_target': href,
            });
        });

                'event': 'gtm4wp.socialAction',
                'network': 'facebook',
                'socialAction': 'send',
                'opt_target': response,
            });
        });
    } // end of Facebook social events

            var t, js, fjs = d.getElementsByTagName(s)[0];
            if (d.getElementById(id)) return;
            js = d.createElement(s);
            js.id = id;
            js.src = "https://platform.twitter.com/widgets.js";
            fjs.parentNode.insertBefore(js, fjs);
                _e: [],
                ready: function(f) {
                    t._e.push(f);
                }
            });
        }(document, "script", "twitter-wjs"));
    } // end of loading Twitter JS

            twttr.events.bind('tweet', function(intent_event) {
                if (intent_event) {
                    var label = intent_event.data.tweet_id;

                    if (typeof label != 'undefined' && label) {
                        if (label == 'label') {
                        }
                    } else {
                    }

                        'event': 'gtm4wp.socialAction',
                        'network': 'twitter',
                        'socialAction': 'tweet',
                        'opt_target': label,
                    });
                }
            });

                if (intent_event) {
                    var label = intent_event.data.user_id + " (" + intent_event.data.screen_name + ")";

                        'event': 'gtm4wp.socialAction',
                        'network': 'twitter',
                        'socialAction': 'follow',
                        'opt_target': label,
                    });
                }
            });
        });
    }
});