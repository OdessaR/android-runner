function getAdminbarHeight() {
    var a = 0;
    return jQuery("#wpadminbar").length && (a = parseInt(jQuery("#wpadminbar").outerHeight(), 10)), a
}

function getWaypointOffset(a) {
    var b, c, d = a.data("animationoffset");
}
jQuery(window).load(function() {
    setTimeout(function() {
    }, 300)
});