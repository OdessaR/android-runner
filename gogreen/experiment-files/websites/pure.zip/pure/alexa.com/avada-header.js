function getStickyHeaderHeight(a) {
    var b = 1,
        c = 0,
}

function getWaypointTopOffset() {
    var a = 0,
        c = 1;
}
jQuery(window).load(function() {
    var a, b, c, d, e, f, g, h, i, j, k, l, m, n = !0,
        o = 0;
    jQuery(window).scroll(function() {
        var c, d, f, g, j, k, l, m;
            j += jQuery(this).outerWidth()
            height: "",
            top: ""
        }), jQuery("#side-header").hasClass("fusion-is-sticky") && (jQuery("#side-header").css({
            top: "",
            position: ""
            "margin-top": "",
            "margin-bottom": ""
        }), jQuery(".fusion-main-menu > ul > li > a").css({
            height: "",
            "line-height": ""
        }, {
            queue: !1,
            duration: a,
            easing: "easeOutCubic",
            complete: function() {
                jQuery(this).css("overflow", "visible")
            }
        }), jQuery(".fusion-header-sticky-height").show(), jQuery(".fusion-header-sticky-height").stop(!0, !0).animate({
        }, {
            queue: !1,
            duration: a,
            easing: "easeOutCubic",
            complete: function() {
                jQuery(this).css("overflow", "visible")
            }
            height: l
        }, {
            queue: !1,
            duration: a,
            easing: "easeOutCubic",
            complete: function() {
                jQuery(this).css("display", "")
            },
            step: function() {
                jQuery(this).css("display", "")
            }
        })), jQuery(".fusion-logo").stop(!0, !0).animate({
            "margin-top": m,
            "margin-bottom": m
        }, {
            queue: !1,
            duration: a,
            easing: "easeOutCubic"
        }), jQuery(".fusion-header-v6").length || jQuery(".fusion-main-menu > ul > li").not(".fusion-middle-logo-menu-logo").find("> a").stop(!0, !0).animate({
        }, {
            queue: !1,
            duration: a,
            easing: "easeOutCubic"
        }))))), h = jQuery(window).width(), i = jQuery(window).height())
    }), jQuery(window).scroll(function() {
        var b, g;
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic",
                complete: function() {
                    jQuery(this).css("overflow", "visible")
                }
            }), jQuery(".fusion-header-sticky-height").show(), jQuery(".fusion-header-sticky-height").stop(!0, !0).animate({
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic",
                complete: function() {
                    jQuery(this).css("overflow", "visible")
                }
            })) : jQuery(".fusion-header-sticky-height").show(), setTimeout(function() {
                jQuery(".fusion-header").addClass("fusion-sticky-shadow")
                "padding-top": 0,
                "padding-bottom": 0
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic"
                height: b
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic",
                complete: function() {
                    jQuery(this).css("display", "")
                },
                step: function() {
                    jQuery(this).css("display", "")
                }
            })), jQuery(".fusion-logo").stop(!0, !0).animate({
                "margin-top": g,
                "margin-bottom": g
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic"
            }), jQuery(".fusion-header-v6").length || jQuery(".fusion-main-menu > ul > li").not(".fusion-middle-logo-menu-logo").find("> a").stop(!0, !0).animate({
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic"
                height: jQuery("#side-header").outerHeight()
            }), jQuery("#side-header").css({
                position: "fixed",
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic",
                complete: function() {
                    jQuery(this).css("overflow", "visible")
                },
                step: function() {
                    jQuery(this).css("overflow", "visible")
                }
            }), jQuery(".fusion-header-sticky-height").stop(!0, !0).animate({
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic",
                complete: function() {
                    jQuery(this).css("overflow", "visible")
                },
                step: function() {
                    jQuery(this).css("overflow", "visible")
                }
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic"
            }), e && e.stop(!0, !0).animate({
                height: e.data("logo-height")
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic",
                complete: function() {
                    jQuery(this).css("display", ""), jQuery(".fusion-sticky-logo").css("height", "")
                }
            }), jQuery(".fusion-logo").stop(!0, !0).animate({
                "margin-top": jQuery(".fusion-logo").data("margin-top"),
                "margin-bottom": jQuery(".fusion-logo").data("margin-bottom")
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic"
            }), jQuery(".fusion-header-v6").length || jQuery(".fusion-main-menu > ul > li").not(".fusion-middle-logo-menu-logo").find("> a").stop(!0, !0).animate({
                height: c,
                "line-height": c - d
            }, {
                queue: !1,
                duration: a,
                easing: "easeOutCubic"
                height: ""
            }), jQuery("#side-header").css({
                position: ""
            }).removeClass("fusion-is-sticky")), f = !1)
        }
    }), jQuery(window).trigger("scroll")), setTimeout(function() {
        n = !1, jQuery(window).trigger("resize"), n = !0
    }, 10), jQuery(window).on("resize", function() {
        jQuery(".woocommerce-store-notice").length && jQuery(".woocommerce-store-notice").is(":visible") && !jQuery(".fusion-top-frame").length && (jQuery("#wrapper").css("margin-top", jQuery(".woocommerce-store-notice").outerHeight()), jQuery(".sticky-header").length && jQuery(".sticky-header").css("margin-top", jQuery(".woocommerce-store-notice").outerHeight())), jQuery(".sticky-header").length && (765 > jQuery(window).width() ? jQuery("body.admin-bar #header-sticky.sticky-header").css("top", "46px") : jQuery("body.admin-bar #header-sticky.sticky-header").css("top", "32px"))
    })
}), jQuery(document).ajaxComplete(function() {
    var a, b, c, d;
        height: c + "px",
        "line-height": d + "px"
    }))
});