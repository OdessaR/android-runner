! function(a) {
        var g = "object" == typeof d ? d : {
            complete: f || !f && e || a.isFunction(d) && d,
            duration: d,
            easing: f && e || e && !a.isFunction(e) && e
        };
        g.queue = !1;
        var h = g.complete;
        return g.complete = function() {
            a(this).dequeue(), a.isFunction(h) && h.call(this)
            var d = a(this);
            "mouseover" == b || "mouseenter" == b ? d.data("jQuery.hoverFlow", !0) : d.removeData("jQuery.hoverFlow"), d.queue(function() {
                ("mouseover" == b || "mouseenter" == b ? void 0 !== d.data("jQuery.hoverFlow") : void 0 === d.data("jQuery.hoverFlow")) ? d.animate(c, g): d.queue([])
            })
        })
    }
}(jQuery);