! function(a) {
    "use strict";
        var b, c, d, e, f = a(this).data("plugin_fusion_maps");
    }
}(jQuery);