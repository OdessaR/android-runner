window.qSuggest = window.qSuggest || {},
    function() {
        function t(e) {
            return !!e && e.nodeType == 1
        }
        var e = function() {
                var e = function(e) {
                };
                return function() {
                    return
                }
            }(),
            s = function(e) {
                    recAllTimeout: 150
            };
        s.prototype = {}, s.prototype._init = function() {
            return n(e), !0
        }, s.prototype.setOne = function(e, t, n) {
        }, s.prototype.setAll = function(e, t) {
        }, s.prototype.getAll = function(e) {
        }, s.prototype.getOne = function(e, t) {
                name: e,
                query: t,
                data: n._recData[t][e]
        }, s.prototype.bindGroupHandler = function(e, t) {
        }, s.prototype._requestAll = function(e) {
            e = e.toLowerCase(), t._recAllStarted && (t._recAllStarted = !1, clearTimeout(t._recAllTimer)), t._recData[e] || (t._recData[e] = {});
            var n;
            for (n in t._handler) t._handler[n].request && function(n) {
                t._recData[e] && t._recData[e][n] ? (t._recAllStarted || (t._recAllStarted = !0, t._recAllTimer = setTimeout(function() {
                    t.trigger("receiveAll", {
                        query: e,
                        data: t._recData[e]
                    })
                }, t._config.recAllTimeout)), t._receiveOne(n, t._recData[e][n])) : t._handler[n].request(e, function(r) {
                    t._recAllStarted || (t._recAllStarted = !0, t._recAllTimer = setTimeout(function() {
                        t.trigger("receiveAll", {
                            query: e,
                            data: t._recData[e]
                        })
                    }, t._config.recAllTimeout)), t._receiveOne(n, r)
                })
            }(n);
            return !0
        }, s.prototype._requestOne = function(e, t) {
                n._handler[e].request(t, function(t) {
                    n._receiveOne(e, t)
                })
            }(e), !0
        }, s.prototype._receiveOne = function(e, t) {
                r;
            return n._handler[e] && n._handler[e].receive && (r = n._handler[e].receive(t), r && r.query && (r.query = r.query.toLowerCase(), n._recData[r.query] || (n._recData[r.query] = {})), r && r.query && r.data && (n._recData[r.query][e] = r.data, n.trigger("receiveOne", {
                name: e,
                query: r.query,
                data: r.data
            }))), !0
        };
        var o = function(e) {
                e.style.display = ""
            },
            u = function(e) {
                e.style.display = "none"
            },
            a = {
                DOWN: 40,
                UP: 38,
                ESC: 27,
                ENTER: 13,
                BACKSPACE: 8
            },
            f = [40, 39, 38, 37, 27, 13, 18, 17, 16],
            l = function(e, t) {
                    uiReferElem: null,
                    uiContainerElem: null,
                    posAdjust: {},
                    autoPosition: !0
            };
        l.prototype = {
            config: function() {
                var e = [].slice.call(arguments);
            }
        }, l.prototype._init = function(r) {
            n(this);
                s = i.setupTextInput(r);
        }, l.prototype.setupTextInput = function(n) {
        }, l.prototype.focusTextInput = function() {
            setTimeout(function() {
                e.textInput.focus(), e.trigger("focus")
            }, 0)
        }, l.prototype.setTextInputVal = function(e) {
        }, l.prototype.getTextInputVal = function() {
        }, l.prototype.resetTextInput = function() {
        }, l.prototype._initTextInput = function() {
                n, r = function() {
                    var e = t.getTextInputVal(),
                        n = e.trim();
                    if (e === t.lastInputVal) return;
                    t.lastInputVal = e, t.query = n, n || (t.fillContent(""), t.hide()), t.trigger("change", {
                        query: t.query
                    })
                },
                i = function() {
                    if (t.isWatching) return;
                    n = setTimeout(function() {
                        r(), n = setTimeout(arguments.callee, 200)
                    }, 100), t.isWatching = !0
                },
                s = function() {
                    n && clearTimeout(n), t.isWatching = !1
                };
            return t.textInput.attr("autocomplete", "off").on("focus", function() {
                t.trigger("focus")
            }).on("blur", function() {
                t.trigger("stopWatch"), t.trigger("blur")
            }).on("paste input", function(e) {
                t.trigger("startWatch")
            }).on("keydown", function(e) {
                t.keyEventHandler(e)
            }), t.on("startWatch", i), t.on("stopWatch", s), t.on("restoreQuery", function(e) {
                t.setTextInputVal(t.query)
            }), e("initTextInput finished"), !0
        }, l.prototype.keyEventHandler = function() {
            var e = function(e) {
                return f.indexOf(e) === -1
            };
            return function(t) {
                    r = "",
                    i = {
                        trigger: "keyboard"
                    };
                switch (t.keyCode) {
                    case a.UP:
                        r = "up", n.isVisible() && n.previous(), t.preventDefault && t.preventDefault(), n.trigger("stopWatch");
                        break;
                    case a.DOWN:
                        r = "down", n.isVisible() ? n.next() : n.displayContainer(), t.preventDefault && t.preventDefault(), n.trigger("stopWatch");
                        break;
                    case a.ESC:
                        r = "esc", n.hide(), n.trigger("stopWatch");
                        break;
                    case a.BACKSPACE:
                        r = "backspace", n.trigger("startWatch");
                        break;
                    case a.ENTER:
                        n.isVisible() && (r = "itemSelect", i.group = n.getFocusedGroup(), i.index = n._focusedItemIndex[i.group]), n.trigger("stopWatch");
                        break;
                    default:
                        e(t.keyCode) && n.trigger("startWatch")
                }
                r != "" && n.trigger(r, i)
            }
        }(), l.prototype._initSuggest = function() {
            return t.fillContent(), t.on("enter", function(n) {
                t.trigger("stopWatch");
                if (n.trigger == "mouse" || n.trigger == "touch") {
                    var r = t.searchForm[0],
                        i = !0,
                    if (!r) return;
                    if (s.createEvent) {
                        var o = s.createEvent("MouseEvents");
                        o.initEvent("submit", !0, !0), i = r.dispatchEvent(o)
                    } else s.createEventObject && (i = r.fireEvent("onsubmit"));
                    i && r.submit()
                }
                e("enter with:" + t.getTextInputVal())
            }), t.on("itemFocus", function() {
                var e = "";
                return function(n) {
                    if (n.group != e) {
                        var r = t._groupHandlerNames;
                        for (var i = r.length - 1; i >= 0; i--) r[i] != n.group && t.restoreGroup(r[i]);
                        e = n.group
                    }
                }
            }()), $(window).on("resize", function() {
                setTimeout(function() {
                    t.setContainerRegion()
                })
            }), t.container.on("mousedown", function(e) {
                var n = t.textInput[0];
                n.onbeforedeactivate = function(e) {
                }
            }), e("initEvent finished"), !0
        }, l.prototype.setFocusedGroup = function(e) {
        }, l.prototype.getFocusedGroup = function() {
        }, l.prototype.bindGroupHandler = function(e, t) {
            n._groupHandlerNames.push(e), n._groupHandler[e] = t, n._focusedItemIndex[e] = -1, t.init && t.init()
        }, l.prototype.restoreGroup = function(e) {
            t.trigger("itemBlur", {
                group: e,
                index: t._focusedItemIndex[e]
            }), t._focusedItemIndex[e] = -1, t._groupHandlerNames[t._focusedGroupIndex] && (t._focusedGroupIndex = -1)
        }, l.prototype.initGroupUserBehavior = function(e, t) {
                r = "mouse";
            n.container.delegate(t, "mouseover", function(r) {
                var i = $(this).attr("data-index"),
                    s = i === undefined ? $(t, n.container).index(this) : i,
                    o = n._groupHandlerNames;
                for (var u = o.length - 1; u >= 0; u--) n.trigger("itemBlur", {
                    group: o[u],
                    index: n._focusedItemIndex[o[u]],
                    trigger: "mouse"
                });
                n.trigger("itemFocus", {
                    group: e,
                    index: s,
                    trigger: "mouse"
                }), n.setFocusedGroup(e, s), n._focusedItemIndex[e] = s
            }), n.container.delegate(t, "touchstart", function(i) {
                var s = $(this).attr("data-index"),
                    o = s === undefined ? $(t, n.container).core.indexOf(this) : s,
                    u = n._groupHandlerNames;
                for (var a = u.length - 1; a >= 0; a--) n.trigger("itemBlur", {
                    group: u[a],
                    index: n._focusedItemIndex[u[a]],
                    trigger: "touch"
                });
                n.trigger("itemFocus", {
                    group: e,
                    index: o,
                    trigger: "touch"
                }), n.setFocusedGroup(e, o), n._focusedItemIndex[e] = o, r = "touch"
            }), n.container.delegate(t, "touchend", function(r) {
                var i = $(this).attr("data-index"),
                    s = i === undefined ? $(t, n.container).core.indexOf(this) : i;
                n.trigger("itemBlur", {
                    group: e,
                    index: s,
                    trigger: "touch"
                })
            }), n.container.delegate(t, "click", function(i) {
                var s = $(this).attr("data-index"),
                    o = s === undefined ? $(t, n.container).index(this) : s;
                n.trigger("itemSelect", {
                    group: e,
                    index: o,
                    trigger: r
                })
            })
        }, l.prototype.render = function(t) {
                r, i, s = [],
                o, u;
            for (o = 0, u = n._groupHandlerNames.length; o < u; o++) r = n._groupHandlerNames[o], i = n._groupHandler[r], i && i.render && (i.render.setup && (i.render.setup(), n.setGroupTotal(r, 0), n.restoreGroup(r), e("Render setup [" + r + "]")), i.render.build && (s.push(i.render.build(t[r])), e("Render buildui [" + r + "]:", t[r])));
            n.fillContent(s.join(""));
            for (o = 0, u = n._groupHandlerNames.length; o < u; o++) r = n._groupHandlerNames[o], i = n._groupHandler[r], i && i.render && i.render.teardown && (i.render.teardown(), e("Render teardown [" + r + "]"))
        }, l.prototype.setGroupTotal = function(e, t) {
        }, l.prototype.groupPrevious = function(e) {
                n = t._groupTotal[e],
                r = t._focusedItemIndex[e],
                i = -1;
            return n > 0 && (r <= -1 ? r = n - 1 : r >= 0 && (i = r, r--)), t.trigger("itemBlur", {
                group: e,
                index: i,
                trigger: "keyboard"
            }), t.trigger("itemFocus", {
                group: e,
                index: r,
                trigger: "keyboard"
            }), t._focusedItemIndex[e] = r, r
        }, l.prototype.groupNext = function(e) {
                n = t._groupTotal[e],
                r = t._focusedItemIndex[e],
                i = -1;
            return n > 0 && (r <= -1 ? r = 0 : r < n && (i = r, r++), r >= n && (r = -1)), t.trigger("itemBlur", {
                group: e,
                index: i,
                trigger: "keyboard"
            }), t.trigger("itemFocus", {
                group: e,
                index: r,
                trigger: "keyboard"
            }), t._focusedItemIndex[e] = r, r
        }, l.prototype.displayContainer = function() {
            e.container.html().trim() ? e.show() : e.hide()
        }, l.prototype.fillContent = function(t) {
            n.container.html(t || ""), n.displayContainer(), n.isVisible(), e("fillContent :" + t)
        }, l.prototype.setContainerRegion = function() {
            if (!e.config("autoPosition")) return !1;
            var t = e.config("uiReferElem"),
                n = $(e.config("uiReferElem")).offset(),
                r = e.config("posAdjust"),
                i = e.wrap.attr("width") ? parseInt(e.wrap.attr("width"), 10) : t.offsetWidth;
            n.bottom = n.top + t.offsetHeight, e.wrap.css({
                position: "absolute",
                top: (r.top ? r.top + n.bottom : n.bottom) + "px",
                left: (r.left ? r.left + n.left : n.left) + "px",
                width: (r.width ? r.width + i : i) + "px",
                "z-index": r["z-index"] ? r["z-index"] : 99
            }, 1)
        }, l.prototype.isVisible = function() {
        }, l.prototype.show = function() {
            e.trigger("show");
            if (e.isVisible()) return;
            e.setContainerRegion(), o(e.wrap[0])
        }, l.prototype.hide = function() {
            e.trigger("hide");
            if (!e.isVisible()) return;
            u(e.wrap[0])
        }, l.prototype.previous = function() {
                n = t._focusedGroupIndex,
                r = t._groupHandlerNames[n],
                i = t._groupHandlerNames.length,
                s = -1;
            n <= -1 && (n = i - 1, r = t._groupHandlerNames[n]);
            while (s === -1 && n > -1) t._groupHandler[r] && (s = t.groupPrevious(r)), s === -1 && (n > 0 ? (n--, r = t._groupHandlerNames[n]) : (n = -1, r = ""), e("changeGroup", n));
            n === -1 && s === -1 && t.trigger("restoreQuery"), t._focusedGroupIndex = n, e(r + " previous:" + s)
        }, l.prototype.next = function() {
                n = t._focusedGroupIndex,
                r = t._groupHandlerNames[n],
                i = t._groupHandlerNames.length,
                s = -1;
            n >= i && (n = -1), n <= -1 && (n = 0, r = t._groupHandlerNames[n]);
            while (s === -1 && n < i) t._groupHandler[r] && (s = t.groupNext(r)), s === -1 && (n < i ? (n++, r = t._groupHandlerNames[n]) : (n = -1, r = ""), e("changeGroup", n));
            n === i && s === -1 && t.trigger("restoreQuery"), t._focusedGroupIndex = n, e(r + " next:" + s)
        };
        var c = function(e, t) {
            if (!(n instanceof c)) return new c(e, t);
            n._config = {
                ui: null,
                data: null
            }, r(!0, n._config, t), n.query = "", n.renderQuery = "", n.ui = null, n.data = null, n._init(e, t)
        };
        c.prototype = {
            config: function() {
                var e = [].slice.call(arguments);
            }
        }, c.prototype._init = function(t, r) {
            return i.isWatching = !1, i.ui = i.config("ui") || i.config("ui", new l(t, r)), i.ui ? (i.data = i.config("data") || i.config("data", new s(r)), i.data ? (n(i), i._initEvent()) : (e.error("init data error"), !1)) : (e.error("init ui error"), !1)
        }, c.prototype._initEvent = function() {
                n = t.data,
                r = t.ui;
            return r.on("change", function(r) {
                var i = t.query = r.query.toLowerCase();
                i && (n.getAll(i), e("input query:" + i))
            }), n.on("receiveAll", function(e) {
                e.query.toLowerCase() === t.query && (t.renderQuery = e.query.toLowerCase(), r.render(e.data))
            }), !0
    }();