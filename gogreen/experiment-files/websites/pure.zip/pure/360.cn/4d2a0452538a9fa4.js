var qload = qload || {};
qload = function() {
        n = {},
        r = {},
        i = function(e) {
            return e.constructor === Array
        },
        s = {
            mods: {}
        },
        o = e.getElementsByTagName("script"),
        u = o[o.length - 1],
        a, f = function(e) {
            if (e.clearAttributes) e.clearAttributes();
            else
                for (var t in e) e.hasOwnProperty(t) && t.toLowerCase() !== "parentnode" && delete e[t];
            e && e.parentNode && e.parentNode.removeChild(e), e = null
        },
        l = e.createElement("script").readyState ? function(e, t) {
            e.onreadystatechange = function() {
                var n = e.readyState;
                if (n === "loaded" || n === "complete") e.onreadystatechange = null, t.apply(this)
            }
        } : function(e, t) {
            e.addEventListener("load", t, !1)
        },
        c = function(t, i, s, o, a, h) {
            var p = u;
            if (!t) return;
            if (n[t]) {
                r[t] = !1;
                if (!o) {
                    a && a(t, h);
                    return
                }
            }
            if (r[t]) {
                setTimeout(function() {
                    c(t, i, s, o, a, h)
                }, 1);
                return
            }
            r[t] = !0;
            var d;
            if (i === "js" || t.indexOf(".js") >= 0) d = e.createElement("script"), d.setAttribute("type", "text/javascript"), s && (d.charset = s), d.setAttribute("src", t), d.setAttribute("async", !0), l(d, function() {
                n[t] = !0, a && a(t, h), f(d)
            }), p.parentNode.insertBefore(d, p);
            else if (i === "css" || t.indexOf(".css") >= 0) {
                d = e.createElement("link"), d.setAttribute("type", "text/css"), s && (d.charset = s), d.setAttribute("rel", "stylesheet"), d.setAttribute("href", t), n[t] = !0, p.parentNode.insertBefore(d, p), a && a(t, h);
                return
            }
        },
        h = function(e) {
            if (!e || !i(e)) return;
            var t = 0,
                n, r = [],
                o = s.mods,
                u = [],
                a = {},
                f = function(e) {
                    var t = 0,
                        n, r;
                    if (a[e]) return u;
                    a[e] = !0;
                    if (o[e].requires) {
                        r = o[e].requires;
                        for (; typeof(n = r[t++]) != "undefined";) o[n] ? (f(n), u.push(n)) : u.push(n);
                        return u
                    }
                    return u
                };
            for (; typeof(n = e[t++]) != "undefined";) o[n] && o[n].requires && o[n].requires[0] && (u = [], a = {}, r = r.concat(f(n))), r.push(n);
            return r
        },
        p = function(e) {
            if (!e || !i(e)) return;
        };
    return p.prototype = {
        _interval: 10,
        start: function() {
                return
            }
        },
        run: function() {
            if (typeof n == "function") {
                return
            }
            typeof n == "string" && (s.mods[n] ? (t = s.mods[n], c(t.path, t.type, t.charset, t.force, function(t) {
                e.start()
            }, e)) : /\.js|\.css/i.test(n) ? c(n, "", "", "", function(e, t) {
                t.start()
        },
        next: function() {
        }
    }, a = function() {
        var e = [].slice.call(arguments),
            t, n = e[0];
        if (typeof n != "string" && typeof n != "function") {
            var r = n.name || n.path,
                i = n.callback || e[1];
            a.add(r, n), e[0] = r, e[1] = i
        }
        t = new p(h(e)), t.start()
    }, a.add = function(e, t) {
        if (!e || !t || !t.path) return;
        s.mods[e] = t
    }, a.delay = function() {
        var e = [].slice.call(arguments),
            n = e.shift();
        t.setTimeout(function() {
            a.apply(this, e)
        }, n)
    }, a.done = function() {
        var e = [].slice.call(arguments),
            t = 0,
            r;
    }, a.css = function(t, n) {
        n = n || "qboot-inline-css";
        var r = e.getElementById(n);
        r || (r = e.createElement("style"), r.type = "text/css", r.id = n, e.getElementsByTagName("head")[0].appendChild(r)), r.styleSheet ? r.styleSheet.cssText = r.styleSheet.cssText + t : r.appendChild(e.createTextNode(t))
    }, a
}();