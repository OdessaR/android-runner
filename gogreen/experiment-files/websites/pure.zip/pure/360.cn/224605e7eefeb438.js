(function(e) {
    function t() {
        var t = e("#userinfo"),
            r = ['<div class="user-info">', '<a href="//i.360.cn/login/?src=pcw_home&destUrl=' + n + '" target="_self">\u767b\u5f55</a>', '<span class="line">|</span>', '<a href="//i.360.cn/reg/?src=pcw_home&destUrl=' + n + '" target="_self">\u6ce8\u518c</a>', "</div>"].join("").tmpl(),
            i = ['<div class="user-info">', '<a href="https://i.360.cn"><img src="{$img_url}"/></a>', "<p>", '<i class="user-arr"></i>', '<a href="https://i.360.cn">{$userName}</a>', '<a href="https://i.360.cn">\u4e2a\u4eba\u4e2d\u5fc3</a>', '<a href="https://login.360.cn/?op=logout&crumb={$crumb}&destUrl=' + n + '" target="_self">\u9000\u51fa</a>', "</p>", "</div>"].join("").tmpl(),
            s = function(e) {
                e.userName != "" ? t.html(i(e)) : t.html(r())
            };
        e.ajax({
            type: "get",
            url: "//login.360.cn/?o=sso&m=info&requestScema=https",
            dataType: "jsonp",
            success: s
        }), e("body").on("mouseenter", ".user-info", function() {
            e(this).find("p").show()
        }), e("body").on("mouseleave", ".user-info", function() {
            e(this).find("p").hide()
        })
    }
    t()
})(jQuery);