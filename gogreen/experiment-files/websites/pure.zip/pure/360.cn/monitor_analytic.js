(function() {
    var e = "v1.5.0 (2016.01.25)",
        t = ["360.cn", "so.com", "leidian.com"],
        n = function(r, i) {
            var s;
            (function() {
                s = !0;
                try {
                    if (e == "http:" || e == "https:") s = !1
                } catch (t) {}
            })();
                a = r.screen,
                l = u.userAgent.toLowerCase(),
                c = {
                    trim: function(e) {
                        return e.replace(/^[\s\xa0\u3000]+|[\u3000\xa0\s]+$/g, "")
                    }
                },
                h = {
                    on: function(e, t, n) {
                        e.addEventListener ? e && e.addEventListener(t, n, !1) : e && e.attachEvent("on" + t, n)
                    },
                    parentNode: function(e, t, n) {
                        n = n || 5, t = t.toUpperCase();
                        while (e && n-- > 0) {
                            if (e.tagName === t) return e;
                            e = e.parentNode
                        }
                        return null
                    }
                },
                p = {
                    fix: function(e) {
                        if (!("target" in e)) {
                            var t = e.srcElement || e.target;
                            t && t.nodeType == 3 && (t = t.parentNode), e.target = t
                        }
                        return e
                    }
                },
                d = function() {
                    function e(e) {
                        return e != null && e.constructor != null ? Object.prototype.toString.call(e).slice(8, -1) : ""
                    }
                    return {
                        isArray: function(t) {
                            return e(t) == "Array"
                        },
                        isObject: function(e) {
                            return e !== null && typeof e == "object"
                        },
                        mix: function(e, t, n) {
                            for (var r in t)
                                if (n || !(e[r] || r in e)) e[r] = t[r];
                            return e
                        },
                        encodeURIJson: function(e) {
                            var t = [];
                            for (var n in e) {
                                if (e[n] == null) continue;
                                t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]))
                            }
                            return t.join("&")
                        }
                    }
                }(),
                v = {
                    get: function(e) {
                        try {
                            var t, n = new RegExp("(^| )" + e + "=([^;]*)(;|$)");
                            return (t = o.cookie.match(n)) ? unescape(t[2]) : ""
                        } catch (r) {
                            return ""
                        }
                    },
                    set: function(e, t, n) {
                        n = n || {};
                        var r = n.expires;
                        typeof r == "number" && (r = new Date, r.setTime(r.getTime() + n.expires));
                        try {
                            o.cookie = e + "=" + escape(t) + (r ? ";expires=" + r.toGMTString() : "") + (n.path ? ";path=" + n.path : "") + (n.domain ? "; domain=" + n.domain : "")
                        } catch (i) {}
                    }
                },
                m = {
                    getColorDepth: function() {
                        return a.colorDepth + "-bit"
                    },
                    getLanguage: function() {
                        return (u.language || u.browserLanguage).toLowerCase()
                    },
                    getScreenSize: function() {
                        return a.width + "x" + a.height
                    },
                    getProject: function() {
                        return ""
                    },
                    getReferrer: function() {
                        var e = o.referrer || "";
                        return e.indexOf("pass") > -1 || e.indexOf("pwd") > -1 ? "403" : e
                    },
                    getBrowser: function() {
                        var e = {
                            "360se-ua": "360se",
                            TT: "tencenttraveler",
                            Maxthon: "maxthon",
                            GreenBrowser: "greenbrowser",
                            Sogou: "se 1.x / se 2.x",
                            TheWorld: "theworld"
                        };
                        for (var t in e)
                            if (l.indexOf(e[t]) > -1) return t;
                        var n = !1;
                        try {
                        } catch (i) {}
                        if (n) return "360se-noua";
                        var s = l.match(/(msie|chrome|safari|firefox|opera|trident)/);
                        return s = s ? s[0] : "", s == "msie" ? s = l.match(/msie[^;]+/) + "" : s == "trident" && l.replace(/trident\/[0-9].*rv[ :]([0-9.]+)/ig, function(e, t) {
                            s = "msie " + t
                        }), s
                    },
                    getLocation: function() {
                        var e = "";
                        try {
                        } catch (t) {
                            e = o.createElement("a"), e.href = "", e = e.href
                        }
                        return e = /\.(s?htm|php)/.test(e) ? e : e.replace(/\/$/, "") + "/", e
                    },
                    hash: function(e) {
                        var t = 0,
                            n = 0,
                            r = e.length - 1;
                        for (r; r >= 0; r--) {
                            var i = parseInt(e.charCodeAt(r), 10);
                            t = (t << 6 & 268435455) + i + (i << 14), (n = t & 266338304) != 0 && (t ^= n >> 21)
                        }
                        return t
                    },
                    guid: function() {
                        var e = [u.appName, u.version, u.language || u.browserLanguage, u.platform, u.userAgent, a.width, "x", a.height, a.colorDepth, o.referrer].join(""),
                            t = e.length,
                            n = r.history.length;
                        while (n) e += n-- ^ t++;
                        return (Math.round(Math.random() * 2147483647) ^ m.hash(e)) * 2147483647
                    },
                    getSid: function() {
                        var e = "__sid",
                            t = v.get(e);
                        t || (t = [m.hash(s ? "" : o.domain), m.guid(), +(new Date) + Math.random()].join("."));
                        var n = {
                            expires: (m._activeTime || 30) * 60 * 1e3,
                            path: "/"
                        };
                        return v.set(e, t, n), t
                    },
                    getMid: function() {
                        try {
                        } catch (e) {
                            return ""
                        }
                    },
                    getGid: function() {
                        var e = "__gid",
                            n = v.get(e);
                        n ? (n = n.split("."), n[3] = (new Date).getTime(), n[4] = (parseInt(n[4]) || 1) + 1, n = n.join(".")) : n = [m.hash(s ? "" : o.domain), Math.floor(Math.random() * 1e9), (new Date).getTime(), (new Date).getTime(), 1].join(".");
                        var r = {
                            expires: 63072e6,
                            path: "/"
                        };
                        if (t.length)
                            for (var i = 0; i < t.length; i++) {
                                var u = t[i],
                                    a = "." + u;
                                if (f.indexOf(a) > 0 && f.lastIndexOf(a) == f.length - a.length || f == u) {
                                    r.domain = a;
                                    break
                                }
                            }
                        return v.set(e, n, r), n
                    },
                    getGuid: function() {
                        var e = "__guid",
                            n = v.get(e);
                        if (!n) {
                            n = [m.hash(s ? "" : o.domain), m.guid(), +(new Date) + Math.random() + Math.random()].join(".");
                            var r = {
                                expires: 2592e7,
                                path: "/"
                            };
                            if (t.length)
                                for (var i = 0; i < t.length; i++) {
                                    var u = t[i],
                                        a = "." + u;
                                    if (f.indexOf(a) > 0 && f.lastIndexOf(a) == f.length - a.length || f == u) {
                                        r.domain = a;
                                        break
                                    }
                                }
                            v.set(e, n, r)
                        }
                        return n
                    },
                    getCount: function() {
                        var e = "monitor_count",
                            t = v.get(e);
                        return t = (parseInt(t) || 0) + 1, v.set(e, t, {
                                expires: 864e5,
                                path: "/"
                            }),
                            function() {
                                return t
                            }
                    }(),
                    getFlashVer: function() {
                        var e = -1;
                        if (u.plugins && u.mimeTypes.length) {
                            var t = u.plugins["Shockwave Flash"];
                            t && t.description && (e = t.description.replace(/([a-zA-Z]|\s)+/, "").replace(/(\s)+r/, ".") + ".0")
                        } else if (r.ActiveXObject && !r.opera) try {
                            if (n) {
                                var i = n.GetVariable("$version");
                                e = i.replace(/WIN/g, "").replace(/,/g, ".")
                            }
                        } catch (s) {}
                        return e = parseInt(e, 10), e
                    },
                    getContainerId: function(e) {
                        var t, n, r = 100;
                        y.areaIds && (t = new RegExp("^(" + y.areaIds.join("|") + ")$", "ig"));
                        while (e) {
                            if (e.attributes && ("bk" in e.attributes || "data-bk" in e.attributes)) {
                                n = e.getAttribute("bk") || e.getAttribute("data-bk");
                                if (n) return n = "bk:" + n, n.substr(0, r);
                                if (e.id) return n = e.getAttribute("data-desc") || e.id, n.substr(0, r)
                            } else if (t && e.id && t.test(e.id)) return n = e.getAttribute("data-desc") || e.id, n.substr(0, r);
                            e = e.parentNode
                        }
                        return ""
                    },
                    getText: function(e) {
                        var t = "";
                        return e.tagName.toLowerCase() == "input" ? t = e.getAttribute("text") || e.getAttribute("data-text") || e.value || e.title || "" : t = e.getAttribute("text") || e.getAttribute("data-text") || e.innerText || e.textContent || e.title || "", c.trim(t).substr(0, 100)
                    },
                    getHref: function(e) {
                        try {
                            return e.getAttribute("data-href") || e.href || ""
                        } catch (t) {
                            return ""
                        }
                    }
                },
                g = {
                    getBase: function() {
                        return {
                            p: m.getProject(),
                            u: m.getLocation(),
                            guid: m.getGuid(),
                            gid: m.getGid(),
                            sid: m.getSid(),
                            mid: m.getMid()
                        }
                    },
                    getTrack: function(e) {
                        var t = m.getSid() === m.getSid() ? 1 : 0,
                            n = {
                                b: m.getBrowser(),
                                c: m.getCount(),
                                r: m.getReferrer(),
                                fl: m.getFlashVer(),
                                sd: m.getColorDepth(),
                                sr: m.getScreenSize(),
                                ul: m.getLanguage(),
                                ce: t
                            };
                        if (e) {
                            e = e.split(",");
                            var r = [];
                            for (var i = 0, s = e.length; i < s; i++) {
                                var o = v.get(e[i]);
                                r.push(e[i] + "=" + encodeURIComponent(o))
                            }
                            n.uc = encodeURIComponent(r.join("&"))
                        }
                        return n
                    },
                    getClick: function(e) {
                        var t = e.target,
                            n = t.tagName,
                            r = m.getContainerId(t);
                        if (!t.type || t.type != "submit" && t.type != "button") {
                            if (n == "AREA") return {
                                f: m.getHref(t),
                                c: "area:" + t.parentNode.name,
                                cId: r
                            };
                            var f, l;
                            return n == "IMG" && (f = t), t = h.parentNode(t, "A"), t ? (l = m.getText(t), {
                                f: m.getHref(t),
                                c: l ? l : f ? f.src.match(/[^\/]+$/) : "",
                                cId: r
                            }) : !1
                        }
                        var i = h.parentNode(t, "FORM"),
                            s = {};
                        if (i) {
                            var o = i.id || "",
                                u = t.id;
                            s = {
                                f: i.action,
                                c: "form:" + (i.name || o),
                                cId: r
                            };
                            if ((o == "search-form" || o == "searchForm") && (u == "searchBtn" || u == "search-btn")) {
                                var a = b("kw") || b("search-kw") || b("kw1");
                                s.w = a ? a.value : ""
                            }
                        } else s = {
                            f: m.getHref(t),
                            c: m.getText(t),
                            cId: r
                        };
                        return s
                    },
                    getKeydown: function(e) {
                        if (e.keyCode != 13) return !1;
                        var t = e.target,
                            n = t.tagName,
                            r = m.getContainerId(t);
                        if (n == "INPUT") {
                            var i = h.parentNode(t, "FORM");
                            if (i) {
                                var s = i.id || "",
                                    o = t.id,
                                    u = {
                                        f: i.action,
                                        c: "form:" + (i.name || s),
                                        cId: r
                                    };
                                if (o == "kw" || o == "search-kw" || o == "kw1") u.w = t.value;
                                return u
                            }
                        }
                        return !1
                    }
                },
                y = {
                    trackUrl: null,
                    clickUrl: null,
                    areaIds: null
                },
                b = function(e) {
                };
            return {
                version: e,
                util: m,
                data: g,
                config: y,
                sendLog: function() {
                        function(e) {
                            var t = "log_" + +(new Date),
                            n.onload = n.onerror = function() {
                            }, n.src = e
                        }
                }(),
                buildLog: function() {
                    var e = "";
                    return function(t, n) {
                        if (t === !1) return;
                        t = t || {};
                        var r = g.getBase();
                        t = d.mix(r, t, !0);
                        var i = n + d.encodeURIJson(t);
                        if (i == e) return;
                        e = i, setTimeout(function() {
                            e = ""
                        }, 100);
                        var s = d.encodeURIJson(t);
                    }
                }(),
                log: function(e, t) {
                    t = t || "click";
                    var n = y[t + "Url"];
                },
                setConf: function(e, t) {
                    var n = {};
                },
                setUrl: function(e) {
                        return e
                },
                setProject: function(e) {
                        return e
                },
                setId: function() {
                    var e = [],
                        t = 0,
                        n;
                    while (n = arguments[t++]) d.isArray(n) ? e = e.concat(n) : e.push(n);
                },
                getTrack: function(e) {
                },
                getClickHeatmap: function(e, t) {
                        r = [];
                    e = e || 10, t = t || 5;
                    var i = 0,
                        s = function(o) {
                            clearTimeout(i);
                            if (o || r.length > e) {
                                if (!r.length) return;
                                n.log({
                                    pos: r.join(","),
                                    sr: m.getScreenSize()
                                }, "clickHeatMap"), r = [];
                                return
                            }
                            i = setTimeout(function() {
                                s(!0)
                            }, t * 60 * 1e3)
                        };
                    return h.on(o, "mousedown", function(e) {
                        var t = e.pageX + "." + e.pageY;
                        r.push(t), s()
                },
                getClickAndKeydown: function() {
                    return h.on(o, "mousedown", function(t) {
                        var n = e.data.getClick(t);
                        e.log(n, "click")
                    }), h.on(o, "keydown", function(t) {
                        var n = e.data.getKeydown(t);
                        e.log(n, "click")
                    }), n.getClickAndKeydown = function() {
                        return e
                },
                setActiveTime: function(e) {
                }
            }
        }(window);
    n.setConf({
        trackUrl: "http://s.360.cn/qdas/s.htm",
        clickUrl: "http://s.360.cn/qdas/c.htm",
        clickHeatMapUrl: "http://s.360.cn/qdas/c.htm",
        wpoUrl: "http://s.360.cn/qdas/p.htm"
})();