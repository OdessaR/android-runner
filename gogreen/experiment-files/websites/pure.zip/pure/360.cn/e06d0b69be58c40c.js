(function(e, t, n, r) {
        Config: {
            panels: ".items > *",
            initIndex: 0,
            effect: "scroll",
            loop: !1,
            onBeforeSwitch: null,
            onSwitch: null
        },
        Effects: {
            none: function(e, t) {
                    r = n.panels;
                r.slice(e, e + 1).hide(), r.slice(t, t + 1).show()
            }
        },
        Plugins: []
    };
    var i = function(n, i) {
            o = e(this),
            u = "beforeSwitch",
            a = "switch";
        e.extend(s, {
            _initPlugins: function() {
                var t = e.switchable.Plugins,
                    n = t.length,
                    r = 0;
                for (; r < n; r++) e.isFunction(t[r].init) && t[r].init(s)
            },
            _warn: function(e) {
            },
            _init: function() {
                s.root = n, s.config = i;
                var t = e(n),
                    r;
                if (!t.find(i.panels).length) {
                    s._warn("No panel in switchable");
                    return
                }
                s.panels = t.find(i.panels), s.length = s.panels.length;
                if (s.length < 1) {
                    s._warn("No panel group in switchable");
                    return
                }
            },
            _switchPanels: function(t, n) {
                if (n === t) return;
                i.effect = i.effect.toLowerCase();
                if (!i.effect || !e.switchable.Effects[i.effect]) {
                    s._warn("No switch effect");
                    return
                }
                e.switchable.Effects[i.effect].call(s, t, n)
            },
            switchTo: function(t) {
                if (t === s.index) return s;
                s._nextIndex = t;
                var n = e.Event(u);
                o.trigger(n, [t]);
                if (n.isDefaultPrevented()) return;
                return s._switchPanels(s.index, t), s.index = t, n.type = a, o.trigger(n, [t]), s
            },
            willTo: function() {
                return s._nextIndex
            },
            destroy: function() {
                s._destroyPlugins(), s._destroy()
            },
            _destroyPlugins: function() {
                var t = e.switchable.Plugins,
                    n = t.length,
                    r = 0;
                for (; r < n; r++) e.isFunction(t[r].destroy) && t[r].destroy(s)
            },
            _destroy: function() {
                var t;
                e(n)[0]._switchable = r;
                for (t in s) delete s[t]
            }
        });
        if (!s._init()) return e(n)[0]._switchable;
        s._initPlugins()
    };
        var n = e(this),
            r = n.length,
            s = [],
            o;
        for (o = 0; o < r; o++) s[o] = new i(n.eq(o), t);
        return s[0]
    }
})(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    e.extend(e.switchable.Config, {
        duration: 500,
        easing: "ease"
            f = {},
            l, c;
            isAnimated: !1,
            run: function() {
                if (a.isAnimated) return;
                var r, i = [];
                for (r in n) i.push(r);
                if (l) f[l + "Property"] = i.join(", ") || "all", f[l + "Duration"] = s + "ms", f[l + "TimingFunction"] = o, t.css(e.extend(n, f)), c = setTimeout(function() {
                    a._clearCss(), a._complete()
                }, s);
                else {
                    var u = /cubic-bezier\(([\s\d.,]+)\)/,
                        h = o.match(u),
                        p = e.switchable.TimingFn[o];
                    t.animate(n, s, o, function() {
                        a._complete()
                    })
                }
                return a.isAnimated = !0, a
            },
            stop: function(e) {
                if (!a.isAnimated) return;
                return l ? (clearTimeout(c), c = r, e && (a._clearCss(), a._complete())) : t.stop(!1, e), a.isAnimated = !1, a
            },
            _complete: function() {
                e.isFunction(u) && u()
            },
            _clearCss: function() {
                f[l + "Property"] = "none", t.css(f)
            }
        }), a.run()
    };
    var i = function() {
        var e = n.documentElement,
            t = ["Webkit", "Moz"],
            i = "transition",
            s = "",
            o;
        if (e.style[i] !== r) s = i;
        else
            for (o = 0; o < 2; o++)
                if (e.style[i = t[o] + "Transition"] !== r) {
                    s = i;
                    break
                } return s
    }
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    var i = function(e) {
            return "cubic-bezier(" + e + ")"
        },
        s = function(e) {
            var t = [],
                n = 101,
                r;
            for (r = 0; r <= n; r++) t[r] = e.call(null, r / n);
            return function(e) {
                if (e === 1) return t[n];
                var r = n * e,
                    i = Math.floor(r),
                    s = t[i],
                    o = t[i + 1];
                return s + (o - s) * (r - i)
            }
        },
        o = function(e, t, n, r, i, s) {
            function h(e) {
                return ((o * e + u) * e + a) * e
            }

            function p(e) {
                return ((f * e + l) * e + c) * e
            }

            function d(e) {
                return (3 * o * e + 2 * u) * e + a
            }

            function v(e) {
                return 1 / (200 * e)
            }

            function m(e, t) {
                return p(g(e, t))
            }

            function g(e, t) {
                function a(e) {
                    return e >= 0 ? e : 0 - e
                }
                var n, r, i, s, o, u;
                for (i = e, u = 0; u < 8; u++) {
                    s = h(i) - e;
                    if (a(s) < t) return i;
                    o = d(i);
                    if (a(o) < 1e-6) break;
                    i -= s / o
                }
                n = 0, r = 1, i = e;
                if (i < n) return n;
                if (i > r) return r;
                while (n < r) {
                    s = h(i);
                    if (a(s - e) < t) return i;
                    e > s ? n = i : r = i, i = (r - n) * .5 + n
                }
                return i
            }
            var o, u, a, f, l, c;
            return o = u = a = f = l = c = 0, a = 3 * t, u = 3 * (r - t) - a, o = 1 - a - u, c = 3 * n, l = 3 * (i - n) - c, f = 1 - c - l, m(e, v(s))
        };
        ease: i(".25, .1, .25, 1"),
        linear: i("0, 0, 1, 1"),
        "ease-in": i(".42, 0, 1, 1"),
        "ease-out": i("0, 0, .58, 1"),
        "ease-in-out": i(".42, 0, .58, 1")
        var r, u, a = 0,
            f;
            return o(e, n[0], n[1], n[2], n[3], 5)
            return f.call(null, e)
        })), r
    }
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
            s = i.config,
            o = i.panels,
            u = o.slice(t, t + 1),
            a = o.slice(n, n + 1),
            f = function() {
                a.css({
                    opacity: 1
                })
            },
            l = function() {
                a.css({
                    zIndex: i.length
                }), u.css({
                    zIndex: 1
                }), i._anim = r
            };
        i._anim && i._anim.stop(!0), f(), i._anim = new e.switchable.Animate(u, {
            opacity: 0
        }, s.duration, s.easing, l)
    }, e.switchable.Plugins.push({
        name: "fade effect",
        init: function(e) {
            var t = e.config,
                n = e.panels,
                r = e.index,
                i = n.slice(r, r + 1);
            t.effect.toLowerCase() === "fade" && (n.css({
                position: "absolute",
                top: 0,
                left: 0
            }), n.not(i).css({
                opacity: 0,
                zIndex: 1
            }), i.css({
                opacity: 1,
                zIndex: e.length
            }))
        },
        destroy: function(e) {
            e._anim && e._anim.stop(!0)
        }
    })
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    var i = "position",
        s = "absolute",
        o = "relative";
    e.extend(e.switchable.Config, {
        horiz: !0
            s = i.config,
            o = i._data,
            u = t === 0 && n === o.max,
            a = (u || t === o.max && n === 0) && i._circle,
            f = {},
            l = function() {
                f[o.prop] = a ? i._adjustPosition(u) : -o.size * n
            },
            c = function() {
                a && i._resetPosition(u), i._anim = r
            };
        i._anim && i._anim.stop(!0), setTimeout(function() {
            l(), i._anim = new e.switchable.Animate(o.wrap, f, s.duration, s.easing, c)
        }, 0)
    }, e.switchable.Plugins.push({
        name: "scroll effect",
        init: function(t) {
            var n = t.config,
                u = t.panels,
                a = u.eq(0).outerWidth(!0),
                f = u.eq(0).outerHeight(!0),
                l = {},
                    wrap: u.parent(),
                    max: t.length - 1,
                    prop: n.horiz ? "left" : "top",
                    size: n.horiz ? a : f
                };
            if (n.effect.toLowerCase() !== "scroll") return;
                _adjustPosition: function(e) {
                    var n = e ? c.max : 0;
                    return l[i] = o, l[c.prop] = (e ? -1 : 1) * c.size * t.length, u.slice(n, n + 1).css(l), e ? c.size : -c.size * t.length
                },
                _resetPosition: function(e) {
                    var t = e ? c.max : 0;
                    l[i] = "", l[c.prop] = "", u.slice(t, t + 1).css(l), l[i] = r, l[c.prop] = e ? -c.size * c.max : 0, c.wrap.css(l)
                }
            })
        },
        destroy: function(e) {
            e._anim && e._anim.stop(!0)
        }
    })
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    e.extend(e.switchable.Config, {
        autoplay: !1,
        interval: 3e3,
        pauseOnHover: !0,
        isBackward: !1
    }), e.switchable.Plugins.push({
        name: "autoplay",
        init: function(t) {
            var n = t.config,
                i = !1,
                s, o, u, a = function() {
                    u = t.willTo();
                    if (u === !1) {
                        t._cancelTimers();
                        return
                    }
                },
                f = function() {
                    var e = n.duration || 0;
                    o = setInterval(function() {
                        a()
                    }, n.interval + e)
                },
                l = function(e, r) {
                    if (!n.loop && n.isBackward && t.index === 0) return;
                    if (!n.loop && !n.isBackward && t.index === t.length - 1) return;
                    var i = 1;
                };
            if (!n.autoplay || t.length <= 1) return;
            l(r, t.index), n.pauseOnHover && t.panels.on("mouseenter.switchAutoplay", function() {
                t._pause()
            }).on("mouseleave.switchAutoplay", function() {
                i || t._play()
            }), e(t).on("switch", l), e.extend(t, {
                _play: function() {
                        a(), f()
                    }, n.interval)
                },
                _pause: function() {
                },
                _cancelTimers: function() {
                    s && (clearTimeout(s), s = r), o && (clearInterval(o), o = r)
                },
                play: function() {
                    return t._play(), i = !1, t
                },
                pause: function() {
                    return t._pause(), i = !0, t
                }
            }), t._play()
        },
        destroy: function(e) {
            if (!e.config.autoplay || e.length <= 1) return;
            e._pause(), e.panels.off(".switchAutoplay")
        }
    })
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    e.extend(e.switchable.Config, {
        triggers: ".slide-pagination a",
        currentTrigger: "active",
        triggerType: "hover",
        delay: 100
    }), e.switchable.Plugins.push({
        name: "trigger",
        init: function(t) {
            var n = t.config,
                i = e(t.root),
                s, o, u = i.find(n.triggers).length;
            if (!u) return;
            while (u < t.length) i.find(n.triggers).slice(0, 1).clone().insertAfter(i.find(n.triggers).last()), u = i.find(n.triggers).length;
                n.preventDefault(), s = e(this).index(), t._cancelDelayTimer(), t.switchTo(s)
            }), n.triggerType === "hover" && t.triggers.on("mouseenter.switchTrigger", function() {
                    t.switchTo(s)
                }, n.delay)
            }).on("mouseleave.switchTrigger", function() {
                t._cancelDelayTimer()
            }), e(t).on("switch", function(e, n) {
                t._switchTrigger(n)
            }), n.autoplay && n.pauseOnHover && t.triggers.on("mouseenter.switchTrigger", function() {
                o = t.paused, t._pause()
            }).on("mouseleave.switchTrigger", function() {
                o || t._play()
            }), e.extend(t, {
                _cancelDelayTimer: function() {
                },
                _switchTrigger: function(e) {
                    t.triggers.removeClass(n.currentTrigger).eq(e).addClass(n.currentTrigger)
                }
            })
        },
        destroy: function(t) {
            e(t.root).find(t.config.triggers).length && (t.triggers.off("click.switchTrigger"), t.triggers.off(".switchTrigger"))
        }
    })
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    e.extend(e.switchable.Config, {
        prev: ".prev",
        next: ".next",
        disabledClass: "disabled",
        respondinAnimating: !0
    }), e.switchable.Plugins.push({
        name: "carousel",
        init: function(t) {
            var n = t.config,
                r = ["prev", "next"],
                i, s, o = 0,
                u, a, f = function(e, r) {
                    if (!n.loop && r && e === 0) return;
                    if (!n.loop && !r && e === t.length - 1) return;
                    var i = 1;
                };
            if (!e(t.root).find(n.prev).length && !e(t.root).find(n.next).length) return;
            for (; o < 2; o++) {
                i = r[o], s = e(t.root).find(n[i]);
                if (!s.length) continue;
            }
            e(t.root).find(n.prev).on("click.switchCarousel", function(r) {
                r.preventDefault();
                if (!e(this).hasClass(n.disabledClass)) {
                    if (t._anim) {
                        if (!n.respondinAnimating) return;
                        t._anim.stop(!0)
                    }
                }
            }), e(t.root).find(n.next).on("click.switchCarousel", function(r) {
                r.preventDefault();
                if (!e(this).hasClass(n.disabledClass)) {
                    if (t._anim) {
                        if (!n.respondinAnimating) return;
                        t._anim.stop(!0)
                    }
                }
            }), n.autoplay && n.pauseOnHover && e(t.root).find(n.prev + ", " + n.next).on("mouseenter.switchCarousel", function() {
                a = t.paused, t._pause()
            }).on("mouseleave.switchCarousel", function() {
                a || t._play()
            }), e(t).on("switch", function() {
            })
        },
        destroy: function(t) {
            e(t.root).find(t.config.prev).length && e(t.root).find(t.config.prev).off(".switchCarousel"), e(t.root).find(t.config.next).length && e(t.root).find(t.config.next).off(".switchCarousel")
        }
    })
}(jQuery, window, document),
function(e, t, n, r) {
    if (!e.switchable) return;
    e.extend(e.switchable.Config, {
        indexOffset: 1,
        numFormat: "[index]/[length]",
        switchNum: ".slide-text"
    }), e.switchable.Plugins.push({
        name: "switchnum",
        init: function(t) {
            var n = t.config,
                r = function(e, t) {
                    var r = n.numFormat.replace(/\[index\]/ig, e + n.indexOffset);
                    return r.replace(/\[length\]/ig, t)
                };
            if (!n.switchNum && e(t.root).find(n.switchNum).length) return;
            e(t.root).find(n.switchNum).html(r(n.initIndex, t.length)), e(t).on("switch", function() {
                e(t.root).find(n.switchNum).html(r(t.index, t.length))
            })
        }
    })
}(jQuery, window, document),
function(e, t, n, r) {
    e.extend(e.switchable.Config, {
        lazyloadCls: "switchlazyload"
    }), e.switchable.Plugins.push({
        name: "lazyload",
        init: function(t) {
            var n = t.config.lazyloadCls,
                r = function(e) {
                    if (e.hasClass(n)) {
                        var t = e.val().trim();
                        return e.replaceWith(t), !0
                    }
                    return !1
                };
            e(t).on("beforeSwitch", function() {
                e(t.panels).each(function(t, i) {
                    r(e(i)) || r(e(i).find("." + n))
                })
            })
        }
    })
}(jQuery, window, document),
function(e) {
    e(".j-switchable").each(function(t, n) {
        var r = e(n).data("slide") || {},
            i = e(n).switchable(r);
        e.extend(n, {
            switchable: i
        })
    })
}(jQuery);