(function(e) {
    function p() {
        var e = Array.prototype.slice.call(arguments),
            t = e.length;
        while (t > -1) typeof e[t - 1] == "number" && clearTimeout(e[t - 1]), t--
    }

    function d(t, n) {
        var r = t.data("slide") || {};
        e.extend(r, n);
        var i = t.switchable(r);
        return e.extend(t, {
            switchable: i
        }), i
    }

    function v() {
            r = n.split(";"),
            i = t == "Microsoft Internet Explorer" ? i = r[1].replace(/[ ]/g, "") : "other",
            s = 1920,
            o = 560,
            u = e(window).width(),
            a;
        if (u > 1400) {
            var f = s,
                l = Math.min(f, u);
            a = l / s * o, e("#focus-slide,.focus-slide .switchable,.focus-block").width(l), e("#focus-slide,.focus-block").height(a + 108), e(".focus-slide .switchable,.focus-slide .switchable>div").height(a), e("#btnsFirst").removeAttr("style"), i == "MSIE6.0" && e(".focus-slide .items li img").width(l)
        } else a = 1340 / s * o, e("#focus-slide,.focus-slide .switchable,.focus-block").width("1340"), e("#focus-slide,.focus-block").height(a + 108), e(".focus-slide .switchable,.focus-slide .switchable>div").height(a), e("#btnsFirst").css("top", "56%"), i == "MSIE6.0" && e(".focus-slide .items li img").width(1340)
    }

    function m() {
        i = d(e(".j-tabview"), {
            onSwitch: function(e) {
                s = e.target.index, p(f, l, c), e.target.index == 0 ? (h == "prev" ? (t.switchTo(t.length - 1), h = "next") : t.switchTo(o), n.switchTo(0).pause(), r.switchTo(0).pause(), t.play()) : e.target.index == 1 ? (h == "prev" ? (n.switchTo(n.length - 1), h = "next") : n.switchTo(u), t.switchTo(0).pause(), r.switchTo(0).pause(), n.play()) : e.target.index == 2 && (h == "prev" ? (r.switchTo(r.length - 1), h = "next") : r.switchTo(a), t.switchTo(0).pause(), n.switchTo(0).pause(), r.play())
            }
        })
    }

    function b() {
    }
    var t, n, r, i, s = 0,
        o = 0,
        u = 0,
        a = 0,
        f, l, c, h;
    v(), e("#focus-slide .tabs").show(), t = d(e(".j-focus-a"), {
        onSwitch: function(e) {
            o = e.target.index, e.target.index == e.target.length - 1 && (e.target.pause(), f = setTimeout(function() {
                i.switchTo(1)
            }, e.target.config.interval))
        }
    }), n = d(e(".j-focus-b"), {
        onSwitch: function(e) {
            u = e.target.index, e.target.index == e.target.length - 1 && (e.target.pause(), l = setTimeout(function() {
                i.switchTo(2)
            }, e.target.config.interval))
        }
    }), r = d(e(".j-focus-c"), {
        onSwitch: function(e) {
            a = e.target.index, e.target.index == e.target.length - 1 && (e.target.pause(), c = setTimeout(function() {
                i.switchTo(0)
            }, e.target.config.interval))
        }
    }), n.pause(), r.pause(), m(), e(".j-tabview").delegate(".btn-next", "click", function(e) {
        e.preventDefault();
        var o, u;
        h = "next", p(f, l, c), s == 0 ? (o = t, u = 1) : s == 1 ? (o = n, u = 2) : s == 2 && (o = r, u = 0);
        if (o._nextIndex == 0) return o.pause(), i.switchTo(u), !1;
        o.switchTo(o._nextIndex), o.pause()
    }), e(".j-tabview").delegate(".btn-prev", "click", function(e) {
        e.preventDefault();
        var o, u;
        h = "prev", p(f, l, c), s == 0 ? (o = t, u = 2) : s == 1 ? (o = n, u = 0) : s == 2 && (o = r, u = 1);
        var a = o.index;
        if (o.index == 0) return o.pause(), i.switchTo(u), !1;
        o.switchTo(o.index - 1), o.pause()
    });
    var g;
    e(".j-tabview").on("mouseenter", function(e) {
        s == 0 ? g = t : s == 1 ? g = n : s == 2 && (g = r), g.pause()
    }).on("mouseleave", function(e) {
        g.play()
    });
    var y = e("#focus-slide");
    y.on("mouseenter", function(t) {
        e(this).addClass("mouseenter")
    }).on("mouseleave", function() {
        e(this).removeClass("mouseenter")
    }), e(window).resize(b)
})(jQuery);