(function() {
        poll: function(e, t, n, r, i) {
            if (n <= 0) {
                r && r();
                return
            }
            e() !== !1 ? setTimeout(function() {
            }, t) : i && i()
        },
        await: function(e, t, n, r, i) {
                return e() ? (t(), !1) : !0
            }, r, i, n)
        },
        jsonp: function() {
            var e = {},
                t = 0,
                n = 6e5,
                r = {},
                i = function(s, o, u, a) {
                        jsonp: "_callback",
                        timeout: 3e4,
                        threshold: n
                    var f;
                    f = e[s] = e[s] || a.cb || "__jsonp" + t++ + "__", r[f] = {
                        url: s,
                        startTime: +(new Date)
                        var e = [],
                            t = function(t, n) {
                                r[f].endTime = +(new Date), i.fire("resourceLoaded", {
                                    data: r[f]
                                });
                                var s = e.shift();
                                s && s(t, n)
                            };
                        return t.add = function(t) {
                            e.push(t)
                        }, t
                    }());
                    var l = setTimeout(function() {
                            status: "error",
                            reason: "timeout"
                        })
                    }, a.timeout);
                        clearTimeout(l), u && (t = t || {
                            status: "ok"
                        }, u(e, t))
                    }), qload({
                        path: s,
                        type: "js",
                        force: !0
                };
            return i.getMonitorData = function() {
                return r
            }, i
        }(),
        encodeURIJson: function(e) {
            var t = [];
            for (var n in e) {
                if (e[n] == null) continue;
                if (e[n] instanceof Array)
                    for (var r = 0; r < e[n].length; r++) t.push(encodeURIComponent(n) + "[]=" + encodeURIComponent(e[n][r]));
                else t.push(encodeURIComponent(n) + "=" + encodeURIComponent(e[n]))
            }
            return t.join("&")
        },
        mix: function(e, t, n) {
                return e[r] || r in e ? t : n
                return t
            });
            return e
        },
        createEvents: function(e) {
            var t = {},
            return n(!0, e, {
                on: function(e, n) {
                    t[e] = t[e] || [];
                    if (t[e].indexOf(n) > -1) return;
                    return t[e].push(n), !0
                },
                off: function(e, n) {
                    t[e] = t[e] || [];
                    if (n) {
                        var r = t[e].indexOf(n);
                        if (r < 0) return !1;
                        t[e].splice(r, 1)
                    } else t[e] = [];
                    return !0
                },
                fire: function(r, i) {
                        type: r,
                        target: e,
                        preventDefault: function() {
                        }
                    });
                    var s = t[r] || [];
                    for (var o = 0; o < s.length; o++) s[o](i);
                    return i.returnValue !== !1
                }
        }
        getRaw: function(e) {
            var t = new RegExp("(^| )" + e + "=([^;]*)(;|$)"),
            return n ? n[2] || null : null
        },
        get: function(e) {
            return "string" == typeof t ? (t = decodeURIComponent(t), t) : null
        },
        setRaw: function(e, t, n) {
            var r = n.expires;
        },
        set: function(e, t, n) {
        },
        remove: function(e, t) {
        }
})();